"""Ground-truth tests for the `softzone` variant: FAST_SoftZone + SoftHead.

`softzone` is the user's own proposal -- "give every electrode in every region its own
adaptive weight" -- reduced to the one form of it that is a modelling change and not a
retraining trick: a learnable soft channel->zone assignment in place of the hard
anatomical one. `spatial` v1 is the precedent for skipping this file: an arm that
silently evaluates a different model scores -0.26 and burns two hours before anyone
learns why. `spatial` v2 matched its `spatial` v1 predecessor to within noise, so the
tests would not have caught THAT bug -- but the failure modes here are different and
invisible to a shape check:

  * `_build_softzone` constructs a real `Head` and throws it away. `Head` is resolved
    from the FAST module globals, so patching the global is the only way to swap it in
    without drawing a second set of values from the global torch RNG. If that patch
    silently failed, or if SoftHead consumed a different number of RNG draws than Head,
    then every parameter built AFTER the head would differ from base while the model
    still trains to a plausible score. Since `seed_all(42)` runs ONCE before the fold
    loop, fold 1 onward would initialise from the wrong RNG state and the arm would be
    measuring an initialisation difference, not the soft assignment. The `param_report`
    comment says the two defects are deliberately not fixed in one experiment; this is the
    same class of silent-shift bug and it gets a direct test (RNG PARITY below).

  * The slot->zone MAPPING is positional. `SoftHead.forward` walks `self.encoders.items()`
    and advances an offset into the columns of S, while `__init__` built the slot list by
    walking `zone_dict.values()`. Those two orders agreeing is an implementation detail of
    `nn.ModuleDict` (insertion order) that nothing in the code states. If they ever
    disagree, each zone silently receives a mixture of SOME OTHER zone's electrodes --
    correctly shaped, finite, and meaningless. Tested against `index_dict` directly.

  * cnn2's shape has to stay the anatomical one. The variant's whole claim is that it
    changes WHICH electrodes a zone sees, not HOW MANY; if a zone were handed 64 virtual
    channels, the parameter count would jump by ~100k and the arm would be a capacity
    ablation. Asserted as an exact +4,097.

  * `temp` is a parameter but nothing forces it to be USED. If the learnable temperature
    were dropped from the softmax, the assignment would still be soft, still readable, and
    still train -- just frozen at the initial sharpness. Checked by changing it.

Run on the training box (CPU only, so it does not disturb a run on the GPU):
    CUDA_VISIBLE_DEVICES= python test_softzone.py
"""

import os
import sys

import torch
from transformers import PretrainedConfig

sys.path.insert(0, "/root/FAST")
os.chdir("/root/FAST")

from BCIC2020Track3_preprocess import Electrodes, Zones
from FAST import FAST
from fast_zones import FAST_SoftZone, SoftHead, build, param_report

# Measured on this box, and pinned because the riemann file already showed what a
# mis-derived constant costs: 2,688 branch params were once reported as 4,736 by
# conflating a component with a total. These are read off `param_report`, not derived.
BASE_TOTAL = 191781
BASE_HEAD = 148992
BASE_TRANSFORMER = 34176
BASE_INPUT_LAYER = 8224
BASE_N_TOKENS = 6

# 64 slots x 64 channels of assignment logits, plus the scalar temperature.
ASSIGN_PARAMS = len(Electrodes) * sum(len(c) for c in Zones.values()) + 1


def cfg(variant):
    return PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1, variant=variant,
    )


def main():
    torch.manual_seed(0)
    x = torch.randn(2, len(Electrodes), 800)

    # ---- 1. parameter accounting -------------------------------------------------
    rep = param_report(cfg("base"))
    b, s = rep["base"], rep["softzone"]
    print("  base     total %6d  head %6d  tokens %d" % (b["total"], b["head"], b["n_tokens"]))
    print("  softzone total %6d  head %6d  tokens %d" % (s["total"], s["head"], s["n_tokens"]))

    assert b["total"] == BASE_TOTAL, "base moved: %d" % b["total"]
    assert b["head"] == BASE_HEAD, "base head moved: %d" % b["head"]
    assert ASSIGN_PARAMS == 4097, ASSIGN_PARAMS          # 64*64 + 1
    assert s["total"] == BASE_TOTAL + ASSIGN_PARAMS, \
        "softzone total is %d, expected %d" % (s["total"], BASE_TOTAL + ASSIGN_PARAMS)
    assert s["head"] == BASE_HEAD + ASSIGN_PARAMS, \
        "softzone head is %d, expected %d" % (s["head"], BASE_HEAD + ASSIGN_PARAMS)

    # The change is the assignment and nothing else. In particular the tokenisation
    # must NOT move: softzone varies the spatial assignment alone, so a token-count
    # change here would mean the two defects got fixed in one experiment.
    for key, want in (("transformer", BASE_TRANSFORMER), ("input_layer", BASE_INPUT_LAYER),
                      ("pos", b["pos"])):
        assert s[key] == b[key], "softzone changed %s: %d vs %d" % (key, s[key], b[key])
        assert b[key] == want, "base %s moved: %d" % (key, b[key])
    assert s["n_tokens"] == BASE_N_TOKENS, "softzone changed the token count: %d" % s["n_tokens"]
    print("  ok  +%d params, all of it in the head; transformer/input_layer/pos/tokens identical"
          % (s["total"] - b["total"]))

    # ---- 2. slot -> zone mapping (the positional assumption) ----------------------
    ms = build(cfg("softzone"))
    assert isinstance(ms, FAST_SoftZone)
    assert isinstance(ms.head, SoftHead)

    slots = ms.head.slot_zones
    assert len(slots) == len(Electrodes) == 64, len(slots)

    # encoders iteration order is what forward() offsets into; it must equal the order
    # the slots were built in, and that order must equal zone_dict's own order.
    order_enc = list(ms.head.encoders.keys())
    order_zd = list(Zones.keys())
    assert order_enc == order_zd, "encoder order %s != zone_dict order %s" % (order_enc, order_zd)

    # softmax rows are CHANNELS, columns are SLOTS: each column is a distribution over
    # electrodes, so each slot's distribution must be supported on its own zone.
    S = ms.head.assignment()
    assert S.shape == (len(Electrodes), len(slots)), S.shape
    assert torch.allclose(S.sum(dim=0), torch.ones(len(slots)), atol=1e-6), "columns do not sum to 1"
    assert (S >= 0).all(), "negative assignment weight"

    off = 0
    for area in order_enc:
        n = len(ms.head.index_dict[area])
        blk = S[:, off:off + n]
        own = ms.head.index_dict[area].tolist()
        assert blk.argmax(dim=0).tolist() == own, \
            "zone %s slots are peaked on the wrong electrodes: %s vs %s" % (
                area, blk.argmax(dim=0).tolist(), own)
        assert set(slots[off:off + n]) == {area}, "slot_zones misaligned with encoders"
        off += n
    assert off == len(slots), "slot offsets do not cover every slot"
    print("  ok  64 slots, one per anatomical electrode, each peaked on its own channel")

    # how sharp is the initialisation, actually? The docstring says init is "close to
    # the released behaviour"; measured rather than assumed.
    diag = torch.stack([S[c, s] for s, c in enumerate(
        [Electrodes.index(ch) for area in order_zd for ch in Zones[area]])])
    bleed = (S.sum(dim=0) - diag).max().item()
    print("      init: own-channel weight %.4f (min %.4f), max off-channel %.4f"
          % (diag.mean(), diag.min(), bleed))
    assert diag.min() > 0.80, "init is not close to the hard partition: %.4f" % diag.min()

    # ---- 3. RNG PARITY with base (the `_build_softzone` trap) --------------------
    torch.manual_seed(1234)
    mb = build(cfg("base"))
    torch.manual_seed(1234)
    ms2 = build(cfg("softzone"))
    pb, ps = dict(mb.named_parameters()), dict(ms2.named_parameters())
    missing = sorted(set(pb) - set(ps))
    assert not missing, "softzone is missing shared parameters: %s" % missing
    shifted = [n for n in pb if not torch.equal(pb[n], ps[n])]
    assert not shifted, ("building softzone shifted the RNG stream for %d shared "
                         "parameters, e.g. %s -- _build_softzone is consuming draws it "
                         "should not, so every fold after the first would initialise "
                         "from the wrong state" % (len(shifted), shifted[:3]))
    extra = sorted(set(ps) - set(pb))
    assert extra == ["head.assign_logit", "head.temp"], "unexpected extra params: %s" % extra
    assert ps["head.assign_logit"].shape == (64, 64), ps["head.assign_logit"].shape
    assert ps["head.temp"].numel() == 1, ps["head.temp"].shape
    print("  ok  %d shared parameters bit-identical to base under the same seed" % len(pb))
    print("      (the head swap consumed exactly the same RNG draws)")

    # ---- 4. the one-hot limit reproduces base EXACTLY ---------------------------
    # Force S to a hard one-hot on each slot's own electrode and push temp up so the
    # softmax underflows to exact 0/1 in float32. If the einsum/offset machinery is not
    # exactly `x[:, index_dict[area]]`, this is where it shows.
    ms2.head.load_state_dict(mb.head.state_dict(), strict=False)
    A0 = ms2.head.assign_logit.detach().clone()      # restored after this test, because
    T0 = ms2.head.temp.detach().clone()              # test 5 needs a SOFT model and it
    with torch.no_grad():                            # is the same object

        A = torch.zeros_like(ms2.head.assign_logit)
        for s_i, c_i in enumerate([Electrodes.index(ch) for area in order_zd for ch in Zones[area]]):
            A[c_i, s_i] = 1.0
        ms2.head.assign_logit.copy_(A)
        ms2.head.temp.fill_(200.0)
        S_hard = ms2.head.assignment()
    assert torch.equal(S_hard, torch.nn.functional.one_hot(
        torch.tensor([Electrodes.index(ch) for area in order_zd for ch in Zones[area]]),
        len(Electrodes)).T.to(S_hard.dtype)), "temp=200 did not produce an exact one-hot S"

    with torch.no_grad():
        fb, fs = mb.head(x), ms2.head(x)
    # Head.forward is `stack([...], dim=1)`, so the head output is (B, Z, F) with the
    # ZONE on axis 1. (test_zones.py compared forward_head, which is a different call
    # and carries the extra 5-wide axis; comparing the heads directly is the tighter
    # test, since Head is the only thing softzone replaces.)
    assert fb.shape == fs.shape == (2, len(Zones), 32), (fb.shape, fs.shape)
    dmax = (fb - fs).abs().max().item()
    assert dmax == 0.0, \
        "hard-limit softzone differs from base by %g -- the slot/offset path is not " \
        "equivalent to x[:, index_dict[area]]" % dmax
    print("  ok  one-hot limit of SoftHead is bit-identical to Head (%s)" % (tuple(fs.shape),))

    # put the soft assignment back, and prove it is soft again before relying on it
    with torch.no_grad():
        ms2.head.assign_logit.copy_(A0)
        ms2.head.temp.copy_(T0)
    assert not torch.equal(ms2.head.assignment(), S_hard), "ms2 was left in the hard limit"

    # ---- 5. the zone boundary is genuinely broken open --------------------------
    # This is the variant's entire claim. In base, cnn2 convolves over channels WITHIN
    # a zone, so no other zone's encoder can see the perturbed electrode at all. In
    # softzone every other zone has a nonzero weight on it, so every other zone moves.
    zone_a, zone_b = "Pre-frontal", "Occipital"
    ia, ib = list(Zones).index(zone_a), list(Zones).index(zone_b)
    ch = Electrodes.index(Zones[zone_b][0])

    torch.manual_seed(7)
    xb = x.clone()
    xb[:, ch] = xb[:, ch] * 2.0 + torch.randn(xb.shape[2])   # multiplicative: a constant
    # would be invisible to any mean-removing front end, which is the trap test_riemann hit.

    with torch.no_grad():
        base_delta = (mb.head(x) - mb.head(xb)).abs()
        soft_delta = (ms2.head(x) - ms2.head(xb)).abs()

    base_other = base_delta[:, ia].max().item()
    soft_other = soft_delta[:, ia].max().item()
    assert base_delta[:, ib].max().item() > 1e-6, "perturbation had no effect at all"
    assert base_other == 0.0, \
        "base leaked %.3g from %s into %s -- the hard partition is not hard" % (
            base_other, zone_b, zone_a)
    assert soft_other > 1e-6, \
        "softzone did NOT let %s see channel %s of %s (%.3g): the soft assignment is " \
        "not wired into forward" % (zone_a, Electrodes[ch], zone_b, soft_other)
    print("  ok  %s cannot see channel %s of %s in base (exactly 0.0), and does in "
          "softzone (%.3g)" % (zone_a, Electrodes[ch], zone_b, soft_other))

    # ---- 6. temp is live, and the assignment is trainable ------------------------
    torch.manual_seed(3)
    ms3 = build(cfg("softzone"))
    with torch.no_grad():
        before = ms3.head(x).clone()
        ms3.head.temp.mul_(0.25)          # flatter assignment -> different mixture
        after = ms3.head(x)
    temp_shift = (after - before).abs().max().item()
    assert not torch.equal(before, after), \
        "changing temp did not change the head output: the learnable temperature is unused"
    print("  ok  temp is used: temp x0.25 changes the head output by %.3g" % temp_shift)

    ms3.zero_grad()
    out = ms3(x)
    assert out.shape == (2, 5), out.shape
    assert torch.isfinite(out).all(), "non-finite logits"
    out.sum().backward()
    for nm in ("assign_logit", "temp"):
        g = getattr(ms3.head, nm).grad
        assert g is not None, "%s got no gradient" % nm
        assert torch.isfinite(g).all(), "%s gradient is non-finite" % nm
        assert g.abs().sum() > 0, "%s gradient is identically zero" % nm
    print("  ok  assign_logit (64,64) and temp both receive finite non-zero gradient")

    # ---- 7. assignment() is a detached, honest readout ---------------------------
    a = ms3.head.assignment()
    assert not a.requires_grad, "assignment() is not detached"
    ref = torch.softmax(ms3.head.assign_logit * ms3.head.temp, dim=0)
    assert torch.allclose(a, ref, atol=1e-6), "assignment() does not match the forward path"
    print("  ok  assignment() is detached and matches the softmax actually used in forward")

    # ---- 8. init is soft, not accidentally identical to base --------------------
    torch.manual_seed(11)
    mb4 = build(cfg("base"))
    torch.manual_seed(11)
    ms4 = build(cfg("softzone"))
    ms4.head.load_state_dict(mb4.head.state_dict(), strict=False)
    with torch.no_grad():
        d = (mb4.head(x) - ms4.head(x)).abs().max().item()
    assert d > 1e-6, "softzone at init is bit-identical to base: the soft path is inert"
    print("  ok  at init softzone differs from base by %.3g (live, and not a rewrite)" % d)

    # ---- 9. forward_mode handling is inherited, not silently altered -------------
    # Unlike FAST_ZoneAttn (which had to override forward and therefore had to refuse
    # the modes it could not honour), softzone changes only Head -- and Head has no
    # forward_mode at all. So the right test is not "does it raise" but "does it still
    # behave exactly as base does", whatever that behaviour is.
    def mode_outcome(m, mode):
        try:
            m(x, forward_mode=mode)
            return "ok"
        except Exception as e:                       # the exception TYPE is the readout
            return type(e).__name__

    for mode in ("default", "train_head", "train_transformer"):
        got, want = mode_outcome(ms, mode), mode_outcome(mb, mode)
        assert got == want, \
            "softzone changed forward_mode=%r handling: %s vs base's %s" % (mode, got, want)
    print("  ok  default / train_head / train_transformer behave exactly as base")

    # ---- 10. build() dispatches on config.variant --------------------------------
    assert isinstance(build(cfg("base")), FAST)
    assert isinstance(build(cfg("softzone")), FAST_SoftZone)
    print("  ok  build() dispatches on config.variant")

    print("ALL_TESTS_PASSED")


if __name__ == "__main__":
    main()
