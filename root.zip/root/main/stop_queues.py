"""
Stop the running queue scripts and their python children, without killing anything else.

WHY NOT pkill. `pkill -f "<pattern>"` matches the invoking `bash -c` wrapper's own command
line whenever the pattern text also appears in the command that is doing the killing, so
the killer kills itself -- this has already cost us a run with rc=-1. Matching on the
parsed argv of each process instead of on a substring of a command line avoids that
entirely: the wrapper's argv is ['bash', '-c', 'cd /root/FAST && ...'], which is not equal
to ['bash', 'queue_lr.sh'].

Prints what it kills so the effect is visible rather than assumed. Partial results are
left on disk: zone_attn_probe.py skips any subject whose .npz already exists, so every
subject finished before the stop is kept and re-running the same tag resumes.
"""

import os
import signal

# Matched by prefix, not by an explicit list: a hardcoded list silently misses whatever
# queue was written most recently, which is exactly the one that needs stopping.
QUEUE_PREFIX = "queue_"
PROBE = "zone_attn_probe.py"


def argv_of(pid):
    try:
        raw = open("/proc/%d/cmdline" % pid, "rb").read()
    except (IOError, OSError):
        return None
    return [p.decode("utf-8", "replace") for p in raw.split(b"\0") if p]


def main():
    me = os.getpid()
    targets = []
    for entry in os.listdir("/proc"):
        if not entry.isdigit():
            continue
        pid = int(entry)
        if pid == me:
            continue
        av = argv_of(pid)
        if not av:
            continue
        # a queue script: argv is exactly ['bash', 'queue_<something>.sh']
        is_queue = len(av) == 2 and os.path.basename(av[0]) in ("bash", "sh") \
            and os.path.basename(av[1]).startswith(QUEUE_PREFIX)
        # a probe: argv[0] is the interpreter path, and the probe script is named
        is_probe = os.path.basename(av[0]).startswith("python") and \
            any(PROBE in a for a in av[1:])
        if is_queue or is_probe:
            targets.append((pid, av))

    if not targets:
        print("nothing to stop")
        return
    for pid, av in targets:
        print("stop pid %-7d %s" % (pid, " ".join(av)[:75]))
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError as e:
            print("   (already gone: %s)" % e)
    print("stopped %d process(es); partial .npz results are kept" % len(targets))


if __name__ == "__main__":
    main()
