"""
Cross-subject representational geometry, v2 -- with an estimator that can actually
answer the question, and a multiple-comparison correction.

WHY v1 FAILED, AND WHY THAT IS NOT A NEGATIVE RESULT. rsa_probe.py reported no
time point below p<0.01, but the number that matters is the CEILING:

    within-subject split-half RDM reliability : epoch mean +0.124
    cross-subject RDM correlation             : epoch mean +0.008

and a separate power calibration (15 subjects, 10 pairwise distances, 2000
permutations) established that the test detects cross-subject RDM correlation only
from about r >= 0.4 upward. A ceiling of 0.124 is far BELOW the detection threshold:
even a perfectly shared geometry could not have been detected. So v1 was not
evidence of absence, it was an unanswerable experiment, and reporting it as a null
finding would have been wrong.

Why the ceiling was 0.124: the RDM at a single time point is estimated from 35 trials
per class per half, and Euclidean distance in 64 dimensions from that few trials is
extremely unstable. Two standard, outcome-independent remedies:
  1. TIME-WINDOW averaging (half-width 10 downsampled samples = 200 ms). Single-
     sample ERP estimates are noisy; windowed averages are the norm in ERP work.
  2. PCA to 20 components before the distance. Euclidean distance in 64 dimensions
     with few trials is dominated by noise directions.
Both are applied to the ceiling and the observed measure IDENTICALLY, so the
comparison stays fair. Neither is chosen by looking at the outcome -- they are chosen
because the v1 ceiling was demonstrably too low to test anything.

THE STATISTICAL CORRECTION v1 LACKED. v1 tested 160 time points one at a time and
reported the smallest p, which under the null is expected to be ~1/161 = 0.006 -- so
a minimum p of 0.011 was entirely unremarkable and v1's "0/160 significant" was the
only honest reading of it. v2 instead permutes the MAXIMUM over time: for each of
N_PERM label shufflings it records max_t r(t), and the corrected p is the fraction of
those maxima reaching the observed maximum. This is a max-statistic permutation test
and it accounts for the 160 comparisons exactly.

The anterior/posterior control from v1 is kept: anterior k=8 AF7 AF8 Fp1 Fp2 F7 F8
FT9 FT10 are the artifact-prone, highest-amplitude channels; shared ocular artifact
would show up there and nowhere else.

Whatever comes out is reported as it comes out. If the ceiling rises and the observed
correlation does not follow, that is a real null. If the ceiling does not rise, the
conclusion is that this dataset cannot answer the question, and that is reported too.
"""

import os
import sys
import itertools
import numpy as np
import h5py

H5 = "Processed/BCIC2020Track3.h5"
OUT = "Results/RSA"
DS = 5
HALF = 10                  # window half-width, downsampled samples -> 200 ms
N_COMP = 20
N_PERM = 1000
FS = 250.0
PAIRS = list(itertools.combinations(range(5), 2))
ANTERIOR = ['AF7', 'AF8', 'Fp1', 'Fp2', 'F7', 'F8', 'FT9', 'FT10']


def mean_pair_r(Z):
    if Z.shape[0] < 2:
        return float('nan')
    Zc = Z - Z.mean(axis=1, keepdims=True)
    sd = Zc.std(axis=1, keepdims=True)
    sd[sd == 0] = 1e-12
    Zs = Zc / sd
    C = (Zs @ Zs.T) / Z.shape[1]
    return float(C[np.triu_indices(Z.shape[0], 1)].mean())


def class_means(x, y, n_cls=5):
    return np.stack([x[y == c].mean(axis=0) for c in range(n_cls)])


def smooth(M, half=HALF):
    """Boxcar over time, edge-replicated. M: (..., T)."""
    if half <= 0:
        return M
    k = 2 * half + 1
    pad = np.pad(M, [(0, 0)] * (M.ndim - 1) + [(half, half)], mode='edge')
    c = np.cumsum(pad, axis=-1)
    c = np.concatenate([np.zeros_like(c[..., :1]), c], axis=-1)
    return (c[..., k:] - c[..., :-k]) / k


def rdm_series(M):
    return np.stack([np.linalg.norm(M[i] - M[j], axis=0) for i, j in PAIRS])


def stratified_halves(y, rng):
    h1, h2 = [], []
    for c in np.unique(y):
        ix = rng.permutation(np.where(y == c)[0])
        k = len(ix) // 2
        h1 += ix[:k].tolist()
        h2 += ix[k:2 * k].tolist()
    return np.array(h1), np.array(h2)


def reduce_pca(x, n_comp=N_COMP):
    """x: (trials, ch, T) -> (trials, n_comp, T), PCA fit on flattened trials.

    n_comp is clamped to the channel count: the anterior control group has only 8
    channels, so asking for 20 components there made reduce_pca return an 8-column
    matrix and the caller's reshape blow up (ValueError: cannot reshape 448000 into
    (350,160,20)).
    """
    n, ch, T = x.shape
    n_comp = min(n_comp, ch)
    flat = x.transpose(0, 2, 1).reshape(n * T, ch)
    flat = flat - flat.mean(axis=0, keepdims=True)
    U, S, Vt = np.linalg.svd(flat, full_matrices=False)
    comp = Vt[:n_comp]                                    # (n_comp, ch)
    y = (flat @ comp.T).reshape(n, T, n_comp).transpose(0, 2, 1)
    return y


def main():
    os.makedirs(OUT, exist_ok=True)
    sys.path.insert(0, "/root/FAST")
    from BCIC2020Track3_preprocess import Electrodes
    idx = {e: i for i, e in enumerate(Electrodes)}
    ant = np.array([idx[e] for e in ANTERIOR])
    subsets = {"all": np.arange(len(Electrodes)), "anterior": ant,
               "posterior": np.array([i for i in range(len(Electrodes)) if i not in ant])}
    print("estimator: window +/-%d downsampled samples (%.0f ms), PCA to min(%d, ch)"
          % (HALF, HALF * DS / FS * 1000, N_COMP))
    print("correction: max-statistic permutation, %d perms" % N_PERM)
    print("")

    M = {k: [] for k in subsets}
    H = {k: [] for k in subsets}
    n_T = None
    with h5py.File(H5, "r") as f:
        for key in sorted(f.keys()):
            X = f[key]["X"][()].astype(np.float64)
            Y = f[key]["Y"][()]
            if Y.ndim > 1:
                Y = Y.argmax(1)
            mu = X.mean(axis=(0, 2), keepdims=True)
            sd = X.std(axis=(0, 2), keepdims=True)
            sd[sd < 1e-8] = 1.0
            X = ((X - mu) / sd)[:, :, ::DS]
            if n_T is None:
                n_T = X.shape[2]
            rng = np.random.RandomState(42)
            i1, i2 = stratified_halves(Y, rng)
            for name, ch in subsets.items():
                x = reduce_pca(X[:, ch, :])
                M[name].append(smooth(class_means(x, Y)))
                H[name].append(np.stack([smooth(rdm_series(class_means(x[i1], Y[i1]))),
                                         smooth(rdm_series(class_means(x[i2], Y[i2])))]))
            del X
            print("  %s ok" % key, flush=True)

    t_ms = np.arange(n_T) * DS / FS * 1000.0
    print("")
    print("=== CROSS-SUBJECT REPRESENTATIONAL CONSISTENCY, v2 ESTIMATOR ===")
    print("")

    rng = np.random.RandomState(0)
    for name in subsets:
        Ms = M[name]
        obs = np.array([mean_pair_r(np.stack([rdm_series(m)[:, t] for m in Ms]))
                        for t in range(n_T)])
        Hs = np.array(H[name])
        ceil = np.array([np.corrcoef(Hs[s, 0, :, t], Hs[s, 1, :, t])[0, 1]
                         for s in range(Hs.shape[0]) for t in range(n_T)]
                        ).reshape(Hs.shape[0], n_T).mean(axis=0)

        null = np.empty(N_PERM)
        null_series = np.empty((N_PERM, n_T))
        for p in range(N_PERM):
            Rp = np.array([rdm_series(m[rng.permutation(5)]) for m in Ms])
            s = np.array([mean_pair_r(Rp[:, :, t]) for t in range(n_T)])
            null_series[p] = s
            null[p] = s.max()
        obs_max = obs.max()
        p_corr = float((null >= obs_max).mean())
        peak = int(np.argmax(obs))

        print("--- %s (k=%d, %d PCA comps) ---" % (name, len(subsets[name]), N_COMP))
        print("  CEILING (within-subject split-half, same estimator):")
        print("      peak %.4f   epoch mean %.4f   at 220 ms %.4f"
              % (ceil.max(), ceil.mean(), ceil[peak]))
        print("  OBSERVED (cross-subject):")
        print("      peak r=%+.4f at %.0f ms   epoch mean %+.4f"
              % (obs[peak], t_ms[peak], obs.mean()))
        print("      peak is %.0f%% of the ceiling at that latency"
              % (100.0 * obs[peak] / ceil[peak] if ceil[peak] > 0 else float('nan')))
        print("      epoch mean is %.0f%% of the epoch-mean ceiling"
              % (100.0 * obs.mean() / ceil.mean() if ceil.mean() else float('nan')))
        print("  MAX-STATISTIC CORRECTED TEST:")
        print("      null of max_t r: mean %+.4f  sd %.4f  95th pct %+.4f"
              % (null.mean(), null.std(), np.percentile(null, 95)))
        print("      observed max %+.4f -> corrected p = %.4f  %s"
              % (obs_max, p_corr, "SIGNIFICANT" if p_corr < 0.05 else "not significant"))
        unc = (null_series >= obs).mean(axis=0)
        print("      (uncorrected per-point min p = %.4f at %.0f ms; %d points < 0.05)"
              % (unc.min(), t_ms[int(np.argmin(unc))], int((unc < 0.05).sum())))
        print("")

        np.savez("%s/v2_%s.npz" % (OUT, name), t_ms=t_ms, obs=obs, ceil=ceil,
                 null_max=null, p_corrected=p_corr)
    print("RSA2_DONE")


if __name__ == "__main__":
    main()
