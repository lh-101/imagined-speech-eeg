"""Paired per-subject comparison of each --harness exact arm against the released baseline.

The baseline is NOT a rerun. It is the stored released CSV (Results/FAST/<s>-Tune.csv, our
own run of the authors' script, reproduced byte-for-byte this session), dumped per fold to
released_ref.json. --harness exact was verified to reproduce that CSV exactly (subject 0:
0.5714 0.5286 0.6714 0.5429 0.6714; subjects 1 and 2 whole-subject 0.5400 and 0.6086).

Reports the PAIRED per-subject difference, never two means side by side, because the two
runs share the subject, the split and the seed -- the subject is a block, not a sample.

`placebo` is the control: byte-identical architecture to base, one extra torch.randn(1)
before construction. Whatever it shows is what the released protocol produces from a change
that is not an architectural one, i.e. the floor below which an arm's difference means
nothing.
"""

import json
import os
import numpy as np

RUN = "Results/ZA"
REF = "released_ref.json"
ARMS = ["nl", "w1std", "sharedtemp", "placebo", "spatial"]


def load(arm, subjects):
    out = {}
    for s in subjects:
        f = "%s/%d-%s-h8-ex.npz" % (RUN, s, arm)
        if os.path.exists(f):
            out[s] = float(np.load(f)["correct"].mean())
    return out


def signflip_p(d):
    """Exact sign-flip p for n <= 20, sampled above. Two-sided on the mean."""
    n = len(d)
    if n == 0:
        return float("nan")
    obs = abs(d.mean())
    if n <= 20:
        cnt = 0
        for m in range(2 ** n):
            sg = np.array([1.0 if (m >> i) & 1 else -1.0 for i in range(n)])
            if abs((d * sg).mean()) >= obs - 1e-12:
                cnt += 1
        return cnt / (2 ** n)
    rng = np.random.default_rng(0)
    cnt = sum(1 for _ in range(200000)
              if abs((d * rng.choice([-1.0, 1.0], n)).mean()) >= obs)
    return cnt / 200000


def main():
    ref = json.load(open(REF))
    by_subject = {s: float(np.mean(ref[str(s)])) for s in range(15)}
    print("released baseline (stored CSV): %.4f over 15 subjects" %
          np.mean([by_subject[s] for s in range(15)]))
    print("")
    print("%-11s %-4s %-9s %-9s %-9s %-7s %-7s %-6s %s" %
          ("arm", "n", "arm mean", "base mean", "paired d", "sem", "t", "p", "up"))
    for arm in ARMS:
        got = load(arm, range(15))
        if not got:
            print("%-11s (not run yet)" % arm)
            continue
        subs = sorted(got)
        a = np.array([got[s] for s in subs])
        b = np.array([by_subject[s] for s in subs])
        d = a - b
        m = float(d.mean())
        se = float(d.std(ddof=1) / np.sqrt(len(d))) if len(d) > 1 else float("nan")
        t = m / se if se == se and se > 0 else float("nan")
        print("%-11s %-4d %-9.4f %-9.4f %-+9.4f %-7.4f %-+7.2f %-6.3f %d/%d" %
              (arm, len(subs), a.mean(), b.mean(), m, se, t, signflip_p(d),
               int((d > 0).sum()), len(d)))
        print("              per-subject d: %s" %
              " ".join("%+.3f" % x for x in d))
        print("              subjects      : %s" %
              " ".join("%d" % s for s in subs))
    print("")
    print("Read p as descriptive, not as a test: one arm shares one init draw across all")
    print("subjects, and the trials within a subject are not independent. The placebo row is")
    print("the honest noise floor for arms that change nothing at all.")
    print("ANALYZE_EXACT_DONE")


if __name__ == "__main__":
    main()
