"""
Channel-scale normalization ablation: is the cross-subject failure a SCALE problem
or a CODE problem?

WHY. channel_probe.py produced a 64-channel importance map that is cross-subject
consistent (r = +0.2932, p < 0.0005, split-half 0.7402). But amplitude_control.py
showed that map is largely an ordering of channel amplitude: within-subject
r(damage, log10 std) = +0.6232, positive in 15/15 subjects, R^2 = 0.7535 between
the mean map and the mean amplitude, and residualizing amplitude removes about
two thirds of the cross-subject consistency (r 0.2932 -> 0.1032).

Channel amplitude is a PHYSICAL property -- electrode impedance, skin, EOG, EMG. It
is not part of the neural code. So the residual r = +0.1032 (8.5 sigma against its
own permutation null) is the part that is a CANDIDATE neural structure, and the
question this script answers is the one that decides what that residual means:

    is the cross-subject decoding failure caused by subjects differing in channel
    SCALE, or by subjects differing in the CODE itself?

If scale is the cause, removing it should let cross-subject decoding lift off
chance, and the shared neural code was there all along, masked.
If the code is the cause, nothing should move -- and "the code is individual" is
itself the finding.
Either way it is a biological statement rather than a critique, but ONLY if
normalization does not wreck within-subject performance, which is why condition A
exists. Without A, "cross-subject stayed at chance" and "normalization broke the
model" are indistinguishable.

Per-subject statistical alignment is the standard technique in the EEG transfer
literature (Euclidean alignment); this is an instance of it, not an ad-hoc trick.

TWO CONDITIONS
  A. WITHIN-SUBJECT, 5-fold, per-channel z-score from TRAIN-FOLD statistics only.
     baseline to beat: the released protocol gives 0.5779 (and 0.5949 on the
     channel_probe runs). If A stays near that, the manipulation is safe.
  B. TRANSFER MATRIX, the exact transfer_matrix.py protocol (released full batch
     280, KFold fold 0, 200 epochs, bf16) so its off-diagonal mean is directly
     paired against the existing flat result 0.1990 at a 0.20 chance level.
     Source normalized by its own TRAIN-FOLD stats; target normalized by its own
     full-350-trial stats -- UNSUPERVISED, no labels touched, so this is legitimate
     calibration, not leakage.

The statistics are computed per channel over (trials x time), i.e. one mean and one
sigma per electrode, which is exactly the quantity amplitude_control.py found to be
driving the map.

OUTPUT Results/NORM/<s>-within.npz and Results/NORM/<s>-src.npz.
"""

import os
import sys
import logging
import numpy as np
import torch

sys.path.insert(0, "/root/FAST")
os.chdir("/root/FAST")

logging.getLogger("pytorch_lightning").setLevel(logging.WARNING)
logging.getLogger("lightning").setLevel(logging.WARNING)

import lightning as pl
from torch.utils.data import DataLoader
from transformers import PretrainedConfig
from sklearn.model_selection import KFold

from BCIC2020Track3_train import (
    EEG_Encoder_Module, BasicDataset, seed_all, load_standardized_h5, inference_on_loader,
)
from BCIC2020Track3_preprocess import Electrodes, Zones

RUN = "Results/NORM"
MAX_EPOCHS = 200
N_CH = len(Electrodes)


def build_config():
    return PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1,
    )


def fit_stats(x):
    """One mean and one sigma per electrode, over trials and time. (1, 64, 1)."""
    mu = x.mean(axis=(0, 2), keepdims=True)
    sd = x.std(axis=(0, 2), keepdims=True)
    sd[sd < 1e-8] = 1.0
    return mu, sd


def apply_stats(x, stats):
    mu, sd = stats
    return (x - mu) / sd


def train_model(config, x_train, y_train):
    loader = DataLoader(BasicDataset(x_train, y_train), batch_size=len(x_train),
                        shuffle=True, num_workers=0, pin_memory=True)
    model = EEG_Encoder_Module(config, MAX_EPOCHS, len(loader))
    trainer = pl.Trainer(strategy="auto", accelerator="gpu", devices=[0],
                         max_epochs=MAX_EPOCHS, callbacks=[],
                         enable_progress_bar=False, enable_checkpointing=False,
                         precision="bf16-mixed", logger=False)
    trainer.fit(model, train_dataloaders=loader)
    return model.model


def predict(model, x):
    model.eval()
    model.cuda()
    with torch.no_grad():
        return torch.argmax(model(x.cuda()), dim=1).cpu()


def condition_A(s, X, Y, config):
    """Within-subject 5-fold, statistics from the training fold only."""
    seed_all(42)
    correct = np.zeros(350, dtype=bool)
    for fi, (tr, te) in enumerate(KFold(n_splits=5, shuffle=False).split(X[s])):
        st = fit_stats(X[s][tr])
        x_tr = apply_stats(X[s][tr], st)
        x_te = apply_stats(X[s][te], st)
        model = train_model(config, x_tr, Y[s][tr])
        correct[te] = (predict(model, torch.from_numpy(x_te.astype(np.float32))).numpy() == Y[s][te])
        print("    [A subj %02d fold %d] norm acc=%.4f" % (s, fi, correct[te].mean()), flush=True)
        del model
        torch.cuda.empty_cache()
    return correct


def condition_B(s, X, Y, config):
    """transfer_matrix.py protocol, per-subject aligned."""
    seed_all(42)
    train_idx, self_test_idx = next(iter(KFold(n_splits=5, shuffle=False).split(X[s])))
    st_src = fit_stats(X[s][train_idx])
    x_train = apply_stats(X[s][train_idx], st_src)
    model = train_model(config, x_train, Y[s][train_idx])

    preds = np.zeros((15, 350), dtype=np.int64)
    trues = np.zeros((15, 350), dtype=np.int64)
    for t in range(15):
        st_tgt = fit_stats(X[t])                       # unsupervised, full 350 trials
        x_t = apply_stats(X[t], st_tgt).astype(np.float32)
        loader = DataLoader(BasicDataset(x_t, Y[t]), batch_size=len(X[t]),
                            shuffle=False, num_workers=0, pin_memory=True)
        p, r = inference_on_loader(model.model, loader)
        preds[t], trues[t] = p, r
    diag_pred, diag_true = preds[s][self_test_idx], trues[s][self_test_idx]
    del model
    torch.cuda.empty_cache()
    return preds, trues, diag_pred, diag_true


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--subjects", type=str, default="0-14")
    ap.add_argument("--condition", type=str, default="AB", help="A, B, or AB")
    a = ap.parse_args()
    todo = []
    for part in a.subjects.split(","):
        if "-" in part:
            lo, hi = [int(v) for v in part.split("-")]
            todo += list(range(lo, hi + 1))
        else:
            todo.append(int(part))

    os.makedirs(RUN, exist_ok=True)
    config = build_config()
    X, Y = load_standardized_h5("Processed/BCIC2020Track3.h5")
    print("loaded %s %s | conditions %s | subjects %s" % (X.shape, Y.shape, a.condition, todo),
          flush=True)
    print("baselines to compare against: within-subject 0.5779 (released protocol), "
          "cross-subject off-diagonal 0.1990 (chance 0.20)", flush=True)

    if "A" in a.condition:
        print("", flush=True)
        print("=== CONDITION A: within-subject, per-channel z-scored ===", flush=True)
        for s in todo:
            f = "%s/%d-within.npz" % (RUN, s)
            if os.path.exists(f):
                print("  skip subject %02d (exists)" % s, flush=True)
                continue
            correct = condition_A(s, X, Y, config)
            np.savez(f, correct=correct)
            print("  [A subject %02d] normalized within-subject acc = %.4f  (released 0.5779)"
                  % (s, correct.mean()), flush=True)

    if "B" in a.condition:
        print("", flush=True)
        print("=== CONDITION B: transfer matrix, per-subject aligned ===", flush=True)
        for s in todo:
            f = "%s/%d-src.npz" % (RUN, s)
            if os.path.exists(f):
                print("  skip source %02d (exists)" % s, flush=True)
                continue
            preds, trues, dp, dt = condition_B(s, X, Y, config)
            np.savez(f, preds=preds, trues=trues, diag_pred=dp, diag_true=dt)
            acc = (preds == trues).mean(axis=1)
            print("  [B source %02d] diag(fold0)=%.4f | row: %s"
                  % (s, (dp == dt).mean(), " ".join("%.3f" % v for v in acc)), flush=True)

    # ---- summary ----
    print("", flush=True)
    wa = []
    for s in range(15):
        f = "%s/%d-within.npz" % (RUN, s)
        if os.path.exists(f):
            wa.append(np.load(f)["correct"].mean())
    if wa:
        print("CONDITION A within-subject, normalized : mean=%.4f  n=%d  (released protocol 0.5779)"
              % (np.mean(wa), len(wa)), flush=True)

    rows, diags = {}, {}
    for s in range(15):
        f = "%s/%d-src.npz" % (RUN, s)
        if os.path.exists(f):
            d = np.load(f)
            rows[s] = (d["preds"] == d["trues"]).mean(axis=1)
            diags[s] = float((d["diag_pred"] == d["diag_true"]).mean())
    if rows:
        common = sorted(rows)
        n = len(common)
        M = np.array([[rows[s][t] for t in common] for s in common], dtype=float)
        for i, s in enumerate(common):
            M[i, i] = diags[s]
        off = M[~np.eye(n, dtype=bool)]
        print("CONDITION B off-diagonal (cross-subject): mean=%.4f std=%.4f n=%d"
              % (off.mean(), off.std(), off.size), flush=True)
        print("            existing un-normalized result: mean=0.1990 std=0.0306 n=210", flush=True)
        print("            chance level 0.20 | paired difference = %+.4f"
              % (off.mean() - 0.1990), flush=True)
        print("            cells above 0.20: %d/%d (%.1f%%; chance alone gives ~50%%)"
              % (int((off > 0.20).sum()), off.size, 100.0 * (off > 0.20).mean()), flush=True)
        if n >= 3:
            ab = M[~np.eye(n, dtype=bool)].reshape(n, n - 1)
            ba = np.array([[M[j, i] for j in range(n) if j != i] for i in range(n)])
            print("            symmetry corr(A->B, B->A) = %.4f  (un-normalized: 0.0333)"
                  % np.corrcoef(ab.ravel(), ba.ravel())[0, 1], flush=True)
    print("NORM_DONE", flush=True)
