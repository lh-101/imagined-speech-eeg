"""Paired per-subject difference of each `--harness exact` arm against the STORED released baseline.

The baseline is NOT rerun. `released_ref.json` holds the per-fold accuracies of
`Results/FAST/<s>-Tune.csv` -- our own run of the authors' script on this box, reproduced
byte-for-byte this session (same md5), and `--harness exact` was verified on subjects 0/1/2 to
reproduce that CSV's folds EXACTLY (0.5714 0.5286 0.6714 0.5429 0.6714; 0.5400; 0.6086). So the
reference is a fixed verified constant and the arms are the only thing being measured.

Reported as a PAIRED difference, never as two means side by side: arm and baseline share the
subject, the trial split and the seed, so the subject is a block, not a sample.

A row with n < 15 is a RUNNING TOTAL, not a reading. `nl` was +0.0219 at n=3 and -0.0006 at
n=15; `sharedtemp` was +0.0000 at n=6. Never quote a partial as a result.

Run from /root/FAST:  python paired_arms.py
"""

import json
import os
import numpy as np

RUN = os.environ.get("RUN", "Results/ZA")
REF = os.environ.get("REF", "released_ref.json")
ARMS = ["nl", "w1std", "sharedtemp", "placebo", "spatial"]


def main():
    ref = json.load(open(REF))
    base = {s: float(np.mean(ref[str(s)])) for s in range(15)}
    print("released baseline (stored CSV, 15 subjects): %.4f"
          % np.mean([base[s] for s in range(15)]))
    print("")
    print("%-11s %-3s %-8s %-9s %-8s %-7s %-6s %s"
          % ("arm", "n", "arm mean", "paired d", "sem", "t", "up", "reading"))
    for arm in ARMS:
        got = {}
        for s in range(15):
            f = "%s/%d-%s-h8-ex.npz" % (RUN, s, arm)
            if os.path.exists(f):
                got[s] = float(np.load(f)["correct"].mean())
        if not got:
            print("%-11s (not run yet)" % arm)
            continue
        subs = sorted(got)
        a = np.array([got[s] for s in subs])
        b = np.array([base[s] for s in subs])
        d = a - b
        n = len(d)
        m = float(d.mean())
        se = float(d.std(ddof=1) / np.sqrt(n)) if n > 1 else float("nan")
        t = m / se if se == se and se > 0 else float("nan")
        up = int((d > 0).sum())
        if n < 15:
            read = "PARTIAL (n=%d) -- not a reading" % n
        elif up >= 13:
            read = "BEATS baseline"
        elif up <= 2:
            read = "loses to baseline"
        else:
            read = "tie"
        print("%-11s %-3d %-8.4f %-+9.4f %-8.4f %-+7.2f %-6s %s"
              % (arm, n, a.mean(), m, se, t, "%d/%d" % (up, n), read))
        print("              per-subject d: %s" % " ".join("%+.3f" % x for x in d))
        print("              subjects      : %s" % " ".join("%d" % s for s in subs))
    print("")
    print("PAIRED_ARMS_DONE")


if __name__ == "__main__":
    main()
