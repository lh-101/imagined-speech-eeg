"""
Per-subject IMPORTANCE probe for FAST on BCIC2020 Track 3.

THE QUESTION. FAST's cross-subject transfer is exactly zero (210/210 cells average
19.90% against a 20% chance level, no pair structure, no canonical subject). Two
hypotheses both predict that and this dataset alone cannot separate them:

  H1  the neural code for covert speech is genuinely subject-specific
  H2  the model reads subject/session state (impedance, alpha, drift), not speech

THE DISCRIMINATOR IS SPATIAL STRUCTURE:
  if the model decodes SPEECH, a cognitive process, then Broca's area is Broca's
  area in every head, so the per-subject importance maps should agree;
  if it decodes SESSION STATE, every subject's nuisance profile is idiosyncratic,
  so the maps should disagree. The paper reports only the GROUP AVERAGE map --
  nobody has looked subject-by-subject, so heterogeneous maps could still average
  into a Broca's-shaped blob.

METHOD. Input perturbation, not attention. The paper drew its conclusion from the
model's own attention weights, so re-reading that same quantity to test it would be
circular. Instead damage the INPUT: replace one group's signal with another trial's
signal (a derangement of the batch) and re-measure accuracy. Importance = baseline
accuracy minus perturbed accuracy.

THE CONTROL THAT MAKES IT INTERPRETABLE. Damaging 9 channels might cost accuracy
simply because 9 channels are gone, with nothing "functional" about the grouping.
So every group is compared against RANDOM channel sets of the SAME SIZE. A group
only counts as a functional unit if it hurts MORE than a random set of equal size.
Two anchors: `none` (no perturbation) and `ALL` (all 64 deranged), which must
collapse to chance -- if it does not, the model is not reading the input at all and
every number here is meaningless.

WHY THE HEMISPHERE GROUPS EXIST. The paper's claim is specifically LEFT
frontal/temporal. The paper's own 8 zones are bilateral, so they cannot test
laterality. L-Frontal / R-Frontal / L-Temporal / R-Temporal can.

PILOT RESULT (subjects 03 and 11, done): method validated -- ALL-deranged collapses
0.6943 -> 0.1629 and 0.4143 -> 0.2057, and random-channel drops increase
monotonically with size. But the zone importance does NOT reproduce the paper:
for subj 03 only Temporal beat its size-matched control (+0.054) while Frontal fell
BELOW it (-0.035); for subj 11 no group beat its control at all, Temporal included
(-0.021). n=2, so this is a reason to scale up, not a finding yet.

Uses the released protocol: KFold(5, shuffle=False) over the subject's own 350
trials, full batch 280, 200 epochs, bf16, seed_all(42) once before the fold loop
exactly as Finetune() does. All 5 folds trained so importance rests on 350 held-out
trials rather than 70.
"""

import os
import sys
import logging
import numpy as np
import torch

sys.path.insert(0, "/root/FAST")
os.chdir("/root/FAST")

logging.getLogger("pytorch_lightning").setLevel(logging.WARNING)
logging.getLogger("lightning").setLevel(logging.WARNING)

import lightning as pl
from torch.utils.data import DataLoader
from transformers import PretrainedConfig
from sklearn.model_selection import KFold

from BCIC2020Track3_train import EEG_Encoder_Module, BasicDataset, seed_all, load_standardized_h5
from BCIC2020Track3_preprocess import Electrodes, Zones

RUN = "Results/ZP"
MAX_EPOCHS = 200
N_RAND = 10          # random channel sets per distinct group size


def hemi_of(name):
    """10-20 convention: trailing z = midline, odd trailing digit = left, even = right."""
    if name.endswith("z"):
        return "mid"
    return "L" if int(name[-1]) % 2 == 1 else "R"


ZONE_CH = {z: [Electrodes.index(e) for e in names] for z, names in Zones.items()}

# every channel group we test: the paper's 8 zones, plus hemisphere splits that the
# paper's own bilateral zoning cannot express
GROUPS = dict(ZONE_CH)
for zn in ("Frontal", "Temporal"):
    for h in ("L", "R"):
        GROUPS["%s-%s" % (h, zn)] = [i for i, e in enumerate(Electrodes)
                                     if e in Zones[zn] and hemi_of(e) == h]
GROUPS["L-all"] = [i for i, e in enumerate(Electrodes) if hemi_of(e) == "L"]
GROUPS["R-all"] = [i for i, e in enumerate(Electrodes) if hemi_of(e) == "R"]


def build_config():
    return PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1,
    )


def derangement(n, seed):
    """A permutation of range(n) with no fixed point.

    A plain torch.randperm leaves ~1 fixed point in 70, and a fixed point means that
    trial keeps its OWN signal -- the perturbation would leak. Repair: rotate the
    values among the fixed positions (if there are >=2 they are exactly each other's
    values, so one rotation clears all of them). A lone fixed point has to borrow one
    extra position first -- rotating a 1-element set is a no-op, which is what made
    the first version of this spin forever.
    """
    g = torch.Generator().manual_seed(seed)
    p = torch.randperm(n, generator=g)
    ar = torch.arange(n)
    for _ in range(200):
        fx = (p == ar).nonzero().flatten()
        if fx.numel() == 0:
            return p
        if fx.numel() == 1:
            i = int(fx[0])
            j = int(torch.randint(0, n, (1,), generator=g))
            if j == i:
                j = (i + 1) % n
            fx = torch.tensor([i, j], dtype=torch.long)
        p[fx] = p[fx].clone().roll(1)
    raise RuntimeError("could not build a derangement for n=%d" % n)


def predict(model, x):
    model.eval()
    model.cuda()           # Lightning leaves the params on CPU after fit(); the released
    with torch.no_grad():  # inference_on_loader() calls .cuda() for the same reason
        return torch.argmax(model(x.cuda()), dim=1).cpu()


def train_fold(config, x_train, y_train):
    loader = DataLoader(BasicDataset(x_train, y_train), batch_size=len(x_train),
                        shuffle=True, num_workers=0, pin_memory=True)
    model = EEG_Encoder_Module(config, MAX_EPOCHS, len(loader))
    trainer = pl.Trainer(strategy="auto", accelerator="gpu", devices=[0],
                         max_epochs=MAX_EPOCHS, callbacks=[],
                         enable_progress_bar=False, enable_checkpointing=False,
                         precision="bf16-mixed", logger=False)
    trainer.fit(model, train_dataloaders=loader)
    return model.model


def probe_subject(s, X, Y, config):
    seed_all(42)                      # once, before the fold loop, as Finetune() does
    names = list(GROUPS.keys())
    sizes = sorted({len(GROUPS[g]) for g in names})

    n_t = 350
    base = np.zeros(n_t, dtype=bool)
    grp_ok = {g: np.zeros(n_t, dtype=bool) for g in names}
    all_ok = np.zeros(n_t, dtype=bool)
    rand_ok = {(k, d): np.zeros(n_t, dtype=bool) for k in sizes for d in range(N_RAND)}

    rng = np.random.RandomState(1234)
    rand_sets = {(k, d): torch.tensor(sorted(rng.choice(64, size=k, replace=False)))
                 for k in sizes for d in range(N_RAND)}

    for fi, (tr, te) in enumerate(KFold(n_splits=5, shuffle=False).split(X[s])):
        x_te = torch.from_numpy(X[s][te])
        y_te = Y[s][te]
        model = train_fold(config, X[s][tr], Y[s][tr])

        base[te] = (predict(model, x_te).numpy() == y_te)

        p_all = derangement(len(te), 9000 + fi)
        xa = x_te.clone()
        xa[:, :, :] = x_te[p_all][:, :, :]
        all_ok[te] = (predict(model, xa).numpy() == y_te)

        for gi, g in enumerate(names):
            ch = GROUPS[g]
            p = derangement(len(te), 1000 * (gi + 1) + fi)
            xp = x_te.clone()
            xp[:, ch, :] = x_te[p][:, ch, :]
            grp_ok[g][te] = (predict(model, xp).numpy() == y_te)

        for k in sizes:
            for d in range(N_RAND):
                ch = rand_sets[(k, d)]
                p = derangement(len(te), 777000 + 100 * k + d * 7 + fi)
                xp = x_te.clone()
                xp[:, ch, :] = x_te[p][:, ch, :]
                rand_ok[(k, d)][te] = (predict(model, xp).numpy() == y_te)

        print("  [subj %02d fold %d] base=%.4f  all-deranged=%.4f"
              % (s, fi, base[te].mean(), all_ok[te].mean()), flush=True)
        del model
        torch.cuda.empty_cache()

    return base, grp_ok, rand_ok, all_ok, names, sizes


def report(s, base, grp_ok, rand_ok, all_ok, names, sizes):
    ba = base.mean()
    rnd = {k: np.mean([rand_ok[(k, d)].mean() for d in range(N_RAND)]) for k in sizes}
    print("", flush=True)
    print("=== subject %02d  baseline=%.4f  (chance 0.20, n=%d held-out trials) ==="
          % (s, ba, len(base)), flush=True)
    print("  %-14s %5s %8s %8s   %s"
          % ("condition", "size", "acc", "drop", "vs random same size"), flush=True)
    print("  %-14s %5s %8.4f %8.4f" % ("none", "-", ba, 0.0), flush=True)
    print("  %-14s %5s %8.4f %8.4f   <- anchor: must be ~0.20"
          % ("ALL-deranged", 64, all_ok.mean(), ba - all_ok.mean()), flush=True)
    for k in sizes:
        print("  %-14s %5d %8.4f %8.4f" % ("rand(size=%d)" % k, k, rnd[k], ba - rnd[k]), flush=True)
    print("  " + "-" * 62, flush=True)
    for g in names:
        a = grp_ok[g].mean()
        k = len(GROUPS[g])
        print("  %-14s %5d %8.4f %8.4f   %+.4f"
              % (g, k, a, ba - a, (ba - a) - (ba - rnd[k])), flush=True)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--subjects", type=str, default="0-14")
    a = ap.parse_args()
    todo = []
    for part in a.subjects.split(","):
        if "-" in part:
            lo, hi = [int(v) for v in part.split("-")]
            todo += list(range(lo, hi + 1))
        else:
            todo.append(int(part))

    os.makedirs(RUN, exist_ok=True)
    config = build_config()

    print("groups and sizes:", {g: len(v) for g, v in GROUPS.items()}, flush=True)
    print("hemisphere counts: L=%d R=%d mid=%d"
          % (len(GROUPS["L-all"]), len(GROUPS["R-all"]),
             sum(1 for e in Electrodes if hemi_of(e) == "mid")), flush=True)
    missing = set(Electrodes) - {e for names_ in Zones.values() for e in names_}
    print("electrodes not in any zone:", sorted(missing) if missing else "none (all 64 covered)",
          flush=True)

    X, Y = load_standardized_h5("Processed/BCIC2020Track3.h5")
    print("probe subjects: %s" % todo, flush=True)

    for s in todo:
        f = "%s/%d-groups.npz" % (RUN, s)
        if os.path.exists(f):
            print("skip subject %02d (exists)" % s, flush=True)
            continue
        base, grp_ok, rand_ok, all_ok, names, sizes = probe_subject(s, X, Y, config)
        np.savez(f, base=base, all_ok=all_ok, names=np.array(names),
                 grp_acc=np.array([grp_ok[g].mean() for g in names]),
                 grp_correct=np.array([grp_ok[g] for g in names]),
                 grp_size=np.array([len(GROUPS[g]) for g in names]),
                 rand_sizes=np.array(sizes),
                 rand_acc=np.array([[rand_ok[(k, d)].mean() for d in range(N_RAND)]
                                    for k in sizes]))
        report(s, base, grp_ok, rand_ok, all_ok, names, sizes)
    print("ZP_DONE", flush=True)
