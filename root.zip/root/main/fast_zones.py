"""
A zonal-attention variant of FAST. Exactly one structural change, nothing else.

WHAT IS WRONG WITH THE RELEASED MODEL. FAST tokenises its input as

    x.unfold(-1, 250, 125)                  -> (B, 5, C, 250)    5 time windows
    Head.forward                            -> (B, 5, 8, 32)     5 x 8 zones x 32

and then forward_transformer does

    einops.rearrange(x, 'B N Z F -> B N (Z F)')   -> (B, 5, 256)
    self.input_layer = Linear(256, 32)            -> (B, 5, 32)

so the eight zone features are FLATTENED and squeezed through one static linear map
before the transformer ever runs. The transformer then attends over 6 tokens: the 5
time windows plus cls. Consequences, all of them measured rather than argued:

  * There is NO spatial attention. The name says spatio-temporal; the attention is
    purely temporal. Space is mixed once, by a linear layer whose weights are the
    same for every trial and every time window, so the model cannot express "the
    Temporal zone dominates the first 500 ms and the Parietal zone the last 500".
  * That layer is an 8:1 linear bottleneck (256 -> 32) sitting in front of all
    nonlinearity. The zone encoders hold 77.7% of the parameters (148,992 of
    191,781) and their output is compressed to 32 numbers before anything can act
    on it.
  * Eight attention heads over six tokens, with head_dim = 32/8 = 4.

THE CHANGE. Keep the zone encoders and the transformer blocks exactly as they are.
Tokenise as (time window, zone) instead of collapsing zones into the feature axis:

    (B, N, Z, F) -> (B, N*Z, dim_token)      with pos = pos_time[n] + pos_zone[z]

The model now has 5*8 = 40 content tokens plus cls, and the attention itself decides
how much each zone contributes at each window. Nothing else is touched: same zone
encoders, same 4 AttentionBlocks, same head structure, same window unfold, same
training loop, same seed, same 5-fold split.

PARAMETER COUNT GOES DOWN, which matters for the honesty of the comparison. Attention
weights are per-dimension, not per-token, so widening 6 tokens to 41 costs nothing in
the transformer. The only change is input_layer, Linear(256->32)+GELU = 8,256 params
becoming Linear(32->32)+GELU = 1,088, and pos_embedding (1,6,32) = 192 becoming
pos_time (1,5,1,32) + pos_zone (1,1,8,32) = 416. Net change: -6,944 parameters.

So if this variant wins, it wins with FEWER parameters than the model it beats, and
the claim is not "we made it bigger".

Ablation knobs are exposed as plain config fields so a run can vary one thing:
    num_heads          -- 8 (released) or 4; head_dim 4 is very small for 32 dims
    dim_token          -- token width
    n_zones is read from config.zone_dict and is always 8 here.

Not used by the released training path, so the two forward_mode branches that assume
the old token shape raise instead of silently returning something wrong.
"""

import copy
import math

import einops
import torch
import torch.nn as nn
import torch.nn.functional as F

from FAST import FAST, Head, Conv4Layers, AttentionBlock


class Conv4LayersNL(Conv4Layers):
    """Conv4Layers with a GELU between the convolutions instead of only at the end.

    THE DEFECT. The released head runs cnn1 -> cnn2 -> cnn3 -> cnn4 with no activation
    between them and a single F.gelu at the very end. A composition of affine maps is
    an affine map, so the four convolutions collapse to ONE linear operator:

        out = mean_t( gelu( W4 W3 W2 W1 x + b ) )

    The depth therefore buys a larger temporal receptive field (13 samples instead of
    5) and NOTHING else -- zero extra representational power for 77.7% of the model's
    parameters. The author's own unused HeadConv_Paper_Version applies
    F.gelu(self.norm(...)) after every one of its four blocks, so the released head is
    not the paper's head. This variant restores the nonlinearity and changes nothing
    else, which isolates its contribution.
    """

    def forward(self, x):
        x = einops.rearrange(x, 'B C T -> B 1 C T')
        x = F.gelu(self.cnn1(x))
        x = F.gelu(self.cnn2(x))
        x = F.gelu(self.cnn3(x))
        x = F.gelu(self.cnn4(x))
        return einops.reduce(x, 'B F 1 T -> B F', 'mean')


class Conv4LayersNLNorm(Conv4LayersNL):
    """Conv4LayersNL plus BatchNorm2d after each conv, matching the paper version's
    block structure (gelu(norm(conv))).

    Normalisation is worth testing separately from the nonlinearity because
    proc_one does NO normalisation at all and per-channel amplitude spans 21x-73x
    within a subject, so the eight zone encoders see wildly different input scales.
    Separating the two keeps the rows interpretable: Conv4LayersNL is nonlinearity
    alone, this is nonlinearity plus normalisation.
    """

    def __init__(self, channels, dim=32):
        super().__init__(channels, dim)
        self.norm1 = nn.BatchNorm2d(dim)
        self.norm2 = nn.BatchNorm2d(dim)
        self.norm3 = nn.BatchNorm2d(dim)
        self.norm4 = nn.BatchNorm2d(dim)

    def forward(self, x):
        x = einops.rearrange(x, 'B C T -> B 1 C T')
        x = F.gelu(self.norm1(self.cnn1(x)))
        x = F.gelu(self.norm2(self.cnn2(x)))
        x = F.gelu(self.norm3(self.cnn3(x)))
        x = F.gelu(self.norm4(self.cnn4(x)))
        return einops.reduce(x, 'B F 1 T -> B F', 'mean')


class Conv4LayersBank(Conv4Layers):
    """Replace the 5-tap input conv with a physiological band-pass filter bank.

    WHY. The released front end cannot represent the bands the signal lives in. cnn1 has
    a 5-sample kernel and cnn3/cnn4 another 5 each, so the total receptive field of the
    zone encoder is 13 samples = **52 ms at 250 Hz**. A filter that sees 52 ms cannot
    express a theta oscillation (period 125-250 ms) or an alpha/mu one (77-125 ms); those
    bands are not merely under-weighted, they are outside the model's function space, and
    since the encoder is affine (see Conv4LayersNL) the "depth" does not widen it in any
    nonlinear way either. What the encoder can express is a broadband edge detector plus
    the one final GELU -- i.e. roughly a rectified broadband power, with no frequency
    selectivity to speak of.

    THE CHANGE. cnn1 becomes a 125-tap (500 ms) depthwise filter bank initialised to
    zero-mean unit-norm Gabor kernels on 32 log-spaced centre frequencies from 2 Hz to
    45 Hz, covering delta through gamma. Everything else -- cnn2/3/4, the head, the
    tokenisation, the transformer, the training loop -- is untouched.

    Cost: cnn1 goes from 1*32*1*5 + 32 = 192 to 1*32*1*125 + 32 = 4,032 per zone, so the
    model goes 191,781 -> 222,501, i.e. +30,720 (+16%). That is a capacity INCREASE, which
    is the wrong direction given TRAIN 1.0000, so the architecture is reported alongside
    the frozen arm below and neither is claimed to win on size.

    The prior is the point, not the parameter count: the kernels are band-structured
    rather than free. `bankfrozen` is the same architecture with the bank frozen, which
    leaves 190,245 TRAINABLE parameters -- fewer than the released model's 191,781 -- so
    the two arms bracket the question "does the band prior help, and does it have to be
    learned to help?"

    Invariance note: a 500 ms kernel over a 1 s window means each of the 5 windows now
    overlaps its neighbours in what it can see, which is a real change and is the point --
    the bands simply were not reachable before.
    """

    N_TAPS = 125
    F_LO, F_HI = 2.0, 45.0
    FS = 250.0

    def _gabor_bank(self, dim):
        """Zero-mean, unit-L2 Gabor kernels on log-spaced centre frequencies.

        Zero-mean removes the DC response, so each filter measures a band rather than a
        band plus the offset. Unit L2 puts every band on a comparable output scale, which
        matters here because proc_one does no normalisation anywhere and raw EEG power
        falls off steeply with frequency.
        """
        n = self.N_TAPS
        t = (torch.arange(n, dtype=torch.float64) - (n - 1) / 2.0) / self.FS
        freqs = torch.exp(torch.linspace(math.log(self.F_LO), math.log(self.F_HI), dim,
                                         dtype=torch.float64))
        w = torch.zeros(dim, 1, 1, n, dtype=torch.float64)
        for k in range(dim):
            f = float(freqs[k])
            # envelope width scaled as 1/f keeps the number of cycles per band roughly
            # constant, so low bands get proportionally longer kernels and every filter
            # resolves about the same number of oscillations.
            sigma = 1.0 / (2.0 * math.pi * 0.5 * f)
            env = torch.exp(-t ** 2 / (2.0 * sigma ** 2))
            g = env * torch.cos(2.0 * math.pi * f * t)
            g = g - g.mean()
            g = g / g.norm()
            w[k, 0, 0] = g
        return w.float()

    def __init__(self, channels, dim=32):
        nn.Module.__init__(self)
        self.cnn1 = nn.Conv2d(1, dim, (1, self.N_TAPS),
                              padding=(0, self.N_TAPS // 2), bias=True)
        with torch.no_grad():
            self.cnn1.weight.copy_(self._gabor_bank(dim))
        self.cnn2 = nn.Conv2d(dim, dim, (channels, 1), padding=0, bias=False)
        self.cnn3 = nn.Conv2d(dim, dim, (1, 5), padding=(0, 2), bias=False)
        self.cnn4 = nn.Conv2d(dim, dim, (1, 5), padding=(0, 2), bias=False)

    def freeze_bank(self):
        self.cnn1.weight.requires_grad_(False)
        self.cnn1.bias.requires_grad_(False)

    def forward(self, x):
        x = einops.rearrange(x, 'B C T -> B 1 C T')
        x = self.cnn1(x)
        x = self.cnn2(x)
        x = self.cnn3(x)
        x = self.cnn4(x)
        x = F.gelu(x)
        return einops.reduce(x, 'B F 1 T -> B F', 'mean')


class Conv4LayersShared(Conv4Layers):
    """Temporal convolutions SHARED across all eight zones; only spatial mixing stays
    per-zone.

    WHY. diagnose.py measured TRAIN 1.0000 against TEST 0.6143 on this protocol: with
    280 training trials the released model memorises the training set outright, so any
    change that ADDS capacity loses -- as the zoneattn arm did, on 5/5 subjects,
    t=-3.56. The lever is therefore constraint, and the parameter census says where the
    constraint belongs:

        head total 148,992
          cnn2  32*32*64 = 65,536   per-zone spatial mixing (sum of n_ch over zones = 64)
          cnn1/cnn3/cnn4 = 10,432 per zone x 8 = 83,456   TEMPORAL convs

    The 83,456 are eight independently-initialised copies of the SAME architecture, each
    fitting 32x32x5 temporal filters plus a 192-parameter input filter on one zone's
    electrodes and the same 280 trials. Nothing about a 20 ms or 100 ms temporal filter
    is a property of scalp location -- the EEG dynamics being filtered are the same
    signal. Sharing them encodes that as a hard constraint instead of hoping the data
    will impose it eight times over.

    Cost: 83,456 -> 10,432 head parameters, i.e. 191,781 -> 118,757 total (-38%), with
    the per-zone spatial mixing left completely intact. Nothing else changes -- same
    tokenisation, same transformer, same forward, same training loop.

    IMPLEMENTATION NOTE. The shared convs are assigned to `self.cnn1/3/4` on every zone
    encoder as the SAME module object. nn.Module.named_parameters() deduplicates by
    identity, so they appear once in model.parameters() and the optimizer sees them once,
    while each encoder still finds them where Conv4Layers.forward expects. A plain
    module-level singleton would have been silently dropped from the optimizer.

    The construction deliberately does NOT call Conv4Layers.__init__, so the 21 conv
    tensors that would be built and discarded do not consume global RNG draws.
    """

    _shared = None

    @classmethod
    def _ensure(cls, dim):
        if cls._shared is None:
            sh = nn.Module()
            sh.cnn1 = nn.Conv2d(1, dim, (1, 5), bias=True)
            sh.cnn3 = nn.Conv2d(dim, dim, (1, 5), padding=(0, 2), bias=False)
            sh.cnn4 = nn.Conv2d(dim, dim, (1, 5), padding=(0, 2), bias=False)
            cls._shared = sh

    def __init__(self, channels, dim=32):
        nn.Module.__init__(self)
        self.cnn2 = nn.Conv2d(dim, dim, (channels, 1), padding=0, bias=False)
        Conv4LayersShared._ensure(dim)
        self.cnn1 = Conv4LayersShared._shared.cnn1
        self.cnn3 = Conv4LayersShared._shared.cnn3
        self.cnn4 = Conv4LayersShared._shared.cnn4

    def forward(self, x):
        x = einops.rearrange(x, 'B C T -> B 1 C T')
        x = Conv4LayersShared._shared.cnn1(x)
        x = self.cnn2(x)
        x = Conv4LayersShared._shared.cnn3(x)
        x = Conv4LayersShared._shared.cnn4(x)
        x = F.gelu(x)
        return einops.reduce(x, 'B F 1 T -> B F', 'mean')


class FAST_ZoneAttn(FAST):
    """FAST with (window x zone) attention tokens instead of (window) tokens."""

    name = "FAST_ZoneAttn"

    def __init__(self, config):
        super().__init__(config)
        n_zones = len(config.zone_dict)
        self.n_zones = n_zones

        # Per-token projection: replaces the 256->32 flatten-and-squeeze. When
        # dim_cnn == dim_token this is a 32->32 map whose only job is to move the
        # zone encoder's output into the transformer's width.
        self.input_layer = nn.Sequential(
            nn.Linear(config.dim_cnn, config.dim_token), nn.GELU()
        )

        # Factorised position: one code per time window, one per zone, added. This
        # is what lets attention distinguish "Parietal at t=2 s" using only
        # n_tokens + n_zones learned vectors rather than n_tokens*n_zones.
        del self.pos_embedding
        self.pos_time = nn.Parameter(torch.randn(1, self.n_tokens, 1, config.dim_token))
        self.pos_zone = nn.Parameter(torch.randn(1, 1, n_zones, config.dim_token))

    def forward_transformer(self, x):
        """x: (B, N, Z, F) from the inherited forward_head."""
        B, N, Z, F = x.shape
        x = self.input_layer(x)                                  # (B, N, Z, D)
        x = x.reshape(B, N * Z, -1)
        x = x + (self.pos_time + self.pos_zone).reshape(1, N * Z, -1)
        cls = self.cls_token.expand(B, -1, -1)
        x = torch.cat((cls, x), dim=1)                           # (B, 1+N*Z, D)
        tokens = self.transformer(x)
        return self.last_layer(self.dropout(tokens[:, 0]))

    def forward(self, x, forward_mode="default"):
        if forward_mode != "default":
            raise NotImplementedError(
                "FAST_ZoneAttn only supports the default forward mode: the "
                "'%s' branch in the parent class assumes the old (B, N, Z*F) "
                "token shape and would silently compute the wrong thing."
                % forward_mode
            )
        return self.forward_transformer(self.forward_head(x))


class SoftHead(Head):
    """Head with a LEARNABLE channel->zone assignment in place of the hard one.

    THE DEFECT THIS ADDRESSES. `Head.forward` is `encoder(x[:, self.index_dict[area]])`:
    each zone encoder only ever sees its own electrodes, fixed at construction from the
    anatomical `Zones` dict. A spatial filter spanning a zone boundary is therefore not
    merely discouraged, it is UNREPRESENTABLE -- no setting of the weights can put a
    weight on C3 and CP3 in the same filter, because those two channels never enter the
    same encoder. Scalp projections of a cortical source routinely cross those borders
    (perisylvian and sensorimotor sources in particular), so the hard partition is an
    assumption about the data that was never tested.

    THE CHANGE. Each zone slot gets a soft weight over ALL 64 channels:

        S = softmax(assign_logit * temp, dim=0)          # (64, n_slots), columns sum to 1
        z_in = einsum('cs,bct->bst', S[:, slots_of_z], x)

    assign_logit is initialised to +INIT on each slot's own anatomical channel and 0
    elsewhere, so at initialisation the softmax is strongly peaked on the anatomical
    channel and the model starts close to the released behaviour rather than needing to
    rediscover spatial structure from scratch. temp is learnable and lets the assignment
    go hard (large temp) or spread out over several electrodes (small temp).

    The learned S is readable. That is the point of this variant as much as the accuracy:
    it is a DATA-DRIVEN functional parcellation, and comparing it against the anatomical
    one is a result about the data, not just about the model.

    Parameter cost: one (64, n_slots) logit matrix plus a scalar, i.e. 64*64 + 1 = 4,097
    parameters, against a 191,781-parameter baseline. cnn2 keeps its original shape
    because each zone still receives exactly as many "virtual channels" as it has
    anatomical ones.
    """

    INIT_LOGIT = 6.0

    def __init__(self, head, electrodes, zone_dict, feature_dim):
        super().__init__(head, electrodes, zone_dict, feature_dim)
        names = list(electrodes)
        slots = []
        for ch_names in zone_dict.values():
            slots += [names.index(c) for c in ch_names]
        A = torch.zeros(len(names), len(slots))
        for s, c in enumerate(slots):
            A[c, s] = self.INIT_LOGIT
        self.assign_logit = nn.Parameter(A)
        self.temp = nn.Parameter(torch.ones(1))
        self.slot_zones = [z for z, ch in zone_dict.items() for _ in ch]

    def assignment(self):
        """(64, n_slots) soft assignment, detached, for inspection."""
        with torch.no_grad():
            return torch.softmax(self.assign_logit * self.temp, dim=0)

    def forward(self, x):
        S = torch.softmax(self.assign_logit * self.temp, dim=0)
        outs, off = [], 0
        for area, encoder in self.encoders.items():
            n = len(self.index_dict[area])
            outs.append(encoder(torch.einsum('cs,bct->bst', S[:, off:off + n], x)))
            off += n
        return torch.stack(outs, dim=1)


class Conv4LayersMeanStd(Conv4Layers):
    """Released encoder with its temporal pooling changed from mean to [mean, std].

    WHY. `Conv4Layers.forward` ends in einops.reduce(x, 'B F 1 T -> B F', 'mean'), so the
    only thing it can report about a window is the time-average of a filtered signal. The
    probes say that is very close to all the amplitude information there is -- and that the
    SECOND moment is where the missing part lives:

        whole-epoch per-channel mean+std, 128 dims, logistic regression   0.4149
        band power, 384 dims                                              0.3623
        time-resolved band power, 5 or 10 sub-windows                    0.13 WORSE

    mean+std was the best hand-built representation tried, and the one that came closest to
    a trained model. The released front end computes the mean and throws the std away, so
    the single most useful statistic found in this data has no path into the model at all.

    THE CHANGE. Pool with `torch.cat([mean, std], dim=1)` instead of `mean`, taking the
    encoder from F to 2F outputs. Nothing else moves: same four convolutions, same weights,
    same init, same head assembly. `unbiased=False` because this is a descriptive statistic
    of a fixed-length window, not an estimate of a population parameter, and the 800-sample
    N-1 correction would be noise anyway.
    """

    def forward(self, x):
        x = einops.rearrange(x, 'B C T -> B 1 C T')
        x = self.cnn1(x)
        x = self.cnn2(x)
        x = self.cnn3(x)
        x = self.cnn4(x)
        x = F.gelu(x)
        x = einops.rearrange(x, 'B F 1 T -> B F T')
        return torch.cat([x.mean(dim=2), x.std(dim=2, unbiased=False)], dim=1)


class FAST_WholeEpoch(FAST):
    """ONE window covering the whole epoch, instead of 5 overlapping 1 s windows.

    WHY. The released tokeniser cuts the epoch into five 250-sample windows at stride 125,
    so each window is 1 s and consecutive windows share half their samples. That is five
    highly correlated views of the same trial presented as five independent tokens, and
    the probes give no evidence that the time-localisation is worth anything: every
    time-resolved band-power feature measured landed 0.13 BELOW its whole-epoch
    counterpart, and in only 1 of 15 subjects was the time-resolved version better. So the
    five tokens are paying for resolution the data does not seem to have, on a model that
    already reaches TRAIN 1.0000 on 280 trials.

    THE CHANGE. window_len = the whole epoch, so n_tokens = 1 and the attention runs over
    2 tokens (one content + cls). Everything else is the released code path, unchanged --
    this variant is pure subtraction, and it is the ablation that says what the temporal
    tokenisation was worth. If accuracy holds, five tokens were decoration; if it collapses,
    the 5-window structure is load-bearing and the probes were measuring the wrong thing.

    The config is deep-copied rather than mutated: FAST keeps `self.config` and
    forward_head reads window_len off it on every call, so restoring the shared config
    after construction would silently put the old window length back and this would train
    as plain base. Mutating the caller's config in place is the other wrong answer -- the
    runner reuses one config object across variants.
    """

    def __init__(self, config):
        cfg = copy.deepcopy(config)
        cfg.window_len = cfg.seq_len
        cfg.slide_step = cfg.seq_len
        super().__init__(cfg)


class FAST_WholeEpochMeanStd(FAST_WholeEpoch):
    """Both changes at once: one whole-epoch window, described by its mean AND its std.

    This is the arm that can actually win, as opposed to w1 which can only tell us what
    the released tokenisation was worth. The reasoning is entirely from the probes: the
    discriminative amplitude information is a static whole-epoch property, mean+std is the
    best hand-built family for it, and the released front end can only compute the mean.
    Giving every zone a mean and a std over the full epoch is strictly more of the same
    kind of information the model is already good at, at fewer tokens than it had.

    Token cost 6 -> 2 and input width 256 -> 512. Under TRAIN 1.0000 the token cut is the
    direction that helps and the widening is the direction that hurts, so the two are
    reported separately (w1, w1std) rather than together, and neither is claimed to win on
    size: 191,781 -> 199,845 (+4.2%); the input_layer gains 8,192 and pos_embedding loses
    128 with the 6 -> 2 token cut.
    """

    def __init__(self, config):
        super().__init__(config)
        n_zones = len(config.zone_dict)
        del self.input_layer
        self.input_layer = nn.Sequential(
            nn.Linear(2 * config.dim_cnn * n_zones, config.dim_token), nn.GELU())


class RiemannBranch(nn.Module):
    """Per (window, zone): the spatial covariance of the zone's channels, mapped through
    the matrix logarithm and read out as a fixed second-order spatial feature.

    WHY THE COVARIANCE, AND WHY IT IS NOT JUST MORE CAPACITY.
    `Conv4Layers` is affine (see Conv4LayersNL), so a zone encoder computes
    mean_t(gelu(W x + b)): a spatial linear filter, pooled over time. Whatever a source
    does that is not a fixed linear projection of the electrodes -- in particular two
    electrodes going up and down TOGETHER because one source projects to both -- is
    outside its function space. The only other spatial machinery in the model is the
    single Linear(256->32) that flattens the eight zones before attention, which is again
    a static first-order map. So the model has no second-order spatial term at all.

    This branch supplies one, as a FIXED basis rather than learned freedom: the descriptor
    log(C) is a parameter-free function of the window's own channels, and only a linear
    readout of it is learned. That is the same shape as adding a kernel basis to a linear
    model -- it can help under overfitting precisely because the basis itself is not fit.
    The readout is small: 2,688 parameters for the projections plus 2,048 for the widened
    input layer, i.e. 191,781 -> 196,517 (+2.5%), against zoneattn's -6,944 which lost.

    WHY THE LOG AND NOT C. C is symmetric positive definite, so it lives on a cone, not in
    a vector space; averaging or linearly reading out raw covariances mixes scales and
    inflates the diagonal. The matrix logarithm maps the cone to the tangent space at
    identity, turning the problem back into an ordinary linear one. It is used here in its
    REFERENCE-FREE form, log(C) = V diag(log ev) V^T, rather than spectral_probe.py's
    `tangent(Cs, ref)`: a reference point would have to be estimated from the training
    fold and carried into the model, and a wrong or leaking reference is exactly the kind
    of thing that makes a variant look better than it is. Reference-free means no fold
    statistics enter the model at all.

    NUMERICS. eigh has no bf16 kernel, so the whole branch runs under autocast disabled in
    float32 and casts back. The ridge is scaled by the mean eigenvalue of each covariance
    rather than being an absolute constant, because proc_one does no normalisation and
    per-channel amplitude spans 21x-73x within a subject -- a fixed ridge would be
    negligible on one subject and dominant on another. The ridge also keeps eigh away from
    degenerate eigenvalues, whose gradients are where this construction normally NaNs.
    """

    RIDGE = 1e-4
    LOG_EPS = 1e-12

    def __init__(self, electrodes, zone_dict, out_dim=8):
        super().__init__()
        self.zones = list(zone_dict.keys())
        self.out_dim = out_dim
        self.index, self.triu = {}, {}
        self.projs = nn.ModuleDict()
        for area, ch_names in zone_dict.items():
            # NOT registered as a buffer: these are index bookkeeping, and a buffer would
            # add entries to model.parameters()/state_dict and shift the RNG bookkeeping
            # for no reason. Index tensors on CPU are accepted by advanced indexing.
            self.index[area] = torch.tensor([electrodes.index(c) for c in ch_names])
            n = len(ch_names)
            self.triu[area] = torch.triu_indices(n, n)
            self.projs[area] = nn.Linear(n * (n + 1) // 2, out_dim)

    def forward(self, x):
        """x: (B, C, T) -> (B, Z * out_dim)."""
        dt = x.dtype
        with torch.autocast(device_type=x.device.type, enabled=False):
            y = self._fp32(x.float())
        return y.to(dt)

    def _fp32(self, x):
        return torch.cat([self.projs[area](f)
                          for area, f in zip(self.zones, self.log_cov_triu(x))], dim=1)

    def log_cov_triu(self, x):
        """The raw reference-free log-covariance, upper triangle, per zone.

        Split out from the readout so the tests can check the descriptor itself -- that it
        is symmetric, that its eigenvalues are the logs of the covariance's, and that it
        agrees with the truncated power series of log(I+N) -- none of which is visible
        through the linear readout.
        """
        outs = []
        for area in self.zones:
            outs.append(self._log_cov(x, area))
        return outs

    def _log_cov(self, x, area):
        xz = x[:, self.index[area]]                           # (B, Cz, T)
        xz = xz - xz.mean(dim=2, keepdim=True)                # covariance about the mean
        T = xz.shape[2]
        C = torch.bmm(xz, xz.transpose(1, 2)) / T             # (B, Cz, Cz)
        Cz = C.shape[-1]
        eye = torch.eye(Cz, device=x.device, dtype=C.dtype)
        scale = C.diagonal(dim1=-2, dim2=-1).mean(-1).clamp_min(1e-12)
        C = C + (self.RIDGE * scale)[:, None, None] * eye
        L = self.logm(C, self.LOG_EPS)
        r, c = self.triu[area]
        return L[:, r, c]

    @staticmethod
    def logm(C, eps=1e-12):
        """Reference-free matrix logarithm of a batch of SPD matrices.

        logm(C) = V diag(log ev) V^T with (ev, V) = eigh(C). Kept as a static method so
        the tests can check it against an independent computation -- the truncated power
        series of log(I + N) -- on synthetic matrices, which is not possible through
        `_log_cov` because that always reconstructs C from a window of x.
        """
        ev, V = torch.linalg.eigh(C)                          # ascending eigenvalues
        return (V * ev.clamp_min(eps).log().unsqueeze(1)) @ V.transpose(1, 2)


class FAST_Riemann(FAST):
    """FAST with a reference-free log-Euclidean spatial covariance branch per zone.

    The released path is untouched: same zone encoders, same 5 windows, same 6 tokens,
    same 4 AttentionBlocks. The only difference is that the vector each window hands to
    the transformer is [ 8 zone features | 8 zone covariance readouts ] = 320 wide
    instead of 256, so the model sees spatial second-order structure it structurally
    could not express before.
    """

    name = "FAST_Riemann"
    COV_DIM = 8

    def __init__(self, config):
        super().__init__(config)
        n_zones = len(config.zone_dict)
        self.cov_dim = self.COV_DIM
        self.riemann = RiemannBranch(config.electrodes, config.zone_dict,
                                     out_dim=self.cov_dim)
        # The inherited input_layer is Linear(256->32) and is now the wrong width. It is
        # deleted rather than left in place so it cannot be counted as live parameters by
        # param_report, which would make this arm look bigger than it is.
        del self.input_layer
        self.input_layer = nn.Sequential(
            nn.Linear((config.dim_cnn + self.cov_dim) * n_zones, config.dim_token),
            nn.GELU(),
        )

    def forward_head_cov(self, x):
        """Returns ((B, N, Z, F) zone features, (B, N, Z, cov_dim) covariance readouts).

        The two are computed from the SAME unfolded window, so zone z's covariance and
        zone z's encoder output describe the same 250 samples. Reusing forward_head's
        unfold rather than unrolling x a second time guarantees that.
        """
        x = x.unfold(-1, self.config.window_len, self.config.slide_step)
        B, C, N, T = x.shape
        x = einops.rearrange(x, 'B C N T -> (B N) C T')
        feature = self.head(x)
        feature = einops.rearrange(feature, '(B N) Z F -> B N Z F', B=B)
        cov = self.riemann(x)
        cov = einops.rearrange(cov, '(B N) (Z F) -> B N Z F', B=B, Z=feature.shape[2])
        return feature, cov

    def forward_transformer(self, x, cov):
        x = einops.rearrange(x, 'B N Z F -> B N (Z F)')
        cov = einops.rearrange(cov, 'B N Z F -> B N (Z F)')
        x = self.input_layer(torch.cat((x, cov), dim=-1))
        cls_token_expand = self.cls_token.expand(x.shape[0], -1, -1)
        x = torch.cat((cls_token_expand, x), dim=1)
        x = x + self.pos_embedding[:, :self.n_tokens + 1]
        tokens = self.transformer(x)
        return self.last_layer(self.dropout(tokens[:, 0]))

    def forward(self, x, forward_mode="default"):
        if forward_mode != "default":
            raise NotImplementedError(
                "FAST_Riemann only supports the default forward mode: the other "
                "branches of the parent class call forward_head, which here would "
                "silently drop the covariance branch and evaluate a different model."
            )
        return self.forward_transformer(*self.forward_head_cov(x))


class FAST_SoftZone(FAST):
    """FAST with the hard anatomical zone partition replaced by a learned soft one."""

    name = "FAST_SoftZone"


def _build_softzone(config):
    """Construct FAST while swapping in SoftHead at the single line that builds it.

    FAST.__init__ does `self.head = Head(head, electrodes, zone_dict, dim_cnn)` and Head
    is resolved from the FAST module globals at call time, so patching the module global
    makes SoftHead get built by that one line. Building a FAST and then replacing its
    head would construct a Head first and THROW IT AWAY, drawing a second set of values
    from the global torch RNG; since seed_all(42) runs once before the fold loop, every
    later fold would then initialise from the wrong RNG state. See zone_attn_probe.py's
    make_encoder for the same trap in the training harness, where it was caught by a
    per-trial mismatch against an established result.
    """
    import FAST as FAST_mod
    orig = FAST_mod.Head
    FAST_mod.Head = SoftHead
    try:
        return FAST_SoftZone(config)
    finally:
        FAST_mod.Head = orig


class SpatialAttention(nn.Module):
    """Attention over the electrode tokens, applied independently at every timestep.

    NOT AttentionBlock. AttentionBlock wraps nn.MultiheadAttention and unpacks
    `attn_output, attn_weights = self.attn(...)`, so it materialises the (L, heads, C, C)
    weight tensor, and autograd keeps it. At the released full-batch step L is 280 trials x
    5 windows x 62 steps = 86,800, so that one tensor is 86,800 * 8 * 64 * 64 * 2 B = 5.7 GB.
    F.scaled_dot_product_attention dispatches to the memory-efficient kernels and never
    builds it. Same operation AttentionBlock performs, minus the returned weights.

    The time axis arrives already folded into the batch (L = b*T), so attention runs WITHIN
    one timestep and cannot move information across time. That is the point of folding it:
    the spatial mixing must not smuggle in a temporal average, because a temporal average
    before spatial mixing is exactly what made v1 fail.
    """

    # Largest number of (trial x window x timestep) sequences to hand SDPA in one call.
    # MEASURED, not chosen for taste: at the released full-batch step the sequence count is
    # 280 trials x 5 windows x 62 timesteps = 86,800, and that raises
    # "CUDA error: invalid configuration argument" from inside SDPA -- the memory-efficient
    # kernel's grid carries the batch in a dimension capped at 65,535. A no-grad probe of the
    # same shape succeeds, which is how the failure was localised to the kernel chosen when
    # autograd is on. Chunking the time axis keeps the whole tensor count under the cap
    # without touching the geometry of the attention itself: timesteps never attend to each
    # other, so running them in groups is arithmetically identical.
    MAX_L = 32768

    def __init__(self, dim, n_heads, dropout):
        super().__init__()
        assert dim % n_heads == 0, (dim, n_heads)
        self.h = n_heads
        self.d = dim // n_heads
        self.p_drop = dropout
        self.ln1 = nn.LayerNorm(dim)
        self.qkv = nn.Linear(dim, 3 * dim)
        self.proj = nn.Linear(dim, dim)
        self.ln2 = nn.LayerNorm(dim)
        self.ff = nn.Sequential(nn.Linear(dim, 4 * dim), nn.GELU(), nn.Linear(4 * dim, dim))

    def _chunk(self, x):
        L, C, D = x.shape
        qkv = self.qkv(self.ln1(x)).reshape(L, C, 3, self.h, self.d).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        o = F.scaled_dot_product_attention(
            q, k, v, dropout_p=self.p_drop if self.training else 0.0)
        o = o.transpose(1, 2).reshape(L, C, D)
        x = x + self.proj(o)
        x = x + self.ff(self.ln2(x))
        return x

    def forward(self, x):
        L = x.shape[0]
        if L <= self.MAX_L:
            return self._chunk(x)
        # Assembled only AFTER each chunk is computed, so the retained activations are the
        # chunk's, not one 86,800-row graph.
        return torch.cat([self._chunk(x[i:i + self.MAX_L])
                          for i in range(0, L, self.MAX_L)], dim=0)


# Read by BOTH the class body and _build_spatial, and it must be one value in one place.
# _build_spatial used to fall back to a hardcoded 8 for the head count, which silently
# overrode the class's own 4 and put head_dim back to 4 -- precisely the value that makes
# SDPA refuse every memory-safe backend and fall back to MATH. A default that quietly undoes
# its own documented reason for existing is worse than no default.
SPATIAL_N_HEADS = 4
# 8, not 4, and the reason is memory rather than modelling. At stride 4 the spatial
# attention sees 62 timesteps and one bf16 step OOMs: measured 10.56 GiB allocated plus a
# 680 MiB request against an 11.63 GiB card. At stride 8 it sees 31. Either way the spatial
# mixing is applied at a resolution 30-60x finer than v1's, which averaged the entire 1 s
# window before touching space -- the error this version exists to fix is the ORDER, not the
# resolution, so trading 16 ms for 32 ms is the cheapest 4 GB in the design.
SPATIAL_TIME_STRIDE = 8


class SpatialHead(nn.Module):
    """One shared encoder over the WHOLE montage, plus attention across electrodes.

    THE TWO DEFECTS THIS IS AIMED AT, both measured rather than argued.

    1. There is no spatial attention. `Head.forward` is
       `torch.stack([encoder(x[:, idx[area]]) for area ...], dim=1)`: eight encoders,
       each of which only ever sees its own electrodes, and their outputs are then
       flattened and squeezed through one static Linear(256->32) before the transformer
       runs. So the attention is purely temporal; space is mixed exactly once, by a
       linear map with the same weights for every trial and every window. A filter
       spanning a zone boundary (C3 in Central + CP3 in Post-central) is not merely
       discouraged, it is UNREPRESENTABLE.

    2. The parameter census is badly placed. head = 148,992 of 191,781 (77.7%), split as
       cnn2 32*32*64 = 65,536 for the per-zone spatial mixing and cnn1/cnn3/cnn4 =
       10,432 per zone x 8 = 83,456 for the TEMPORAL convs. The 83,456 are eight
       independently-initialised copies of one architecture, each fitting the same 32x32x5
       temporal filters to the same 280 trials. Nothing about a 20 ms or a 100 ms temporal
       filter is a property of scalp location; the EEG dynamics being filtered are the same
       signal at every electrode. And diagnose.py measured TRAIN 1.0000 / TEST 0.6143 here,
       so capacity is the liability, not the lever.

    THE CHANGE, in one sentence: the montage stops being eight independent patches and
    becomes a set of 64 electrode tokens that attend to each other.

        x (b, 64, T)
          -> tcn1/tcn2/tcn3, SHARED weights, applied per electrode   (b, 32, 64, T')
          -> + learned per-electrode position embedding
          -> attention over the 64 ELECTRODE tokens AT EVERY TIMESTEP (b, 32, 64, T')
          -> mean within each anatomical zone, KEEPING time           (b, 32, 8, T')
          -> mean over time, LAST                                     (b, 8, 32)

    V1 OF THIS ARM WAS WRONG. It is recorded here so the mistake is not repeated. V1 pooled
    over the 246 time samples -- the whole 1 s window -- BEFORE any spatial mixing, so the
    attention saw one time-averaged token per electrode. Measured: paired -0.2566, 0/5
    subjects better, t = -8.24. That is far outside the +-0.06 per-subject jitter the
    `placebo` control measured, so it was not noise. Two candidate explanations were then
    tested and BOTH were refuted by measurement:

      * SCALE -- pos_elec (std 1.00) drowning the temporal feature (std 6.07) so that every
        token was mostly its position embedding. Refuted: ratio 0.16, the feature dominates
        six-to-one, and two different trials move the head output by up to 22.5 where the
        same trial twice moves it by 0.0. The head was input-driven.
      * "THE REFERENCE HAS NO CROSS-ELECTRODE MIXING". That was my own unverified claim and
        it is FALSE. Measured kernel shapes: cnn1 (32,1,1,5) temporal, cnn2 (32,32,n_ch,1)
        -- kernel HEIGHT n_ch, a dense spatial filter that collapses the zone's electrodes
        to 1, with per-zone private weights -- cnn3/cnn4 (32,32,1,5) temporal. The reference
        mixes space exactly once, in cnn2, and it is the single largest parameter block.

    What remains is an ORDERING error, and it is the one thing this version changes. The
    reference's spatial op has kernel height n_ch and WIDTH 1: it is pointwise in time, so it
    acts on the time-resolved tensor (b, 32, n_ch, 246) and the window average happens only
    at the very end. Mixing space before averaging time is what the reference does; v1 did
    the opposite and destroyed every spatio-temporal pattern inside the window.

    The output shape is deliberately the same (b, Z, F) the rest of FAST expects, so the
    transformer, the tokeniser, the window unfold and the training loop are all untouched.
    The zone dict is now used only to pool electrode tokens down to zone tokens at the end.

    WHY THE POSITION EMBEDDING IS NOT OPTIONAL. Sharing one encoder across electrodes
    makes the model blind to which electrode it is looking at, and scalp topography is the
    part of EEG that carries the most signal -- the best hand-built feature out of six
    tried was the one carrying spatial structure (per-band covariance, 0.4015) and the
    worst was the one with none (per-channel power, 0.3623). So identity is restored as a
    learned per-electrode vector rather than by giving every electrode its own weights.

    COST. The head drops from 148,992 parameters to roughly 25k (-83%), with the shared
    temporal filters encoding the "same dynamics everywhere" prior as a hard constraint
    instead of hoping 280 trials impose it eight times over. The price is compute, not
    parameters: attention at every timestep costs ~62x the attention of v1, which is why the
    spatial block uses SDPA (see SpatialAttention) and why tcn3 strides time 4x.

    STATUS. Passes test_spatial.py, including the inverted-leakage assertion that perturbing
    one electrode must move ALL eight zones -- the property the released head provably lacks
    (it moves exactly 1/8). Not yet measured against the baseline.
    """

    # Class attributes, set by _build_spatial before construction. Harmless as class state:
    # they are ints, not trained tensors, so they cannot leak between folds the way
    # Conv4LayersShared._shared would.
    #
    # 4 heads, not the transformer's 8, so head_dim is 8 rather than 4. Two reasons: a
    # 4-dimensional attention subspace is too small to be meaningful, and F.scaled_dot_
    # product_attention's flash kernel requires head_dim to be a multiple of 8 -- at d=4 it
    # would silently fall back to the MATH backend, which materialises the (L, h, C, C)
    # weight matrix that the choice of SDPA exists to avoid. That fallback would OOM at the
    # released full-batch step rather than fail loudly, so the head count is not a free knob.
    N_HEADS = SPATIAL_N_HEADS
    TIME_STRIDE = SPATIAL_TIME_STRIDE

    def __init__(self, head, electrodes, zone_dict, feature_dim):
        super().__init__()
        # `head` is accepted and ignored: FAST.__init__ calls
        # Head(head, electrodes, zone_dict, dim_cnn) and this class replaces Head whole,
        # so there is no per-zone encoder to resolve.
        self.n_zones = len(zone_dict)
        self.n_electrodes = len(electrodes)
        # Zone membership, kept only for the final pooling step. A plain list of CPU index
        # tensors, exactly as the released Head.index_dict does it -- they cannot be
        # stacked into one buffer because the zones have different channel counts (6, 9,
        # 6, 7, 7, 10, 15, 4), and they do not need to be: an index tensor on the CPU is
        # perfectly valid for indexing a CUDA tensor. Being a plain list, they are also
        # invisible to named_parameters() and so cannot enter the optimizer.
        self.zone_index = [torch.tensor([electrodes.index(c) for c in ch])
                           for ch in zone_dict.values()]

        F_ = feature_dim
        self.tcn1 = nn.Conv2d(1, F_, (1, 5), bias=True)
        self.tcn2 = nn.Conv2d(F_, F_, (1, 5), padding=(0, 2), bias=False)
        # Stride on the LAST temporal conv only, so the 4x temporal reduction is a LEARNED
        # strided convolution rather than a mean. It exists to bound the memory the
        # per-timestep attention costs; v1's error was not that a reduction existed but its
        # SIZE -- it averaged all 246 samples of the window into a single number, this keeps
        # 62 steps of 16 ms and so retains within-window structure.
        self.tcn3 = nn.Conv2d(F_, F_, (1, 5), stride=(1, SpatialHead.TIME_STRIDE),
                              padding=(0, 2), bias=False)
        self.pos_elec = nn.Parameter(torch.randn(1, self.n_electrodes, F_))
        self.spatial = SpatialAttention(F_, SpatialHead.N_HEADS, dropout=0.1)

    def forward(self, x):
        """x: (b, C, T) -> (b, Z, F). Same contract as the released Head."""
        x = einops.rearrange(x, 'b c t -> b 1 c t')
        x = self.tcn1(x)
        x = self.tcn2(x)
        x = self.tcn3(x)
        x = F.gelu(x)                              # (b, F, C, T') -- TIME IS STILL ALIVE
        b = x.shape[0]
        # SPACE FIRST. The electrode axis is mixed at every timestep, mirroring the
        # reference's own spatial op (cnn2, kernel (32, 32, n_ch, 1)) which is pointwise in
        # time. Time is folded into the batch, so this attention cannot carry information
        # across timesteps and no temporal average can sneak in ahead of the spatial mixing.
        y = einops.rearrange(x, 'b f c t -> (b t) c f') + self.pos_elec
        y = self.spatial(y)
        y = einops.rearrange(y, '(b t) c f -> b f c t', b=b)
        # TIME LAST. Pool electrode tokens within each anatomical zone, KEEPING time, and
        # only then average the window away -- the order the reference uses.
        idx = self.zone_index
        z = torch.stack([y[:, :, idx[k]].mean(dim=2) for k in range(self.n_zones)], dim=2)
        z = F.gelu(z)                              # (b, F, Z, T')
        return einops.rearrange(z.mean(dim=-1), 'b f z -> b z f')


class FAST_Spatial(FAST):
    """FAST with one montage-wide shared encoder and attention over 64 electrode tokens."""

    name = "FAST_Spatial"


def _build_spatial(config):
    """Construct FAST while swapping SpatialHead in at the single line that builds the head.

    Same trap as _build_softzone: FAST.__init__ does
    `self.head = Head(head, electrodes, zone_dict, dim_cnn)` with Head resolved from the
    FAST module globals at call time. Patching the global makes SpatialHead get built by
    that one line. Building a FAST and then replacing its head would construct a released
    Head first and THROW IT AWAY, drawing a second set of values from the global torch RNG,
    and since seed_all(42) runs once before the fold loop every later fold would initialise
    from the wrong state.
    """
    import FAST as FAST_mod
    SpatialHead.N_HEADS = int(getattr(config, "n_spatial_heads", SPATIAL_N_HEADS))
    SpatialHead.TIME_STRIDE = int(getattr(config, "n_spatial_stride", SPATIAL_TIME_STRIDE))
    orig = FAST_mod.Head
    FAST_mod.Head = SpatialHead
    try:
        return FAST_Spatial(config)
    finally:
        FAST_mod.Head = orig


# variant name -> (zone-encoder class name, model class). The encoder is named as a
# STRING because Head.__init__ resolves it with `Head = globals()[head]` against
# FAST.py's module namespace; _register() writes the new classes into that namespace so
# the lookup succeeds. Keeping the released lookup path means a variant differs from
# base only in the encoder body, not in how the head is assembled.
RESOLVE = {
    "base":       ("Conv4Layers",        FAST),
    "zoneattn":   ("Conv4Layers",        FAST_ZoneAttn),
    "softzone":   ("Conv4Layers",        FAST_SoftZone),
    "nl":         ("Conv4LayersNL",      FAST),
    "nlnorm":     ("Conv4LayersNLNorm",  FAST),
    "sharedtemp": ("Conv4LayersShared",  FAST),
    "bank":       ("Conv4LayersBank",    FAST),
    "bankfrozen": ("Conv4LayersBank",    FAST),
    "riemann":    ("Conv4Layers",        FAST_Riemann),
    "w1":         ("Conv4Layers",        FAST_WholeEpoch),
    "w1std":      ("Conv4LayersMeanStd", FAST_WholeEpochMeanStd),
    "spatial":    ("Conv4Layers",        FAST_Spatial),
    "placebo":    ("Conv4Layers",        FAST),
}


def _register():
    """Publish the variant encoders into FAST.py's namespace so `globals()[head]`
    resolves them. Without this, Head.__init__ raises KeyError on the new head name."""
    import FAST as FAST_mod
    for cls in (Conv4LayersNL, Conv4LayersNLNorm, Conv4LayersShared, Conv4LayersBank,
                Conv4LayersMeanStd):
        setattr(FAST_mod, cls.__name__, cls)


def build(config):
    """Single place the runner asks for a model, so the variant is one string."""
    _register()
    variant = getattr(config, "variant", "base")
    if variant not in RESOLVE:
        raise ValueError("unknown variant %r" % (variant,))
    enc, model = RESOLVE[variant]
    # Head.__init__ will read this back off the config; it is a pure function of the
    # variant, so setting it here keeps the name and the class from drifting apart.
    config.head = enc
    # Conv4LayersShared holds its shared convs in a CLASS attribute, which outlives a
    # single build. Without this reset, the second model built in a process would reuse
    # the first model's shared temporal filters -- i.e. fold 2 would start from fold 1's
    # trained weights. Four folds of a subject train in one process, so this would be
    # silent and would corrupt the arm rather than crash it.
    Conv4LayersShared._shared = None
    # The placebo arm: byte-identical architecture, byte-identical parameter count, one
    # extra draw from the global torch RNG before construction. It changes nothing about
    # the model and everything about the stream the model is built and trained on, which
    # is exactly the confound under test. If placebo scores below base by roughly the
    # amount the small variants do, then those penalties were measuring RNG offsets and
    # not architecture. Build false on purpose -- it must not appear in param_report's
    # totals as if it were a real variant.
    if variant == "placebo":
        torch.randn(1)
    if model is FAST_SoftZone:
        m = _build_softzone(config)
    elif model is FAST_Spatial:
        m = _build_spatial(config)
    else:
        m = model(config)
    # bankfrozen is the same architecture as bank with the filter bank's prior made hard:
    # the kernels keep their band structure for the whole run instead of being free to
    # drift on 280 trials. Freezing is a capacity REDUCTION, which is the direction the
    # overfitting measurement points, so it is a separate arm rather than a default.
    if variant == "bankfrozen":
        for enc in m.head.encoders.values():
            enc.freeze_bank()
    return m


VARIANTS = ("base", "zoneattn", "softzone", "nl", "nlnorm", "sharedtemp",
            "bank", "bankfrozen", "riemann", "w1", "w1std", "spatial", "placebo")


def param_report(config):
    """Count parameters for every variant at the same config."""
    out = {}
    old = getattr(config, "variant", None)
    for v in VARIANTS:
        config.variant = v
        m = build(config)
        named = dict(m.named_parameters())
        # Only zoneattn changes the token set. softzone keeps FAST's original
        # flatten-and-project tokenisation and varies the spatial assignment alone,
        # so that the two defects are not fixed in the same experiment.
        n_tok = m.n_tokens + 1
        if v == "zoneattn":
            n_tok = m.n_tokens * m.n_zones + 1
        out[v] = {
            "total": sum(p.numel() for p in m.parameters()),
            "head": sum(p.numel() for p in m.head.parameters()),
            "transformer": sum(p.numel() for p in m.transformer.parameters()),
            "input_layer": sum(p.numel() for p in m.input_layer.parameters()),
            "pos": sum(p.numel() for n, p in named.items() if "pos" in n),
            "n_tokens": n_tok,
        }
    if old is not None:
        config.variant = old
    else:
        del config.variant
    return out
