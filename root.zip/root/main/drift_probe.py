"""
DOES THE RELEASED SPLIT EVALUATE UNDER SESSION DRIFT?

THE SUSPICION. The released protocol is KFold(5, shuffle=False) over trials in file
order, so every test fold is a CONTIGUOUS BLOCK of 70 trials -- fold 0 is trials
0-69, fold 4 is trials 280-349. If anything in the recording drifts across the
session (electrode impedance, gel drying, subject fatigue, amplifier warm-up), then
train and test are drawn from different parts of that drift and the model is being
scored partly on distribution shift rather than on the neural code.

This is worth checking because the literature reports 60-78% on this competition
while the released protocol gives 54.8-60%, and almost every method reporting the
higher numbers uses a SHUFFLED stratified split. A protocol artefact would explain
that gap without anyone having to be wrong.

IT IS NOT A LABEL-BLOCK ARTEFACT. Checked separately: the labels are uniformly
interleaved (every 100-trial block holds ~20 of each class, lag-1 label
autocorrelation ~0.04), so a non-shuffled split does not put classes in different
folds. Whatever this script finds is drift, not label structure.

TWO MEASUREMENTS
  1. DRIFT MAGNITUDE. Regress each feature on trial index, per subject, and report
     how much of its variance is explained. Then the decisive summary: the distance
     between the first and last 70-trial blocks in units of the within-block trial
     scatter. A small number means no drift and the split is harmless.
  2. ACCURACY COST. Same features, same classifier, KFold(shuffle=False) vs
     StratifiedKFold(shuffle=True). The difference is what the released split pays
     for drift. Both are run on band power AND on raw moments, because a drift that
     hits amplitude hard may leave band power almost untouched, or vice versa.

Read-only, CPU only, seconds. Run: python drift_probe.py
"""

import os
import sys
import numpy as np

from spectral_probe import features, make_clf, band_power, N_PAD
from sklearn.model_selection import KFold, StratifiedKFold

H5 = "Processed/BCIC2020Track3.h5"
OUT = "Results/DRIFT"
BLOCK = 70                      # fold size under the released split
SEED = 42


def fit(F, y, splitter):
    accs = []
    for tr, te in splitter.split(F, y):
        clf = make_clf()
        clf.fit(F[tr], y[tr])
        accs.append(float((clf.predict(F[te]) == y[te]).mean()))
    return float(np.mean(accs))


def drift_stats(F):
    """Slope of each feature on trial index, and the first-block vs last-block
    separation in units of the within-block trial scatter."""
    n = F.shape[0]
    idx = np.arange(n, dtype=np.float64)
    idx = (idx - idx.mean()) / idx.std()
    Fc = F - F.mean(axis=0, keepdims=True)
    Fs = Fc / (Fc.std(axis=0, keepdims=True) + 1e-12)
    r = (Fs * idx[:, None]).mean(axis=0)              # per-feature Pearson r with time

    sd = Fc.std(axis=0) + 1e-12
    a = Fc[:BLOCK].mean(axis=0) / sd                  # first block, in sd units
    b = Fc[-BLOCK:].mean(axis=0) / sd                 # last block
    return r, np.abs(a - b)


def main():
    import h5py
    os.makedirs(OUT, exist_ok=True)
    sys.path.insert(0, "/root/FAST")
    from BCIC2020Track3_preprocess import Electrodes, Zones
    idx = {e: i for i, e in enumerate(Electrodes)}
    zones = [np.array([idx[c] for c in ch]) for ch in Zones.values()]

    print("split A: KFold(5, shuffle=False)      <- released, contiguous test blocks")
    print("split B: StratifiedKFold(5, shuffle=True, seed=%d)" % SEED)
    print("chance 0.2000")
    print("")

    rows = []
    with h5py.File(H5, "r") as f:
        for key in sorted(f.keys()):
            X = f[key]["X"][()].astype(np.float64)
            Y = f[key]["Y"][()]
            if Y.ndim > 1:
                Y = Y.argmax(1)
            fs = features(X, zones)

            bp = band_power(X[:, :, : X.shape[2] - N_PAD])
            bp_flat = np.log10(bp + 1e-12).reshape(bp.shape[0], -1)
            r_bp, d_bp = drift_stats(bp_flat)

            rm_flat = fs["raw_moments"]
            r_rm, d_rm = drift_stats(rm_flat)

            a_bp = fit(fs["bp"], Y, KFold(5, shuffle=False))
            b_bp = fit(fs["bp"], Y, StratifiedKFold(5, shuffle=True, random_state=SEED))
            a_rm = fit(rm_flat, Y, KFold(5, shuffle=False))
            b_rm = fit(rm_flat, Y, StratifiedKFold(5, shuffle=True, random_state=SEED))

            rows.append((a_bp, b_bp, a_rm, b_rm, r_bp, d_bp, r_rm, d_rm))
            print("  %s | acc bp  seq %.4f -> shuf %.4f (%+.4f) | rm  seq %.4f -> shuf %.4f (%+.4f)"
                  % (key, a_bp, b_bp, b_bp - a_bp, a_rm, b_rm, b_rm - a_rm))
            print("      drift: |r| median %.3f max %.3f (%d/%d feats |r|>0.2) | "
                  "blk1-vs-blk5 sep median %.2f sd max %.2f sd"
                  % (np.median(np.abs(r_bp)), np.abs(r_bp).max(),
                     int((np.abs(r_bp) > 0.2).sum()), len(r_bp),
                     np.median(d_bp), d_bp.max()), flush=True)
            del X

    A = np.array([[r[0], r[1], r[2], r[3]] for r in rows])
    print("")
    print("=== ACCURACY: RELEASED SPLIT vs SHUFFLED STRATIFIED ===")
    for j, (nm, i0) in enumerate([("bp", 0), ("raw_moments", 2)]):
        seq, shf = A[:, i0], A[:, i0 + 1]
        d = shf - seq
        se = d.std(ddof=1) / np.sqrt(len(d))
        print("  %-12s sequential %.4f   shuffled %.4f   diff %+.4f (se %.4f, t=%.2f)"
              % (nm, seq.mean(), shf.mean(), d.mean(), se, d.mean() / se))
    print("")
    print("=== DRIFT MAGNITUDE ===")
    allr = np.concatenate([np.abs(r[4]) for r in rows])
    alld = np.concatenate([r[5] for r in rows])
    print("  band power: |r with trial index| median %.4f  mean %.4f  (n=%d)"
          % (np.median(allr), allr.mean(), len(allr)))
    print("  band power: first-block vs last-block separation, median %.3f sd, max %.3f sd"
          % (np.median(alld), alld.max()))
    allr2 = np.concatenate([np.abs(r[6]) for r in rows])
    alld2 = np.concatenate([r[7] for r in rows])
    print("  raw moments: |r| median %.4f  | first-vs-last median %.3f sd max %.3f sd"
          % (np.median(allr2), np.median(alld2), alld2.max()))
    print("")
    print("  Reading: a median |r| near 0 and first-vs-last separation well under 1 sd")
    print("  means the recording is stationary and the released split costs nothing.")
    print("  A separation of several sd means test folds sit off the training")
    print("  distribution, and the shuffled column is the size of that penalty.")
    np.savez("%s/summary.npz" % OUT, A=A, rows=np.array(rows, dtype=object))
    print("DRIFT_DONE")


if __name__ == "__main__":
    main()
