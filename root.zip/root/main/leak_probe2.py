"""DECOMPOSITION of the leakage: is the decodable information a GLOBAL per-trial scale,
a SPECTRAL shape, or a SPATIAL pattern?

Why this decides the whole modelling programme. analyze_leak.py found the pre-cue and
full-epoch channel maps are flat (top5/median 1.06x, 0/64 channels above chance) yet the
all-channel decode works (0.2943 / 0.3709), correlated at r=+0.48 across subjects, with
occipital DEAD LAST. Broadband, scalp-wide, task-absent, same map in and out of task.

If that is a per-trial global amplitude offset, then it is a scalar per trial and NO
spatial architecture can be a fix for it -- a smoothness prior, a zone partition, an
attention map all act on the spatial pattern, which would be the wrong object. If instead
the information survives removing the global offset, it is a genuine spatial/spectral
pattern and spatial modelling is back on the table. So this is the gate, not a detail.

F is (trials, channels, bands) log band power. Four views of the SAME folds:
  raw    no centring -- the control, reproduces leak_probe.py
  gmean  F - mean over (channel, band) per trial   kills the global per-trial scalar
  spat   F - mean over channels per (trial, band)  kills the common mode in each band,
                                                   keeps the spatial pattern
  spec   F - mean over bands per (trial, channel)  kills broadband level per electrode,
                                                   keeps the spectral shape

CPU only, no GPU, no training:
    /root/venv_fast/bin/python -u leak_probe2.py --subjects 0-14
"""

import argparse
import os

import h5py
import numpy as np

from leak_probe import (BANDS, BASE_SLICE, FULL_SLICE, H5, band_power, cv_acc,
                        stack_bands)

RUN = "Results/LEAK2"
MODES = ("raw", "gmean", "spat", "spec")


def centre(F, mode):
    """F (trials, ch, band) or (trials, ch). Centring only, no scaling: the question is
    whether OFFSET carries the label, and a variance change would confound it."""
    if mode == "raw":
        return F
    if F.ndim == 2:
        if mode == "gmean":
            return F - F.mean(axis=1, keepdims=True)
        if mode == "spat":
            return F - F.mean(axis=1, keepdims=True)
        if mode == "spec":
            return F                     # no band axis -> spectral centring is undefined
    if mode == "gmean":
        return F - F.mean(axis=(1, 2), keepdims=True)
    if mode == "spat":
        return F - F.mean(axis=1, keepdims=True)
    if mode == "spec":
        return F - F.mean(axis=2, keepdims=True)
    raise ValueError(mode)


def acc(F2, Y, mode):
    F = centre(F2, mode)
    return cv_acc(F.reshape(len(Y), -1), Y)[0].mean()


def run_subject(sid):
    with h5py.File(H5, "r") as f:
        X = f[sid]["X"][:].astype(np.float64)
        Y = f[sid]["Y"][:].astype(int)

    res = {}
    for seg, (a, b) in (("full", FULL_SLICE), ("base", BASE_SLICE)):
        Xs = X[:, :, a:b]
        F6 = stack_bands(Xs, list(BANDS))            # (T, 64, 6)
        Fh = band_power(Xs, 40.0, 127.0)             # (T, 64)
        Fl = band_power(Xs, 1.0, 40.0)
        for mode in MODES:
            res["%s_6band_%s" % (seg, mode)] = acc(F6, Y, mode)
            res["%s_high40_%s" % (seg, mode)] = acc(Fh, Y, mode)
            res["%s_low40_%s" % (seg, mode)] = acc(Fl, Y, mode)
        _, chance = cv_acc(F6.reshape(len(Y), -1), Y)
        res["%s_chance" % seg] = chance
        print("  [%s] raw6 %.4f | gmean %.4f | spat %.4f | spec %.4f  (high40 raw %.4f)"
              % (seg, res["%s_6band_raw" % seg], res["%s_6band_gmean" % seg],
                 res["%s_6band_spat" % seg], res["%s_6band_spec" % seg],
                 res["%s_high40_raw" % seg]), flush=True)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--subjects", type=str, default="0-14")
    ap.add_argument("--out", type=str, default=RUN)
    a = ap.parse_args()

    lo, hi = (int(v) for v in a.subjects.split("-"))
    todo = list(range(lo, hi + 1))
    os.makedirs(a.out, exist_ok=True)
    for s in todo:
        f = "%s/%d-decomp.npz" % (a.out, s)
        if os.path.exists(f):
            print("  skip %02d" % s, flush=True)
            continue
        print("[subj %02d]" % (s + 1), flush=True)
        np.savez(f, **run_subject("%02d" % (s + 1)))
        print("  [saved %s]" % f, flush=True)

    keys = ["%s_%s_%s" % (seg, band, mode)
            for seg in ("full", "base")
            for band in ("6band", "high40", "low40")
            for mode in MODES]
    acc = {k: [] for k in keys}
    chance = []
    for s in todo:
        f = "%s/%d-decomp.npz" % (a.out, s)
        if not os.path.exists(f):
            continue
        d = np.load(f, allow_pickle=True)
        for k in keys:
            acc[k].append(d[k])
        chance.append(d["base_chance"])

    print("\n" + "=" * 78)
    print("DECOMPOSITION -- n=%d, chance %.4f" % (len(chance), np.mean(chance)))
    print("=" * 78)
    print("%-8s %-8s %-8s %-8s %-8s %s"
          % ("segment", "bands", "raw", "gmean", "spat", "spec"))
    for seg in ("full", "base"):
        for band in ("6band", "high40", "low40"):
            v = [np.mean(acc["%s_%s_%s" % (seg, band, m)]) for m in MODES]
            print("%-8s %-8s %-8.4f %-8.4f %-8.4f %-8.4f" % (seg, band, *v))

    print("\npaired vs raw, per subject (n=%d):" % len(chance))
    for seg in ("full", "base"):
        for band in ("6band", "high40", "low40"):
            r = np.array(acc["%s_%s_raw" % (seg, band)])
            for m in ("gmean", "spat", "spec"):
                d = np.array(acc["%s_%s_%s" % (seg, band, m)]) - r
                t = d.mean() / (d.std(ddof=1) / np.sqrt(len(d))) if d.std(ddof=1) else 0.0
                print("  %-5s %-7s %-6s %+.4f   t %+5.2f   up %2d/%d"
                      % (seg, band, m, d.mean(), t, int((d > 0).sum()), len(d)))
    print("LEAK2_DONE", flush=True)


if __name__ == "__main__":
    main()
