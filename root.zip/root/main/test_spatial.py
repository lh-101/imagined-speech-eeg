"""
Ground-truth checks for fast_zones.SpatialHead / FAST_Spatial.

The claim of this arm is exactly two things, and each needs a test that would FAIL if the
claim were false:

  1. THE ENCODER IS SHARED OVER THE WHOLE MONTAGE. One set of temporal convs, applied to
     all 64 electrodes. If the code had quietly kept per-electrode copies, the parameter
     count would say so -- and it does, so this is checked as arithmetic.

  2. ELECTRODES ATTEND TO EACH OTHER. This is the whole point, and it is the exact
     OPPOSITE of a property the released model has. test_zones.py asserts for base that
     perturbing one channel leaves the other seven zones COMPLETELY BLIND. Here the
     assertion must invert: a perturbation on one electrode has to reach every zone,
     because attention over electrode tokens mixes them. If this test reports "no leakage",
     the arm has failed to do the one thing it exists to do, however good its accuracy.

  3. IDENTITY IS CARRIED BY pos_elec. Sharing the encoder makes the model blind to which
     electrode it is looking at, so the learned per-electrode vector is load-bearing, not
     decoration. Checked by permutation equivariance: permute the electrode axis of the
     input, permute pos_elec and the zone index the same way, and the head output must come
     back the same. If anything else secretly depends on electrode order, this fails.

Run on the training box (needs torch): python test_spatial.py
"""

import sys
import torch
from transformers import PretrainedConfig

sys.path.insert(0, "/root/FAST")
from BCIC2020Track3_preprocess import Electrodes, Zones
from FAST import FAST
from fast_zones import FAST_Spatial, build, param_report


def cfg(variant):
    return PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1, variant=variant,
    )


def capture_head_output(model, x):
    """The head's output, shaped (B*N, Z, F).

    NOT (B, N, Z, F): FAST.forward_head flattens B and N into one axis before calling the
    head and only reshapes back afterwards, so the hook sees the flattened form. Callers
    that index it as if the window axis were dim 1 are wrong -- with a batch of 2 the rows
    5..9 are batch 1's five windows, not extra windows of batch 0, and a per-window
    assertion silently reads the wrong rows. Pass a batch of ONE.
    """
    seen = {}
    h = model.head.register_forward_hook(
        lambda m, i, o: seen.__setitem__("o", o.detach().clone()))
    with torch.no_grad():
        model(x)
    h.remove()
    o = seen["o"]
    assert o.dim() == 3 and o.shape[0] == x.shape[0] * model.n_tokens, \
        "unexpected head output shape %s for input %s" % (tuple(o.shape), tuple(x.shape))
    return o


def main():
    torch.manual_seed(0)
    x = torch.randn(2, len(Electrodes), 800)
    # build(), not FAST_Spatial(...) directly: the head is swapped in by _build_spatial
    # patching FAST.Head during construction, so constructing the class by hand silently
    # gives you the RELEASED head and tests the wrong model.
    m = build(cfg("spatial"))
    # eval() is REQUIRED here, not cosmetic. The hook below captures the head output,
    # which is downstream of the spatial AttentionBlock's dropout; in train mode two
    # forward passes draw different masks and every token "moves" for free.
    # test_zones.py escapes this only because its hook is on the transformer INPUT,
    # upstream of any dropout. Any comparison of two forward passes must be in eval.
    m.eval()

    # ---- 1. parameter accounting ----
    rep = param_report(cfg("base"))
    b, s = rep["base"], rep["spatial"]
    print("  base    total %d  head %d  tokens %d" % (b["total"], b["head"], b["n_tokens"]))
    print("  spatial total %d  head %d  tokens %d" % (s["total"], s["head"], s["n_tokens"]))
    assert s["n_tokens"] == b["n_tokens"] == 6, "the downstream token contract changed"
    assert s["total"] < b["total"], "variant is not the smaller model"
    assert s["head"] < b["head"] // 4, "head did not shrink as the sharing predicts"
    print("  ok  %+d params total, head %d -> %d, token count untouched"
          % (s["total"] - b["total"], b["head"], s["head"]))

    # one shared set of temporal convs, and no per-electrode module list
    assert not hasattr(m.head, "encoders"), "a per-zone encoder dict survived"
    convs = [n for n, mod in m.head.named_modules() if isinstance(mod, torch.nn.Conv2d)]
    assert sorted(convs) == ["tcn1", "tcn2", "tcn3"], convs
    print("  ok  exactly three convs, shared: %s" % convs)

    # ---- 2. electrodes attend to each other: EVERY zone must see the perturbation ----
    zone = "Occipital"
    zone_ch = [Electrodes.index(c) for c in Zones[zone]]
    zi = list(Zones).index(zone)
    ch = zone_ch[0]

    # A BATCH OF ONE, deliberately. The hook sees (B*N, Z, F), so with B=2 the rows 5..9 are
    # batch 1's five windows rather than extra windows of batch 0, and `moved[2:]` would then
    # read batch 1's window 0 -- which DOES move, because xb perturbs every batch element.
    # That was a real failure of this test, not of the model: the leak was batch axis, not
    # attention. B=1 makes dim 0 the window axis outright.
    x1 = x[:1]
    xb = x1.clone()
    xb[:, ch, 0:250] += 50.0        # samples 0-249: window 0 in full, window 1 by half
    # subtract FIRST, then abs: taking abs of each capture and subtracting compares
    # magnitudes, so a token that merely grows would read as "did not move".
    tb = capture_head_output(m, x1).amax(dim=-1)              # (N, Z)
    tp = capture_head_output(m, xb).amax(dim=-1)
    moved = ((tb - tp).abs() > 1e-6)

    N, Z = m.n_tokens, m.head.n_zones
    # within the perturbed windows, ALL zones must move -- this is the inversion of
    # test_zones.py's "no leakage into the other 7 zones"
    assert moved[0].all() and moved[1].all(), \
        "zones stayed blind inside the perturbed window: %s" % moved[0].nonzero().flatten().tolist()
    # and windows that cannot overlap must be untouched (attention is per-window)
    assert not moved[2:].any(), \
        "perturbation reached a window it cannot overlap"
    print("  perturbed electrode %s (zone '%s'); moved windows %s, all %d zones in each"
          % (Electrodes[ch], zone, moved.any(dim=1).nonzero().flatten().tolist(), Z))
    print("  ok  every zone moves -- electrodes are NOT blind to each other")

    # the released head, by contrast, is blind on purpose. Assert the difference is real
    # rather than assuming it: this is the property the arm is meant to change.
    mb = FAST(cfg("base")).eval()
    f = mb.head(x[:1, :, 0:250])
    fb, fp = f, mb.head(xb[:1, :, 0:250])
    base_moved = ((fb - fp).abs().amax(dim=-1) > 1e-6)
    assert base_moved.sum() == 1, \
        "released head moved %d zones; expected exactly 1" % int(base_moved.sum())
    print("  ok  released head moves %d/8 zones on the same input (the defect, measured)"
          % int(base_moved.sum()))

    # ---- 3. pos_elec is the only carrier of electrode identity ----
    n_elec = len(Electrodes)
    perm = torch.randperm(n_elec, generator=torch.Generator().manual_seed(0))
    inv = torch.empty(n_elec, dtype=torch.long)
    inv[perm] = torch.arange(n_elec)

    mp = build(cfg("spatial")).eval()
    mp.load_state_dict(m.state_dict())
    mp.head.pos_elec.data = m.head.pos_elec.data[:, perm, :].clone()
    mp.head.zone_index = [inv[zi_] for zi_ in m.head.zone_index]

    with torch.no_grad():
        o0 = m.forward_head(x)
        o1 = mp.forward_head(x[:, perm, :])
    dmax = (o0 - o1).abs().max().item()
    assert dmax < 1e-5, "electrode permutation changed the output by %g" % dmax
    print("  ok  permuting electrodes + pos_elec + zone index leaves the head output "
          "unchanged (max|d| = %.2e)" % dmax)

    # pos_elec must actually be used: zeroing it changes the output
    mp2 = build(cfg("spatial")).eval()
    mp2.load_state_dict(m.state_dict())
    mp2.head.pos_elec.data.zero_()
    with torch.no_grad():
        o2 = mp2.forward_head(x)
    assert (o0 - o2).abs().max().item() > 1e-3, "zeroing pos_elec changed nothing"
    print("  ok  zeroing pos_elec does change the output: it is load-bearing")

    # ---- 4. output shape, finiteness, gradient flow ----
    m.zero_grad()
    out = m(x)
    assert out.shape == (2, 5), out.shape
    assert torch.isfinite(out).all(), "non-finite logits"
    out.sum().backward()
    g = m.head.pos_elec.grad
    assert g is not None and torch.isfinite(g).all() and g.abs().sum() > 0, \
        "pos_elec got no gradient"
    sp = [n for n, p in m.head.spatial.named_parameters()
          if p.grad is None or p.grad.abs().sum() == 0]
    assert not sp, "spatial attention received no gradient: %s" % sp
    print("  ok  output %s finite; pos_elec and the spatial attention both train"
          % (tuple(out.shape),))

    # ---- 5. the inherited non-default modes remain valid (Z stayed 8) ----
    for mode in ("train_head", "train_transformer"):
        o = m(x, forward_mode=mode)
        assert o.shape == (2, 5), (mode, o.shape)
    print("  ok  train_head / train_transformer still compute (Z is unchanged at 8)")

    # ---- 6. dispatch ----
    assert isinstance(build(cfg("spatial")), FAST_Spatial)
    print("  ok  build() dispatches on config.variant")

    print("ALL_TESTS_PASSED")


if __name__ == "__main__":
    main()
