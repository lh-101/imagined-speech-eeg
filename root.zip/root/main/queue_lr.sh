#!/bin/bash
# The decisive experiment: is the architecture penalty real, or is it a schedule mismatch?
#
# Everything so far (zoneattn -0.047, bankfrozen -0.035, bank -0.020, nl -0.006) lost in
# an order that tracks HOW MUCH each change perturbed the optimisation problem, not which
# direction it moved. That is the signature of a fixed optimisation budget charging every
# variant for a mismatch with the released architecture it was co-tuned against.
#
# So vary the budget, holding the architecture fixed, for both the released model and the
# variant that lost the most:
#   base     at 1e-3 and 2e-4  -- the control. If base itself collapses away from 5e-4,
#                                 the released point is a sharp optimum and small edits
#                                 cannot win; the answer is a LARGE structural move.
#   zoneattn at 1e-3 and 2e-4  -- if its -0.047 shrinks toward 0, the penalty was the
#                                 schedule and every architecture comparison in this
#                                 literature (and all of ours) is confounded.
#   zoneattn at 400 steps      -- the separate hypothesis that 41 tokens are simply not
#                                 trained in 200 steps.
#
# 5 subjects, not 15. The point is the SIGN and SIZE of the change, and a paired
# difference of this magnitude (0.047 against a paired sd of ~0.033) is already 3 SEM at
# n=5. Full 15-subject runs wait until one of these says something.
#
# Serial, one arm at a time, for the reason measured on this box: two concurrent arms run
# 4.6 min/subject each, i.e. 2.3 aggregate, against 1.6 serial.
cd /root/FAST || exit 1
P=/root/venv_fast/bin/python
A="--subjects 0-4"

echo "=== base lr=1e-3 START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant base --lr 1e-3 $A
echo "=== zoneattn lr=1e-3 START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant zoneattn --lr 1e-3 $A
echo "=== base lr=2e-4 START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant base --lr 2e-4 $A
echo "=== zoneattn lr=2e-4 START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant zoneattn --lr 2e-4 $A
echo "=== zoneattn 400 steps START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant zoneattn --epochs 400 $A
echo QUEUE_LR_DONE
