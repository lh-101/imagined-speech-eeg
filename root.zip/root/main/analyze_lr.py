"""
Did the step size cause the architecture penalty, or is the architecture really worse?

THE PROBLEM. A plain table of "zoneattn at lr 1e-3 scores X" answers nothing. If moving the
lr away from 5e-4 hurts EVERY architecture -- which it will, because 5e-4 is the point the
released model's authors tuned at -- then zoneattn scoring lower at 1e-3 is evidence about
the schedule, not about zoneattn. What carries the information is the per-subject
difference in differences:

    D[s] = [zoneattn(lr,s) - zoneattn(5e-4,s)] - [base(lr,s) - base(5e-4,s)]

  * near 0 -> the penalty is the same at every step size. The schedule is not the
              confound, the architecture is genuinely worse under this data budget, and lr
              tuning will not rescue it.
  * strongly positive -> the penalty shrinks when the variant gets its own step size, so
              part of the released-schedule penalty was mismatch.

Both outcomes are informative and point in opposite directions, which is why the base arms
at 1e-3 and 2e-4 exist at all: a variant-only sweep is uninterpretable.

WHY THE CONTRAST IS PAIRED PER SUBJECT. All four arms for a subject run the same
KFold(5, shuffle=False) split of that subject's own trials and the runner calls seed_all(42)
per subject, so fold boundaries are identical across arms. Taking the contrast within
subject and then averaging cancels the between-subject spread (base has sd 0.0885 across
subjects) instead of counting it as noise. This is the ONLY correct way to form the SE:
the two group-level penalties share two of their four arms, so their SEMs cannot be
combined. It matters -- at n=5 the quadrature formula sqrt(se_c^2 + se_0^2) gives t=1.38
where the per-subject DiD gives t=1.64, and the error is largest exactly where the two
schedules are closest. The quadrature number is printed below, labelled DO NOT USE, only so
the size of the mistake is visible.

WHY THE VERDICT ALSO GETS A PERMUTATION p. The per-subject DiD has 15 values and no
replication on the seed dimension (seed_all(42) is called once per subject, so every arm
shares one init draw). Under the exchangeability null -- the arch gap is invariant to lr --
the sign of each D[s] is exchangeable, so the exact null distribution is the 2^15 sign-flip
enumeration. That is the honest small-n answer and it costs nothing.

WHAT THIS CANNOT DISTINGUISH. With 1 gradient step per epoch, "lr" is also "distance
travelled", so a positive DiD is equally consistent with "cand pays a mismatch fee" and
"cand is under-trained". Section 5 addresses this with a matched-displacement control and
only reports the fee reading if the control agrees.

Reads Results/ZA/*.npz only; trains nothing. Safe to run while the queue is going -- every
section reports the subjects it actually has and no section aborts the ones after it.
"""

import os
import re
from itertools import product

import numpy as np

RUN = "Results/ZA"
BASE = "base-h8"                 # released model, released schedule
VAR = "zoneattn-h8"              # the variant that lost the most at 5e-4

# (label, base arm, variant arm, lr)
LR_ARMS = [
    ("2e-4", "base-h8-lr0.0002", "zoneattn-h8-lr0.0002", 2e-4),
    ("1e-3", "base-h8-lr0.001", "zoneattn-h8-lr0.001", 1e-3),
]
RELEASED_LR = 5e-4
# (label, base arm, variant arm) at 4x the steps, released lr -- the under-training control
STEP_ARMS = [
    ("400 steps", "base-h8-ep400", "zoneattn-h8-ep400"),
]

# Pre-registered BEFORE the n=15 numbers existed, so neither outcome can be rationalised
# after the fact. |t| >= 2 AND positive -> the schedule is a confound and every architecture
# comparison must be matched-budget. Anything else -> the architecture is genuinely worse
# and the next move is structural. The permutation p is reported alongside but the rule was
# written on t; it is not to be swapped for p after seeing the numbers.
T_VERDICT = 2.0
SCREEN = [0, 1, 2, 3, 4]         # the subjects the n=5 screen used; an easier subset


def avail(tag):
    if not os.path.isdir(RUN):
        return set()
    return {int(m.group(1)) for fn in os.listdir(RUN)
            if (m := re.match(r"^(\d+)-%s\.npz$" % re.escape(tag), fn))}


def subj_set(*tags):
    sets = [avail(t) for t in tags]
    return sorted(set.intersection(*sets)) if sets else []


def load(tag, subjects, folds=False):
    """Per-subject accuracy, and optionally per-fold accuracy, for `subjects`."""
    acc, fld = [], []
    for s in subjects:
        z = np.load(os.path.join(RUN, "%d-%s.npz" % (s, tag)))
        c, fo = z["correct"], z["fold_of"]
        acc.append(c.mean())
        if folds:
            fld.append([c[fo == f].mean() for f in range(int(fo.max()) + 1)])
    return (np.array(acc), np.array(fld)) if folds else np.array(acc)


def tt(d):
    """Paired mean, SEM, t for a per-subject difference vector."""
    n = len(d)
    if n < 2:
        return d.mean() if n else float("nan"), float("nan"), float("nan")
    se = d.std(ddof=1) / np.sqrt(n)
    return d.mean(), se, (d.mean() / se if se > 0 else float("nan"))


def signflip_p(d):
    """Exact two-sided p over all 2^n sign patterns. n<=16, else sampled."""
    d = np.asarray(d, float)
    n = len(d)
    obs = abs(d.mean())
    if n > 16:
        rng = np.random.default_rng(0)
        s = rng.choice([1.0, -1.0], size=(200000, n))
    else:
        s = np.array(list(product((1.0, -1.0), repeat=n)))
    hits = (np.abs(s @ d / n) >= obs - 1e-12).sum()
    return hits / len(s)


def main():
    if not os.path.isdir(RUN):
        print("no %s -- run this on the remote" % RUN)
        return

    # ------------------------------------------------------------------ 0
    print("=== 0. WHAT IS ON DISK ===")
    tags = [BASE, VAR] + [t for _, b, v, _ in LR_ARMS for t in (b, v)] \
        + [t for _, b, v in STEP_ARMS for t in (b, v)]
    for tag in tags:
        s = avail(tag)
        if s:
            a = load(tag, sorted(s))
            print("  %-22s n=%2d  mean %.4f  sd %.4f" % (tag, len(s), a.mean(),
                                                         a.std(ddof=1)))
        else:
            print("  %-22s --" % tag)

    # Is the screen subset representative? This is not bookkeeping: if subjects 0-4 are
    # easier, the DiD measured on them is not obviously the DiD on the rest.
    b_all = avail(BASE)
    if len(b_all) >= 6:
        b = load(BASE, sorted(b_all))
        m = np.array([s in SCREEN for s in sorted(b_all)])
        print("  base by subgroup: screen(0-4) %.4f (n=%d)   rest %.4f (n=%d)   gap %+.4f"
              % (b[m].mean(), m.sum(), b[~m].mean(), (~m).sum(),
                 b[m].mean() - b[~m].mean()))
    print("")

    # ------------------------------------------------------------------ 1
    s0 = subj_set(BASE, VAR)
    print("=== 1. THE PENALTY AT THE RELEASED SCHEDULE, n=%d ===" % len(s0))
    if len(s0) < 2:
        print("  not enough subjects yet")
        print("LR_ANALYSIS_DONE")
        return
    b5, f5 = load(BASE, s0, folds=True)
    v5, g5 = load(VAR, s0, folds=True)
    pen0 = v5 - b5
    m0, se0, t0 = tt(pen0)
    print("  base      %.4f" % b5.mean())
    print("  zoneattn  %.4f" % v5.mean())
    print("  penalty   %+.4f  se %.4f  t %+5.2f   (%d/%d subjects worse)"
          % (m0, se0, t0, int((pen0 < 0).sum()), len(pen0)))
    print("")

    # ------------------------------------------------------------------ 2
    print("=== 2. THE DECISIVE NUMBER: per-subject difference in differences ===")
    print("  D[s] = (zoneattn_lr - zoneattn_5e-4) - (base_lr - base_5e-4), same fold split")
    dids = []
    for label, b_tag, v_tag, lr in LR_ARMS:
        s = subj_set(BASE, VAR, b_tag, v_tag)
        if len(s) < 2:
            print("  %-6s (not finished -- on disk: %s)"
                  % (label, {t: len(avail(t)) for t in (BASE, VAR, b_tag, v_tag)}))
            continue
        bl = load(b_tag, s)
        vl = load(v_tag, s)
        db, dv = bl - load(BASE, s), vl - load(VAR, s)
        D = dv - db
        m, se, t = tt(D)
        p = signflip_p(D)
        ml, sel, tl = tt(vl - bl)
        r = np.corrcoef(db, dv)[0, 1] if db.std() > 0 and dv.std() > 0 else float("nan")

        print("  %-6s n=%2d   base %.4f (%+.4f)   zoneattn %.4f (%+.4f)"
              % (label, len(s), bl.mean(), db.mean(), vl.mean(), dv.mean()))
        print("         penalty %.4f -> %+.4f    change %+.4f  se %.4f  t %+5.2f  p %.4f"
              % (m0, ml, m, se, t, p))
        print("         variance check: sd(D) %.4f | sd cand %.4f  sd base %.4f  r %+.2f"
              "  -> predict %.4f"
              % (D.std(ddof=1), dv.std(ddof=1), db.std(ddof=1), r,
                 np.sqrt(max(dv.std(ddof=1) ** 2 + db.std(ddof=1) ** 2
                             - 2 * r * dv.std(ddof=1) * db.std(ddof=1), 0))))
        se_q = np.sqrt(se0 ** 2 + sel ** 2)
        print("         quadrature on the two arm-level penalties: %+.4f se %.4f t %+5.2f"
              "   DO NOT USE" % (m, se_q, m / se_q if se_q > 0 else float("nan")))
        print("         what cand actually gained: %+.4f   (D differs by base's %+.4f,"
              " which D credits to cand)" % (dv.mean(), db.mean()))
        print("         per subject D: %s" % " ".join("%+.3f" % x for x in D))
        print("         %d of %d positive" % (int((D > 0).sum()), len(D)))

        # pre-specified subgroup: the 5 screen subjects vs the subjects added afterwards
        sm = np.array([x in SCREEN for x in s])
        if sm.sum() >= 2 and (~sm).sum() >= 2:
            ms, ses, ts = tt(D[sm])
            ma, sea, ta = tt(D[~sm])
            print("         screen(0-4) %+.4f (t %+5.2f, n=%d) | added %+.4f "
                  "(t %+5.2f, n=%d)" % (ms, ts, sm.sum(), ma, ta, (~sm).sum()))
        dids.append((label, m, se, t, p, len(s), D))
    print("")

    # ------------------------------------------------------------------ 3
    print("=== 3. VERDICT (rule fixed before the numbers: |t|>=%g and positive)" % T_VERDICT)
    if not dids:
        print("  no lr arm finished yet")
    for label, m, se, t, p, n, D in dids:
        if not np.isfinite(t) or abs(t) < T_VERDICT:
            v = ("UNRESOLVED at lr %s (%+.4f, t=%+.2f, p=%.3f, n=%d). Not enough evidence "
                 "that the schedule is the confound; treat the penalty as real until a "
                 "larger-n or better-powered arm says otherwise." % (label, m, t, p, n))
        elif m < 0:
            v = ("PENALTY GROWS at lr %s (%+.4f, t=%+.2f, p=%.3f, n=%d). The variant sits "
                 "further from the released optimum than base does -- the released "
                 "schedule is not what is holding it back." % (label, m, t, p, n))
        else:
            v = ("CONFOUND at lr %s: penalty shrinks %+.4f (t=%+.2f, p=%.3f, n=%d). Part "
                 "of the released-schedule penalty was mismatch, so architecture "
                 "comparisons here must be matched-budget." % (label, m, t, p, n))
        print("  lr %-6s %s" % (label, v))
    print("")

    # ------------------------------------------------------------------ 4
    print("=== 4. DOSE-RESPONSE: does the penalty track distance from 5e-4? ===")
    print("  %-9s %-6s %-22s %-22s" % ("lr", "n", "base", "zoneattn"))
    lvls = []
    for lr, b_tag, v_tag in sorted([(RELEASED_LR, BASE, VAR)]
                                   + [(lr, b, v) for _, b, v, lr in LR_ARMS]):
        s = subj_set(b_tag, v_tag)
        if len(s) < 2:
            print("  %-9g (not finished)" % lr)
            continue
        bl, vl = load(b_tag, s), load(v_tag, s)
        p = vl - bl
        m, se, t = tt(p)
        print("  %-9g %-6d %.4f                 %.4f   pen %+.4f (t %+5.2f)"
              % (lr, len(s), bl.mean(), vl.mean(), m, t))
        lvls.append((lr, s, bl, vl))

    # With three lr levels the DiD can be estimated as a per-subject slope in log10(lr),
    # which is ~2.3x more precise than one two-point DiD because it uses all three cells.
    if len(lvls) == 3:
        s3 = subj_set(BASE, VAR, *[t for _, b, v, _ in LR_ARMS for t in (b, v)])
        if len(s3) >= 2:
            x = np.log10([lr for lr, _, _, _ in lvls])
            x = x - x.mean()
            P = np.vstack([load(v, s3) - load(b, s3) for _, _, b, v in lvls])
            slope = (x @ P) / (x @ x)          # per-subject slope per decade of lr
            m, se, t = tt(slope)
            span = np.log10(1e-3) - np.log10(RELEASED_LR)
            print("  per-subject slope over 3 lr levels: %+.4f per decade (t %+5.2f, "
                  "n=%d)" % (m, t, len(s3)))
            print("  predicted penalty change over 5e-4 -> 1e-3: %+.4f  (the two-point "
                  "estimate is in section 2)" % (m * span))
    print("")

    # ------------------------------------------------------------------ 5
    print("=== 5. OR IS THE VARIANT SIMPLY UNDER-TRAINED? (4x steps, released lr) ===")
    print("  1 step/epoch means lr IS distance travelled, so a positive DiD is equally")
    print("  consistent with 'mismatch fee' and 'cand needs more optimisation'. This")
    print("  needs BOTH arms at 400 steps to be a matched-displacement contrast.")
    for label, b_tag, v_tag in STEP_ARMS:
        s = subj_set(b_tag, v_tag)
        if len(s) < 2:
            print("  %-10s (not finished -- base %d, zoneattn %d subjects)"
                  % (label, len(avail(b_tag)), len(avail(v_tag))))
            continue
        bl, vl = load(b_tag, s), load(v_tag, s)
        D = (vl - bl)
        m, se, t = tt(D)
        print("  at %s: base %.4f  zoneattn %.4f  gap %+.4f  se %.4f  t %+5.2f  (n=%d)"
              % (label, bl.mean(), vl.mean(), m, se, t, len(s)))
        s250 = subj_set(BASE, VAR, b_tag, v_tag)
        if len(s250) >= 2:
            g5 = load(VAR, s250) - load(BASE, s250)
            g4 = load(v_tag, s250) - load(b_tag, s250)
            dd = g4 - g5
            m2, se2, t2 = tt(dd)
            print("           gap change 200->400 steps %+.4f  se %.4f  t %+5.2f  "
                  "(zoneattn %+.4f, base %+.4f)"
                  % (m2, se2, t2, (load(v_tag, s250) - load(VAR, s250)).mean(),
                     (load(b_tag, s250) - load(BASE, s250)).mean()))
    print("")

    # ------------------------------------------------------------------ 6
    print("=== 6. CEILING CHECK: is the DiD just base running out of headroom? ===")
    print("  If base's change term is squashed on the subjects where base already scores")
    print("  high, a positive DiD appears with no lr mechanism. r(delta_base, base@5e-4)")
    for label, b_tag, v_tag, lr in LR_ARMS:
        s = subj_set(BASE, VAR, b_tag, v_tag)
        if len(s) < 3:
            continue
        db = load(b_tag, s) - load(BASE, s)
        r = np.corrcoef(db, load(BASE, s))[0, 1]
        hi = load(BASE, s) >= np.median(load(BASE, s))
        print("  %-6s r = %+.2f   | high-base half DiD %+.4f   low-base half %+.4f"
              % (label, r, (load(v_tag, s) - load(VAR, s) - db)[hi].mean(),
                 (load(v_tag, s) - load(VAR, s) - db)[~hi].mean()))
    print("")

    # ------------------------------------------------------------------ 7
    print("=== 7. MATCHED-BUDGET: best-of-two schedules, per subject ===")
    print("  Under exchangeable architectures max() is symmetric so the null is centred at")
    print("  zero -- but E[max of 2] = mu + 0.56*sigma, and the hypothesis under test IS")
    print("  'cand has a larger schedule sensitivity', so the raw max is inflated in the")
    print("  direction being argued. Hence both the raw and the de-selected estimate, and")
    print("  a sign-flip null rather than a t.")
    full = None
    for _, b_tag, v_tag, _ in LR_ARMS:
        s = subj_set(BASE, VAR, b_tag, v_tag)
        full = s if full is None else sorted(set(full) & set(s))
    if not full or len(full) < 2:
        print("  (needs both lr arms finished for the same subjects)")
    else:
        for label, b_tag, v_tag, _ in LR_ARMS:
            bb = np.maximum(load(BASE, full), load(b_tag, full))
            vb = np.maximum(load(VAR, full), load(v_tag, full))
            d = vb - bb
            m, se, t = tt(d)
            infl = 0.564 * (load(v_tag, full) - load(VAR, full)).std(ddof=1)
            print("  vs %-6s n=%2d  base %.4f  zoneattn %.4f  diff %+.4f  se %.4f  "
                  "t %+5.2f  p(signflip) %.4f" % (label, len(full), bb.mean(),
                                                  vb.mean(), m, se, t, signflip_p(d)))
            print("           de-selected: raw %+.4f minus max-selection inflation "
                  "0.56*sd(delta_cand)=%.4f -> %+.4f" % (m, infl, m - infl))
    print("LR_ANALYSIS_DONE")


if __name__ == "__main__":
    main()
