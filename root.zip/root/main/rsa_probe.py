"""
Cross-subject representational geometry of imagined speech (time-resolved RSA).

THE QUESTION, and why it is not the one already answered. The field has thoroughly
established that zero-shot cross-subject DECODING of imagined speech sits at chance
(our own LOSO: 0.1829 vs 0.20; our transfer matrix: 210/210 cells at 0.1990; and
independently the literature, e.g. Odyssey 2026: "across 28,000+ evaluations,
zero-shot cross-subject transfer failed universally at chance ~20%"). Reproducing
that is not a contribution.

But decoding failure is NOT evidence that representations differ. Decoding demands
that the same channels carry the same signal in the same direction. Two subjects can
encode the same word with entirely different spatial patterns and still agree about
the RELATIONS between words. So the open question is:

    is the GEOMETRY of the imagined-speech representation shared across subjects,
    even though the decodable code is not?

A literature search found no study combining RSA with cross-subject EEG imagined
speech: RSA has been applied to imagined speech within subject (Chinese-word
time-resolved RSA, bioRxiv 2026), and cross-subject sharing has been shown in MEG via
decoding, but the cross-subject representational geometry in EEG is unclaimed.

METHOD. For each subject, per time point, form the 5x5 dissimilarity matrix over the
five words from the trial-averaged responses (Euclidean distance between class means
in channel space) -- 10 numbers per time point. Then ask whether those 10 numbers
agree across subjects. The permutation test shuffles the five class labels
INDEPENDENTLY per subject, which destroys any shared word geometry while preserving
each subject's own internal RDM structure exactly.

A within-subject split-half gives the CEILING: if the RDM does not even replicate
across two disjoint halves of one subject's own trials, no cross-subject test can
succeed, and that is the finding.

THE CONFOUND THAT MUST BE CONTROLLED. Eye movements and blinks are strongly
stereotyped ACROSS people -- a shared ocular artifact would produce high cross-subject
RDM agreement that is not neural. So the analysis is repeated on channel subsets:
    anterior  AF7 AF8 Fp1 Fp2 F7 F8 FT9 FT10   <- artifact-prone, and exactly the
              highest-amplitude channels found in amplitude_control.py
    posterior everything else
Agreement appearing ONLY in the anterior group is artifact. It must appear in the
posterior group to count as neural.

Per-channel z-scoring is applied (unsupervised, from the subject's own trials) because
amplitude_control.py showed raw channel amplitude otherwise dominates, and norm_probe
condition A shows z-scoring leaves within-subject decoding essentially unchanged
(subject 00: 0.5857 vs 0.5779 released), so the manipulation is safe.

Runtime: minutes, CPU only, no training.
"""

import os
import sys
import itertools
import numpy as np
import h5py

H5 = "Processed/BCIC2020Track3.h5"
OUT = "Results/RSA"
DS = 5                     # keep every 5th sample -> 50 Hz
N_PERM = 1000
FS = 250.0
PAIRS = list(itertools.combinations(range(5), 2))
ANTERIOR = ['AF7', 'AF8', 'Fp1', 'Fp2', 'F7', 'F8', 'FT9', 'FT10']


def mean_pair_r(Z):
    """Mean Pearson r over all row pairs. Z: (n_subj, n_feat)."""
    if Z.shape[0] < 2:
        return float('nan')
    Zc = Z - Z.mean(axis=1, keepdims=True)
    sd = Zc.std(axis=1, keepdims=True)
    sd[sd == 0] = 1e-12
    Zs = Zc / sd
    C = (Zs @ Zs.T) / Z.shape[1]
    iu = np.triu_indices(Z.shape[0], 1)
    return float(C[iu].mean())


def class_means(x, y, n_cls=5):
    return np.stack([x[y == c].mean(axis=0) for c in range(n_cls)])


def rdm_series(M):
    """M: (5, ch, T) -> (10, T) Euclidean distances for the 10 word pairs."""
    return np.stack([np.linalg.norm(M[i] - M[j], axis=0) for i, j in PAIRS])


def stratified_halves(y, rng):
    """Two disjoint trial index sets, balanced within each class."""
    h1, h2 = [], []
    for c in np.unique(y):
        ix = np.where(y == c)[0]
        ix = rng.permutation(ix)
        k = len(ix) // 2
        h1 += ix[:k].tolist()
        h2 += ix[k:2 * k].tolist()
    return np.array(h1), np.array(h2)


def main():
    os.makedirs(OUT, exist_ok=True)
    sys.path.insert(0, "/root/FAST")
    from BCIC2020Track3_preprocess import Electrodes
    idx = {e: i for i, e in enumerate(Electrodes)}
    ant = [idx[e] for e in ANTERIOR]
    subsets = {"all": np.arange(len(Electrodes)),
               "anterior": np.array(ant),
               "posterior": np.array([i for i in range(len(Electrodes)) if i not in ant])}
    print("channels: anterior k=%d %s" % (len(ant), ANTERIOR))
    print("          posterior k=%d" % len(subsets["posterior"]))
    print("")

    # ---- single pass: store class means and split-half RDMs only (small) ----
    M = {k: [] for k in subsets}
    H = {k: [] for k in subsets}          # (2, 10, T) the two halves' RDMs
    n_T = None
    with h5py.File(H5, "r") as f:
        for key in sorted(f.keys()):
            X = f[key]["X"][()].astype(np.float64)
            Y = f[key]["Y"][()]
            if Y.ndim > 1:
                Y = Y.argmax(1)
            mu = X.mean(axis=(0, 2), keepdims=True)
            sd = X.std(axis=(0, 2), keepdims=True)
            sd[sd < 1e-8] = 1.0
            X = ((X - mu) / sd)[:, :, ::DS]
            if n_T is None:
                n_T = X.shape[2]
            rng = np.random.RandomState(42)
            i1, i2 = stratified_halves(Y, rng)
            for name, ch in subsets.items():
                x = X[:, ch, :]
                M[name].append(class_means(x, Y))
                H[name].append(np.stack([rdm_series(class_means(x[i1], Y[i1])),
                                         rdm_series(class_means(x[i2], Y[i2]))]))
            del X
            print("  %s ok" % key, flush=True)

    t_ms = np.arange(n_T) * DS / FS * 1000.0
    print("")
    print("=== CROSS-SUBJECT REPRESENTATIONAL CONSISTENCY, TIME-RESOLVED ===")
    print("  per time point, correlate the 10-pair RDM across the 15 subjects;")
    print("  null = shuffle the 5 class labels independently per subject")
    print("")

    rng = np.random.RandomState(0)
    results = {}
    for name in subsets:
        Ms = M[name]                                    # list of (5, ch, T)
        obs = np.array([mean_pair_r(np.stack([rdm_series(m)[:, t] for m in Ms]))
                        for t in range(n_T)])
        null = np.zeros((N_PERM, n_T))
        for p in range(N_PERM):
            Rp = np.array([rdm_series(m[rng.permutation(5)]) for m in Ms])
            null[p] = [mean_pair_r(Rp[:, :, t]) for t in range(n_T)]
        pval = (null >= obs).mean(axis=0)
        Hs = np.array(H[name])                          # (15, 2, 10, T)
        ceil = np.array([np.corrcoef(Hs[s, 0, :, t], Hs[s, 1, :, t])[0, 1]
                         for s in range(Hs.shape[0]) for t in range(n_T)]
                        ).reshape(Hs.shape[0], n_T).mean(axis=0)
        results[name] = dict(obs=obs, p=pval, ceil=ceil,
                             null_mean=null.mean(axis=0), null_sd=null.std(axis=0))

        peak = int(np.argmax(obs))
        print("--- %s (k=%d) ---" % (name, len(subsets[name])))
        print("  null: mean %+.4f  sd %.4f" % (null.mean(), null.std()))
        print("  observed: peak r=%+.4f at %.0f ms  |  epoch mean %+.4f"
              % (obs[peak], t_ms[peak], obs.mean()))
        print("  split-half ceiling: peak %.4f  epoch mean %.4f"
              % (ceil.max(), ceil.mean()))
        print("  peak is %.0f%% of the ceiling at that latency"
              % (100.0 * obs[peak] / ceil[peak] if ceil[peak] > 0 else float('nan')))
        sig = pval < 0.01
        print("  time points p<0.01: %d/%d" % (sig.sum(), n_T))
        if sig.any():
            runs, cur, best, bestend = [], 0, 0, 0
            for i, v in enumerate(sig):
                cur = cur + 1 if v else 0
                runs.append(cur)
                if cur > best:
                    best, bestend = cur, i
            print("  longest contiguous run: %d points, %.0f-%.0f ms"
                  % (best, t_ms[bestend - best + 1], t_ms[bestend]))
        else:
            print("  NO time point survives p<0.01")
        print("")

    np.savez("%s/rsa.npz" % OUT, t_ms=t_ms,
             **{("%s_%s" % (n, k)): v for n, d in results.items() for k, v in d.items()})
    print("  wrote %s/rsa.npz" % OUT)
    print("RSA_DONE")


if __name__ == "__main__":
    main()
