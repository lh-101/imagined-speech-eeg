"""Final analysis of the 15-subject zone-perturbation probe."""
import numpy as np, glob, os, itertools
from scipy import stats

fs = sorted(glob.glob('/root/FAST/Results/ZP/*-groups.npz'), key=lambda p: int(os.path.basename(p).split('-')[0]))
subs = [int(os.path.basename(f).split('-')[0]) for f in fs]
D = [np.load(f, allow_pickle=True) for f in fs]
names = [str(x) for x in D[0]['names']]
gidx = {g: i for i, g in enumerate(names)}
size = {g: int(D[0]['grp_size'][gidx[g]]) for g in names}
rsizes = list(D[0]['rand_sizes'])


def excess(d, g):
    """zone drop minus size-matched random drop: removes the mechanical size effect."""
    ba = d['base'].mean()
    k = size[g]
    return (ba - d['grp_acc'][gidx[g]]) - (ba - float(np.mean(d['rand_acc'][rsizes.index(k)])))


def drop(d, g):
    return d['base'].mean() - d['grp_acc'][gidx[g]]


print("=" * 78)
print("1. ANCHOR + BASELINE  (already-known values; anchor must be ~0.20)")
print("=" * 78)
print("%-6s %9s %9s" % ("subj", "baseline", "all-deranged"))
for s, d in zip(subs, D):
    print("%-6d %9.4f %9.4f" % (s, d['base'].mean(), d['all_ok'].mean()))
anc = np.array([d['all_ok'].mean() for d in D])
print("anchor mean %.4f  min %.4f  max %.4f   (chance 0.20)" % (anc.mean(), anc.min(), anc.max()))

print()
print("=" * 78)
print("2. THE PAPER'S LATERALITY CLAIM, PAIRED WITHIN SUBJECT  (no control involved)")
print("=" * 78)
for a, b in [('L-all', 'R-all'), ('L-Temporal', 'R-Temporal'), ('L-Frontal', 'R-Frontal')]:
    A = np.array([drop(d, a) for d in D]); B = np.array([drop(d, b) for d in D])
    diff = A - B
    t, p = stats.ttest_rel(A, B)
    w, pw = stats.wilcoxon(A, B)
    se = diff.std(ddof=1) / np.sqrt(len(diff))
    print("%-11s vs %-11s  mean diff %+.4f  L>R in %2d/%d  t p=%.3f  wilcoxon p=%.3f  (2SE=%.4f)"
          % (a, b, diff.mean(), int((diff > 0).sum()), len(diff), p, pw, 2 * se))

print()
print("=" * 78)
print("3. ZONE IMPORTANCE vs SIZE-MATCHED RANDOM CONTROL, all 15")
print("=" * 78)
E = np.array([[excess(d, g) for g in names] for d in D])       # 15 x n_groups
print("%-14s %5s" % ("group", "size") + "".join(" %7d" % s for s in subs) + "   %8s %6s" % ("MEAN", "sign"))
for j, g in enumerate(names):
    col = E[:, j]
    print("%-14s %5d" % (g, size[g]) + "".join(" %+7.4f" % v for v in col)
          + "   %+8.4f  %d+/%d-" % (col.mean(), (col > 0).sum(), (col < 0).sum()))

zones8 = names[:8]                 # GROUPS inserts the paper's 8 zones first
w = np.array([size[g] for g in zones8], float)
meanE = np.array([E[:, gidx[g]].mean() for g in zones8])
print()
print("size-weighted average excess over the paper's 8 zones (must be 0 if damage were"
      " linear): %+.4f" % float((w * meanE).sum() / w.sum()))
print("-> non-zero means spatially contiguous groups are penalised for redundancy, so a")
print("   NEGATIVE excess is NOT evidence that a zone is unimportant. Only POSITIVE counts.")

print()
print("=" * 78)
print("4. CROSS-SUBJECT CONSISTENCY OF THE IMPORTANCE MAP  (H1 vs H2)")
print("=" * 78)
Z = E[:, [gidx[g] for g in names]]
Z = (Z - Z.mean(axis=1, keepdims=True)) / Z.std(axis=1, keepdims=True)   # z-scored per subject


def mean_pair_r(M):
    rs = [np.corrcoef(M[i], M[j])[0, 1] for i, j in itertools.combinations(range(len(M)), 2)]
    return float(np.mean(rs))


obs = mean_pair_r(Z)
rng = np.random.RandomState(0)
null = np.array([mean_pair_r(np.array([rng.permutation(row) for row in Z])) for _ in range(2000)])
pval = float((null >= obs).mean())
print("mean pairwise Pearson r between subjects' importance profiles: %.4f" % obs)
print("permutation null (each subject's zone labels shuffled): mean %.4f  sd %.4f" % (null.mean(), null.std()))
print("p = %.4f   (H0: subjects' importance maps are unrelated)" % pval)

# split-half reliability, on the uncorrected profile as well
sh = []
for _ in range(2000):
    idx = rng.permutation(15)
    a, b = idx[:7], idx[7:]
    sh.append(np.corrcoef(Z[a].mean(axis=0), Z[b].mean(axis=0))[0, 1])
print("split-half reliability (7 vs 8 subjects, 2000 random splits): mean r = %.4f  sd %.4f"
      % (np.mean(sh), np.std(sh)))

print()
print("argmax zone (most important) per subject, from the excess matrix:")
for i, s in enumerate(subs):
    j = int(np.argmax(E[i]))
    print("  subj %02d -> %-14s (excess %+.4f)" % (s, names[j], E[i, j]))
from collections import Counter
c = Counter(names[int(np.argmax(E[i]))] for i in range(15))
print("argmax tally:", dict(c))

print()
print("per-zone mean excess, ranked:")
for g, v in sorted(zip(names, Z.mean(axis=0)), key=lambda t: -t[1]):
    print("  %-14s %+.4f" % (g, v))
print()
print("ANALYSIS_DONE")
