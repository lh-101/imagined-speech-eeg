"""
Ground-truth checks for fast_zones.FAST_ZoneAttn.

The ablation is only interpretable if the change really is the one thing claimed. Two
properties have to hold, and neither is visible from a shape check:

  1. THE ZONE ENCODERS ARE UNTOUCHED. Copy the released model's weights for every
     module the two variants share (head, transformer, cls_token, last_layer) into
     the variant and confirm forward_head returns bit-identical features. If the
     variant had quietly altered the encoders or the unfold, this fails.

  2. TOKEN (n, z) REALLY IS WINDOW n OF ZONE z. Perturb one channel of one zone
     inside one time window and observe which transformer input tokens move. The
     correct answer is exact: only the tokens of the perturbed zone, and only for
     the windows whose 250-sample span overlaps the perturbed samples. Anything else
     -- the right count but the wrong tokens, or a token changing for a zone it does
     not belong to -- means the reshape/position pairing is wrong and every result
     downstream would be meaningless.

Run on the training box (needs torch): python test_zones.py
"""

import sys
import numpy as np
import torch
from transformers import PretrainedConfig

sys.path.insert(0, "/root/FAST")
from BCIC2020Track3_preprocess import Electrodes, Zones
from FAST import FAST
from fast_zones import FAST_ZoneAttn, build, param_report


def cfg(variant):
    return PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1, variant=variant,
    )


def capture_transformer_input(model, x):
    """Return the exact tensor fed to model.transformer."""
    seen = {}
    h = model.transformer.register_forward_pre_hook(
        lambda m, args: seen.__setitem__("x", args[0].detach().clone()))
    with torch.no_grad():
        model(x)
    h.remove()
    return seen["x"]


def main():
    torch.manual_seed(0)
    x = torch.randn(2, len(Electrodes), 800)

    # ---- 1. parameter accounting ----
    rep = param_report(cfg("base"))
    b, z = rep["base"], rep["zoneattn"]
    print("  base     total %d  tokens %d  input_layer %d" % (b["total"], b["n_tokens"], b["input_layer"]))
    print("  zoneattn total %d  tokens %d  input_layer %d" % (z["total"], z["n_tokens"], z["input_layer"]))
    assert b["n_tokens"] == 6 and z["n_tokens"] == 41, "token counts wrong"
    assert z["total"] < b["total"], "variant is not the smaller model"
    assert b["head"] == z["head"] == 148992, "zone encoders differ in size"
    assert b["transformer"] == z["transformer"], "transformer differs in size"
    print("  ok  variant has %+d params, head and transformer identical in size"
          % (z["total"] - b["total"]))

    # ---- 2. the shared weights produce identical features ----
    mb, mz = FAST(cfg("base")), FAST_ZoneAttn(cfg("zoneattn"))
    with torch.no_grad():                      # copy shared weights across
        mz.head.load_state_dict(mb.head.state_dict())
        mz.transformer.load_state_dict(mb.transformer.state_dict())
        mz.cls_token.copy_(mb.cls_token)
        mz.last_layer.load_state_dict(mb.last_layer.state_dict())
    fb, fz = mb.forward_head(x), mz.forward_head(x)
    assert fb.shape == fz.shape == (2, 5, 8, 32), (fb.shape, fz.shape)
    dmax = (fb - fz).abs().max().item()
    assert dmax == 0.0, "forward_head differs between variants by %g" % dmax
    print("  ok  forward_head bit-identical across variants with shared weights")
    print("      (zone encoders, unfold and window count are provably untouched)")

    # ---- 3. which tokens does a localised perturbation move? ----
    zone = "Occipital"
    zone_ch = [Electrodes.index(c) for c in Zones[zone]]
    zi = list(Zones).index(zone)
    ch = zone_ch[0]

    xb = x.clone()
    xb[:, ch, 0:250] += 50.0                   # samples 0-249: window 0 in full, window 1 by half
    tb = capture_transformer_input(mz, x)
    tp = capture_transformer_input(mz, xb)
    delta = (tb - tp).abs().amax(dim=-1)[0]    # (1 + 40,) per token
    moved = (delta > 1e-6).nonzero().flatten().tolist()

    N, Z = mz.n_tokens, mz.n_zones
    expect = sorted([1 + n * Z + zi for n in (0, 1)])   # +1 for cls at index 0
    print("  perturbed zone '%s' (index %d, channel %s) over samples 0-249"
          % (zone, zi, Electrodes[ch]))
    print("  token index 0 is cls; token 1 + n*8 + z is (window n, zone z)")
    print("  expected to move: %s  (%s)" % (expect, [("w%d,%s" % (n, zone)) for n in (0, 1)]))
    print("  actually moved  : %s" % moved)
    assert 0 not in moved, "cls token moved: it is a parameter and must be input-independent"
    assert moved == expect, "wrong tokens moved -- the (window, zone) pairing is broken"
    print("  ok  exactly the overlapping windows of the perturbed zone moved")

    # other zones must be completely blind to that channel: cnn2 convolves over
    # channels WITHIN a zone, so no other zone's encoder may see it
    other = [i for i in moved if (i - 1) % Z != zi]
    assert not other, "perturbation leaked into another zone: %s" % other
    print("  ok  no leakage into the other 7 zones")

    # a window that cannot overlap must be untouched
    xb2 = x.clone()
    xb2[:, ch, 0:125] += 50.0                  # only window 0 overlaps
    moved2 = ((capture_transformer_input(mz, x)
               - capture_transformer_input(mz, xb2)).abs().amax(dim=-1)[0] > 1e-6)
    moved2 = moved2.nonzero().flatten().tolist()
    assert moved2 == sorted([1 + 0 * Z + zi]), "expected only (window 0, %s), got %s" % (zone, moved2)
    print("  ok  samples 0-124 move exactly one token: (window 0, %s)" % zone)

    # ---- 4. output shape, finiteness, gradient flow ----
    mz.zero_grad()
    out = mz(x)
    assert out.shape == (2, 5), out.shape
    assert torch.isfinite(out).all(), "non-finite logits"
    out.sum().backward()
    for nm in ("pos_time", "pos_zone"):
        g = getattr(mz, nm).grad
        assert g is not None and torch.isfinite(g).all(), "%s got no gradient" % nm
        assert g.abs().sum() > 0, "%s gradient is identically zero" % nm
    print("  ok  output %s finite, pos_time and pos_zone both receive gradient" % (tuple(out.shape),))

    # ---- 5. the inherited non-default modes must refuse, not silently mis-compute ----
    for mode in ("train_head", "train_transformer"):
        try:
            mz(x, forward_mode=mode)
        except NotImplementedError:
            continue
        raise AssertionError("forward_mode=%r did not raise" % mode)
    print("  ok  train_head / train_transformer raise instead of mis-computing")

    # ---- 6. dispatch ----
    assert isinstance(build(cfg("base")), FAST)
    assert isinstance(build(cfg("zoneattn")), FAST_ZoneAttn)
    print("  ok  build() dispatches on config.variant")

    print("ALL_TESTS_PASSED")


if __name__ == "__main__":
    main()
