"""
Paired analysis of every arm in Results/ZA against the base arm.

WHY PAIRED, AND WHY THIS IS THE ONLY READ THAT MEANS ANYTHING. Subjects differ from
one another far more than any variant is expected to: base-h8 has sd 0.0885 across 15
subjects, so the SEM of an arm mean is 0.0229 and a whole-arm mean carries almost no
information about a variant. Both arms call seed_all(42) once before the fold loop and
use KFold(5, shuffle=False), so subject s in arm A and subject s in arm B see the same
split from the same initialisation. The PER-SUBJECT DIFFERENCE is therefore the unit,
and its sign count is what separates "the variant changed the function" from "the
variant shifted the noise".

THE BASE ROW IS CHECKED FIRST. base-h8 is the released model running through this
harness. If it does not land on the released 0.5779 / channel_probe 0.5949, the harness
is not the released one and no other row is interpretable.

Everything here is a difference between arms run through the SAME code path, so a
confound in the harness cancels rather than being attributed to the variant. The one
exception is the parameter count, which is reported per arm because a variant that wins
by having more parameters has not shown what it claims to show.

Writes nothing; prints the tables. Run any time -- arms still in progress are simply
compared on the subjects they have finished, and the subject count is printed next to
every row so a partial arm cannot be mistaken for a complete one.
"""

import os
import re
import sys
import numpy as np

RUN = "Results/ZA"
BASE = "base-h8"
RELEASED = 0.5779
CHANNEL_PROBE = 0.5949
N_SUBJ = 15


def discover():
    """tag -> {subject: file}, read off the filenames actually on disk."""
    tags = {}
    if not os.path.isdir(RUN):
        return tags
    for fn in sorted(os.listdir(RUN)):
        m = re.match(r"^(\d+)-(.+)\.npz$", fn)
        if not m:
            continue
        tags.setdefault(m.group(2), {})[int(m.group(1))] = os.path.join(RUN, fn)
    return tags


def load(files, subjects):
    acc, corr, fold = [], [], []
    for s in subjects:
        d = np.load(files[s])
        acc.append(d["correct"].mean())
        corr.append(d["correct"])
        fold.append(d["fold_of"])
    return np.array(acc), np.array(corr), np.array(fold)


def main():
    tags = discover()
    if not tags:
        print("no arms in %s" % RUN)
        return
    if BASE not in tags:
        print("base arm %r missing -- every comparison is relative to it" % BASE)
        return

    print("=== 0. BASE MUST REPRODUCE BEFORE ANY OTHER ROW IS READ ===")
    base_files = tags[BASE]
    base_subj = sorted(base_files)
    b_acc, b_corr, b_fold = load(base_files, base_subj)
    print("  %-10s n=%2d  mean %.4f  sd %.4f  min %.4f  max %.4f"
          % (BASE, len(b_acc), b_acc.mean(), b_acc.std(ddof=1), b_acc.min(), b_acc.max()))
    print("  released protocol %.4f   |   channel_probe %.4f" % (RELEASED, CHANNEL_PROBE))
    d = b_acc - CHANNEL_PROBE
    se = d.std(ddof=1) / np.sqrt(len(d))
    print("  paired vs channel_probe: diff %+.4f  t=%+.2f  (a large |t| means the harness"
          % (d.mean(), d.mean() / se))
    print("  differs from the established one and NO row below is interpretable)")
    print("")

    others = [t for t in tags if t != BASE]
    if not others:
        print("  only the base arm present; nothing to compare yet")
        return

    print("=== 1. ALL ARMS, PAIRED WITH %s ON THEIR COMMON SUBJECTS ===" % BASE)
    print("  %-16s %5s %8s %8s %9s %8s  %s"
          % ("arm", "n", "mean", "diff", "se", "t", "subjects up"))
    rows = []
    for tag in sorted(others):
        subj = sorted(set(tags[tag]) & set(base_files))
        if not subj:
            print("  %-16s  (no subject in common with base yet)" % tag)
            continue
        a_acc, a_corr, a_fold = load(tags[tag], subj)
        b_idx = [base_subj.index(s) for s in subj]
        bb = b_acc[b_idx]
        d = a_acc - bb
        se = d.std(ddof=1) / np.sqrt(len(d)) if len(d) > 1 else float("nan")
        t = d.mean() / se if se and se > 0 else float("nan")
        rows.append((tag, subj, a_acc, a_corr, a_fold, bb, d, t))
        print("  %-16s %5d %8.4f %+8.4f %9.4f %+8.2f  %2d/%d"
              % (tag, len(subj), a_acc.mean(), d.mean(), se, t,
                 int((d > 0).sum()), len(d)))
    print("")
    if not rows:
        return

    # Arms that are still running cover different subject subsets, so the per-subject
    # table is restricted to the subjects EVERY arm has finished. Otherwise the column
    # means are taken over different subject sets and the table reads as a comparison
    # when it is not one.
    common = sorted(set.intersection(*[set(r[1]) for r in rows]))
    print("=== 2. PER-SUBJECT ACCURACY ON THE %d SUBJECTS EVERY ARM HAS FINISHED ==="
          % len(common))
    print("  (an arm that has finished fewer subjects than this shows up in table 1 "
          "only)")
    # the base column is printed first in every row, so it needs a header too
    hdr = "  %-5s%10s" % ("subj", BASE[:9])
    hdr += "".join("%10s" % r[0][:9] for r in rows)
    print(hdr)
    for s in common:
        bi = base_subj.index(s)
        line = "  %-5d %10.4f" % (s, b_acc[bi])
        for r in rows:
            line += "%10.4f" % r[2][r[1].index(s)]
        print(line)
    line = "  %-5s %10.4f" % ("MEAN", np.mean([b_acc[base_subj.index(s)]
                                                for s in common]))
    for r in rows:
        line += "%10.4f" % np.mean([r[2][r[1].index(s)] for s in common])
    print(line)
    line = "  %-5s %10s" % ("DIFF", "")
    for r in rows:
        line += "%+10.4f" % np.mean([r[2][r[1].index(s)] - b_acc[base_subj.index(s)]
                                     for s in common])
    print(line)
    print("")

    print("=== 3. WHERE EACH DIFFERENCE COMES FROM ===")
    for tag, subj, a_acc, a_corr, a_fold, bb, d, t in rows:
        print("  %s:" % tag)
        print("    per-subject diff, sorted: "
              + " ".join("%d:%+.3f" % (subj[i], d[i]) for i in np.argsort(d)))
        # fold-level: does the sign hold per fold, or is a subject's win carried by one
        # fold out of five? A variant that helps 3 folds and hurts 2 on most subjects is
        # inside the fold noise even if the subject mean looks positive.
        ups = []
        for k, s in enumerate(subj):
            bi = base_subj.index(s)
            pf = []
            for f in range(5):
                m = b_fold[bi] == f
                if m.sum() == 0:
                    continue
                pf.append(a_corr[k][m].mean() - b_corr[bi][m].mean())
            if pf:
                ups.append(sum(v > 0 for v in pf))
        if ups:
            print("    folds won per subject (out of 5): mean %.2f, %d/%d subjects >=3"
                  % (np.mean(ups), sum(u >= 3 for u in ups), len(ups)))
    print("ZA_ANALYSIS_DONE")


if __name__ == "__main__":
    main()
