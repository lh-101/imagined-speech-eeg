"""
LOSO (leave-one-subject-out) probe for FAST on BCIC2020 Track 3.

WHY: the released BCIC2020 script trains purely subject-dependently
(Finetune(config, X[fold], Y[fold], ...) -- one subject's 350 trials, KFold inside).
So the published 54.8% has train and test coming from the SAME person.
Nobody has reported how much of that survives when the test subject is unseen.

This probe answers one question: does FAST decode covert speech ACROSS subjects?

DEVIATION FROM THE RELEASED CODE (deliberate, and it matters):
  The released Finetune uses batch_size = len(x_train) (full batch, 280 trials).
  Here the training set is 14 subjects = 4900 trials; a full batch would need
  ~24.7 GB just for the first conv layer's retained activations. We use a fixed
  batch of 512 (peak ~7 GB, sized for a 12 GB card such as the RTX 3080 Ti)
  instead. This changes gradient noise, so treat the numbers as a PROBE, not as
  a protocol that can be compared head-to-head with the subject-dependent run.

  HARDWARE NOTE (measured 2026-09-24): this pipeline is bit-reproducible across
  GPUs. The 15 subject-dependent runs were repeated on an RTX 3080 Ti (sm_86)
  and diffed against the original vGPU-4080 (sm_89): 0/15 CSVs differ, final
  Accuracy identical at 0.577905. seed_all(42) + full-batch + bf16 makes the
  result deterministic w.r.t. GPU architecture, so cross-machine comparison is
  safe. An earlier version of this docstring claimed ~3 points of environment
  drift; that was a conflation -- the ~3 points is the gap between our 57.79%
  and the paper's 54.8%, not a machine effect.

RESULT (held-out 0-4): .1657 .2000 .1457 .1771 .2257 -> mean .1829 std .0277,
against a .20 chance level. Same 5 subjects subject-dependently on the same
card: .5971 .5400 .6086 .7257 .6829 -> mean .6309. Drop .4480 +- .0669.
"""

import os
import sys
import logging
import numpy as np
import torch

sys.path.insert(0, "/root/FAST")
os.chdir("/root/FAST")

logging.getLogger("pytorch_lightning").setLevel(logging.WARNING)
logging.getLogger("lightning").setLevel(logging.WARNING)

import lightning as pl
from torch.utils.data import DataLoader
from transformers import PretrainedConfig

from BCIC2020Track3_train import (
    EEG_Encoder_Module, BasicDataset, seed_all, load_standardized_h5, inference_on_loader,
)
from BCIC2020Track3_preprocess import Electrodes, Zones

RUN = "Results/LOSO"
MAX_EPOCHS = 200
BATCH = 512          # sized for a 12 GB card; 1024 needs ~10.3 GB and will OOM there


def build_config():
    return PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1,
    )


def loso_one(s, X, Y, config):
    """Train on every subject except s, test on s."""
    idx = [i for i in range(len(X)) if i != s]
    xtr = np.concatenate([X[i] for i in idx], axis=0)
    ytr = np.concatenate([Y[i] for i in idx], axis=0)
    xte, yte = X[s], Y[s]

    seed_all(42)
    train_loader = DataLoader(BasicDataset(xtr, ytr), batch_size=BATCH,
                              shuffle=True, num_workers=0, pin_memory=True)
    test_loader = DataLoader(BasicDataset(xte, yte), batch_size=len(xte),
                             shuffle=False, num_workers=0, pin_memory=True)

    model = EEG_Encoder_Module(config, MAX_EPOCHS, len(train_loader))
    trainer = pl.Trainer(strategy="auto", accelerator="gpu", devices=[0],
                         max_epochs=MAX_EPOCHS, callbacks=[],
                         enable_progress_bar=False, enable_checkpointing=False,
                         precision="bf16-mixed", logger=False)
    trainer.fit(model, train_dataloaders=train_loader)

    pred, real = inference_on_loader(model.model, test_loader)
    del xtr, ytr, model, trainer
    torch.cuda.empty_cache()
    return pred, real


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--subjects", type=str, default="0-14",
                    help="held-out subjects to run, e.g. '0-4' or '0,3,7'. Resumable: "
                         "a subject whose CSV exists is skipped.")
    a = ap.parse_args()
    if "-" in a.subjects:
        lo, hi = [int(x) for x in a.subjects.split("-")]
        todo = list(range(lo, hi + 1))
    else:
        todo = [int(x) for x in a.subjects.split(",")]

    os.makedirs(RUN, exist_ok=True)
    config = build_config()

    X, Y = load_standardized_h5("Processed/BCIC2020Track3.h5")
    print("loaded X=%s Y=%s" % (X.shape, Y.shape), flush=True)
    print("PROBE protocol: train on the other 14 subjects (4900 trials), "
          "batch=%d, %d epochs" % (BATCH, MAX_EPOCHS), flush=True)
    print("held-out queue: %s" % todo, flush=True)

    for s in todo:
        logf = "%s/%d-LOSO.csv" % (RUN, s)
        if os.path.exists(logf):
            print("skip %s (exists)" % logf, flush=True)
            continue
        pred, real = loso_one(s, X, Y, config)
        np.savetxt(logf, np.array([pred, real]).T, delimiter=",", fmt="%d")
        acc = float(np.mean(pred == real))
        print("[held-out subj %02d] n=%d acc=%.4f" % (s, len(real), acc), flush=True)

    accs = []
    for s in range(15):
        logf = "%s/%d-LOSO.csv" % (RUN, s)
        if not os.path.exists(logf):
            continue
        d = np.loadtxt(logf, delimiter=",", dtype=int)
        accs.append(float(np.mean(d[:, 0] == d[:, 1])))
    if accs:
        print("")
        print("LOSO (cross-subject, %d/%d subjects done): mean=%.4f std=%.4f"
              % (len(accs), 15, np.mean(accs), np.std(accs)), flush=True)
        print("chance level = 0.20", flush=True)
        print("PROBE_DONE", flush=True)
