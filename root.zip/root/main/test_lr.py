"""
Ground-truth tests for the lr / warmup override in zone_attn_probe.py. Run on the remote.

WHY THIS NEEDS A TEST AT ALL. The whole point of the lr arms is to separate "this
architecture is worse" from "this architecture is worse UNDER THE RELEASED SCHEDULE".
That reading is only valid if the override demonstrably reaches the optimizer. The
failure mode is silent and total: the override is attached to the instance because
Lightning calls configure_optimizers long after construction, and if that attachment
does not survive, every lr arm runs at 5e-4 and comes back numerically identical to the
released-protocol arm -- which would look like clean evidence that the learning rate
does not matter, when in fact nothing was varied.

So the load-bearing test is `test_override_actually_reaches_the_optimizer`: build the
module through the same make_encoder path the runner uses and read the lr back off the
AdamW the scheduler is attached to.

The other direction matters just as much. `test_default_path_is_bit_identical` asserts
that with no --lr and no --warmup the reconstructed schedule equals the one
EEG_Encoder_Module.__init__ built, element for element, and that the lr is exactly the
released 5e-4. The released arms already on disk were produced through this same file,
so if the default path drifted by even one element of the cosine list, those results
would no longer be reproducible by re-running it.
"""

import sys

import numpy as np
import torch

sys.path.insert(0, "/root/FAST")

import zone_attn_probe as zp
from BCIC2020Track3_train import cosine_scheduler

MAX_EPOCHS = 200
NITER = 1                                            # batch == training fold, so 1 step/ep


def _module(lr=None, warmup=None):
    """Built through the runner's own path, so this tests the code that will actually
    run and not a copy of it."""
    cfg = zp.build_config("base", 8)
    return zp.make_encoder(cfg, MAX_EPOCHS, NITER, lr=lr, warmup=warmup)


def _lr_after_configure(lr):
    """The lr the optimizer is holding once configure_optimizers has returned.

    It is NOT the base lr, and that is the released behaviour, not something this override
    introduced: torch's LambdaLR calls step() once from its own __init__, so the very first
    multiplier (cosine_lr_list[-1] = the final_value 0.1, because global_step is 0 before
    the trainer attaches) is applied at construction. The released path does exactly the
    same thing; the trainer's first step then overwrites it. What has to be true for the lr
    arms to mean anything is that this factor is the SAME in every arm, so the arms differ
    by a pure scale.
    """
    m = _module(lr=lr)
    opts, _ = m.configure_optimizers()
    return [g["lr"] for g in opts[0].param_groups][0], m


def test_override_actually_reaches_the_optimizer():
    """The lr must scale linearly across arms, and the schedule SHAPE must not move."""
    got = {}
    for lr in (2e-4, 5e-4, 1e-3):
        got[lr], m = _lr_after_configure(lr)
        sched = np.asarray(m.cosine_lr_list, dtype=np.float64)
        assert len(sched) == MAX_EPOCHS * NITER, len(sched)
        assert abs(sched[0]) < 1e-12, sched[0]
        assert abs(sched[9] - 1.0) < 1e-12, sched[9]      # warmup ends at 1.0
        assert abs(sched.max() - 1.0) < 1e-12, sched.max()
        # the cosine's last entry is one step short of the true end, so it lands just
        # ABOVE final_value=0.1 rather than exactly on it
        assert 0.1 < sched[-1] < 0.1002, sched[-1]

    # the decisive check: an arm at lr L holds exactly L/5e-4 times the released arm's lr.
    # If the override had not landed, all three would be identical and this fails.
    for lr in (2e-4, 1e-3):
        ratio = got[lr] / got[5e-4]
        want = lr / 5e-4
        assert abs(ratio - want) < 1e-12, \
            "lr arm %g is %.6f x the released arm, expected %.6f" % (lr, ratio, want)
    assert got[5e-4] != 1e-3, "the override did not land at all"
    print("  lr arms: 5e-4 -> %.3e, 1e-3 -> %.3e (2.000x), 2e-4 -> %.3e (0.400x)"
          % (got[5e-4], got[1e-3], got[2e-4]))
    print("  schedule shape unchanged at every lr: [0]=0 [9]=1.0 peak=1.0 "
          "[last]=%.4f (one step short of final_value)" % sched[-1])

    # The returned LambdaLR must read this module's own list, not a copy captured at
    # construction. Replacing the list after configure_optimizers and asking the lambda
    # again is the check -- if the lambda had closed over a snapshot, it would keep
    # returning the old entry and the optimizer would never see the override's schedule.
    # (global_step itself is a read-only property on LightningModule, so the index it
    # supplies cannot be set directly from here.)
    m = _module(lr=1e-3)
    scheds = m.configure_optimizers()[1][0]["scheduler"]
    m.cosine_lr_list = np.arange(MAX_EPOCHS, dtype=np.float64)
    assert abs(scheds.lr_lambdas[0](0) - (MAX_EPOCHS - 1)) < 1e-12, \
        "the LambdaLR is not reading the module's current cosine_lr_list"
    print("test_override_actually_reaches_the_optimizer OK")


def test_warmup_override_reaches_the_schedule():
    # warmup=0 removes the ramp entirely: there is no linspace prefix, so the cosine
    # starts at its own peak (0.1 + 0.45*(1+cos 0) = 1.0) instead of ramping from 0.
    # configure_optimizers must be called first: it is the thing that rebuilds the list,
    # and reading m.cosine_lr_list before it returns the __init__ schedule instead -- which
    # is what the first version of this test did, giving the released 0.0 and looking like
    # a broken override when the override had not run at all.
    m = _module(lr=1e-3, warmup=0)
    m.configure_optimizers()
    sched = np.asarray(m.cosine_lr_list, dtype=np.float64)
    assert abs(sched[0] - 1.0) < 1e-12, sched[0]
    assert len(sched) == MAX_EPOCHS, len(sched)

    # warmup=40: 40-step linear ramp to 1.0, then the cosine. The ramp is
    # linspace(0, 1, 40), so entry 20 is 20/39 and NOT 0.5 -- asserting 0.5 here was the
    # first version of this test and it was wrong about the released scheduler, not about
    # the override.
    m2 = _module(lr=1e-3, warmup=40)
    m2.configure_optimizers()
    sched2 = np.asarray(m2.cosine_lr_list, dtype=np.float64)
    assert abs(sched2[39] - 1.0) < 1e-12, sched2[39]
    assert abs(sched2[20] - 20.0 / 39.0) < 1e-12, sched2[20]
    assert abs(sched2[40] - 1.0) < 1e-2, sched2[40]      # cosine just after the peak
    assert len(sched2) == MAX_EPOCHS, len(sched2)
    print("  warmup=0 starts at full peak (%.1f); warmup=40 ramps to 1.0 at step 40 "
          "(%.4f at step 20 = 20/39)" % (sched[0], sched2[20]))
    print("test_warmup_override_reaches_the_schedule OK")


def test_default_path_is_bit_identical():
    """No --lr / --warmup must reproduce the released configuration exactly.

    The arms already on disk (base-h8, zoneattn-h8, ...) were produced before this
    override existed. If the default path changed by even one schedule element, re-running
    them would no longer reproduce, and every pairing against base-h8 would be invalid.
    """
    m = _module(lr=None, warmup=None)
    want = cosine_scheduler(1, 0.1, MAX_EPOCHS, NITER, warmup_epochs=10)
    got = np.asarray(m.cosine_lr_list, dtype=np.float64)
    assert np.array_equal(got, np.asarray(want, dtype=np.float64)), \
        "the default schedule changed -- the arms already on disk are no longer reproducible"

    # bit-identical lr to the released path: 5e-4 x the same first multiplier
    opts, _ = m.configure_optimizers()
    lr = [g["lr"] for g in opts[0].param_groups]
    assert lr == [0.0005 * float(want[-1])], (lr, 0.0005 * float(want[-1]))
    print("  default path: lr %s = 5e-4 x %.1f, schedule bit-identical to "
          "EEG_Encoder_Module.__init__" % (lr[0], float(want[-1])))
    print("test_default_path_is_bit_identical OK")


def test_runner_tag_cannot_collide_with_a_default_arm():
    """A non-default schedule must not be writable to a default-named .npz.

    If --lr 1e-3 could write to `zoneattn-h8.npz`, the arm would be read by analyze_za as
    the released-protocol zoneattn number. The tag is built inside main(), so the rule is
    checked here by reproducing it: same expression, same inputs.
    """
    def tag_of(variant, heads, lr, warmup, epochs, explicit=None):
        t = explicit
        if t is None:
            t = "%s-h%d" % (variant, heads)
            if lr is not None:
                t += "-lr%g" % lr
            if warmup is not None:
                t += "-wu%d" % warmup
            if epochs is not None:
                t += "-ep%d" % epochs
        return t

    N = None
    assert tag_of("zoneattn", 8, N, N, N) == "zoneattn-h8"
    assert tag_of("zoneattn", 8, 1e-3, N, N) == "zoneattn-h8-lr0.001"
    assert tag_of("zoneattn", 8, N, 40, N) == "zoneattn-h8-wu40"
    assert tag_of("zoneattn", 8, N, N, 400) == "zoneattn-h8-ep400"
    assert tag_of("zoneattn", 8, 1e-3, 40, 400, explicit="x") == "x"

    # no combination of overrides can collide with the released-protocol tag, which is what
    # analyze_za pairs every arm against
    for v in ("base", "zoneattn"):
        for lr in (None, 1e-3, 2e-4):
            for wu in (None, 0, 40):
                for ep in (None, 400):
                    if lr is None and wu is None and ep is None:
                        continue
                    assert tag_of(v, 8, lr, wu, ep) != "%s-h8" % v, (v, lr, wu, ep)
    print("  non-default schedules get distinct tags; the released tag is unreachable")
    print("test_runner_tag_cannot_collide_with_a_default_arm OK")


def test_epochs_override_rebuilds_a_longer_schedule():
    """--epochs is the step count here, because batch_size is the whole training fold: one
    gradient step per epoch. So it must rebuild the cosine over the new length rather than
    leaving the schedule at 200 entries and silently truncating or overrunning."""
    cfg = zp.build_config("base", 8)
    m = zp.make_encoder(cfg, 400, NITER)
    m.configure_optimizers()
    sched = np.asarray(m.cosine_lr_list, dtype=np.float64)
    assert len(sched) == 400, len(sched)
    # the warmup is still 10 steps, so the SHAPE at the front is unchanged and only the
    # cosine has been stretched -- that is what makes it a step-count arm and not an lr arm
    assert abs(sched[9] - 1.0) < 1e-12, sched[9]
    assert abs(sched[0]) < 1e-12, sched[0]
    assert sched[-1] < sched[199] < 1.0, (sched[-1], sched[199])
    print("  --epochs 400 -> schedule of %d steps, same 10-step warmup, still peaking at 1.0"
          % len(sched))
    print("test_epochs_override_rebuilds_a_longer_schedule OK")


def main():
    for fn in (test_override_actually_reaches_the_optimizer,
               test_warmup_override_reaches_the_schedule,
               test_epochs_override_rebuilds_a_longer_schedule,
               test_default_path_is_bit_identical,
               test_runner_tag_cannot_collide_with_a_default_arm):
        fn()
    print("ALL_TESTS_PASSED")


if __name__ == "__main__":
    main()
