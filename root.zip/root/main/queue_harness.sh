#!/bin/bash
# THE DECISIVE TEST. Does the between-fold torch.cuda.empty_cache() account for the
# 0.5779 -> 0.5949 gap, and does a pure RNG perturbation (placebo) reproduce the penalty
# pattern that the whole variant table is built on?
#
# Three runs, same architecture (`base` and `placebo` are byte-identical), same seed, same
# data, 5 subjects. Only the harness and one RNG draw differ.
cd /root/FAST || exit 1
P=/root/venv_fast/bin/python

# 1. base under the released fold loop (no empty_cache). If the mechanism is right this
#    lands near the released 0.5779 -- i.e. BELOW the 0.5949 the probe has been reporting
#    for the same model, so the arm-level table's reference has been inflated all along.
echo "=== base / released harness START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant base --harness released --subjects 0-4
echo "=== base / released harness END $(date +%H:%M:%S) ==="

# 2. base under pinned (no empty_cache, re-seed every fold). This is the mode in which
#    arms are actually comparable, so it also becomes the new reference if it holds.
echo "=== base / pinned harness START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant base --harness pinned --subjects 0-4
echo "=== base / pinned harness END $(date +%H:%M:%S) ==="

# 3. THE PLACEBO. Identical architecture, identical parameter count, one extra
#    torch.randn(1) drawn before construction. If it scores ~0.02 below base with a
#    0/N-subjects-better pattern, then the small penalties in the variant table
#    (nl -0.006, bank -0.020) were RNG offsets, not architecture.
echo "=== placebo / legacy harness START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant placebo --subjects 0-4
echo "=== placebo / legacy harness END $(date +%H:%M:%S) ==="

echo QUEUE_HARNESS_DONE
