"""Why did `spatial` collapse? Measure the two candidate mechanisms on REAL data.

The arm scored -0.2566 (0/5 subjects, t=-8.24) -- far outside the +-0.06 per-subject jitter
that `placebo` measured, so it is not noise. Two mechanisms are on the table and they call for
opposite responses:

  A. A SCALE BUG. SpatialHead adds `pos_elec` (init torch.randn, so std ~1) to the temporal
     feature BEFORE the first LayerNorm (AttentionBlock does layer_norm_1 first). LayerNorm
     normalises per token, so what matters is the RATIO: if pos_elec's std dominates the
     feature's std, every electrode token is essentially its position embedding and attention
     sees almost no data. This is a BUG -- fixable, and the arm would deserve a re-run.

  B. A DESIGN LOSS. The released per-zone encoder is Conv2d(1, F, (n_ch, k)): its kernel spans
     every electrode of the zone, so it IS a dense spatial filter, and the electrode axis is
     collapsed to 1 by the conv (see the reduce 'B F 1 T -> B F'). SpatialHead uses
     Conv2d(1, F, (1, 5)) -- kernel height 1, no cross-electrode mixing at all -- and then
     mean-pools electrodes within a zone AFTER the attention. If that is the cause, the arm is
     a genuine negative and there is nothing to fix.

A decides whether to re-run; B decides whether to abandon. Measure, do not guess.

Run on the training box: python probe_spatial_scale.py <cache.h5>
"""

import sys
import h5py
import numpy as np
import torch

sys.path.insert(0, "/root/FAST")
from transformers import PretrainedConfig
from BCIC2020Track3_preprocess import Electrodes, Zones
from fast_zones import build

CACHE = sys.argv[1] if len(sys.argv) > 1 else "/root/FAST/Processed/BCIC2020Track3.h5"


def subject0(path):
    """One subject, not the whole cache.

    load_standardized_h5() np.array()s all 15 subjects at once -- 15*350*64*800*4 B = 1.07 GB
    on disk and about twice that in RAM once the list is materialised, which is enough to get
    SIGKILLed on a memory-capped box. Eight trials carry every number this probe needs.
    """
    with h5py.File(path, "r") as f:
        keys = sorted(f.keys())
        return f[keys[0]]["X"][:8]


def cfg(variant):
    return PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1, variant=variant,
    )


def tap(model, name):
    """Capture one submodule's output on the next forward."""
    seen = {}
    mod = dict(model.named_modules())[name]
    h = mod.register_forward_hook(lambda m, i, o: seen.__setitem__("o", o.detach()))
    return seen, h


def main():
    x = torch.from_numpy(subject0(CACHE)).float()
    print("input (b, C, T) = %s   std %.4f   absmax %.2f   per-channel std: %.4f..%.4f"
          % (tuple(x.shape), x.std(), x.abs().max(),
             x.std(dim=(0, 2)).min(), x.std(dim=(0, 2)).max()))

    m = build(cfg("spatial")).eval()

    # --- A. the scale question, measured where it bites: right before the attention ---
    # Nothing taps pos_elec: it is an nn.Parameter, not a module, so named_modules() has no
    # entry for it and the lookup would KeyError. Read it off the module directly below.
    seen_tcn, h1 = tap(m, "head.tcn3")
    with torch.no_grad():
        m.forward_head(x)
    h1.remove()

    t = seen_tcn["o"]                      # (b, F, C, T) BEFORE the time-mean
    f = t.mean(dim=-1)                     # (b, F, C) -> the token content, pre-pos
    f = f.permute(0, 2, 1)                 # (b, C, F)
    p = m.head.pos_elec.detach()
    print("")
    print("A. SCALE")
    print("   temporal feature (b,C,F): std %.4f  absmax %.4f" % (f.std(), f.abs().max()))
    print("   pos_elec         (1,C,F): std %.4f  absmax %.4f" % (p.std(), p.abs().max()))
    ratio = float(p.std() / f.std())
    print("   ratio pos/feature = %.2f  -> %s"
          % (ratio, "POSITION DOMINATES: tokens are mostly their position embedding"
             if ratio > 0.5 else "feature still visible above the position term"))

    # the decisive version: how much does the token at the attention input depend on the DATA
    # at all? compare two different trials through the same electrode.
    with torch.no_grad():
        o1 = m.forward_head(x[:1]).flatten()
        o2 = m.forward_head(x[1:2]).flatten()
        o3 = m.forward_head(x[:1]).flatten()
    print("   head output: trial0 vs trial1 max|d| = %.4f ; trial0 vs itself = %.4f"
          % ((o1 - o2).abs().max(), (o1 - o3).abs().max()))
    print("   head output std across trials = %.4f" % (o1 - o2).abs().mean())

    # --- B. what the released head gets that this one does not: a cross-electrode kernel ---
    mb = build(cfg("base")).eval()
    convs = {n: tuple(mod.weight.shape) for n, mod in mb.head.encoders[list(Zones)[0]]
             .named_modules() if isinstance(mod, torch.nn.Conv2d)}
    print("")
    print("B. THE KERNEL")
    print("   released per-zone convs (zone '%s', %d ch): %s"
          % (list(Zones)[0], len(Zones[list(Zones)[0]]), convs))
    mine = {n: tuple(mod.weight.shape) for n, mod in m.head.named_modules()
            if isinstance(mod, torch.nn.Conv2d)}
    print("   spatial  shared  convs                 : %s" % mine)
    print("   -> released kernel height = n_ch (spans the electrodes of the zone);")
    print("      spatial  kernel height = 1 (per-electrode, no mixing).")

    # --- and: does the released head's electrode axis really collapse to 1? ---
    seen, h = tap(mb.head.encoders[list(Zones)[0]], "cnn4")
    with torch.no_grad():
        mb.head(x[:1, :, 0:250])
    h.remove()
    print("   released cnn4 output shape on the raw head call: %s" % (tuple(seen["o"].shape),))

    print("")
    print("SPATIAL_SCALE_DONE")


if __name__ == "__main__":
    main()
