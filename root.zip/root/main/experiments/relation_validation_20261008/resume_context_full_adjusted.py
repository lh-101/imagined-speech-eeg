import sys,json,time,subprocess
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/relation_validation_20261008')
import run_context_full as run
for item in Path('/proc').iterdir():
 if not item.name.isdigit():continue
 try:cmd=(item/'cmdline').read_bytes().replace(b'\0',b' ').decode()
 except (OSError,UnicodeDecodeError):continue
 if 'python' in cmd and 'run_context_full.py' in cmd:raise RuntimeError('Already running: '+item.name)
done=sum((run.ROOT/f'{kind}_{s}_fold{fold}_{mode}.json').exists() for kind,s,fold in run.CASES for mode in run.active_modes(kind,fold))
plan=dict(started=time.time(),total_models=run.TOTAL,reused_models=done,new_models=run.TOTAL-done,steps=200,estimated_minutes=[40,55],protocol='BCI all three modes fivefold; Nguyen original/uniform fivefold, balanced stopped after twofold negative interim; development data')
script=Path('/root/FAST/experiments/relation_validation_20261008/run_context_full.py')
proc=subprocess.Popen(['/root/venv_fast/bin/python',str(script)],stdout=open(run.ROOT/'run.log','a'),stderr=subprocess.STDOUT,start_new_session=True)
plan['pid']=proc.pid
(run.ROOT/'plan.json').write_text(json.dumps(plan,indent=2))
print(json.dumps(plan))
