import os
for key in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[key]='2'
import sys,time,json,math,traceback,copy,hashlib,argparse
from pathlib import Path
sys.path[:0]=['/root/FAST/experiments/relation_validation_20261008','/root/FAST/experiments/parallel_questions_20261008']
import common as c
from window_consistent_model import WindowConsistentModel
import torch,numpy as np
from torch.nn import functional as F
torch.set_num_threads(2)
ROOT=Path('/root/FAST/experiments/context_combination_20261009')
HIST=c.temporal.ROOT/'results'/'temporal_screen'
CASES=[(kind,s,f) for f in range(5) for kind,ss in [('main',range(15)),('external',range(1,7))] for s in ss]
def save(name,obj):
 ROOT.mkdir(exist_ok=True);p=ROOT/name;q=p.with_suffix('.tmp');q.write_text(json.dumps(obj,indent=2));q.replace(p)
def rep(kind,base,adapter,features):return c.ref.rep(kind,base,adapter,features,torch.zeros_like(features))
@torch.no_grad()
def cache_shared(kind,base,xx):
 model=WindowConsistentModel(base,balanced=False);parts=[]
 for i in range(0,len(xx),32):
  with torch.autocast('cuda',enabled=kind=='external',dtype=torch.bfloat16):
   parts.append(model.forward_head(torch.from_numpy(xx[i:i+32]).cuda()))
 return torch.cat(parts)
def train(kind,base,adapter,features,y,seed,correction,context):
 c.ref.main_ref.v4.seed_all(seed)
 params=[p for p in adapter.parameters() if p.requires_grad]
 opt=torch.optim.AdamW(params,lr=.001,weight_decay=.01);trace=[];tic=time.time()
 for step in range(200):
  for g in opt.param_groups:g['lr']=.001*(.1+.9*.5*(1+math.cos(math.pi*step/199)))
  opt.zero_grad(set_to_none=True);logits,q,_,delta=rep(kind,base,adapter,features)
  if correction:
   with torch.no_grad():delta=delta-adapter.saved(features,torch.zeros_like(features))[0]
  ce=F.cross_entropy(logits,y);aux=.3*F.cross_entropy(4*c.ref.ridge(kind,q,y),y)
  loss=ce+aux+.01*delta.square().mean();assert torch.isfinite(loss)
  loss.backward();assert all(p.grad is None or torch.isfinite(p.grad).all() for p in params);opt.step()
  if step in [0,49,99,199]:
   trace.append(dict(step=step+1,ce=float(ce.detach()),aux=float(aux.detach())))
   if context:save('progress.json',dict(state='running',total_cases=105,completed_cases=context['completed'],current=dict(dataset=kind,subject=context['subject'],fold=context['fold'],stage='multiscale' if correction else 'adapter',step=step+1),elapsed=time.time()-context['started']))
 torch.cuda.synchronize();return dict(seconds=time.time()-tic,trace=trace)
@torch.no_grad()
def benchmark(kind,base,oldadapter,newadapter,x):
 shared=WindowConsistentModel(base,balanced=False)
 def old():return rep(kind,base,oldadapter,base.forward_head(x))[0]
 def new():return rep(kind,base,newadapter,shared.forward_head(x))[0]
 out={}
 for name,fn in [('old',old),('shared',new)]:
  with torch.autocast('cuda',enabled=kind=='external',dtype=torch.bfloat16):
   for _ in range(5):fn()
   times=[]
   for _ in range(20):
    torch.cuda.synchronize();tic=time.perf_counter();fn();torch.cuda.synchronize();times.append(1000*(time.perf_counter()-tic))
  out[name]=float(np.median(times))
 out['batch_size']=len(x);out['scope']='Representative batch inference, not full-system latency';return out
def case(kind,s,f,context=None):
 tic=time.time();base,best,trfeat,tefeat,mean,testmean,tr,te,y,oldpred,replayerr,oldsource=c.temporal.load(kind,s,f)
 before=c.ref.main_ref.tensorhash(base)
 name=c.ref.name(kind,s,f);cp=HIST/kind/'multiscale'/(name+'.pt')
 ck=torch.load(cp,map_location='cpu',weights_only=False)
 assert np.array_equal(ck['train_idx'],tr) and np.array_equal(ck['test_idx'],te)
 previous=c.temporal.Temporal(best,'multiscale').cuda();previous.load_state_dict(ck['correction_state_dict'],strict=False);previous.eval().requires_grad_(False)
 with torch.no_grad():oldprob=c.ref.rep(kind,base,previous,tefeat,testmean)[0].float().softmax(-1).cpu().numpy()
 with np.load(HIST/kind/'multiscale'/(name+'.npz')) as z:
  assert np.array_equal(z['y'],y[te]) and np.array_equal(z['train_idx'],tr) and np.array_equal(z['test_idx'],te)
  assert np.array_equal(oldprob.argmax(-1),z['pred'])
  error=float(np.max(np.abs(oldprob-z['prob'])));assert error<1e-6,error
 x,yy=c.ref.dataset(kind,s);assert np.array_equal(yy,y)
 xx=c.normalize(kind,x,tr);full=cache_shared(kind,base,xx);newtrain=full[tr].detach();newtest=full[te].detach()
 seed=c.ref.seed(kind,s,f);c.ref.main_ref.v4.seed_all(seed)
 reference=c.ref.initialize(kind,newtrain,torch.zeros_like(newtrain));generic=c.ref.GenericAdapter(reference).cuda();del reference
 assert sum(p.numel() for p in generic.parameters())==9280
 target=torch.from_numpy(y[tr]).cuda()
 stage1=train(kind,base,generic,newtrain,target,seed,False,context);generic.eval().requires_grad_(False)
 for p in generic.parameters():p.grad=None
 c.ref.main_ref.v4.seed_all(seed);combined=c.temporal.Temporal(generic,'multiscale').cuda()
 assert sum(p.numel() for p in combined.parameters() if p.requires_grad)==6440
 stage2=train(kind,base,combined,newtrain,target,seed,True,context)
 combined.eval()
 with torch.no_grad():prob=rep(kind,base,combined,newtest)[0].float().softmax(-1).cpu().numpy()
 assert np.isfinite(prob).all();assert c.ref.main_ref.tensorhash(base)==before
 assert all(p.grad is None for p in base.parameters())
 timing=None
 if (kind,s,f) in [('main',0,0),('external',1,0)]:timing=benchmark(kind,base,previous,combined,torch.from_numpy(xx[te[:32]]).cuda())
 row=dict(dataset=kind,subject=s,fold=f,old_accuracy=float(np.mean(oldprob.argmax(1)==y[te])),combined_accuracy=float(np.mean(prob.argmax(1)==y[te])),old_replay_error=error,source_frozen=True,base_hash=before,seed=seed,adapter_parameters=9280,correction_parameters=6440,stage1=stage1,stage2=stage2,inference_ms=timing,seconds=time.time()-tic)
 dest=f'{kind}_{s}_fold{f}'
 np.savez_compressed(ROOT/(dest+'.npz'),y=y[te],train=tr,test=te,old_prob=oldprob,prob=prob)
 torch.save(dict(state_dict=combined.state_dict(),source_loo=str(c.old.source_path(kind,'loo',s,f)),source_adapter=str(oldsource),train=tr,test=te),ROOT/(dest+'.pt'))
 save(dest+'.json',row);print('CASE_DONE',json.dumps(row),flush=True)
 del base,best,previous,combined,generic,full,trfeat,tefeat,mean,testmean,newtrain,newtest,target;torch.cuda.empty_cache()
 return row
def report():
 rows=[json.loads((ROOT/f'{kind}_{s}_fold{f}.json').read_text()) for kind,s,f in CASES if (ROOT/f'{kind}_{s}_fold{f}.json').exists()]
 groups={}
 for kind,subjects in [('main',range(15)),('external',range(1,7))]:
  rr=[v for v in rows if v['dataset']==kind];per=[]
  for s in subjects:
   sr=[v for v in rr if v['subject']==s]
   if len(sr)!=5:continue
   per.append(dict(subject=s,old=100*float(np.mean([v['old_accuracy'] for v in sr])),combined=100*float(np.mean([v['combined_accuracy'] for v in sr]))))
  groups[kind]=dict(completed_cases=len(rr),complete_subjects=len(per),subjects=per)
  if per:groups[kind].update(old_mean=float(np.mean([v['old'] for v in per])),combined_mean=float(np.mean([v['combined'] for v in per])),delta_pp=float(np.mean([v['combined']-v['old'] for v in per])))
 save('summary.json',dict(complete=len(rows)==105,groups=groups,limits='Previously inspected development folds, same frozen LOO source; adapter and multiscale stages retrained on shared features using historical fixed recipes. Tests stage2 compatibility, not new stage1 LOO training on shared encoder; no necessity or novelty proof.'))
 return rows
def main(smoke=False):
 ROOT.mkdir(exist_ok=True)
 if smoke:
  for kind,s in [('main',0),('external',1)]:
   if not (ROOT/f'{kind}_{s}_fold0.json').exists():case(kind,s,0)
  save('smoke.json',dict(passed=True,cases=2));report();return
 started=time.time();save('protocol.json',dict(total_cases=105,new_fits=210,steps_per_stage=200,arms=['historical best LOO+generic adapter+multiscale','same frozen LOO source + shared uniform encoder + same adapter/multiscale recipes'],source='Historical baseline predictions replayed and reused, no baseline retraining',scope='All21subjects5folds. Retain all outcomes, fixed uniform pooling, no coverage-weight search.'))
 try:
  for kind,s,f in CASES:
   if (ROOT/f'{kind}_{s}_fold{f}.json').exists():continue
   n=len(report());case(kind,s,f,dict(completed=n,subject=s,fold=f,started=started))
  rows=report()
  for v in rows:
   with np.load(ROOT/f"{v['dataset']}_{v['subject']}_fold{v['fold']}.npz") as z:
    assert abs(float(np.mean(z['prob'].argmax(1)==z['y']))-v['combined_accuracy'])<1e-12
    assert abs(float(np.mean(z['old_prob'].argmax(1)==z['y']))-v['old_accuracy'])<1e-12
  save('progress.json',dict(state='completed',completed_cases=105,total_cases=105,elapsed=time.time()-started,audit_predictions_passed=True))
 except Exception:save('error.json',dict(error=traceback.format_exc()));raise
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--smoke',action='store_true');args=parser.parse_args();main(args.smoke)
