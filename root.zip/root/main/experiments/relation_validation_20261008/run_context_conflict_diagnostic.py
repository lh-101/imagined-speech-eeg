import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
import sys,time,json,math,traceback
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/relation_validation_20261008')
import run_context_alignment as study
import torch,numpy as np
from torch.nn import functional as F
c=study.c;torch.set_num_threads(2)
ROOT=Path('/root/FAST/experiments/context_conflict_diagnostic_20261009')
def save(name,obj):
 ROOT.mkdir(exist_ok=True);p=ROOT/name;q=p.with_suffix('.tmp');q.write_text(json.dumps(obj,indent=2));q.replace(p)
def centered(a):return a-a.mean(0,keepdim=True)-a.mean(1,keepdim=True)+a.mean()
def diagnose(kind,s,condition):
 base,xx,y,tr,te,path=study.load(kind,s,0)
 if condition.startswith('aligned'):
  mode='shared_aligned' if condition.endswith('shared') else 'original_aligned'
  ck=torch.load(study.ROOT/f'{kind}_{s}_fold0_{mode}.pt',map_location='cpu',weights_only=False)
  assert np.array_equal(ck['train'],tr);base.load_state_dict(ck['backbone'])
 base.eval().requires_grad_(True)
 encoder=base if condition.endswith('original') else study.WindowConsistentModel(base,balanced=False)
 xt=torch.from_numpy(xx[tr]).cuda();yt=torch.from_numpy(y[tr]).cuda();params=list(base.parameters())
 with torch.autocast('cuda',dtype=torch.bfloat16):
  logits,q=study.representation(base,encoder,xt);ce=F.cross_entropy(logits,yt)
 aux=.3*F.cross_entropy(4*c.ref.ridge(kind,q,yt),yt)
 gm=torch.autograd.grad(ce,params,retain_graph=True,allow_unused=True)
 ga=torch.autograd.grad(aux,params,allow_unused=True)
 dot=0.;nm=0.;na=0.
 for a,b in zip(gm,ga):
  if a is not None:nm+=float(a.float().square().sum())
  if b is not None:na+=float(b.float().square().sum())
  if a is not None and b is not None:dot+=float((a.float()*b.float()).sum())
 with torch.no_grad():
  qd=q.detach().double();k=torch.exp(-2*(1-qd@qd.T));target=F.one_hot(yt,int(yt.max())+1).double();yk=target@target.T
  kc=centered(k);yc=centered(yk);alignment=float((kc*yc).sum()/(kc.norm()*yc.norm()).clamp_min(1e-15))
  effective_rank=float(kc.trace().square()/kc.square().sum().clamp_min(1e-15))
  same=yt[:,None]==yt[None,:];mask=~torch.eye(len(yt),device='cuda',dtype=torch.bool)
  margin=float(k[same&mask].mean()-k[(~same)&mask].mean())
  with torch.autocast('cuda',dtype=torch.bfloat16):features=encoder.forward_head(xt).float()
  flat=F.normalize(torch.asinh(features).flatten(2),dim=-1)
  adjacent=float((flat[:,:-1]*flat[:,1:]).sum(-1).mean())
 row=dict(dataset=kind,subject=s,fold=0,condition=condition,train_trials=len(tr),ce=float(ce.detach()),aux=float(aux.detach()),train_accuracy=float(np.mean(logits.detach().argmax(1).cpu().numpy()==y[tr])),gradient_cosine=dot/max(math.sqrt(nm*na),1e-20),aux_to_main_gradient_norm=math.sqrt(na)/max(math.sqrt(nm),1e-20),kernel_label_alignment=alignment,centered_kernel_effective_rank=effective_rank,within_between_kernel_margin=margin,adjacent_window_cosine=adjacent)
 del base,encoder,xt,yt,params,gm,ga,q,logits,ce,aux,k,kc,yc,qd,features,flat;torch.cuda.empty_cache()
 return row
def main():
 started=time.time();rows=[];conditions=['source_original','source_shared','aligned_original','aligned_shared']
 save('protocol.json',dict(question='Does shared encoding disrupt train-only intertrial supervision or induce CE/LOO gradient conflict?',conditions=conditions,scope='All21subjects fold0. Only training trials and labels used for diagnostic. Associational development diagnostics, no proof of cause, no automatic subgroup selection.',training=False))
 try:
  for kind,s,f in study.CASES:
   for condition in conditions:
    row=diagnose(kind,s,condition);rows.append(row)
    save('rows.json',rows);save('progress.json',dict(state='running',completed=len(rows),total=84,elapsed=time.time()-started,current=dict(dataset=kind,subject=s,condition=condition)))
  groups={}
  metrics=['gradient_cosine','aux_to_main_gradient_norm','kernel_label_alignment','centered_kernel_effective_rank','within_between_kernel_margin','adjacent_window_cosine','ce','aux']
  for kind in ['main','external']:
   groups[kind]={}
   for condition in conditions:
    rr=[v for v in rows if v['dataset']==kind and v['condition']==condition]
    groups[kind][condition]={m:float(np.mean([v[m] for v in rr])) for m in metrics}
    groups[kind][condition]['negative_gradient_subjects']=sum(v['gradient_cosine']<0 for v in rr)
  save('summary.json',dict(groups=groups,scope='Train-only diagnostics, no causal attribution or novelty claim'));save('progress.json',dict(state='completed',completed=84,total=84,elapsed=time.time()-started))
  print(json.dumps(groups),flush=True)
 except Exception:save('error.json',dict(error=traceback.format_exc()));raise
if __name__=='__main__':main()
