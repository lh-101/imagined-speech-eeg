import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
import sys,time,json,math,copy,traceback,hashlib
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/relation_validation_20261008')
import design_before_pool as old
from window_consistent_model import WindowConsistentModel
import torch,numpy as np
from torch.nn import functional as F
torch.set_num_threads(2)
ROOT=Path('/root/FAST/experiments/context_full_20261008')
CASES=[(kind,s,fold) for fold in range(5) for kind,subjects in [('main',range(15)),('external',range(1,7))] for s in subjects]
MODES=['original_finetune','full_context_uniform','full_context_balanced']
def active_modes(kind,fold):
 return MODES[:2] if kind=='external' and fold>=2 else MODES
TOTAL=sum(len(active_modes(kind,fold)) for kind,subject,fold in CASES)

def save(name,obj):
 p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2));tmp.replace(p)
def digest(model):
 h=hashlib.sha256()
 for k,v in model.state_dict().items():h.update(k.encode());h.update(v.cpu().numpy().tobytes())
 return h.hexdigest()
@torch.no_grad()
def predict(model,x):
 model.eval();out=[]
 for start in range(0,len(x),32):out.append(model(torch.from_numpy(x[start:start+32]).cuda()).float().cpu().numpy())
 return np.concatenate(out)
def main():
 ROOT.mkdir(exist_ok=True);started=time.time();finished=0
 for kind,s,fold in CASES:
  x,y=old.c.ref.dataset(kind,s);tr,te=list(old.c.ref.splits(kind,x,y))[fold];source=old.c.old.source_path(kind,'ce',s,fold)
  ck=torch.load(source,map_location='cpu',weights_only=False);template=old.c.build(kind,s,fold).eval();template.load_state_dict(ck['state_dict'])
  assert np.array_equal(ck['train_idx' if kind=='main' else 'train'],tr) and np.array_equal(ck['test_idx' if kind=='main' else 'test'],te)
  xx=old.c.normalize(kind,x,tr);source_hash=digest(template);xt=torch.from_numpy(xx[tr]).cuda();yt=torch.from_numpy(y[tr]).cuda()
  original=predict(template,xx[te]);np.savez_compressed(ROOT/f'{kind}_{s}_fold{fold}_source.npz',y=y[te],train=tr,test=te,logits=original)
  for mode in active_modes(kind,fold):
   dest=ROOT/f'{kind}_{s}_fold{fold}_{mode}.json'
   if dest.exists():finished+=1;continue
   base=copy.deepcopy(template).requires_grad_(True);assert digest(base)==source_hash
   model=base if mode=='original_finetune' else WindowConsistentModel(base,balanced=mode=='full_context_balanced')
   initial=predict(model,xx[te]);seed=old.c.ref.seed(kind,s,fold)+810091;old.c.ref.main_ref.v4.seed_all(seed)
   model.train();opt=torch.optim.AdamW(model.parameters(),lr=.0001,weight_decay=.01);tic=time.time();trace=[]
   for step in range(200):
    for g in opt.param_groups:g['lr']=.0001*(.1+.9*.5*(1+math.cos(math.pi*step/199)))
    opt.zero_grad(set_to_none=True)
    with torch.autocast('cuda',dtype=torch.bfloat16):logit=model(xt);loss=F.cross_entropy(logit,yt)
    assert torch.isfinite(loss);loss.backward();assert all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters());opt.step()
    if step in [0,99,199]:
     trace.append(dict(step=step+1,loss=float(loss.detach())))
     save('progress.json',dict(state='running',completed_models=finished,total_models=TOTAL,current=dict(dataset=kind,subject=s,mode=mode,step=step+1),elapsed=time.time()-started))
   torch.cuda.synchronize();seconds=time.time()-tic;out=predict(model,xx[te]);train=predict(model,xx[tr])
   row=dict(dataset=kind,subject=s,fold=fold,mode=mode,source=str(source),source_hash=source_hash,seed=seed,parameters=sum(p.numel() for p in model.parameters()),source_accuracy=float(np.mean(original.argmax(1)==y[te])),initial_accuracy=float(np.mean(initial.argmax(1)==y[te])),accuracy=float(np.mean(out.argmax(1)==y[te])),train_accuracy=float(np.mean(train.argmax(1)==y[tr])),training_seconds=seconds,trace=trace)
   np.savez_compressed(ROOT/f'{kind}_{s}_fold{fold}_{mode}.npz',y=y[te],train=tr,test=te,logits=out);torch.save(model.state_dict(),ROOT/f'{kind}_{s}_fold{fold}_{mode}.pt');save(dest.name,row)
   finished+=1;print(json.dumps(row),flush=True);del model,base,opt;torch.cuda.empty_cache()
  del template,xt,yt;torch.cuda.empty_cache()
 rows=[json.loads((ROOT/f'{kind}_{s}_fold{fold}_{mode}.json').read_text()) for kind,s,fold in CASES for mode in active_modes(kind,fold)]
 summary={kind:{mode:float(np.mean([r['accuracy'] for r in rows if r['dataset']==kind and r['mode']==mode])) for mode in MODES} for kind in ['main','external']}
 save('progress.json',dict(state='completed',completed_models=TOTAL,total_models=TOTAL,elapsed=time.time()-started,summary=summary))
if __name__=='__main__':
 try:
  main()
  import audit_context_full
  audit_context_full.main()
 except Exception:save('error.json',dict(error=traceback.format_exc()));raise
