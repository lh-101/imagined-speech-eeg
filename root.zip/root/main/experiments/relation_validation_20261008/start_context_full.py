import sys,subprocess,json,time,shutil
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/relation_validation_20261008')
import run_context_full as run
for item in Path('/proc').iterdir():
 if not item.name.isdigit():continue
 try:cmd=(item/'cmdline').read_bytes().replace(b'\0',b' ').decode()
 except (OSError,UnicodeDecodeError):continue
 if 'python' in cmd and any(n in cmd for n in ['run_context_full.py','run_context_all_subjects.py','run_context_train.py']):raise RuntimeError('Already running: '+item.name)
missing=[str(run.old.c.old.source_path(kind,'ce',s,fold)) for kind,s,fold in run.CASES if not Path(run.old.c.old.source_path(kind,'ce',s,fold)).exists()]
assert not missing,missing
run.ROOT.mkdir(exist_ok=True)
assert shutil.disk_usage(run.ROOT).free>2*1024**3,'Less than 2GiB free'
for kind,s,fold in run.CASES:
 if fold!=0:continue
 for suffix in ['source.npz']+[mode+ext for mode in run.MODES for ext in ['.json','.npz','.pt']]:
  src=Path('/root/FAST/experiments/context_train_20261008')/f'{kind}_{s}_{suffix}'
  dst=run.ROOT/f'{kind}_{s}_fold0_{suffix}'
  assert src.exists(),src
  if not dst.exists():shutil.copy2(src,dst)
done=sum((run.ROOT/f'{kind}_{s}_fold{fold}_{mode}.json').exists() for kind,s,fold in run.CASES for mode in run.MODES)
plan=dict(started=time.time(),total_models=315,reused_models=done,new_models=315-done,steps=200,estimated_minutes=[60,80],protocol='All 21 subjects, original 5 folds; fixed source CE, same optimizer and seed per paired fold; no hyperparameter search; exploratory/development validation')
script=Path('/root/FAST/experiments/relation_validation_20261008/run_context_full.py')
proc=subprocess.Popen(['/root/venv_fast/bin/python',str(script)],stdout=open(run.ROOT/'run.log','a'),stderr=subprocess.STDOUT,start_new_session=True)
plan['pid']=proc.pid
(run.ROOT/'plan.json').write_text(json.dumps(plan,indent=2))
print(json.dumps(plan))
