import sys,json,time,subprocess,shutil
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/relation_validation_20261008')
import run_combination_fixed as run
for item in Path('/proc').iterdir():
 if not item.name.isdigit():continue
 try:cmd=(item/'cmdline').read_bytes().replace(b'\0',b' ').decode()
 except (OSError,UnicodeDecodeError):continue
 if 'python' in cmd and 'run_combination_fixed.py' in cmd:raise RuntimeError('Already running: '+item.name)
assert json.loads((run.ROOT/'smoke.json').read_text())['passed']
assert shutil.disk_usage(run.ROOT).free>1024**3
for kind,s,f in run.CASES:
 for p in [run.HIST/kind/'multiscale'/(run.c.ref.name(kind,s,f)+'.pt'),run.c.old.source_path(kind,'loo',s,f)]:assert p.exists(),p
proc=subprocess.Popen(['/root/venv_fast/bin/python',str(Path(run.__file__))],stdout=open(run.ROOT/'run.log','a'),stderr=subprocess.STDOUT,start_new_session=True)
plan=dict(pid=proc.pid,started=time.time(),total_cases=105,reused_smoke_cases=2,remaining_cases=103,estimated_minutes=[20,35])
(run.ROOT/'plan.json').write_text(json.dumps(plan,indent=2));print(json.dumps(plan))
