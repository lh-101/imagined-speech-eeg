import os
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[key]='2'
import sys,time,json,math,hashlib,argparse,traceback
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/parallel_questions_20261008')
import common as c
import numpy as np,torch
from torch.nn import functional as F
from sklearn.metrics import f1_score
ROOT=Path(__file__).resolve().parent
METHODS=['ce','self','loo','supcon'];FRACTIONS=[.25,.5,1.]

def state_hash(model):
 h=hashlib.sha256()
 for k,v in model.state_dict().items():h.update(k.encode());h.update(v.detach().cpu().contiguous().numpy().tobytes())
 return h.hexdigest()

def subset(tr,y,seed,fraction):
 if fraction==1:return tr.copy()
 rng=np.random.default_rng(seed+70000)
 parts=[]
 for label in np.unique(y):
  ix=rng.permutation(tr[y[tr]==label]);n=max(2,int(np.floor(len(ix)*fraction)));parts.append(ix[:n])
 return np.sort(np.concatenate(parts))

def scores(q,y,method,classes):
 k=torch.exp(-2*(1-q.double()@q.double().T))
 b=torch.cholesky_inverse(torch.linalg.cholesky(k+.1*torch.eye(len(q),device=q.device,dtype=k.dtype)))
 Y=F.one_hot(y,classes).double()
 return (Y-(b@Y)/b.diag()[:,None] if method=='loo' else k@b@Y).float()

def aux(q,y,method,classes):
 if method=='ce':return q.sum()*0
 if method in ('self','loo'):return .3*F.cross_entropy(4*scores(q,y,method,classes),y)
 sim=q.float()@q.float().T/.1;diag=torch.eye(len(q),device=q.device,dtype=torch.bool)
 positive=(y[:,None]==y[None,:])&~diag;assert (positive.sum(1)>0).all()
 logp=sim-torch.logsumexp(sim.masked_fill(diag,-torch.inf),dim=1,keepdim=True)
 return -.3*(logp.masked_fill(~positive,0).sum(1)/positive.sum(1)).mean()

@torch.no_grad()
def predict(model,x,kind):
 chunks=[]
 size=64 if kind=='external' else len(x)
 for i in range(0,len(x),size):
  with torch.autocast('cuda',dtype=torch.bfloat16,enabled=kind=='external'):
   logits,_=c.ref.main_ref.v4.representation(model,torch.from_numpy(x[i:i+size]).cuda())
  chunks.append(logits.float().softmax(1).cpu().numpy())
 return np.concatenate(chunks)

@torch.no_grad()
def diagnostics(model,x,y,kind):
 with torch.autocast('cuda',dtype=torch.bfloat16,enabled=kind=='external'):
  logits,q=c.ref.main_ref.v4.representation(model,torch.from_numpy(x).cuda())
 q=q.double();yt=torch.from_numpy(y).cuda();k=torch.exp(-2*(1-q@q.T))
 b=torch.linalg.inv(k+.1*torch.eye(len(q),device='cuda',dtype=torch.float64));h=1-.1*b.diag();Y=F.one_hot(yt,int(y.max()+1)).double()
 u=Y-(b@Y)/b.diag()[:,None];selfscore=k@b@Y
 neighbor=k.clone();neighbor.fill_diagonal_(0)
 own=(yt[:,None]==yt[None,:]).double()
 collision=(neighbor*(1-own)).sum(1)/neighbor.sum(1)
 return dict(training_accuracy=float((logits.argmax(1)==yt).float().mean()),loo_kernel_train_accuracy=float((u.argmax(1)==yt).double().mean()),self_kernel_train_accuracy=float((selfscore.argmax(1)==yt).double().mean()),self_label_coefficient_mean=float(h.mean()),self_label_coefficient_max=float(h.max()),wrong_class_neighbor_mass=float(collision.mean()),loo_minus_self_score_rms=float((u-selfscore).square().mean().sqrt()))

def fit(kind,s,f,x,y,tr,te,method,steps):
 model=c.build(kind,s,f).train().requires_grad_(True);initial=state_hash(model)
 xx=c.normalize(kind,x,tr);xt=torch.from_numpy(xx[tr]).cuda();yt=torch.from_numpy(y[tr]).cuda();classes=len(np.unique(y))
 params=list(model.parameters());opt=torch.optim.AdamW(params,lr=.0005,weight_decay=.01)
 schedule=c.ref.main_ref.v4.cosine_scheduler(1,.1,steps,1,warmup_epochs=min(10,steps//5));trace=[]
 t0=time.time()
 for epoch in range(steps):
  model.train();opt.zero_grad(set_to_none=True)
  for g in opt.param_groups:g['lr']=.0005*float(schedule[epoch-1 if kind=='main' else epoch])
  with torch.autocast('cuda',dtype=torch.bfloat16):
   logits,q=c.ref.main_ref.v4.representation(model,xt);ce=F.cross_entropy(logits,yt)
  extra=aux(q,yt,method,classes);loss=ce+extra;assert torch.isfinite(loss)
  ratio=None
  if method!='ce' and (kind=='main' or epoch in [0,steps-1]):
   gm=torch.autograd.grad(ce,params,retain_graph=True,allow_unused=True)
   ga=torch.autograd.grad(extra,params,retain_graph=kind!='main',allow_unused=True)
   normmain=sum(g.float().square().sum() for g in gm if g is not None)
   normaux=sum(g.float().square().sum() for g in ga if g is not None)
   ratio=float((normaux/normmain.clamp_min(1e-30)).sqrt())
   if kind=='main':
    for p,a,b in zip(params,gm,ga):p.grad=((torch.zeros_like(p) if a is None else a)+(torch.zeros_like(p) if b is None else b)).detach()
   else:loss.backward()
   del gm,ga
  else:loss.backward()
  assert all(p.grad is None or torch.isfinite(p.grad).all() for p in params)
  opt.step()
  if epoch in [0,steps-1]:trace.append(dict(epoch=epoch+1,ce=float(ce.detach()),aux=float(extra.detach()),weighted_aux_main_grad_ratio=ratio))
 model.eval();prob=predict(model,xx[te],kind);diag=diagnostics(model,xx[tr],y[tr],kind)
 return model,prob,initial,trace,diag,time.time()-t0

def reuse(kind,s,f,x,y,tr,te,method):
 path=c.old.source_path(kind,method,s,f);ck=torch.load(path,map_location='cpu')
 ti=ck['train_idx' if kind=='main' else 'train'];ei=ck['test_idx' if kind=='main' else 'test']
 assert np.array_equal(ti,tr) and np.array_equal(ei,te)
 model=c.build(kind,s,f);model.load_state_dict(ck['state_dict']);model.eval()
 if kind=='external':
  mu,sd=ck['normalization'];xx=((x-mu)/sd).astype(np.float32)
  assert np.allclose(xx,c.normalize(kind,x,tr),atol=2e-5)
 else:xx=x
 with np.load(path.with_suffix('.npz')) as z:
  assert np.array_equal(z['y'],y[te]);prob=z['primary_prob' if kind=='main' else 'prob'].copy()
 replay=predict(model,xx[te],kind);error=float(np.max(abs(prob-replay)))
 assert np.array_equal(prob.argmax(1),replay.argmax(1)) and error<1e-5,(kind,s,f,method,error)
 diag=diagnostics(model,xx[tr],y[tr],kind)
 return model,prob,diag,dict(checkpoint=str(path),sha256=c.old.sha(path),replay_error=error)

def summarize():
 result={'complete':False,'groups':{},'limits':'Fixed development protocols; one subset/initialization rule; no correction for historical selection. Same aux coefficient does not match gradients. Not SOTA or universal LOO necessity.'}
 finished=0
 for kind in ('main','external'):
  for fraction in FRACTIONS:
   group={}
   for method in METHODS:
    subjects=[];times=[]
    for s in c.ref.subjects(kind):
     paths=[ROOT/'results'/kind/f'p{int(fraction*100)}'/method/(c.ref.name(kind,s,f)+'.npz') for f in range(5)]
     if not all(p.exists() for p in paths):continue
     ys=[];ps=[]
     for p in paths:
      with np.load(p) as z:ys.extend(z['y']);ps.extend(z['prob'].argmax(1))
     subjects.append(dict(subject=s,accuracy=float(np.mean(np.array(ys)==np.array(ps))),macro_f1=float(f1_score(ys,ps,average='macro',zero_division=0))))
    paths=list((ROOT/'results'/kind/f'p{int(fraction*100)}'/method).glob('*.json'));finished+=len(paths)
    for p in paths:
     z=json.loads(p.read_text())
     if not z['reused']:times.append(z['seconds'])
    group[method]=dict(completed_subjects=len(subjects),total_subjects=len(c.ref.subjects(kind)),completed_folds=len(paths),subjects=subjects,mean_accuracy_percent=100*np.mean([r['accuracy'] for r in subjects]) if subjects else None,median_fit_seconds=float(np.median(times)) if times else None)
   group['paired_loo_minus_control']={}
   for method in ('ce','self','supcon'):
    a={r['subject']:r['accuracy'] for r in group['loo']['subjects']};b={r['subject']:r['accuracy'] for r in group[method]['subjects']};ss=sorted(set(a)&set(b))
    if ss:
     delta=100*np.array([a[s]-b[s] for s in ss]);rng=np.random.default_rng(20261008)
     ci=np.quantile(delta[rng.integers(0,len(delta),(10000,len(delta)))].mean(1),[.025,.975])
     group['paired_loo_minus_control'][method]=dict(subjects=ss,mean_pp=float(delta.mean()),positive=int((delta>1e-9).sum()),negative=int((delta<-1e-9).sum()),bootstrap95_pp=ci.tolist(),complete=len(ss)==len(c.ref.subjects(kind)))
   result['groups'][f'{kind}_p{int(fraction*100)}']=group
 result['completed_conditions']=finished;result['total_conditions']=1260;result['complete']=finished==1260
 c.save(ROOT/'summary.json',result)
 return result

def run(worker,smoke=False):
 torch.set_num_threads(2);start=time.time();rows=[]
 cases=[(kind,s,f) for kind in ('main','external') for s in c.ref.subjects(kind) for f in range(5)]
 if smoke:cases=[('main',0,0),('external',1,0)]
 else:cases=[v for i,v in enumerate(cases) if i%2==worker]
 try:
  for kind,s,f in cases:
   x,y=c.ref.dataset(kind,s);outer,te=list(c.ref.splits(kind,x,y))[f];seed=c.ref.seed(kind,s,f)
   for fraction in ([.25,1.] if smoke else FRACTIONS):
    tr=subset(outer,y,seed,fraction);assert not np.intersect1d(tr,te).size;assert set(tr)<=set(outer)
    for method in METHODS:
     dest=ROOT/('smoke' if smoke else 'results')/kind/f'p{int(fraction*100)}'/method;dest.mkdir(parents=True,exist_ok=True);p=dest/(c.ref.name(kind,s,f)+'.npz')
     if p.exists():continue
     t0=time.time();used=fraction==1 and method in ('ce','loo')
     if used:model,prob,diag,provenance=reuse(kind,s,f,x,y,tr,te,method);initial=None;trace=[];seconds=time.time()-t0
     else:
      model,prob,initial,trace,diag,seconds=fit(kind,s,f,x,y,tr,te,method,2 if smoke else 200);provenance=None
     row=dict(dataset=kind,subject=s,fold=f,method=method,fraction=fraction,n_train=len(tr),n_test=len(te),accuracy=float((prob.argmax(1)==y[te]).mean()),reused=used,seconds=seconds,initial_sha256=initial,trace=trace,diagnostics=diag,provenance=provenance)
     with p.with_suffix('.npz.tmp').open('wb') as handle:np.savez_compressed(handle,prob=prob,y=y[te],train_idx=tr,test_idx=te,outer_train_idx=outer)
     p.with_suffix('.npz.tmp').replace(p);c.save(p.with_suffix('.json'),row)
     rows.append(row);del model;torch.cuda.empty_cache()
     c.save(ROOT/(f'worker{worker}_status.json' if not smoke else 'smoke_status.json'),dict(state='running',pid=os.getpid(),completed_conditions=len(rows),total_conditions=len(cases)*(8 if smoke else 12),elapsed_seconds=time.time()-start,current={k:row[k] for k in ('dataset','subject','fold','method','fraction')},last_fit_seconds=seconds))
     print('DONE',kind,s,f,fraction,method,'reused' if used else f'{seconds:.1f}s',flush=True)
  c.save(ROOT/(f'worker{worker}_status.json' if not smoke else 'smoke_status.json'),dict(state='complete',pid=os.getpid(),completed_conditions=len(rows),elapsed_seconds=time.time()-start))
 except BaseException:
  c.save(ROOT/(f'worker{worker}_status.json' if not smoke else 'smoke_status.json'),dict(state='failed',error=traceback.format_exc()));raise

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--worker',type=int,default=0);ap.add_argument('--smoke',action='store_true');ap.add_argument('--summary',action='store_true');a=ap.parse_args()
 if a.summary:print(json.dumps(summarize(),ensure_ascii=False))
 else:run(a.worker,a.smoke)
