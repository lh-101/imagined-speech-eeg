import subprocess,json,time
from pathlib import Path
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode()
 except (OSError,UnicodeDecodeError):continue
 if 'python' in cmd and 'run_context_conflict_diagnostic.py' in cmd:raise RuntimeError('Already running '+p.name)
r=Path('/root/FAST/experiments/context_conflict_diagnostic_20261009');r.mkdir(exist_ok=True)
script=Path('/root/FAST/experiments/relation_validation_20261008/run_context_conflict_diagnostic.py');compile(script.read_text(),str(script),'exec')
proc=subprocess.Popen(['/root/venv_fast/bin/python',str(script)],stdout=open(r/'run.log','a'),stderr=subprocess.STDOUT,start_new_session=True)
plan=dict(pid=proc.pid,started=time.time(),checks=84,estimated_minutes=[2,5],new_training=False);(r/'plan.json').write_text(json.dumps(plan,indent=2));print(json.dumps(plan))
