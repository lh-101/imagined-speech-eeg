import subprocess,json,time
from pathlib import Path
root=Path('/root/FAST/experiments/context_train_20261008')
script=Path('/root/FAST/experiments/relation_validation_20261008/run_context_all_subjects.py')
for item in Path('/proc').iterdir():
    if not item.name.isdigit():continue
    try:cmd=(item/'cmdline').read_bytes().replace(b'\0',b' ').decode()
    except (OSError,UnicodeDecodeError):continue
    if 'python' in cmd and ('run_context_all_subjects.py' in cmd or 'run_context_train.py' in cmd):
        raise RuntimeError('Training already running: '+item.name)
cases=[('main',s) for s in range(15)]+[('external',s) for s in range(1,7)]
modes=['original_finetune','full_context_uniform','full_context_balanced']
done=[(kind,s,mode) for kind,s in cases for mode in modes if (root/f'{kind}_{s}_{mode}.json').exists()]
assert len(done)>=12
for name in ['run_context_train.py','run_context_all_subjects.py']:
    p=script.parent/name;compile(p.read_text(),str(p),'exec')
record=dict(started=time.time(),total_models=63,reused_models=len(done),new_models=63-len(done),fold=0,steps=200,selection='all 15 BCI2020 and all 6 Nguyen subjects; original fixed first fold',estimated_minutes=[15,20])
(root/'all_subjects_plan.json').write_text(json.dumps(record,indent=2))
proc=subprocess.Popen(['/root/venv_fast/bin/python',str(script)],stdout=open(root/'all_subjects.log','a'),stderr=subprocess.STDOUT,start_new_session=True)
record['pid']=proc.pid
(root/'all_subjects_plan.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record))
