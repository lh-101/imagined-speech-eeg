from pathlib import Path
import subprocess,time,json,os
R=Path(__file__).resolve().parent;PY='/root/venv_fast/bin/python'
def write(name,z):
 p=R/name;t=p.with_suffix('.tmp');t.write_text(json.dumps(z,indent=2));t.replace(p)
write('launch_status.json',dict(state='smoke',pid=os.getpid(),started=time.time()))
with (R/'smoke.log').open('ab') as h:
 result=subprocess.run([PY,'-u',str(R/'run_study.py'),'--smoke'],cwd=R,stdout=h,stderr=subprocess.STDOUT)
if result.returncode:
 write('launch_status.json',dict(state='failed_smoke',returncode=result.returncode));raise SystemExit(result.returncode)
processes=[];handles=[]
for worker in (0,1):
 h=(R/f'worker{worker}.log').open('ab');handles.append(h)
 p=subprocess.Popen([PY,'-u',str(R/'run_study.py'),'--worker',str(worker)],cwd=R,stdout=h,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
 processes.append(p)
write('launch_status.json',dict(state='running',pid=os.getpid(),workers=[p.pid for p in processes],started=time.time(),total_conditions=1260,new_fits=1050,reused=210))
rc=[p.wait() for p in processes]
for h in handles:h.close()
with (R/'summary.log').open('ab') as h:sumrc=subprocess.run([PY,str(R/'run_study.py'),'--summary'],cwd=R,stdout=h,stderr=subprocess.STDOUT).returncode
write('launch_status.json',dict(state='complete' if not any(rc) and not sumrc else 'failed',returncodes=rc,summary_returncode=sumrc,finished=time.time()))
