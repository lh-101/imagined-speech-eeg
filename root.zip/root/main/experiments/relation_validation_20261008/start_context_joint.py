import sys,subprocess,json,time,shutil
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/relation_validation_20261008')
import run_context_joint as run
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode()
 except (OSError,UnicodeDecodeError):continue
 if 'python' in cmd and 'run_context_joint.py' in cmd:raise RuntimeError('Already running '+p.name)
assert json.loads((run.ROOT/'smoke.json').read_text())['passed']
assert shutil.disk_usage(run.ROOT).free>1024**3
for kind,s,f in run.CASES:
 assert (run.combo.HIST/kind/'multiscale'/(run.c.ref.name(kind,s,f)+'.pt')).exists()
 assert (Path('/root/FAST/experiments/context_combination_corrected_20261009')/f'{kind}_{s}_fold0.pt').exists()
proc=subprocess.Popen(['/root/venv_fast/bin/python',str(Path(run.__file__))],stdout=open(run.ROOT/'run.log','a'),stderr=subprocess.STDOUT,start_new_session=True)
plan=dict(pid=proc.pid,started=time.time(),models=42,subjects=21,fold=0,estimated_minutes=[20,30]);(run.ROOT/'plan.json').write_text(json.dumps(plan,indent=2));print(json.dumps(plan))
