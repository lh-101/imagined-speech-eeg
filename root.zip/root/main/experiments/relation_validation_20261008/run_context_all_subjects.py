import sys
sys.path.insert(0,'/root/FAST/experiments/relation_validation_20261008')
import run_context_train as run
run.CASES=[('main',s) for s in range(15)]+[('external',s) for s in range(1,7)]
if __name__=='__main__':
    try:run.main()
    except Exception:
        import traceback
        run.save('error_all_subjects.json',dict(error=traceback.format_exc()))
        raise
