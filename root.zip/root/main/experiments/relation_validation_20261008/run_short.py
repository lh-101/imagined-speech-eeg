import os,sys,time,json,argparse,traceback,subprocess
from pathlib import Path
import run_study as study
import numpy as np,torch
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'short_screen'

def save(p,z):study.c.save(p,z)

def report():
 rows=[json.loads(p.read_text()) for p in (OUT/'results').glob('*/*/*.json')]
 result={'complete':len(rows)==84,'completed':len(rows),'total':84,'datasets':{},'limits':'Cost-controlled all-subject single-fold50% screening, not fivefold confirmation; no performance-based subject selection; one seed and fixed SupCon recipe.'}
 for kind in ['main','external']:
  subject_rows=[]
  for s in study.c.ref.subjects(kind):
   found=[r for r in rows if r['dataset']==kind and r['subject']==s]
   if len(found)==4:subject_rows.append({'subject':s,'accuracy':{r['method']:r['accuracy'] for r in found}})
  group={'complete':len(subject_rows)==len(study.c.ref.subjects(kind)),'subjects':subject_rows}
  if subject_rows:
   group['mean_percent']={m:100*float(np.mean([r['accuracy'][m] for r in subject_rows])) for m in study.METHODS}
   group['paired_loo_minus_control']={}
   for m in ['ce','self','supcon']:
    delta=100*np.array([r['accuracy']['loo']-r['accuracy'][m] for r in subject_rows]);rng=np.random.default_rng(20261008)
    ci=np.quantile(delta[rng.integers(0,len(delta),(10000,len(delta)))].mean(1),[.025,.975])
    group['paired_loo_minus_control'][m]={'mean_pp':float(delta.mean()),'positive':int((delta>1e-9).sum()),'negative':int((delta<-1e-9).sum()),'descriptive_bootstrap95_pp':ci.tolist()}
  result['datasets'][kind]=group
 if result['complete']:
  main=result['datasets']['main']['paired_loo_minus_control'];ext=result['datasets']['external']['paired_loo_minus_control']
  result['screening_assessment']={'BCI_both_relational_comparators_positive':all(main[m]['mean_pp']>0 for m in ['self','supcon']),'Nguyen_both_relational_comparators_positive':all(ext[m]['mean_pp']>0 for m in ['self','supcon']),'interpretation':'Positive differences are screening signals only. No new-computation-principle or necessity conclusion. Inspect effect distributions and gradient-scale confounds before extension.'}
 save(OUT/'summary.json',result)
 return result

def worker(w):
 torch.set_num_threads(2);OUT.mkdir(exist_ok=True);start=time.time();count=0
 cases=[(k,s) for k in ['main','external'] for s in study.c.ref.subjects(k)][w::2]
 try:
  for kind,s in cases:
   x,y=study.c.ref.dataset(kind,s);outer,te=next(study.c.ref.splits(kind,x,y));tr=study.subset(outer,y,study.c.ref.seed(kind,s,0),.5)
   for method in study.METHODS:
    dest=OUT/'results'/kind/method;dest.mkdir(parents=True,exist_ok=True);name=study.c.ref.name(kind,s,0);p=dest/(name+'.npz')
    if p.exists():count+=1;continue
    old=ROOT/'results'/kind/'p50'/method/(name+'.npz')
    if old.exists() and old.with_suffix('.json').exists():
     with np.load(old) as z:assert np.array_equal(z['train_idx'],tr) and np.array_equal(z['test_idx'],te);assert np.array_equal(z['y'],y[te]);prob=z['prob'].copy()
     row=json.loads(old.with_suffix('.json').read_text());row['short_screen_reused']=str(old)
    else:
     model,prob,initial,trace,diag,seconds=study.fit(kind,s,0,x,y,tr,te,method,200)
     row={'dataset':kind,'subject':s,'fold':0,'fraction':.5,'method':method,'accuracy':float((prob.argmax(1)==y[te]).mean()),'seconds':seconds,'initial_sha256':initial,'trace':trace,'diagnostics':diag,'short_screen_reused':None}
     del model;torch.cuda.empty_cache()
    np.savez_compressed(p,prob=prob,y=y[te],train_idx=tr,test_idx=te,outer_train_idx=outer);save(p.with_suffix('.json'),row);count+=1
    save(OUT/f'worker{w}_status.json',{'state':'running','pid':os.getpid(),'completed':count,'total':len(cases)*4,'elapsed_seconds':time.time()-start,'current':{'dataset':kind,'subject':s,'method':method},'last_fit_seconds':row['seconds']})
    print('SHORT_DONE',kind,s,method,'reuse' if row['short_screen_reused'] else row['seconds'],flush=True)
  save(OUT/f'worker{w}_status.json',{'state':'complete','completed':count,'elapsed_seconds':time.time()-start})
 except BaseException:
  save(OUT/f'worker{w}_status.json',{'state':'failed','error':traceback.format_exc()});raise

def launch():
 OUT.mkdir(exist_ok=True);assert not (OUT/'launch.json').exists(),'Do not duplicate short run';start=time.time();procs=[];logs=[]
 for w in [0,1]:
  log=(OUT/f'worker{w}.log').open('ab');logs.append(log);procs.append(subprocess.Popen(['/root/venv_fast/bin/python','-u',str(Path(__file__)),'--worker',str(w)],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL))
 save(OUT/'launch.json',{'state':'running','pid':os.getpid(),'workers':[p.pid for p in procs],'started':start,'total':84})
 rc=[p.wait() for p in procs]
 for log in logs:log.close()
 result=report();save(OUT/'launch.json',{'state':'complete' if not any(rc) else 'failed','returncodes':rc,'elapsed_seconds':time.time()-start,'completed':result['completed'],'total':84})

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--worker',type=int);ap.add_argument('--report',action='store_true');a=ap.parse_args()
 if a.report:print(json.dumps(report(),ensure_ascii=False))
 elif a.worker is not None:worker(a.worker)
 else:launch()
