import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
import sys,time,json,traceback
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/relation_validation_20261008')
import design_before_pool as old
import numpy as np,torch
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge,RidgeClassifier
torch.set_num_threads(2)
ROOT=Path('/root/FAST/experiments/tail_coverage_20261008')
def save(name,value):
 p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2));tmp.replace(p)
def standard(a,tr):return StandardScaler().fit(a[tr]).transform(a).astype(np.float64)/np.sqrt(a.shape[1])
def raw_stats(x):return np.concatenate([x.mean(-1),x.std(-1)],1)
@torch.no_grad()
def head_chunk(model,x):return torch.cat([model.forward_head(torch.from_numpy(x[i:i+32]).cuda()).cpu() for i in range(0,len(x),32)]).cuda()
@torch.no_grad()
def last_head(model,x):return torch.cat([model.head(torch.from_numpy(x[i:i+32]).cuda()).cpu() for i in range(0,len(x),32)]).cuda()
def case(s,f):
 tic=time.time();c=old.c;x,y=c.ref.dataset('main',s);tr,te=list(c.ref.splits('main',x,y))[f];source=c.old.source_path('main','ce',s,f)
 ck=torch.load(source,map_location='cpu',weights_only=False);model=c.build('main',s,f).eval().requires_grad_(False);model.load_state_dict(ck['state_dict'])
 assert np.array_equal(ck['train_idx'],tr) and np.array_equal(ck['test_idx'],te)
 cfg=model.config;covered=(model.n_tokens-1)*cfg.slide_step+cfg.window_len;missing=cfg.seq_len-covered
 assert covered==750 and missing==50 and x.shape[-1]==800
 h=head_chunk(model,x);base=standard(h.flatten(1).cpu().numpy(),tr)
 tail=standard(raw_stats(x[...,covered:]),tr);visible=standard(raw_stats(x[...,covered-missing:covered]),tr)
 rt=tail-Ridge(alpha=1.,solver='cholesky').fit(base[tr],tail[tr]).predict(base)
 rv=visible-Ridge(alpha=1.,solver='cholesky').fit(base[tr],visible[tr]).predict(base)
 # Permutations stay inside train and test separately and never use labels.
 rng=np.random.default_rng(810081+s*5+f);negative=rt.copy()
 negative[tr]=rt[rng.permutation(tr)];negative[te]=rt[rng.permutation(te)]
 features={'probe_base':base,'probe_tail':np.concatenate([base,tail],1),'probe_visible':np.concatenate([base,visible],1),'probe_tail_residual':np.concatenate([base,rt],1),'probe_visible_residual':np.concatenate([base,rv],1),'probe_shuffled_tail_residual':np.concatenate([base,negative],1)}
 predictions={};accuracy={}
 for name,data in features.items():
  clf=RidgeClassifier(alpha=1.,solver='cholesky').fit(data[tr],y[tr]);predictions[name]=clf.predict(data[te]);accuracy[name]=float(np.mean(predictions[name]==y[te]))
 with torch.no_grad():
  original=old.logits(model,h[te]);direct=model(torch.from_numpy(x[te]).cuda());error=float((original-direct).abs().max());assert error<2e-5
  predictions['neural_original']=original.argmax(1).cpu().numpy()
  for name,start in [('neural_cover_tail',cfg.seq_len-cfg.window_len),('neural_backward_control',covered-cfg.window_len-missing)]:
   updated=h[te].clone();updated[:,-1]=last_head(model,x[te,:,start:start+cfg.window_len]);predictions[name]=old.logits(model,updated).argmax(1).cpu().numpy()
  start=cfg.seq_len-cfg.window_len;sub=x[te,:,start:].copy();sub[...,-missing:]=x[te,:,covered-missing:covered]
  updated=h[te].clone();updated[:,-1]=last_head(model,sub);predictions['neural_cover_copied_tail']=old.logits(model,updated).argmax(1).cpu().numpy()
 for name in ['neural_original','neural_cover_tail','neural_backward_control','neural_cover_copied_tail']:accuracy[name]=float(np.mean(predictions[name]==y[te]))
 np.savez_compressed(ROOT/f's{s}_f{f}_predictions.npz',y=y[te],train=tr,test=te,**predictions)
 row=dict(subject=s,fold=f,source=str(source),accuracy=accuracy,seconds=time.time()-tic,cache_error=error)
 save(f's{s}_f{f}.json',row);return row
def main():
 ROOT.mkdir(exist_ok=True);tic=time.time();rows=[]
 for f in range(5):
  for s in range(15):
   p=ROOT/f's{s}_f{f}.json';row=json.loads(p.read_text()) if p.exists() else case(s,f);rows.append(row)
   summary={name:float(np.mean([z['accuracy'][name] for z in rows])) for name in rows[0]['accuracy']}
   save('progress.json',dict(state='running',completed=len(rows),total=75,elapsed=time.time()-tic,summary=summary));print(json.dumps(row),flush=True)
 save('progress.json',dict(state='completed',completed=75,total=75,elapsed=time.time()-tic,summary=summary))
if __name__=='__main__':
 try:main()
 except Exception:save('error.json',dict(error=traceback.format_exc()));raise
