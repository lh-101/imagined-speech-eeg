import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
import sys,time,json,math,argparse,traceback,copy
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/relation_validation_20261008')
import run_context_joint as j
import torch,numpy as np
from torch import nn
from torch.nn import functional as F
torch.set_num_threads(2)
c=j.c; ROOT=Path('/root/FAST/experiments/decision_bridge_20261009')
ARMS=['global','fixed','adaptive']; ENCODINGS=['original','shared']; TOTAL=126
def save(name,obj):
 ROOT.mkdir(exist_ok=True);p=ROOT/name;t=p.with_suffix('.tmp');t.write_text(json.dumps(obj,indent=2));t.replace(p)
class Decision(nn.Module):
 def __init__(self,regions,width,classes):
  super().__init__();self.weight=nn.Parameter(torch.zeros(regions,width,classes));self.bias=nn.Parameter(torch.zeros(regions,classes))
  self.router=nn.Sequential(nn.Linear(5,8),nn.GELU(),nn.Linear(8,1))
  nn.init.zeros_(self.router[-1].weight);nn.init.zeros_(self.router[-1].bias)
 def route(self,g,regional_prob):
  def entropy(p):return -(p*p.clamp_min(1e-8).log()).sum(-1)/math.log(p.shape[-1])
  def margin(p):v=p.topk(2,dim=-1).values;return v[:,0]-v[:,1]
  signals=torch.stack([entropy(g),entropy(regional_prob),margin(g),margin(regional_prob),(g-regional_prob).abs().sum(-1)/2],-1).detach()
  return self.router(signals).sigmoid()
 def forward(self,full,global_logits,adapter,arm):
  r=((torch.asinh(full.float())-adapter.saved.center)/adapter.saved.scale).clamp(-6,6).mean(1)
  regional_logits=torch.einsum('brd,rdc->brc',r,self.weight)+self.bias
  regional_prob=regional_logits.softmax(-1).mean(1);g=global_logits.float().softmax(-1)
  learned=self.route(g,regional_prob)
  alpha=learned if arm=='adaptive' else torch.full_like(learned,.5 if arm=='fixed' else 0.)
  probability=(1-alpha)*g+alpha*regional_prob
  return probability,regional_logits,alpha
def probabilities(kind,base,adapter,head,features,arm):
 global_logits,q,_,delta=j.combo.rep(kind,base,adapter,features)
 probability,regional_logits,alpha=head(features,global_logits,adapter,arm)
 return probability,global_logits,regional_logits,alpha,q,delta
class Zero(nn.Module):
 def forward(self,features,mean):return features.new_zeros((len(features),features.shape[1],32)),None
def calibrate(kind,s,encoding,steps=200):
 dest=ROOT/f'{kind}_{s}_{encoding}_calibration.pt'
 if dest.exists():return torch.load(dest,map_location='cpu',weights_only=False)
 from sklearn.model_selection import StratifiedShuffleSplit
 x,y=c.ref.dataset(kind,s);tr,te=list(c.ref.splits(kind,x,y))[0]
 seed=c.ref.seed(kind,s,0)+940091
 core,valid=next(StratifiedShuffleSplit(n_splits=1,test_size=.2,random_state=seed).split(x[tr],y[tr]))
 core=tr[core];valid=tr[valid]
 assert not len(np.intersect1d(core,valid)) and not len(np.intersect1d(tr,te))
 # Build from random initialization: historical full-training weights may not be used here.
 c.ref.main_ref.v4.seed_all(seed);base=c.build(kind,s,0).cuda()
 encoder=base if encoding=='original' else j.common.WindowConsistentModel(base,balanced=False)
 xx=c.normalize(kind,x,core);xt=torch.from_numpy(xx[core]).cuda();yt=torch.from_numpy(y[core]).cuda();zero=Zero().cuda()
 opt=torch.optim.AdamW(base.parameters(),lr=.001,weight_decay=.01);tic=time.time()
 for step in range(steps):
  base.train();opt.zero_grad(set_to_none=True)
  for group in opt.param_groups:group['lr']=.001*(.1+.9*.5*(1+math.cos(math.pi*step/max(steps-1,1))))
  with torch.autocast('cuda',dtype=torch.bfloat16):features=encoder.forward_head(xt)
  logits,q,_,_=j.combo.rep(kind,base,zero,features.float())
  loss=F.cross_entropy(logits,yt)+.3*F.cross_entropy(4*c.ref.ridge(kind,q,yt),yt)
  assert torch.isfinite(loss);loss.backward();opt.step()
 base.eval().requires_grad_(False)
 with torch.no_grad():features=j.common.cache(kind,encoder,xx).detach()
 reference=c.ref.initialize(kind,features[core],torch.zeros_like(features[core]));generic=c.ref.GenericAdapter(reference).cuda();del reference
 adapter=c.temporal.Temporal(generic,'multiscale').cuda().requires_grad_(True)
 head=Decision(features.shape[2],features.shape[3],len(np.unique(y))).cuda()
 fit(kind,base,adapter,head,features[core],yt,'fixed',seed,steps)
 adapter.eval();head.eval()
 with torch.no_grad():_,g,r,_,_,_=probabilities(kind,base,adapter,head,features[valid],'fixed');g=g.softmax(-1).detach();r=r.softmax(-1).mean(1).detach()
 target=torch.from_numpy(y[valid]).cuda();opt=torch.optim.AdamW(head.router.parameters(),lr=.005,weight_decay=.01)
 for step in range(steps):
  opt.zero_grad(set_to_none=True);a=head.route(g,r);p=(1-a)*g+a*r
  loss=F.nll_loss(p.clamp_min(1e-8).log(),target);assert torch.isfinite(loss);loss.backward();opt.step()
 with torch.no_grad():a=head.route(g,r);p=(1-a)*g+a*r
 info=dict(core=core.tolist(),calibration=valid.tolist(),outer_test=te.tolist(),seed=seed,random_initialization=True,normalization_from_core_only=True,validation_accuracy=float((p.argmax(-1)==target).float().mean()),validation_global_accuracy=float((g.argmax(-1)==target).float().mean()),validation_region_accuracy=float((r.argmax(-1)==target).float().mean()),mean_weight=float(a.mean()),weight_std=float(a.std()),seconds=time.time()-tic,limitation='One internal split; inner model freshly fit on80% with simplified staged recipe, full outer model uses existing historical source. Router transfer is exploratory, not guaranteed calibration under distribution shift.')
 checkpoint=dict(router=head.router.state_dict(),info=info);torch.save(checkpoint,dest);save(dest.stem+'.json',info)
 print('CALIBRATION_DONE',json.dumps(info),flush=True)
 del base,encoder,adapter,generic,head,features,xt,yt;torch.cuda.empty_cache();return checkpoint
def fit(kind,base,adapter,head,features,y,arm,seed,steps,context=None):
 c.ref.main_ref.v4.seed_all(seed);base.eval().requires_grad_(False);adapter.train().requires_grad_(True);head.train()
 params=list(adapter.parameters())+list(head.parameters())
 opt=torch.optim.AdamW([dict(params=list(adapter.parameters()),lr=1e-4,base_lr=1e-4),dict(params=list(head.parameters()),lr=1e-3,base_lr=1e-3)],weight_decay=.01)
 trace=[];tic=time.time();checks=None
 for step in range(steps):
  for group in opt.param_groups:group['lr']=group['base_lr']*(.1+.9*.5*(1+math.cos(math.pi*step/max(steps-1,1))))
  opt.zero_grad(set_to_none=True)
  p,g,r,a,q,delta=probabilities(kind,base,adapter,head,features,arm)
  fused=F.nll_loss(p.clamp_min(1e-8).log(),y)
  global_loss=F.cross_entropy(g,y);regional_loss=F.cross_entropy(r.flatten(0,1),y[:,None].expand(-1,r.shape[1]).reshape(-1))
  aux=.3*F.cross_entropy(4*c.ref.ridge(kind,q,y),y)
  loss=fused+.3*global_loss+.3*regional_loss+aux+.01*delta.square().mean()
  assert torch.isfinite(loss);loss.backward()
  assert all(v.grad is None or torch.isfinite(v.grad).all() for v in params)
  if step==0:
   def norm(ps):return float(sum((v.grad.float().square().sum() for v in ps if v.grad is not None),torch.zeros((),device='cuda')).sqrt())
   checks=dict(adapter_grad=norm(adapter.parameters()),regional_grad=norm([head.weight,head.bias]),router_grad=norm(head.router.parameters()))
   assert checks['adapter_grad']>0 and checks['regional_grad']>0
   if arm=='adaptive':assert checks['router_grad']>0
  opt.step()
  if step in [0,49,99,steps-1]:
   trace.append(dict(step=step+1,fused=float(fused.detach()),global_ce=float(global_loss.detach()),regional_ce=float(regional_loss.detach()),loo=float(aux.detach()),mean_region_weight=float(a.detach().mean())))
   if context:save('progress.json',dict(state='running',completed_models=context['completed'],total_models=TOTAL,current=dict(dataset=kind,subject=context['subject'],encoding=context['encoding'],arm=arm,step=step+1),elapsed=time.time()-context['started']))
 torch.cuda.synchronize();return dict(seconds=time.time()-tic,trace=trace,gradients=checks)
def run(kind,s,encoding,arm,steps=200,context=None,persist=True):
 if context:save('progress.json',dict(state='running',completed_models=context['completed'],total_models=TOTAL,current=dict(dataset=kind,subject=s,encoding=encoding,arm=arm,stage='inner_calibration' if arm=='adaptive' else 'head_training'),elapsed=time.time()-context['started']))
 tic=time.time();calibration=calibrate(kind,s,encoding,steps=steps) if arm=='adaptive' else None
 base,encoder,adapter,xx,y,tr,te,source,initial,error=j.load(kind,s,encoding+'_joint')
 base.eval().requires_grad_(False);adapter.eval()
 with torch.no_grad():features=j.common.cache(kind,encoder,xx).detach()
 assert features.ndim==4,features.shape
 assert len(np.intersect1d(tr,te))==0
 seed=c.ref.seed(kind,s,0)+930091;c.ref.main_ref.v4.seed_all(seed)
 head=Decision(features.shape[2],features.shape[3],initial.shape[-1]).cuda()
 before=c.ref.main_ref.tensorhash(base);adapterhash=c.ref.main_ref.tensorhash(adapter)
 # The global path must exactly replay the historical checkpoint before training.
 with torch.no_grad():replay=probabilities(kind,base,adapter,head,features[te],'global')[0].cpu().numpy()
 replay_error=float(np.max(abs(replay-initial)));assert replay_error<1e-6,replay_error
 # Adaptive and fixed heads use identical training; only the clean internal router differs.
 training=fit(kind,base,adapter,head,features[tr],torch.from_numpy(y[tr]).cuda(),'fixed' if arm=='adaptive' else arm,seed,steps,context)
 if calibration:head.router.load_state_dict(calibration['router'])
 adapter.eval();head.eval()
 with torch.no_grad():p,g,r,a,_,_=probabilities(kind,base,adapter,head,features[te],arm)
 prob=p.cpu().numpy();global_prob=g.softmax(-1).cpu().numpy();regional_prob=r.softmax(-1).mean(1).cpu().numpy();alpha=a.cpu().numpy()
 assert np.isfinite(prob).all() and np.allclose(prob.sum(-1),1,atol=1e-5)
 assert c.ref.main_ref.tensorhash(base)==before
 row=dict(dataset=kind,subject=s,fold=0,encoding=encoding,arm=arm,seed=seed,initial_accuracy=float(np.mean(initial.argmax(-1)==y[te])),accuracy=float(np.mean(prob.argmax(-1)==y[te])),global_accuracy=float(np.mean(global_prob.argmax(-1)==y[te])),regional_accuracy=float(np.mean(regional_prob.argmax(-1)==y[te])),decision_disagreement=float(np.mean(global_prob.argmax(-1)!=regional_prob.argmax(-1))),mean_region_weight=float(alpha.mean()),weight_std=float(alpha.std()),source_hash=before,initial_adapter_hash=adapterhash,parameters=sum(v.numel() for v in head.parameters())+sum(v.numel() for v in adapter.parameters()),replay_error=replay_error,training=training,seconds=time.time()-tic)
 if persist:
  name=f'{kind}_{s}_{encoding}_{arm}';np.savez_compressed(ROOT/(name+'.npz'),train=tr,test=te,y=y[te],initial_prob=initial,prob=prob,global_prob=global_prob,regional_prob=regional_prob,region_weight=alpha)
  torch.save(dict(adapter=adapter.state_dict(),head=head.state_dict(),train=tr,test=te,seed=seed,source=str(source),encoding=encoding,arm=arm),ROOT/(name+'.pt'));save(name+'.json',row)
 print('BRIDGE_DONE',json.dumps(row),flush=True)
 del base,encoder,adapter,head,features;torch.cuda.empty_cache();return row
def report():
 groups={};n=0
 for kind,ss in [('main',range(15)),('external',range(1,7))]:
  rows=[]
  for s in ss:
   paths=[ROOT/f'{kind}_{s}_{encoding}_{arm}.json' for encoding in ENCODINGS for arm in ARMS]
   n+=sum(p.exists() for p in paths)
   if not all(p.exists() for p in paths):continue
   vals=[json.loads(p.read_text()) for p in paths]
   assert len({v['source_hash'] for v in vals})==1 and len({v['seed'] for v in vals})==1
   rows.extend(vals)
  means={}
  for encoding in ENCODINGS:
   for arm in ARMS:
    rr=[v for v in rows if v['encoding']==encoding and v['arm']==arm]
    if rr:means[encoding+'_'+arm]={key:float(np.mean([v[key] for v in rr])) for key in ['accuracy','initial_accuracy','global_accuracy','regional_accuracy','decision_disagreement','mean_region_weight','seconds']}
  groups[kind]=dict(complete_subjects=len(rows)//6,means=means,rows=rows)
 save('summary.json',dict(complete=n==TOTAL,completed_models=n,total_models=TOTAL,groups=groups,scope='All subjects fold0 exploratory development comparison; source LOO CNN/Transformer frozen, existing regional residual adapter and new heads trained jointly. No independent confirmation, no novelty or necessity claim.'))
 return n
def main(smoke=False):
 global ROOT
 ROOT.mkdir(exist_ok=True);started=time.time()
 if smoke:
  rows=[run(kind,s,encoding,'fixed',steps=2,persist=False) for kind,s in [('main',0),('external',1)] for encoding in ENCODINGS]
  original_root=ROOT;ROOT=ROOT/'inner_smoke';ROOT.mkdir(exist_ok=True)
  checks=[calibrate(kind,s,'shared',steps=2)['info'] for kind,s in [('main',0),('external',1)]]
  ROOT=original_root
  save('smoke.json',dict(passed=True,rows=rows,inner_checks=checks));return
 save('protocol.json',dict(question='Can independent regional readout complement global decisions within one encoder, and does learned decision fusion improve on global and fixed fusion?',total_models=TOTAL,datasets=['BCI2020','Nguyen'],subjects=[15,6],fold=0,encodings=ENCODINGS,arms=ARMS,steps=200,loss='fused NLL + .3global CE + .3 per-region CE + .3CE(4 analytic LOO) + .01 residual squared',optimizer='Frozen source backbone; existing residual adapter lr1e-4 and new regional heads/router lr1e-3, AdamW wd.01 cosine to0.1',router='5 detached confidence/disagreement statistics ->8 GELU -> sigmoid regional mixing weight; zero final-layer initialization gives .5',controls='Same parameters, initial weights and training data; global alpha0, fixed alpha.5, adaptive learned alpha. CNN and transformer source frozen. No test-dependent fusion weights or checkpoint selection.',scope='Previously explored outer fold0; comparative feasibility screen, not independent validation. Finish fixed cohort regardless of signs; no automatic expansion to five folds.',limitations='CNN source was historically trained on original windows with LOO; frozen encoder does not test joint backbone learning. Existing encoder-specific adapters have different starting weights. Local and global heads are standard fusion constructs; this experiment does not prove a new general computing principle.'))
 protocol=json.loads((ROOT/'protocol.json').read_text());protocol.update(calibration='One stratified80/20 internal training split per subject/encoder: fresh random backbone CE+LOO200steps oncore, fresh adapter/heads200steps oncore, router200steps on internal heldout predictions. Normalization fit oncore only. Outer test never used for router. Final adaptive/fixed adapter and regional-head training identical, router transferred from inner model.',additional_inner_models=42,limitation_inner='Inner source/adapter recipe simplified relative to historical final source; transferring router across this distribution shift is exploratory. No claim of perfectly calibrated confidence.');save('protocol.json',protocol)
 try:
  # Finish all arms on paired subjects first; preserve all outcomes.
  order=[]
  for i in range(15):
   order.append(('main',i))
   if i<6:order.append(('external',i+1))
  for kind,s in order:
   for encoding in ENCODINGS:
    for arm in ARMS:
     if (ROOT/f'{kind}_{s}_{encoding}_{arm}.json').exists():continue
     run(kind,s,encoding,arm,context=dict(completed=report(),subject=s,encoding=encoding,started=started));report()
  assert report()==TOTAL
  save('progress.json',dict(state='completed',completed_models=TOTAL,total_models=TOTAL,elapsed=time.time()-started))
 except Exception:save('error.json',dict(error=traceback.format_exc()));raise
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--smoke',action='store_true');args=parser.parse_args();main(args.smoke)
