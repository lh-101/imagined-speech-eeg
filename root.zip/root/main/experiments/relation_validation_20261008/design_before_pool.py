import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
import sys,time,json,traceback,math
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/parallel_questions_20261008')
import common as c
import torch,numpy as np
from torch import nn
from torch.nn import functional as F
torch.set_num_threads(2)
ROOT=Path('/root/FAST/experiments/prepool_design_20261008')
CASES=[('main',0),('main',7),('external',1),('external',4)]
def save(name,obj):
 p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2))

class Correction(nn.Module):
 def __init__(self,feature,train,dim,hidden):
  super().__init__()
  mu=feature[train].mean((0,1),keepdim=True);sd=feature[train].std((0,1),keepdim=True).clamp_min(1e-5)
  self.register_buffer('mu',mu);self.register_buffer('sd',sd)
  self.hidden=nn.Linear(feature.shape[-1],hidden);self.out=nn.Linear(hidden,dim)
  nn.init.zeros_(self.out.weight);nn.init.zeros_(self.out.bias)
 def forward(self,f):return self.out(F.gelu(self.hidden(torch.asinh((f-self.mu)/self.sd))))

@torch.no_grad()
def cache(model,x):
 # Shared fixed random readout; no fit on labels/test data. Base CNN remains intact.
 generator=torch.Generator(device='cuda').manual_seed(810081)
 projection=torch.randn(model.config.dim_cnn,2,device='cuda',generator=generator)/math.sqrt(model.config.dim_cnn)
 zs=len(model.head.encoders);mask=~torch.eye(zs,device='cuda',dtype=torch.bool).repeat_interleave(2,0).repeat_interleave(2,1)
 ii,jj=torch.where(torch.triu(mask,diagonal=1))
 allh=[];before=[];after=[]
 for start in range(0,len(x),16):
  xt=torch.from_numpy(x[start:start+16]).cuda();windows=xt.unfold(-1,model.config.window_len,model.config.slide_step)
  B,C,N,T=windows.shape;flat=windows.permute(0,2,1,3).reshape(B*N,C,T)
  means=[];local=[]
  for area,enc in model.head.encoders.items():
   a=flat[:,model.head.index_dict[area]].unsqueeze(1)
   a=F.gelu(enc.cnn4(enc.cnn3(enc.cnn2(enc.cnn1(a))))).squeeze(2)
   means.append(a.mean(-1));local.append(torch.einsum('bft,fd->bdt',a,projection))
  h=torch.stack(means,1).reshape(B,N,zs,-1)
  u=torch.stack(local,1).flatten(1,2);center=u-u.mean(-1,keepdim=True)
  features=[]
  for lag in [0,16,32,64]:
   a=center[...,:center.shape[-1]-lag] if lag else center;b=center[...,lag:] if lag else center
   # Normalized inner products retain timing relationships, unlike product of time means.
   a=a/a.square().mean(-1,keepdim=True).sqrt().clamp_min(1e-5);b=b/b.square().mean(-1,keepdim=True).sqrt().clamp_min(1e-5)
   mat=torch.bmm(a,b.transpose(1,2))/a.shape[-1];features.append(mat[:,ii,jj])
  cov=torch.cat(features,1).reshape(B,N,-1)
  mu=u.mean(-1);product=(mu[:,ii]*mu[:,jj]).repeat(1,4).reshape(B,N,-1)
  allh.append(h.cpu());before.append(cov.cpu());after.append(product.cpu())
 return torch.cat(allh).cuda(),torch.cat(before).cuda(),torch.cat(after).cuda()

def logits(model,h,adapter=None,feature=None):
 tokens=model.input_layer(h.flatten(2))
 if adapter is not None:tokens=tokens+adapter(feature)
 tokens=torch.cat([model.cls_token.expand(len(h),-1,-1),tokens],1)+model.pos_embedding[:,:model.n_tokens+1]
 tokens=model.transformer(tokens)
 return model.last_layer(model.dropout(tokens[:,0]))

def case(kind,s):
 begin=time.time();x,y=c.ref.dataset(kind,s);tr,te=next(c.ref.splits(kind,x,y));p=c.old.source_path(kind,'ce',s,0)
 ck=torch.load(p,map_location='cpu',weights_only=False);model=c.build(kind,s,0).eval();model.load_state_dict(ck['state_dict']);model.requires_grad_(False)
 assert np.array_equal(ck['train_idx' if kind=='main' else 'train'],tr) and np.array_equal(ck['test_idx' if kind=='main' else 'test'],te)
 xx=c.normalize(kind,x,tr)
 if kind=='external':
  mu,sd=ck['normalization'];assert np.allclose(xx,(x-mu)/sd,atol=2e-5)
 h,pre,post=cache(model,xx);yt=torch.from_numpy(y).cuda();base=h.flatten(2)
 with torch.no_grad():
  direct=model(torch.from_numpy(xx[te]).cuda());cached=logits(model,h[te]);error=float((direct-cached).abs().max());assert error<2e-5,error
  official=cached.argmax(1).cpu().numpy()
 result=dict(kind=kind,subject=s,fold=0,ce=float(np.mean(official==y[te])),cache_error=error,models={},seconds=None)
 pred={'ce':official}
 # Generic control has at least as many trainable parameters as prepool design.
 hidden=math.ceil((pre.shape[-1]*32+32+32*model.config.dim_token+model.config.dim_token-model.config.dim_token)/(base.shape[-1]+1+model.config.dim_token))
 for mode,feature,width in [('prepool',pre,32),('postpool',post,32),('generic',base,hidden)]:
  torch.manual_seed(c.ref.seed(kind,s,0)+81008)
  adapter=Correction(feature,tr,model.config.dim_token,width).cuda();optimizer=torch.optim.AdamW(adapter.parameters(),lr=.001,weight_decay=.01)
  with torch.no_grad():assert torch.equal(logits(model,h[te],adapter,feature[te]),cached)
  initial=float(F.cross_entropy(logits(model,h[tr],adapter,feature[tr]),yt[tr]))
  for step in range(200):
   optimizer.zero_grad(set_to_none=True)
   for group in optimizer.param_groups:group['lr']=.001*(.1+.9*.5*(1+math.cos(math.pi*step/199)))
   d=adapter(feature[tr]);logit=logits(model,h[tr],adapter,feature[tr]);loss=F.cross_entropy(logit,yt[tr])+.01*d.square().mean()
   assert torch.isfinite(loss);loss.backward();assert all(p.grad is None or torch.isfinite(p.grad).all() for p in adapter.parameters());optimizer.step()
  adapter.eval()
  with torch.no_grad():
   out=logits(model,h[te],adapter,feature[te]);pred[mode]=out.argmax(1).cpu().numpy()
   trainacc=float((logits(model,h[tr],adapter,feature[tr]).argmax(1)==yt[tr]).float().mean())
  result['models'][mode]=dict(accuracy=float(np.mean(pred[mode]==y[te])),train_accuracy=trainacc,parameters=sum(p.numel() for p in adapter.parameters()),initial_ce=initial)
  torch.save(dict(adapter=adapter.state_dict(),source=str(p),mode=mode),ROOT/f'{kind}_{s}_{mode}.pt')
 np.savez_compressed(ROOT/f'{kind}_{s}_predictions.npz',y=y[te],train=tr,test=te,**pred)
 result['seconds']=time.time()-begin;save(f'{kind}_{s}.json',result);return result

def main():
 ROOT.mkdir(exist_ok=True);rows=[];start=time.time()
 for kind,s in CASES:
  p=ROOT/f'{kind}_{s}.json';rows.append(json.loads(p.read_text()) if p.exists() else case(kind,s))
  save('progress.json',dict(state='running',completed=len(rows),total=4,elapsed=time.time()-start,rows=rows));print(json.dumps(rows[-1]),flush=True)
 summary={}
 for kind in ['main','external']:
  r=[q for q in rows if q['kind']==kind]
  summary[kind]={'ce':float(np.mean([q['ce'] for q in r]))}
  for mode in ['prepool','postpool','generic']:summary[kind][mode]=float(np.mean([q['models'][mode]['accuracy'] for q in r]))
 save('progress.json',dict(state='completed',completed=4,total=4,elapsed=time.time()-start,rows=rows,summary=summary))
if __name__=='__main__':
 try:main()
 except Exception:save('error.json',dict(error=traceback.format_exc()));raise
