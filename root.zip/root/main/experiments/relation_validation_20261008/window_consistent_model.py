"""Parameter-preserving full-context window encoder prototype; no novelty claim."""
import torch
from torch import nn
from torch.nn import functional as F

class WindowConsistentModel(nn.Module):
 def __init__(self,base,balanced=True):
  super().__init__();self.base=base;cfg=base.config
  length=cfg.seq_len-4;window=cfg.window_len-4
  starts=[i*cfg.slide_step for i in range(base.n_tokens)];starts[-1]=cfg.seq_len-cfg.window_len
  mask=torch.zeros(base.n_tokens,length,device=next(base.parameters()).device)
  for i,start in enumerate(starts):mask[i,start:start+window]=1
  assert (mask.sum(0)>0).all()
  raw=mask/mask.sum(0,keepdim=True) if balanced else mask
  self.register_buffer('pool_weights',raw/raw.sum(1,keepdim=True))
  self.register_buffer('window_mass',raw.sum(1))
  self.balanced=balanced
 def forward_head(self,x):
  areas=[]
  for area,enc in self.base.head.encoders.items():
   a=x[:,self.base.head.index_dict[area]].unsqueeze(1)
   a=F.gelu(enc.cnn4(enc.cnn3(enc.cnn2(enc.cnn1(a))))).squeeze(2)
   areas.append(torch.einsum('bft,nt->bnf',a,self.pool_weights.to(a.dtype)))
  return torch.stack(areas,2)
 def forward(self,x):return self.base.forward_transformer(self.forward_head(x))
