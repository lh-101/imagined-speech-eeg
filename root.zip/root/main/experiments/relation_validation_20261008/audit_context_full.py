import json,numpy as np
from pathlib import Path
def main():
 import run_context_full as run
 r=run.ROOT;rows=[]
 for kind,s,fold in run.CASES:
  with np.load(r/f'{kind}_{s}_fold{fold}_source.npz') as z:
   labels=z['y'].copy();tr=z['train'].copy();te=z['test'].copy()
  assert not len(np.intersect1d(tr,te))
  matched=[]
  for mode in run.active_modes(kind,fold):
   row=json.loads((r/f'{kind}_{s}_fold{fold}_{mode}.json').read_text())
   assert row['fold']==fold and row['subject']==s and row['mode']==mode
   with np.load(r/f'{kind}_{s}_fold{fold}_{mode}.npz') as z:
    assert np.isfinite(z['logits']).all()
    assert np.array_equal(z['y'],labels) and np.array_equal(z['train'],tr) and np.array_equal(z['test'],te)
    assert abs(float(np.mean(z['logits'].argmax(1)==labels))-row['accuracy'])<1e-12
   assert (r/f'{kind}_{s}_fold{fold}_{mode}.pt').exists()
   rows.append(row);matched.append(row)
  for key in ['source_hash','seed','parameters','source']:assert len({v[key] for v in matched})==1
 summary={}
 for kind,subjects in [('main',range(15)),('external',range(1,7))]:
  per=[dict(subject=s,**{mode:100*float(np.mean([v['accuracy'] for v in rows if v['dataset']==kind and v['subject']==s and v['mode']==mode])) for mode in run.MODES}) for s in subjects]
  stats={mode:dict(mean=float(np.mean([v[mode] for v in per])),subject_sd=float(np.std([v[mode] for v in per],ddof=1))) for mode in run.MODES}
  if kind=='external':
   partial=[v for v in rows if v['dataset']==kind and v['mode']=='full_context_balanced']
   paired=[]
   for v in partial:
    control=next(x for x in rows if x['dataset']==kind and x['subject']==v['subject'] and x['fold']==v['fold'] and x['mode']=='original_finetune')
    paired.append(100*(v['accuracy']-control['accuracy']))
   stats['balanced_stopped_partial']=dict(folds=[0,1],paired_cases=len(partial),delta_pp=float(np.mean(paired)),reason='User-directed early stop after negative interim result; not complete fivefold')
   for v in per:v.pop('full_context_balanced',None)
   stats.pop('full_context_balanced',None)
   stats['subjects']=per
   summary[kind]=stats
   continue
  delta=np.array([v['full_context_balanced']-v['original_finetune'] for v in per])
  rng=np.random.default_rng(20261008)
  ci=np.quantile(delta[rng.integers(0,len(delta),size=(10000,len(delta)))].mean(1),[.025,.975]).tolist()
  stats.update(subjects=per,balanced_delta_pp=float(delta.mean()),subject_win_tie_loss=[int((delta>1e-9).sum()),int((abs(delta)<=1e-9).sum()),int((delta< -1e-9).sum())],descriptive_subject_bootstrap_95ci_pp=ci)
  summary[kind]=stats
 out=dict(verified_fits=len(rows),verified_folds=len(run.CASES),summary=summary,rows=rows,limits='Fivefold development validation, not independent confirmation. BCI tail coverage and context changes remain partly confounded. No claim of unprecedented primitive or necessity.')
 (r/'audit.json').write_text(json.dumps(out,indent=2))
 Path('/root/FAST/experiments/relation_validation_20261008/context_full_results.json').write_text(json.dumps(out,indent=2))
 print('AUDIT',json.dumps(summary),flush=True)
if __name__=='__main__':main()
