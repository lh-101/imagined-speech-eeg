from pathlib import Path
import json,subprocess
r=Path('/root/FAST/experiments/context_full_20261008')
plan=json.loads((r/'plan.json').read_text());print('PLAN',json.dumps(plan))
print('PROCESS_PRESENT',Path('/proc',str(plan['pid'])).exists())
for name in ['progress.json','error.json']:
 if (r/name).exists():print(name,(r/name).read_text())
print('LOG',(r/'run.log').read_text()[-1200:])
print(subprocess.check_output(['nvidia-smi','--query-gpu=utilization.gpu,memory.used','--format=csv,noheader']).decode())
