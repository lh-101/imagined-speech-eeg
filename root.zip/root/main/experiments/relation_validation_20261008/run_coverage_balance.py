import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
import sys,time,json,traceback
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/relation_validation_20261008')
import design_before_pool as old
import numpy as np,torch
from torch.nn import functional as F
torch.set_num_threads(2)
ROOT=Path('/root/FAST/experiments/coverage_balance_20261008')
def save(name,obj):
 p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2));tmp.replace(p)
def geometry(cfg,n,complete):
 starts=[i*cfg.slide_step for i in range(n)]
 if complete:starts[-1]=cfg.seq_len-cfg.window_len
 local_len=cfg.window_len-4;length=cfg.seq_len-4
 counts=torch.zeros(length,device='cuda')
 for start in starts:counts[start:start+local_len]+=1
 assert (counts>0).all() if complete else True
 weights=[counts[start:start+local_len].reciprocal() for start in starts]
 mass=torch.stack([w.sum() for w in weights]);return starts,weights,mass,length
def conv_map(enc,x):return F.gelu(enc.cnn4(enc.cnn3(enc.cnn2(enc.cnn1(x.unsqueeze(1)))))).squeeze(2)
@torch.no_grad()
def features(model,x):
 cfg=model.config;starts,weights,mass,length=geometry(cfg,model.n_tokens,True)
 outputs={k:[] for k in ['original','cover_only','cover_local_weighted','cover_global_uniform','cover_global_weighted']};identity_error=0.
 for chunk in range(0,len(x),16):
  xx=torch.from_numpy(x[chunk:chunk+16]).cuda();B=len(xx)
  original=model.forward_head(xx);local=[];weighted=[];gu=[];gw=[]
  for area,enc in model.head.encoders.items():
   a=xx[:,model.head.index_dict[area]];lm=[];lw=[]
   for start,w in zip(starts,weights):
    z=conv_map(enc,a[...,start:start+cfg.window_len]);lm.append(z.mean(-1));lw.append((z*w[None,None]).sum(-1)/w.sum())
   full=conv_map(enc,a);um=[];wm=[];check_wm=[]
   for start,w in zip(starts,weights):
    z=full[...,start:start+cfg.window_len-4];um.append(z.mean(-1));wm.append((z*w[None,None]).sum(-1)/w.sum())
    check_wm.append((z.double()*w.double()[None,None]).sum(-1)/w.double().sum())
   wm=torch.stack(wm,1);recovered=(torch.stack(check_wm,1)*mass.double()[None,:,None]).sum(1)/mass.double().sum()
   identity_error=max(identity_error,float((recovered-full.double().mean(-1)).abs().max()))
   local.append(torch.stack(lm,1));weighted.append(torch.stack(lw,1));gu.append(torch.stack(um,1));gw.append(wm)
  values={'original':original,'cover_only':torch.stack(local,2),'cover_local_weighted':torch.stack(weighted,2),'cover_global_uniform':torch.stack(gu,2),'cover_global_weighted':torch.stack(gw,2)}
  for k,v in values.items():outputs[k].append(v.cpu())
 return {k:torch.cat(v).cuda() for k,v in outputs.items()},identity_error
def case(kind,s,f):
 tic=time.time();c=old.c;x,y=c.ref.dataset(kind,s);tr,te=list(c.ref.splits(kind,x,y))[f];path=c.old.source_path(kind,'ce',s,f)
 ck=torch.load(path,map_location='cpu',weights_only=False);model=c.build(kind,s,f).eval().requires_grad_(False);model.load_state_dict(ck['state_dict'])
 assert np.array_equal(ck['train_idx' if kind=='main' else 'train'],tr) and np.array_equal(ck['test_idx' if kind=='main' else 'test'],te)
 xx=c.normalize(kind,x,tr)
 if kind=='external':
  mu,sd=ck['normalization'];assert np.allclose(xx,(x-mu)/sd,atol=2e-5)
 h,error=features(model,xx[te]);pred={};accuracy={}
 with torch.no_grad():
  direct=model(torch.from_numpy(xx[te]).cuda());baseline=old.logits(model,h['original']);cache_error=float((direct-baseline).abs().max());assert cache_error<2e-5
  for k,v in h.items():pred[k]=old.logits(model,v).argmax(1).cpu().numpy();accuracy[k]=float(np.mean(pred[k]==y[te]))
 assert error<2e-5,error
 np.savez_compressed(ROOT/f'{kind}_{s}_f{f}_predictions.npz',y=y[te],train=tr,test=te,**pred)
 row=dict(dataset=kind,subject=s,fold=f,accuracy=accuracy,conservation_error=error,cache_error=cache_error,seconds=time.time()-tic,source=str(path));save(f'{kind}_{s}_f{f}.json',row);return row
def summarize(rows):
 out={}
 for kind in ['main','external']:
  rr=[r for r in rows if r['dataset']==kind]
  if rr:out[kind]={k:float(np.mean([r['accuracy'][k] for r in rr])) for k in rr[0]['accuracy']}
 return out
def main():
 ROOT.mkdir(exist_ok=True);rows=[];tic=time.time();cases=[(kind,s,f) for f in range(5) for kind,subjects in [('main',range(15)),('external',range(1,7))] for s in subjects]
 for kind,s,f in cases:
  p=ROOT/f'{kind}_{s}_f{f}.json';row=json.loads(p.read_text()) if p.exists() else case(kind,s,f);rows.append(row)
  save('progress.json',dict(state='running',completed=len(rows),total=105,elapsed=time.time()-tic,summary=summarize(rows)));print(json.dumps(row),flush=True)
 save('progress.json',dict(state='completed',completed=105,total=105,elapsed=time.time()-tic,summary=summarize(rows)))
if __name__=='__main__':
 try:main()
 except Exception:save('error.json',dict(error=traceback.format_exc()));raise
