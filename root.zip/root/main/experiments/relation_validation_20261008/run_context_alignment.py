import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
import sys,time,json,math,traceback,argparse
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/relation_validation_20261008')
import run_combination_corrected as combo
from window_consistent_model import WindowConsistentModel
import numpy as np,torch
from torch.nn import functional as F
torch.set_num_threads(2)
c=combo.c
ROOT=Path('/root/FAST/experiments/context_alignment_20261009')
CASES=[('main',s,0) for s in range(15)]+[('external',s,0) for s in range(1,7)]
MODES=['original_aligned','shared_aligned']
def save(name,obj):
 ROOT.mkdir(exist_ok=True);p=ROOT/name;q=p.with_suffix('.tmp');q.write_text(json.dumps(obj,indent=2));q.replace(p)
def representation(base,encoder,x):
 features=encoder.forward_head(x)
 tokens=base.input_layer(features.flatten(2))
 tokens=torch.cat([base.cls_token.expand(len(x),-1,-1),tokens],1)
 hidden=base.transformer(tokens+base.pos_embedding[:,:base.n_tokens+1])[:,0]
 logits=base.last_layer(base.dropout(hidden))
 with torch.autocast('cuda',enabled=False):
  q=torch.cat([F.normalize(torch.asinh(features.float()).flatten(1),dim=-1),F.normalize(hidden.float(),dim=-1)],-1)/math.sqrt(2)
 return logits,q
def load(kind,s,f):
 x,y=c.ref.dataset(kind,s);tr,te=list(c.ref.splits(kind,x,y))[f]
 path=c.old.source_path(kind,'loo',s,f);ck=torch.load(path,map_location='cpu',weights_only=False)
 assert np.array_equal(ck['train_idx' if kind=='main' else 'train'],tr)
 assert np.array_equal(ck['test_idx' if kind=='main' else 'test'],te)
 base=c.build(kind,s,f);base.load_state_dict(ck['state_dict']);base.eval().requires_grad_(True)
 xx=c.normalize(kind,x,tr)
 if kind=='external':
  mu,sd=ck['normalization'];assert np.allclose(xx,(x-mu)/sd,atol=2e-5)
 return base,xx,y,tr,te,path
def backbone_fit(kind,base,encoder,x,y,seed,steps,progress=None):
 c.ref.main_ref.v4.seed_all(seed);encoder.train();opt=torch.optim.AdamW(base.parameters(),lr=.0001,weight_decay=.01)
 xt=torch.from_numpy(x).cuda();yt=torch.from_numpy(y).cuda();trace=[];tic=time.time()
 for step in range(steps):
  for g in opt.param_groups:g['lr']=.0001*(.1+.9*.5*(1+math.cos(math.pi*step/max(steps-1,1))))
  opt.zero_grad(set_to_none=True)
  with torch.autocast('cuda',dtype=torch.bfloat16):logits,q=representation(base,encoder,xt);ce=F.cross_entropy(logits,yt)
  aux=.3*F.cross_entropy(4*c.ref.ridge(kind,q,yt),yt);loss=ce+aux
  assert torch.isfinite(loss);loss.backward()
  assert all(p.grad is None or torch.isfinite(p.grad).all() for p in base.parameters());opt.step()
  if step in [0,49,99,steps-1]:
   trace.append(dict(step=step+1,ce=float(ce.detach()),aux=float(aux.detach())))
   if progress:save('progress.json',dict(state='running',completed_models=progress['completed'],total_models=42,current=dict(dataset=kind,subject=progress['subject'],fold=0,mode=progress['mode'],stage='backbone_loo',step=step+1),elapsed=time.time()-progress['started']))
 torch.cuda.synchronize();base.eval().requires_grad_(False)
 for p in base.parameters():p.grad=None
 return dict(seconds=time.time()-tic,trace=trace)
@torch.no_grad()
def cache(kind,encoder,xx):
 parts=[]
 for i in range(0,len(xx),32):
  with torch.autocast('cuda',enabled=kind=='external',dtype=torch.bfloat16):parts.append(encoder.forward_head(torch.from_numpy(xx[i:i+32]).cuda()))
 return torch.cat(parts)
def run_case(kind,s,f,mode,context):
 tic=time.time();base,xx,y,tr,te,path=load(kind,s,f);sourcehash=c.ref.main_ref.tensorhash(base)
 encoder=base if mode=='original_aligned' else WindowConsistentModel(base,balanced=False)
 seed=c.ref.seed(kind,s,f)+910091
 before=sourcehash;stage0=backbone_fit(kind,base,encoder,xx[tr],y[tr],seed,200,context)
 after=c.ref.main_ref.tensorhash(base);assert before!=after
 full=cache(kind,encoder,xx);train=full[tr].detach();test=full[te].detach();yt=torch.from_numpy(y[tr]).cuda()
 seed_adapter=c.ref.seed(kind,s,f);c.ref.main_ref.v4.seed_all(seed_adapter)
 reference=c.ref.initialize(kind,train,torch.zeros_like(train));generic=c.ref.GenericAdapter(reference).cuda();del reference
 assert sum(p.numel() for p in generic.parameters())==9280
 save('progress.json',dict(state='running',completed_models=context['completed'],total_models=42,current=dict(dataset=kind,subject=s,fold=0,mode=mode,stage='adapter'),elapsed=time.time()-context['started']))
 stage1=combo.train(kind,base,generic,train,yt,seed_adapter,False,None);generic.eval().requires_grad_(False)
 for p in generic.parameters():p.grad=None
 c.ref.main_ref.v4.seed_all(seed_adapter);adapter=c.temporal.Temporal(generic,'multiscale').cuda()
 assert sum(p.numel() for p in adapter.parameters() if p.requires_grad)==6440
 stage2=combo.train(kind,base,adapter,train,yt,seed_adapter,True,None);adapter.eval()
 with torch.no_grad():prob=combo.rep(kind,base,adapter,test)[0].float().softmax(-1).cpu().numpy()
 assert np.isfinite(prob).all();assert c.ref.main_ref.tensorhash(base)==after
 row=dict(dataset=kind,subject=s,fold=f,mode=mode,accuracy=float(np.mean(prob.argmax(1)==y[te])),source=str(path),source_hash=sourcehash,backbone_hash=after,seed_backbone=seed,seed_adapter=seed_adapter,backbone_parameters=sum(p.numel() for p in base.parameters()),adapter_parameters=9280,correction_parameters=6440,stage0=stage0,stage1=stage1,stage2=stage2,seconds=time.time()-tic)
 name=f'{kind}_{s}_fold{f}_{mode}'
 np.savez_compressed(ROOT/(name+'.npz'),y=y[te],train=tr,test=te,prob=prob)
 torch.save(dict(backbone=base.state_dict(),adapter=adapter.state_dict(),source=str(path),mode=mode,train=tr,test=te),ROOT/(name+'.pt'))
 save(name+'.json',row);print('DONE',json.dumps(row),flush=True)
 del base,encoder,full,train,test,yt,generic,adapter;torch.cuda.empty_cache()
def report():
 groups={};rows=[]
 for kind,ss in [('main',range(15)),('external',range(1,7))]:
  paired=[]
  for s in ss:
   files=[ROOT/f'{kind}_{s}_fold0_{mode}.json' for mode in MODES]
   if not all(p.exists() for p in files):continue
   vals=[json.loads(p.read_text()) for p in files]
   for key in ['source_hash','seed_backbone','seed_adapter','backbone_parameters','adapter_parameters','correction_parameters']:assert vals[0][key]==vals[1][key]
   for v in vals:
    with np.load(ROOT/f"{kind}_{s}_fold0_{v['mode']}.npz") as z:assert abs(float(np.mean(z['prob'].argmax(1)==z['y']))-v['accuracy'])<1e-12
   with np.load(ROOT/f'{kind}_{s}_fold0_{MODES[0]}.npz') as a,np.load(ROOT/f'{kind}_{s}_fold0_{MODES[1]}.npz') as b:
    assert np.array_equal(a['y'],b['y']) and np.array_equal(a['train'],b['train']) and np.array_equal(a['test'],b['test'])
    assert not len(np.intersect1d(a['train'],a['test']))
   rows.extend(vals);paired.append(dict(subject=s,original=100*vals[0]['accuracy'],shared=100*vals[1]['accuracy'],delta_pp=100*(vals[1]['accuracy']-vals[0]['accuracy'])))
  groups[kind]=dict(paired_subjects=len(paired),subjects=paired)
  if paired:groups[kind].update(original_mean=float(np.mean([v['original'] for v in paired])),shared_mean=float(np.mean([v['shared'] for v in paired])),delta_pp=float(np.mean([v['delta_pp'] for v in paired])))
 out=dict(complete=len(rows)==42,groups=groups,limits='All subjects fixed fold0 development screen; same historical LOO initialization; both arms get200 additive CE+LOO backbone steps plus200 adapter and200 multiscale steps. No HPO. Does not establish biological mechanism, novelty or universal necessity.')
 save('summary.json',out);return len(rows)
def smoke():
 ROOT.mkdir(exist_ok=True);checks=[]
 for kind,s in [('main',0),('external',1)]:
  for mode in MODES:
   base,xx,y,tr,te,path=load(kind,s,0);before=c.ref.main_ref.tensorhash(base)
   encoder=base if mode=='original_aligned' else WindowConsistentModel(base,balanced=False)
   backbone_fit(kind,base,encoder,xx[tr],y[tr],c.ref.seed(kind,s,0)+910091,1)
   assert c.ref.main_ref.tensorhash(base)!=before
   full=cache(kind,encoder,xx);ref=c.ref.initialize(kind,full[tr],torch.zeros_like(full[tr]));adapter=c.ref.GenericAdapter(ref).cuda()
   logits,q,_,delta=combo.rep(kind,base,adapter,full[tr]);loss=F.cross_entropy(logits,torch.from_numpy(y[tr]).cuda())
   loss.backward();assert all(p.grad is None or torch.isfinite(p.grad).all() for p in adapter.parameters())
   checks.append(dict(dataset=kind,mode=mode,finite_backbone_backward=True,finite_adapter_backward=True))
   del base,encoder,full,ref,adapter,logits,q,delta,loss;torch.cuda.empty_cache()
 save('smoke.json',dict(passed=True,checks=checks));print('SMOKE_PASS',json.dumps(checks))
def main():
 ROOT.mkdir(exist_ok=True);started=time.time()
 save('protocol.json',dict(cases=21,fold=0,modes=MODES,steps=[200,200,200],backbone_lr=.0001,adapter_lr=.001,loss='Backbone CE+.3CE(4LOO); both adapter stages add .01 correction squared; no gradient protection',question='Does backbone co-adaptation restore compatibility of shared encoding with historical LOO+adapter+multiscale?',stop='Finish fixed42 fits irrespective of signs; no test-based tuning or selecting subjects.'))
 try:
  for kind,s,f in CASES:
   for mode in MODES:
    if (ROOT/f'{kind}_{s}_fold{f}_{mode}.json').exists():continue
    n=sum((ROOT/f'{k}_{subject}_fold{fold}_{m}.json').exists() for k,subject,fold in CASES for m in MODES)
    run_case(kind,s,f,mode,dict(completed=n,subject=s,mode=mode,started=started));report()
  assert report()==42
  save('progress.json',dict(state='completed',completed_models=42,total_models=42,elapsed=time.time()-started))
 except Exception:save('error.json',dict(error=traceback.format_exc()));raise
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--smoke',action='store_true');args=parser.parse_args();smoke() if args.smoke else main()
