import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
import sys,time,json,traceback,math,hashlib
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/relation_validation_20261008')
import design_before_pool as old
import numpy as np,torch
from torch import nn
from torch.nn import functional as F
torch.set_num_threads(2)
ROOT=Path('/root/FAST/experiments/order_only_20261008')
MODES=['interaction_then_mean','mean_then_interaction','generic']
def save(name,obj):
 p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2));tmp.replace(p)
def digest(model):
 h=hashlib.sha256()
 for k,v in model.state_dict().items():h.update(k.encode());h.update(v.cpu().numpy().tobytes())
 return h.hexdigest()

@torch.no_grad()
def cache(model,x):
 generator=torch.Generator(device='cuda').manual_seed(810081)
 projection=torch.randn(model.config.dim_cnn,2,device='cuda',generator=generator)/math.sqrt(model.config.dim_cnn)
 zs=len(model.head.encoders);mask=~torch.eye(zs,device='cuda',dtype=torch.bool).repeat_interleave(2,0).repeat_interleave(2,1)
 ii,jj=torch.where(torch.triu(mask,diagonal=1))
 hh=[];aa=[];bb=[]
 for start in range(0,len(x),16):
  xt=torch.from_numpy(x[start:start+16]).cuda();win=xt.unfold(-1,model.config.window_len,model.config.slide_step)
  B,C,N,T=win.shape;flat=win.permute(0,2,1,3).reshape(B*N,C,T);means=[];local=[]
  for area,enc in model.head.encoders.items():
   a=flat[:,model.head.index_dict[area]].unsqueeze(1)
   a=F.gelu(enc.cnn4(enc.cnn3(enc.cnn2(enc.cnn1(a))))).squeeze(2)
   means.append(a.mean(-1));local.append(torch.einsum('bft,fd->bdt',a,projection))
  h=torch.stack(means,1).reshape(B,N,zs,-1)
  u=torch.stack(local,1).flatten(1,2)
  # Exactly the same fixed local features and pair indices. Only operation order changes.
  a=(u[:,ii]*u[:,jj]).mean(-1).reshape(B,N,-1)
  mu=u.mean(-1);b=(mu[:,ii]*mu[:,jj]).reshape(B,N,-1)
  hh.append(h.cpu());aa.append(a.cpu());bb.append(b.cpu())
 return torch.cat(hh).cuda(),torch.cat(aa).cuda(),torch.cat(bb).cuda()

class Branch(nn.Module):
 def __init__(self,dim_in,dim_out,width,mu,sd):
  super().__init__();self.register_buffer('mu',mu);self.register_buffer('sd',sd)
  self.hidden=nn.Linear(dim_in,width);self.out=nn.Linear(width,dim_out)
  nn.init.zeros_(self.out.weight);nn.init.zeros_(self.out.bias)
 def forward(self,x):return self.out(F.gelu(self.hidden(torch.asinh((x-self.mu)/self.sd))))

def case(kind,s):
 tic=time.time();c=old.c;x,y=c.ref.dataset(kind,s);tr,te=next(c.ref.splits(kind,x,y));source=c.old.source_path(kind,'ce',s,0)
 ck=torch.load(source,map_location='cpu',weights_only=False);model=c.build(kind,s,0).eval();model.load_state_dict(ck['state_dict']);model.requires_grad_(False)
 assert np.array_equal(ck['train_idx' if kind=='main' else 'train'],tr) and np.array_equal(ck['test_idx' if kind=='main' else 'test'],te)
 xx=c.normalize(kind,x,tr)
 if kind=='external':
  mu,sd=ck['normalization'];assert np.allclose(xx,(x-mu)/sd,atol=2e-5)
 h,pre,post=cache(model,xx);yt=torch.from_numpy(y).cuda();flat=h.flatten(2)
 # One shared train-only transform, fixed across both order arms.
 combined=torch.cat([pre[tr],post[tr]],0)
 shared_mu=combined.mean((0,1),keepdim=True);shared_sd=combined.std((0,1),keepdim=True).clamp_min(1e-5)
 with torch.no_grad():
  direct=model(torch.from_numpy(xx[te]).cuda());base=old.logits(model,h[te]);error=float((direct-base).abs().max());assert error<2e-5,error
  prediction={'ce':base.argmax(1).cpu().numpy()}
 row=dict(dataset=kind,subject=s,fold=0,ce=float(np.mean(prediction['ce']==y[te])),source=str(source),cache_error=error,models={})
 paired_initial=[]
 width_generic=math.ceil(((pre.shape[-1]+1+model.config.dim_token)*32)/(flat.shape[-1]+1+model.config.dim_token))
 for mode,feature,width in [('interaction_then_mean',pre,32),('mean_then_interaction',post,32),('generic',flat,width_generic)]:
  if mode=='generic':mu=flat[tr].mean((0,1),keepdim=True);sd=flat[tr].std((0,1),keepdim=True).clamp_min(1e-5)
  else:mu=shared_mu;sd=shared_sd
  torch.manual_seed(c.ref.seed(kind,s,0)+810081)
  branch=Branch(feature.shape[-1],model.config.dim_token,width,mu,sd).cuda()
  if mode!='generic':paired_initial.append(digest(branch))
  with torch.no_grad():assert torch.equal(old.logits(model,h[te],branch,feature[te]),base)
  opt=torch.optim.AdamW(branch.parameters(),lr=.001,weight_decay=.01)
  first_grad=None
  for step in range(200):
   opt.zero_grad(set_to_none=True)
   for group in opt.param_groups:group['lr']=.001*(.1+.9*.5*(1+math.cos(math.pi*step/199)))
   d=branch(feature[tr]);logit=old.logits(model,h[tr],branch,feature[tr]);loss=F.cross_entropy(logit,yt[tr])+.01*d.square().mean()
   assert torch.isfinite(loss);loss.backward();assert all(p.grad is None or torch.isfinite(p.grad).all() for p in branch.parameters())
   if step==0:first_grad=float(branch.out.weight.grad.norm())
   opt.step()
  with torch.no_grad():
   out=old.logits(model,h[te],branch,feature[te]);prediction[mode]=out.argmax(1).cpu().numpy()
   train_acc=float((old.logits(model,h[tr],branch,feature[tr]).argmax(1)==yt[tr]).float().mean())
  row['models'][mode]=dict(accuracy=float(np.mean(prediction[mode]==y[te])),train_accuracy=train_acc,parameters=sum(p.numel() for p in branch.parameters()),first_output_gradient=first_grad)
  torch.save(dict(state_dict=branch.state_dict(),source=str(source),mode=mode,width=width),ROOT/f'{kind}_{s}_{mode}.pt')
 assert paired_initial[0]==paired_initial[1]
 row['paired_initial_hash']=paired_initial[0];row['seconds']=time.time()-tic
 np.savez_compressed(ROOT/f'{kind}_{s}_predictions.npz',y=y[te],train=tr,test=te,**prediction)
 save(f'{kind}_{s}.json',row);return row

def summary(rows):
 out={}
 for kind in ['main','external']:
  r=[x for x in rows if x['dataset']==kind]
  if not r:continue
  out[kind]={'n':len(r),'ce':float(np.mean([x['ce'] for x in r]))}
  for mode in MODES:out[kind][mode]=float(np.mean([x['models'][mode]['accuracy'] for x in r]))
 return out
def main():
 ROOT.mkdir(exist_ok=True);tic=time.time();rows=[];cases=[('main',s) for s in range(15)]+[('external',s) for s in range(1,7)]
 for kind,s in cases:
  p=ROOT/f'{kind}_{s}.json';row=json.loads(p.read_text()) if p.exists() else case(kind,s);rows.append(row)
  save('progress.json',dict(state='running',completed=len(rows),total=21,elapsed=time.time()-tic,summary=summary(rows)))
  print(json.dumps(row),flush=True)
 save('progress.json',dict(state='completed',completed=21,total=21,elapsed=time.time()-tic,summary=summary(rows)))
if __name__=='__main__':
 try:main()
 except Exception:save('error.json',dict(error=traceback.format_exc()));raise
