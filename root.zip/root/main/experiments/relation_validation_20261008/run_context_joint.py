import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
import sys,time,json,math,traceback,argparse
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/relation_validation_20261008')
import run_context_alignment as common
import torch,numpy as np
from torch.nn import functional as F
c=common.c;combo=common.combo;torch.set_num_threads(2)
ROOT=Path('/root/FAST/experiments/context_joint_20261009')
CASES=common.CASES;MODES=['original_joint','shared_joint']
def save(name,obj):
 ROOT.mkdir(exist_ok=True);p=ROOT/name;q=p.with_suffix('.tmp');q.write_text(json.dumps(obj,indent=2));q.replace(p)
def load(kind,s,mode):
 base,xx,y,tr,te,source=common.load(kind,s,0);base.eval()
 encoder=base if mode=='original_joint' else common.WindowConsistentModel(base,balanced=False)
 with torch.no_grad():features=common.cache(kind,encoder,xx)
 ref=c.ref.initialize(kind,features[tr],torch.zeros_like(features[tr]));generic=c.ref.GenericAdapter(ref).cuda();del ref
 if mode=='original_joint':
  name=c.ref.name(kind,s,0)
  genericck=torch.load(c.ref.OUT/kind/'generic_adapter'/(name+'.pt'),map_location='cpu',weights_only=False)
  generic.load_state_dict(genericck['state_dict'])
  adapter=c.temporal.Temporal(generic,'multiscale').cuda()
  ck=torch.load(combo.HIST/kind/'multiscale'/(name+'.pt'),map_location='cpu',weights_only=False)
  result=adapter.load_state_dict(ck['correction_state_dict'],strict=False)
  assert not result.unexpected_keys and all(k.startswith('saved.') for k in result.missing_keys)
  historical=combo.HIST/kind/'multiscale'/(name+'.npz');labelkey='y';indexkey='test_idx';probkey='prob'
 else:
  adapter=c.temporal.Temporal(generic,'multiscale').cuda()
  folder=Path('/root/FAST/experiments/context_combination_corrected_20261009')
  ck=torch.load(folder/f'{kind}_{s}_fold0.pt',map_location='cpu',weights_only=False);adapter.load_state_dict(ck['state_dict'])
  historical=folder/f'{kind}_{s}_fold0.npz';labelkey='y';indexkey='test';probkey='prob'
 adapter.eval()
 with torch.no_grad():initial=combo.rep(kind,base,adapter,features[te])[0].float().softmax(-1).cpu().numpy()
 with np.load(historical) as z:
  assert np.array_equal(z[labelkey],y[te]) and np.array_equal(z[indexkey],te)
  error=float(np.max(abs(initial-z[probkey])));assert error<1e-6,error
 base.requires_grad_(True);adapter.requires_grad_(True)
 del features
 return base,encoder,adapter,xx,y,tr,te,source,initial,error
def forward(kind,base,encoder,adapter,x):
 full=encoder.forward_head(x)
 logits,q,gate,delta=combo.rep(kind,base,adapter,full)
 return logits,q,delta
@torch.no_grad()
def predict(kind,base,encoder,adapter,xx):
 base.eval();adapter.eval();parts=[]
 for start in range(0,len(xx),32):
  with torch.autocast('cuda',enabled=kind=='external',dtype=torch.bfloat16):full=encoder.forward_head(torch.from_numpy(xx[start:start+32]).cuda())
  parts.append(combo.rep(kind,base,adapter,full)[0].float().softmax(-1).cpu().numpy())
 return np.concatenate(parts)
def fit(kind,base,encoder,adapter,xx,y,seed,steps,context=None):
 c.ref.main_ref.v4.seed_all(seed);base.train();adapter.train()
 oldbase=c.ref.main_ref.tensorhash(base);oldadapter=c.ref.main_ref.tensorhash(adapter)
 groups=[dict(params=list(base.parameters()),lr=1e-5,base_lr=1e-5),dict(params=list(adapter.parameters()),lr=1e-4,base_lr=1e-4)]
 opt=torch.optim.AdamW(groups,weight_decay=.01);xt=torch.from_numpy(xx).cuda();yt=torch.from_numpy(y).cuda();trace=[];tic=time.time();checks=None
 for step in range(steps):
  for g in opt.param_groups:g['lr']=g['base_lr']*(.1+.9*.5*(1+math.cos(math.pi*step/max(steps-1,1))))
  opt.zero_grad(set_to_none=True)
  with torch.autocast('cuda',dtype=torch.bfloat16):
   logits,q,delta=forward(kind,base,encoder,adapter,xt);ce=F.cross_entropy(logits,yt)
  aux=.3*F.cross_entropy(4*c.ref.ridge(kind,q,yt),yt);penalty=.01*delta.float().square().mean();loss=ce+aux+penalty
  assert torch.isfinite(loss);loss.backward()
  assert all(p.grad is None or torch.isfinite(p.grad).all() for m in [base,adapter] for p in m.parameters())
  if step==0:
   checks=dict(backbone_grad=float(sum(p.grad.float().square().sum() for p in base.parameters() if p.grad is not None).sqrt()),generic_grad=float(sum(p.grad.float().square().sum() for p in adapter.saved.parameters() if p.grad is not None).sqrt()),multiscale_grad=float(sum(p.grad.float().square().sum() for n,p in adapter.named_parameters() if not n.startswith('saved.') and p.grad is not None).sqrt()))
   assert all(v>0 and math.isfinite(v) for v in checks.values()),checks
  opt.step()
  if step in [0,49,99,steps-1]:
   trace.append(dict(step=step+1,ce=float(ce.detach()),aux=float(aux.detach()),penalty=float(penalty.detach())))
   if context:save('progress.json',dict(state='running',completed_models=context['completed'],total_models=42,current=dict(dataset=kind,subject=context['subject'],mode=context['mode'],fold=0,step=step+1),elapsed=time.time()-context['started']))
 torch.cuda.synchronize();assert c.ref.main_ref.tensorhash(base)!=oldbase and c.ref.main_ref.tensorhash(adapter)!=oldadapter
 return dict(seconds=time.time()-tic,trace=trace,gradient_checks=checks)
def case(kind,s,mode,context):
 tic=time.time();base,encoder,adapter,xx,y,tr,te,source,initial,error=load(kind,s,mode)
 source_hash=c.ref.main_ref.tensorhash(base);initial_adapter_hash=c.ref.main_ref.tensorhash(adapter);seed=c.ref.seed(kind,s,0)+920091
 trained=fit(kind,base,encoder,adapter,xx[tr],y[tr],seed,200,context)
 prob=predict(kind,base,encoder,adapter,xx[te]);assert np.isfinite(prob).all()
 row=dict(dataset=kind,subject=s,fold=0,mode=mode,source=str(source),source_hash=source_hash,initial_adapter_hash=initial_adapter_hash,seed=seed,parameters=sum(p.numel() for m in [base,adapter] for p in m.parameters()),initial_accuracy=float(np.mean(initial.argmax(1)==y[te])),accuracy=float(np.mean(prob.argmax(1)==y[te])),initial_replay_error=error,training=trained,seconds=time.time()-tic)
 name=f'{kind}_{s}_{mode}';np.savez_compressed(ROOT/(name+'.npz'),y=y[te],train=tr,test=te,initial_prob=initial,prob=prob)
 torch.save(dict(backbone=base.state_dict(),adapter=adapter.state_dict(),source=str(source),mode=mode,train=tr,test=te),ROOT/(name+'.pt'))
 save(name+'.json',row);print('JOINT_DONE',json.dumps(row),flush=True)
 del base,encoder,adapter;torch.cuda.empty_cache()
def report():
 groups={};rows=[]
 for kind,ss in [('main',range(15)),('external',range(1,7))]:
  paired=[]
  for s in ss:
   ps=[ROOT/f'{kind}_{s}_{m}.json' for m in MODES]
   if not all(p.exists() for p in ps):continue
   vals=[json.loads(p.read_text()) for p in ps]
   for key in ['source_hash','seed','parameters']:assert vals[0][key]==vals[1][key]
   for row in vals:
    with np.load(ROOT/f"{kind}_{s}_{row['mode']}.npz") as z:
     assert not len(np.intersect1d(z['train'],z['test']))
     assert abs(float(np.mean(z['prob'].argmax(1)==z['y']))-row['accuracy'])<1e-12
   with np.load(ROOT/f'{kind}_{s}_{MODES[0]}.npz') as a,np.load(ROOT/f'{kind}_{s}_{MODES[1]}.npz') as b:
    assert np.array_equal(a['y'],b['y']) and np.array_equal(a['train'],b['train']) and np.array_equal(a['test'],b['test'])
   rows.extend(vals);paired.append(dict(subject=s,original_initial=100*vals[0]['initial_accuracy'],shared_initial=100*vals[1]['initial_accuracy'],original_joint=100*vals[0]['accuracy'],shared_joint=100*vals[1]['accuracy'],delta_pp=100*(vals[1]['accuracy']-vals[0]['accuracy'])))
  groups[kind]=dict(paired_subjects=len(paired),subjects=paired)
  if paired:groups[kind]['means']={key:float(np.mean([v[key] for v in paired])) for key in ['original_initial','shared_initial','original_joint','shared_joint','delta_pp']}
 out=dict(complete=len(rows)==42,groups=groups,scope='All21subjects fold0 development check. Matched joint training budget, different previously trained adapter starting weights; shared vs original contrast includes those prior representations. No HPO, no independent confirmation or novelty claim.')
 save('summary.json',out);return len(rows)
def smoke():
 checks=[]
 for kind,s in [('main',0),('external',1)]:
  for mode in MODES:
   base,encoder,adapter,xx,y,tr,te,source,initial,error=load(kind,s,mode)
   result=fit(kind,base,encoder,adapter,xx[tr],y[tr],c.ref.seed(kind,s,0)+920091,1)
   checks.append(dict(dataset=kind,mode=mode,replay_error=error,gradients=result['gradient_checks']))
   del base,encoder,adapter;torch.cuda.empty_cache()
 save('smoke.json',dict(passed=True,checks=checks));print('SMOKE_PASS',json.dumps(checks))
def main():
 ROOT.mkdir(exist_ok=True);started=time.time()
 save('protocol.json',dict(models=42,subjects=21,fold=0,modes=MODES,steps=200,optimizer='AdamW, backbone lr1e-5, adapter lr1e-4, cosine to0.1, wd0.01',loss='CE + .3CE(4LOO) + .01 total residual squared',question='Does simultaneous backbone/generic/multiscale optimization improve shared-encoding compatibility?',source='Historical source LOO backbone; old historical adapter and corrected shared adapter, all initial predictions replayed.',stop='Finish42models regardless of signs, no HPO or selective subjects. Do not extend if no consistent benefit.'))
 try:
  for kind,s,f in CASES:
   for mode in MODES:
    if (ROOT/f'{kind}_{s}_{mode}.json').exists():continue
    n=sum((ROOT/f'{k}_{subject}_{m}.json').exists() for k,subject,fold in CASES for m in MODES)
    case(kind,s,mode,dict(completed=n,subject=s,mode=mode,started=started));report()
  assert report()==42;save('progress.json',dict(state='completed',completed_models=42,total_models=42,elapsed=time.time()-started))
 except Exception:save('error.json',dict(error=traceback.format_exc()));raise
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--smoke',action='store_true');args=parser.parse_args();smoke() if args.smoke else main()
