import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
import sys,time,json,traceback
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/parallel_questions_20261008')
import common as c
import numpy as np,torch
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import RidgeClassifier
torch.set_num_threads(2)
ROOT=Path('/root/FAST/experiments/official_restart_20261008');ROOT.mkdir(exist_ok=True)
def save(name,obj):(ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2))
def block(a,tr):
 return StandardScaler().fit(a[tr]).transform(a).astype(np.float64)/np.sqrt(a.shape[1])
def relations(r):
 out=[]
 for lag in [0,16,32,64]:
  a=r[...,:r.shape[-1]-lag] if lag else r
  b=r[...,lag:] if lag else r
  a=a-a.mean(-1,keepdims=True);b=b-b.mean(-1,keepdims=True)
  a=a/np.maximum(np.linalg.norm(a,axis=-1,keepdims=True),1e-8)
  b=b/np.maximum(np.linalg.norm(b,axis=-1,keepdims=True),1e-8)
  mat=np.einsum('bnit,bnjt->bnij',a,b)
  ii,jj=np.where(~np.eye(r.shape[2],dtype=bool));out.append(mat[:,:,ii,jj].reshape(len(r),-1))
 return np.concatenate(out,axis=1)
def main():
 started=time.time();rows=json.loads((ROOT/'probe_progress.json').read_text())['rows'] if (ROOT/'probe_progress.json').exists() else []
 for kind,n in [('main',15),('external',6)]:
  for s in (range(n) if kind=='main' else range(1,n+1)):
   if any(row['dataset']==kind and row['subject']==s for row in rows):continue
   tic=time.time();x,y=c.ref.dataset(kind,s);tr,te=next(c.ref.splits(kind,x,y));xx=c.normalize(kind,x,tr)
   model=c.build(kind,s,0).eval();p=c.old.source_path(kind,'ce',s,0);ck=torch.load(p,map_location='cpu',weights_only=False)
   assert np.array_equal(ck['train_idx' if kind=='main' else 'train'],tr)
   assert np.array_equal(ck['test_idx' if kind=='main' else 'test'],te)
   model.load_state_dict(ck['state_dict']);chunks=[]
   with torch.no_grad():
    for i in range(0,len(xx),32):
     h=model.forward_head(torch.from_numpy(xx[i:i+32]).cuda());chunks.append(h.flatten(1).cpu().numpy())
   base=block(np.concatenate(chunks),tr)
   cfg=model.config;windows=np.lib.stride_tricks.sliding_window_view(xx,cfg.window_len,axis=-1)[:,:,::cfg.slide_step,:]
   r=np.stack([windows[:,ids.cpu().numpy()].mean(1) for ids in model.head.index_dict.values()],axis=2).astype(np.float64)
   marginal=np.concatenate([r.mean(-1).reshape(len(r),-1),r.std(-1).reshape(len(r),-1)],axis=1)
   centered=r-r.mean(-1,keepdims=True)
   spectrum=np.abs(np.fft.rfft(centered,axis=-1))**2
   # Fixed relative-frequency bins; no assumptions about dataset sampling rate.
   for idx in np.array_split(np.arange(1,spectrum.shape[-1]),4):marginal=np.concatenate([marginal,np.log1p(spectrum[...,idx].mean(-1)).reshape(len(r),-1)],axis=1)
   marginal=block(marginal,tr);rel=block(relations(centered),tr)
   rng=np.random.default_rng(81008+s+(100 if kind=='external' else 0));shuffled=centered.copy()
   for trial in range(len(r)):
    for z in range(r.shape[2]):shuffled[trial,:,z]=np.roll(centered[trial,:,z],int(rng.integers(cfg.window_len)),axis=-1)
   negative=block(relations(shuffled),tr)
   designs={'base':base,'base_marginal':np.concatenate([base,marginal],1),'base_marginal_relation':np.concatenate([base,marginal,rel],1),'base_marginal_shifted_relation':np.concatenate([base,marginal,negative],1),'relation_only':rel}
   result={};pred={}
   for name,features in designs.items():
    clf=RidgeClassifier(alpha=1.,solver='cholesky').fit(features[tr],y[tr]);pred[name]=clf.predict(features[te]);result[name]=float(np.mean(pred[name]==y[te]))
   np.savez_compressed(ROOT/f'{kind}_{s:02d}_probe.npz',y=y[te],train=tr,test=te,**pred)
   row=dict(dataset=kind,subject=s,fold=0,accuracy=result,seconds=time.time()-tic,feature_dims={k:v.shape[1] for k,v in designs.items()});rows.append(row)
   save('probe_progress.json',dict(state='running',completed=len(rows),total=21,elapsed=time.time()-started,rows=rows))
   print(json.dumps(row),flush=True);del model;torch.cuda.empty_cache()
 summary={kind:{method:float(np.mean([row['accuracy'][method] for row in rows if row['dataset']==kind])) for method in designs} for kind in ['main','external']}
 save('probe_progress.json',dict(state='completed',completed=21,total=21,elapsed=time.time()-started,summary=summary,rows=rows))
if __name__=='__main__':
 try:main()
 except Exception:
  save('probe_error.json',dict(error=traceback.format_exc()));raise
