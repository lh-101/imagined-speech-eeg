"""Two bounded tests: readable feature compression and source-loss dependence.

All pretrained baselines and LOO-source generic adapters are reused. Neither
architecture search nor test-label-dependent selection is performed here.
"""
import os
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '4'
from pathlib import Path
import sys, json, time, hashlib, fcntl, argparse, itertools, warnings
sys.path[:0] = ['/root/FAST/experiments/adapter_specificity_20261006',
               '/root/FAST/experiments', '/root/FAST',
               '/root/FAST/experiments/residual_20260925']
import numpy as np
import sklearn
import torch
from torch.nn import functional as F
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import f1_score
import run_specificity as ref

OUT = Path('/root/FAST/experiments/compression_source_20261006')
SOURCE_CE = {
    'main': Path('/root/FAST/experiments/mechanism_20260927/results/full_ce_seed42'),
    'external': ref.external_ref.ROOT / 'results/fast_ce',
}
SOURCE_LOO = {'main': ref.main_ref.SOURCE, 'external': ref.external_ref.SOURCE}
GENERIC_LOO = ref.OUT
PROBES = ['regional_flat', 'linear_flat', 'token_flat', 'cls32',
          'regional_pca32', 'linear_pca32', 'token_pca32',
          'regional_window_pca32', 'regional_random32']
PRIMARY_PROBES = [
    ('regional_window_pca32', 'token_flat'),
    ('regional_pca32', 'token_pca32'),
    ('regional_pca32', 'cls32'),
]
TOTAL_FOLDS = 105
TOTAL_PROBE_FITS = TOTAL_FOLDS * 2 * len(PROBES)


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2), encoding='utf8')
    tmp.replace(path)


def save_npz(path, **values):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    with tmp.open('wb') as handle:
        np.savez_compressed(handle, **values)
    tmp.replace(path)


def sha(path):
    return ref.main_ref.sha(path)


def source_path(kind, method, s, fold):
    return (SOURCE_CE if method == 'ce' else SOURCE_LOO)[kind] / (ref.name(kind, s, fold) + '.pt')


def metrics(y, pred, nclasses):
    return {'accuracy': float((y == pred).mean()),
            'macro_f1': float(f1_score(y, pred, labels=np.arange(nclasses),
                                      average='macro', zero_division=0))}


def read_saved(kind, path, tr, te, y, primary=False):
    with np.load(path) as z:
        trkey = 'train_idx' if 'train_idx' in z else 'train'
        tekey = 'test_idx' if 'test_idx' in z else 'test'
        assert np.array_equal(z[trkey], tr) and np.array_equal(z[tekey], te)
        assert np.array_equal(z['y'], y[te])
        key = 'primary_prob' if primary and 'primary_prob' in z else 'prob'
        p = z[key].copy()
        assert np.isfinite(p).all()
        return p


def load_source(kind, method, s, fold, tr, te, x, y):
    """Verify predictions and training-only normalization before using a source."""
    ref.main_ref.v4.seed_all(ref.seed(kind, s, fold))
    path = source_path(kind, method, s, fold)
    ck = torch.load(path, map_location='cpu')
    if kind == 'main':
        assert np.array_equal(ck['train_idx'], tr) and np.array_equal(ck['test_idx'], te)
        assert ck['job']['method'] == ('ce' if method == 'ce' else 'additive')
        base = ref.main_ref.v4.FAST(ref.main_ref.v4.config()).cuda().eval()
        base.load_state_dict(ck['state_dict'])
        base.requires_grad_(False)
        with torch.no_grad():
            full = base.forward_head(torch.from_numpy(x).cuda()).detach()
            old = base.forward_transformer(full[te]).float()
        norm = None
    else:
        assert ck['architecture'] == 'fast' and ck['method'] == method
        assert np.array_equal(ck['train'], tr) and np.array_equal(ck['test'], te)
        mu, sd = ck['normalization']
        expected_mu = x[tr].mean(axis=(0, 2), keepdims=True, dtype=np.float64).astype(np.float32)
        expected_sd = np.maximum(x[tr].std(axis=(0, 2), keepdims=True,
                                          dtype=np.float64).astype(np.float32), 1e-6)
        assert np.array_equal(mu, expected_mu) and np.array_equal(sd, expected_sd)
        xx = ((x - mu) / sd).astype(np.float32)
        geometry = json.loads((ref.external_ref.ROOT / 'geometry.json').read_text())
        base = ref.external_ref.build(geometry)
        base.load_state_dict(ck['state_dict'])
        base.requires_grad_(False)
        # Replay the exact historical separate training/test cache batches.
        train_full = ref.external_ref.cache(base, xx[tr]).detach()
        test_full = ref.external_ref.cache(base, xx[te]).detach()
        full = torch.empty((len(x), *train_full.shape[1:]), device='cuda', dtype=train_full.dtype)
        full[tr], full[te] = train_full, test_full
        with torch.no_grad(), torch.autocast('cuda', dtype=torch.bfloat16):
            old = base.forward_transformer(test_full).float()
        norm = (mu, sd)
    saved = read_saved(kind, path.with_suffix('.npz'), tr, te, y, primary=True)
    actual = old.softmax(-1).cpu().numpy()
    error = float(np.max(np.abs(saved - actual)))
    assert np.array_equal(actual.argmax(-1), saved.argmax(-1))
    assert error < 1e-6, ('Source probability replay differs', kind, method, s, fold, error)
    return base, full, old.detach(), saved, norm, error


@torch.no_grad()
def extract_views(kind, base, full, tr, te, expected_test_logits):
    """Batch identically to source prediction to avoid BF16 batch-dependent replay."""
    arrays = {k: [] for k in ['regional', 'linear', 'token', 'cls']}
    all_values = {}
    for indices in [tr, te]:
        r = full[indices].flatten(2)
        with torch.autocast('cuda', dtype=torch.bfloat16, enabled=kind == 'external'):
            linear = base.input_layer[0](r)
            token = base.input_layer[1](linear)
            seq = torch.cat([base.cls_token.expand(len(r), -1, -1), token], 1)
            hidden = base.transformer(seq + base.pos_embedding[:, :base.n_tokens + 1])[:, 0]
            logits = base.last_layer(base.dropout(hidden)).float()
        if np.array_equal(indices, te):
            assert torch.equal(logits, expected_test_logits), 'Hidden feature extraction changed source logits'
        for key, value in [('regional', r), ('linear', linear), ('token', token), ('cls', hidden)]:
            a = value.float().cpu().numpy()
            if key not in all_values:
                all_values[key] = np.empty((len(full), *a.shape[1:]), dtype=np.float32)
            all_values[key][indices] = a
    assert all(np.isfinite(a).all() for a in all_values.values())
    return all_values


def pca_train_only(a, tr, dimension=32):
    scaler = StandardScaler().fit(a[tr])
    z = scaler.transform(a)
    # Same fixed solver/seed/dimension on every stage; no outcome-based selection.
    pca = PCA(n_components=dimension, svd_solver='randomized',
              n_oversamples=10, iterated_power=7, random_state=42)
    pca.fit(z[tr])
    return pca.transform(z), {
        'input_dimension': int(a.shape[1]), 'output_dimension': dimension,
        'train_explained_variance': float(pca.explained_variance_ratio_.sum()),
    }


def transform_views(values, tr):
    flat = {key: a.reshape(len(a), -1).astype(np.float64) for key, a in values.items()}
    matrices = {'regional_flat': flat['regional'], 'linear_flat': flat['linear'],
                'token_flat': flat['token'], 'cls32': flat['cls']}
    metadata = {}
    for key in ['regional', 'linear', 'token']:
        matrices[key + '_pca32'], metadata[key + '_pca32'] = pca_train_only(flat[key], tr)
    # Pool only training windows to construct a 256->32 compression, preserving
    # the original window count; same total probe input dimension as token_flat.
    r = values['regional'].astype(np.float64)
    n, windows, dim = r.shape
    scaler = StandardScaler().fit(r[tr].reshape(-1, dim))
    pca = PCA(n_components=32, svd_solver='randomized', n_oversamples=10,
              iterated_power=7, random_state=42)
    pca.fit(scaler.transform(r[tr].reshape(-1, dim)))
    matrices['regional_window_pca32'] = pca.transform(scaler.transform(r.reshape(-1, dim))).reshape(n, windows * 32)
    metadata['regional_window_pca32'] = {'input_dimension_per_window': dim,
        'output_dimension_per_window': 32, 'total_output_dimension': windows * 32,
        'train_explained_variance': float(pca.explained_variance_ratio_.sum())}
    scaler = StandardScaler().fit(flat['regional'][tr])
    rng = np.random.default_rng(42)
    projection = rng.standard_normal((flat['regional'].shape[1], 32)) / np.sqrt(32)
    matrices['regional_random32'] = scaler.transform(flat['regional']) @ projection
    assert matrices['regional_window_pca32'].shape == matrices['token_flat'].shape
    assert all(matrices[k].shape[1] == 32 for k in ['cls32','regional_pca32','linear_pca32','token_pca32','regional_random32'])
    assert all(np.isfinite(a).all() for a in matrices.values())
    return matrices, metadata


def fit_probes(kind, method, s, fold, values, tr, te, y, source_prob, source_error):
    dest = OUT / 'probes' / kind / method
    name = ref.name(kind, s, fold)
    matrices, metadata = transform_views(values, tr)
    preds, probabilities, rows, weights = {}, {}, {}, {}
    nclasses = 5 if kind == 'main' else 3
    start = time.time()
    for key in PROBES:
        scaler = StandardScaler().fit(matrices[key][tr])
        train, test = scaler.transform(matrices[key][tr]), scaler.transform(matrices[key][te])
        model = LogisticRegression(C=1., max_iter=2000, tol=1e-4, random_state=42)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always', ConvergenceWarning)
            model.fit(train, y[tr])
        converged = not any(issubclass(w.category, ConvergenceWarning) for w in caught)
        assert converged, ('Fixed probe did not converge', kind, method, s, fold, key)
        probability = model.predict_proba(test)
        assert np.array_equal(model.classes_, np.arange(nclasses))
        assert np.isfinite(probability).all() and np.allclose(probability.sum(1), 1.)
        pred = probability.argmax(-1)
        preds[key], probabilities[key] = pred, probability
        rows[key] = {'test': metrics(y[te], pred, nclasses),
                     'train': metrics(y[tr], model.predict(train), nclasses),
                     'input_dimension': int(train.shape[1]),
                     'classifier_parameters': int(model.coef_.size + model.intercept_.size),
                     'iterations': model.n_iter_.tolist(), 'converged': converged}
        weights[key + '_coef'] = model.coef_
        weights[key + '_intercept'] = model.intercept_
    save_npz(dest / (name + '.npz'), y=y[te], train_idx=tr, test_idx=te,
             source_pred=source_prob.argmax(-1), **{key + '_pred': v for key, v in preds.items()},
             **{key + '_prob': v for key, v in probabilities.items()})
    save_npz(dest / (name + '_weights.npz'), **weights)
    save(dest / (name + '.json'), {'dataset':kind,'source_method':method,'subject':s,'fold':fold,
        'seconds':time.time()-start,'views':rows,'transform_metadata':metadata,
        'source_checkpoint_sha256':sha(source_path(kind, method, s, fold)),
        'source_probability_replay_max_error':source_error,
        'training_indices_only_for_scalers_and_pca':True})
    print('PROBES_DONE', kind, method, s, fold,
          {k:round(v['test']['accuracy'],4) for k,v in rows.items()}, flush=True)


def initialize_generic(kind, features, s, fold):
    # Consume the exact same initialization RNG sequence as the previous generic
    # experiment, even though unused gate/mean buffers do not enter the model.
    ref.main_ref.v4.seed_all(ref.seed(kind,s,fold))
    reference = ref.initialize(kind, features, torch.zeros_like(features))
    return ref.GenericAdapter(reference).cuda()


def fit_ce_adapter(kind, s, fold, base, full, old, y, tr, te, source_prob, source_error, norm):
    dest = OUT / 'ce_generic_adapter' / kind
    name = ref.name(kind,s,fold)
    adapter = initialize_generic(kind, full[tr], s, fold)
    assert sum(p.numel() for p in adapter.parameters()) == 9280
    train_mean, test_mean = torch.zeros_like(full[tr]), torch.zeros_like(full[te])
    with torch.no_grad():
        initial = ref.rep(kind,base,adapter,full[te],test_mean)[0].float()
    assert torch.equal(initial, old), 'Zero generic adapter changed CE source logits'
    before = ref.main_ref.tensorhash(base)
    opt = torch.optim.AdamW(adapter.parameters(),lr=.001,weight_decay=.01)
    yt = torch.from_numpy(y[tr]).cuda()
    start = time.time()
    trace = []
    for step in range(200):
        opt.zero_grad(set_to_none=True)
        for g in opt.param_groups:
            g['lr'] = .001 * (.1 + .9 * .5 * (1 + np.cos(np.pi * step / 199)))
        logits,q,gate,delta = ref.rep(kind,base,adapter,full[tr],train_mean)
        ce = F.cross_entropy(logits,yt)
        aux = .3 * F.cross_entropy(4 * ref.ridge(kind,q,yt),yt)
        loss = ce + aux + .01 * delta.square().mean()
        assert torch.isfinite(loss)
        loss.backward()
        assert all(p.grad is None or torch.isfinite(p.grad).all() for p in adapter.parameters())
        opt.step()
        if step in [0,49,99,199]:
            trace.append({'step':step+1,'ce':float(ce.detach()),'aux':float(aux.detach()),
                          'delta_rms':float(delta.detach().square().mean().sqrt())})
    assert ref.main_ref.tensorhash(base) == before
    assert all(p.grad is None for p in base.parameters())
    with torch.no_grad():
        probability = ref.rep(kind,base,adapter,full[te],test_mean)[0].float().softmax(-1).cpu().numpy()
    assert np.isfinite(probability).all()
    nclasses = 5 if kind == 'main' else 3
    save(dest / (name + '.json'), {'dataset':kind,'subject':s,'fold':fold,
        'seconds':time.time()-start,'test':metrics(y[te],probability.argmax(-1),nclasses),
        'source':metrics(y[te],source_prob.argmax(-1),nclasses),'trace':trace,
        'zero_initial_logits_exact':True,'frozen_source_unchanged':True,
        'source_probability_replay_max_error':source_error,'parameters':9280,
        'source_checkpoint_sha256':sha(source_path(kind,'ce',s,fold))})
    dest.mkdir(parents=True,exist_ok=True)
    torch.save({'state_dict':adapter.cpu().state_dict(),'train_idx':tr,'test_idx':te,
                'source':str(source_path(kind,'ce',s,fold)),
                'source_normalization':norm},dest / (name + '.pt'))
    save_npz(dest / (name + '.npz'), y=y[te], train_idx=tr, test_idx=te,
             prob=probability,pred=probability.argmax(-1),source_pred=source_prob.argmax(-1))
    print('CE_ADAPTER_DONE',kind,s,fold,metrics(y[te],probability.argmax(-1),nclasses),flush=True)
    return time.time()-start


def paired_stats(delta):
    d = np.asarray(delta,dtype=np.float64)
    rng = np.random.default_rng(20261006)
    ci = np.quantile(d[rng.integers(0,len(d),(50000,len(d)))].mean(1),[.025,.975])
    signs = np.array(list(itertools.product([-1,1],repeat=len(d))))
    p = np.mean(np.abs((signs*d).mean(1)) >= abs(d.mean())-1e-12)
    return {'mean_pp':float(d.mean()),'bootstrap95_pp':ci.tolist(),
            'exact_signflip_p':float(p),'positive_subjects':int((d>1e-10).sum()),
            'negative_subjects':int((d<-1e-10).sum()),'tied_subjects':int((abs(d)<=1e-10).sum())}


def holm(entries):
    last = 0.
    result = {}
    for i,(key,p) in enumerate(sorted(entries.items(),key=lambda a:a[1])):
        last = max(last,min(1.,(len(entries)-i)*p))
        result[key] = last
    return result


def report():
    result = {'complete':True,'datasets':{},'limits':[
        'All folds previously inspected; exploratory development evidence, not independent confirmation.',
        'Linear probe accuracy measures readable predictive information under this fixed decoder, not mutual information or neural mechanism.',
        'PCA equalizes final dimensions but changes subspace and inductive bias; a gap alone is not proof of irreversible compression loss.',
        'Second stage LOO is held fixed in both adapter comparisons; this tests FIRST stage source-loss dependence only.',
        'No cross-dataset weight transfer; both datasets train separate subject-dependent models.',
        'Subject is the sampling unit; fixed-seed descriptive intervals cannot correct historical adaptive selection.']}
    primary_probe_p, primary_source_p = {}, {}
    for kind in ['main','external']:
        nc = 5 if kind == 'main' else 3
        group = {'probe_sources':{},'source_comparison':{}}
        for method in ['ce','loo']:
            rows = []
            for s in ref.subjects(kind):
                paths = [OUT/'probes'/kind/method/(ref.name(kind,s,f)+'.npz') for f in range(5)]
                if not all(p.exists() for p in paths):
                    continue
                yy,source = [],[]
                predictions = {k:[] for k in PROBES}
                for p in paths:
                    with np.load(p) as z:
                        yy.extend(z['y']);source.extend(z['source_pred'])
                        for key in PROBES:predictions[key].extend(z[key+'_pred'])
                y = np.array(yy)
                row = {'subject':s,'source':metrics(y,np.array(source),nc)}
                row.update({k:metrics(y,np.array(v),nc) for k,v in predictions.items()})
                rows.append(row)
            complete = len(rows) == len(ref.subjects(kind))
            result['complete'] &= complete
            pg = {'complete':complete,'completed_subjects':len(rows),'subjects':rows}
            if rows:
                pg['means'] = {k:{m:float(np.mean([r[k][m] for r in rows]))
                                   for m in ['accuracy','macro_f1']} for k in ['source']+PROBES}
            if complete:
                pg['paired_primary'] = {}
                for a,b in PRIMARY_PROBES:
                    key = a+'_minus_'+b
                    st = paired_stats([100*(r[a]['accuracy']-r[b]['accuracy']) for r in rows])
                    pg['paired_primary'][key] = st
                    if method == 'loo':primary_probe_p[kind+'/'+key] = st['exact_signflip_p']
            group['probe_sources'][method] = pg
        rows = []
        for s in ref.subjects(kind):
            if not all((OUT/'ce_generic_adapter'/kind/(ref.name(kind,s,f)+'.npz')).exists() for f in range(5)):
                continue
            yy = []
            predictions = {k:[] for k in ['source_ce','source_loo','generic_ce_source','generic_loo_source']}
            for f in range(5):
                name = ref.name(kind,s,f)
                with np.load(OUT/'ce_generic_adapter'/kind/(name+'.npz')) as z:
                    y = z['y'];yy.extend(y);predictions['source_ce'].extend(z['source_pred'])
                    predictions['generic_ce_source'].extend(z['pred'])
                with np.load(GENERIC_LOO/kind/'generic_adapter'/(name+'.npz')) as z:
                    assert np.array_equal(z['y'],y)
                    predictions['source_loo'].extend(z['source_pred'])
                    predictions['generic_loo_source'].extend(z['pred'])
            y = np.array(yy)
            row = {'subject':s,**{k:metrics(y,np.array(v),nc) for k,v in predictions.items()}}
            rows.append(row)
        complete = len(rows) == len(ref.subjects(kind));result['complete'] &= complete
        sg = {'complete':complete,'completed_subjects':len(rows),'subjects':rows}
        if rows:
            sg['means'] = {k:{m:float(np.mean([r[k][m] for r in rows])) for m in ['accuracy','macro_f1']}
                           for k in ['source_ce','source_loo','generic_ce_source','generic_loo_source']}
        if complete:
            sg['paired'] = {}
            for a,b in [('generic_loo_source','generic_ce_source'),('generic_ce_source','source_ce'),
                        ('generic_loo_source','source_loo'),('source_loo','source_ce')]:
                key = a+'_minus_'+b
                st = paired_stats([100*(r[a]['accuracy']-r[b]['accuracy']) for r in rows])
                sg['paired'][key] = st
                if a == 'generic_loo_source' and b == 'generic_ce_source':
                    primary_source_p[kind] = st['exact_signflip_p']
            sg['adapter_gain_interaction'] = paired_stats([
                100*((r['generic_loo_source']['accuracy']-r['source_loo']['accuracy'])-
                     (r['generic_ce_source']['accuracy']-r['source_ce']['accuracy'])) for r in rows])
        group['source_comparison'] = sg
        result['datasets'][kind] = group
    if len(primary_probe_p) == 6:result['probe_primary_holm_p'] = holm(primary_probe_p)
    if len(primary_source_p) == 2:result['source_primary_holm_p'] = holm(primary_source_p)
    result['multiplicity'] = 'Separate declared families:6 LOO-source matched probe contrasts;2 final adapter source contrasts. CE-source probes and gain interaction secondary. No correction can remove prior adaptive reuse of these data.'
    save(OUT/'summary.json',result)


def counts():
    probes = sum(len(list((OUT/'probes'/k/m).glob('*fold*.npz'))) for k in ['main','external'] for m in ['ce','loo'])
    # Exclude coefficient archives from the fold count.
    weights = sum(len(list((OUT/'probes'/k/m).glob('*_weights.npz'))) for k in ['main','external'] for m in ['ce','loo'])
    probes -= weights
    adapters = sum(len(list((OUT/'ce_generic_adapter'/k).glob('*fold*.npz'))) for k in ['main','external'])
    return probes,adapters


def status(start,state,**extra):
    p,a = counts()
    elapsed = time.time()-start
    done = p+a
    total = 2*TOTAL_FOLDS+TOTAL_FOLDS
    save(OUT/'status.json',{'state':state,'pid':os.getpid(),
        'completed_feature_folds':p,'total_feature_folds':210,
        'completed_probe_fits':p*len(PROBES),'total_probe_fits':TOTAL_PROBE_FITS,
        'completed_adapter_folds':a,'total_adapter_folds':105,
        'elapsed_seconds':elapsed,'estimated_remaining_seconds':elapsed*(total-done)/done if done else None,
        'updated':time.time(),**extra})


def inventory():
    records=[]
    for kind in ['main','external']:
        for s in ref.subjects(kind):
            x,y = ref.dataset(kind,s)
            for fold,(tr,te) in enumerate(ref.splits(kind,x,y)):
                assert not set(tr)&set(te)
                assert np.array_equal(np.sort(np.r_[tr,te]),np.arange(len(x)))
                for method in ['ce','loo']:
                    p=source_path(kind,method,s,fold)
                    assert p.exists()
                    read_saved(kind,p.with_suffix('.npz'),tr,te,y,primary=True)
                    records.append({'dataset':kind,'subject':s,'fold':fold,'method':method,
                                    'checkpoint':str(p),'sha256':sha(p)})
                p=GENERIC_LOO/kind/'generic_adapter'/(ref.name(kind,s,fold)+'.npz')
                read_saved(kind,p,tr,te,y)
                assert p.with_suffix('.pt').exists()
    data_paths=[Path('/root/FAST/Processed/BCIC2020Track3.h5')]
    data_paths += [ref.external_ref.ROOT/f'sub-{s:02d}.npz' for s in range(1,7)]
    save(OUT/'inventory.json',{'source_checkpoints':records,'pretrained_sources':210,
                             'reused_generic_loo_fits':105,'split_disjoint':True,
                             'prepared_data_sha256':{str(p):sha(p) for p in data_paths},
                             'runtime':{'python':sys.version,'numpy':np.__version__,
                                        'torch':torch.__version__,'sklearn':sklearn.__version__}})


def protocol():
    dependencies=[Path(__file__),Path(ref.__file__),Path(ref.main_ref.__file__),
                  Path(ref.external_ref.__file__),Path(ref.external_ref.common.__file__),
                  Path(ref.main_ref.v4.__file__),Path('/root/FAST/FAST.py')]
    return {'version':1,'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
        'questions':['Is classification information more readable before regional-to-token compression under dimension-controlled fixed linear probes?',
                     'Does first-stage LOO source training retain value after adding the SAME generic adapter with the SAME second-stage objective?'],
        'datasets':{'BCI2020':{'subjects':15,'folds':5,'whole_trials':350},
                    'Nguyen2017':{'subjects':6,'folds':5,'whole_trials':300}},
        'sources':{'ce':{k:str(v) for k,v in SOURCE_CE.items()},'loo':{k:str(v) for k,v in SOURCE_LOO.items()}},
        'new_fits':{'linear_probes':1890,'generic_ce_source_adapters':105},
        'reused':{'pretrained_sources':210,'generic_loo_source_adapters':105},
        'probes':PROBES,'primary_probe_contrasts_loo_sources':PRIMARY_PROBES,
        'probe_model':{'classifier':'StandardScaler + LogisticRegression','C':1.,'max_iter':2000,'tol':1e-4,
                       'pca_dimension':32,'pca_solver':'randomized','pca_power':7,'seed':42,
                       'window_pca':'Train windows pooled,256->32 then preserve original5/7 windows',
                       'normalization':'Raw frozen CNN/projection/GELU/CLS features; all scalers and PCA fit ONLY on outer training trials. No asinh for this compression diagnostic.'},
        'adapter':{'parameters':9280,'steps':200,'optimizer':'AdamW','lr':.001,'final_lr':.0001,
                   'weight_decay':.01,'loss':'CE+.3CE(4*analyticLOO)+.01mean(delta^2)',
                   'source_frozen':True,'same_initializer_and_seed_as_existing_generic':True,
                   'comparison':'New CE-source adapter vs saved LOO-source adapter; stage2 LOO held fixed in BOTH.'},
        'known_before_run':['Previous3 selectedBCI people had unmatched kernel compression probes; not novelty proof.',
                            'GenericLOO-source adapters already observed:BCI64.495238%,Nguyen39.222222%.',
                            'Regional gate was not superior to generic control on BCI; static/PSD fusion probes did not improve strongest view.',
                            'All cohorts/splits repeatedly examined; this protocol does NOT create independent confirmation.'],
        'endpoints':'Merge five heldout folds per person, equal person mean accuracy; macroF1 secondary. Report all subjects, paired descriptive bootstrap and exact sign-flip statistics.',
        'stop':'Complete fixed1890 CPU probes and105 stage2 fits regardless of accuracy. No baseline retraining,HPO,subject selection,new dataset or architecture search. Operational validation failures stop rather than silently change controls.',
        'interpretation':'Fixed probe separability is neither true mutual information nor neural origin. Dimensional matching does not match every inductive bias. Source contrast tests stage1 LOO,not all auxiliary learning. No biological/novelty claims.',
        'source_hashes':{str(p):sha(p) for p in dependencies}}


def smoke():
    torch.set_num_threads(4)
    inventory()
    passed = {}
    total_start=time.time()
    for kind,s in [('main',0),('external',1)]:
        x,y=ref.dataset(kind,s)
        tr,te=next(ref.splits(kind,x,y))
        for method in ['ce','loo']:
            base,full,old,saved,norm,error=load_source(kind,method,s,0,tr,te,x,y)
            before=ref.main_ref.tensorhash(base)
            values=extract_views(kind,base,full,tr,te,old)
            matrices,_=transform_views(values,tr)
            # Tamper ONLY heldout features; training-fitted transforms must be
            # unchanged on training observations. This checks transformation code.
            changed={k:a.copy() for k,a in values.items()}
            for a in changed.values():a[te]+=123.
            changed_matrices,_=transform_views(changed,tr)
            assert all(np.array_equal(matrices[k][tr],changed_matrices[k][tr]) for k in PROBES)
            assert ref.main_ref.tensorhash(base)==before
            init=initialize_generic(kind,full[tr],s,0)
            with torch.no_grad():initial=ref.rep(kind,base,init,full[te],torch.zeros_like(full[te]))[0].float()
            assert torch.equal(initial,old)
            if method=='loo':
                path=GENERIC_LOO/kind/'generic_adapter'/(ref.name(kind,s,0)+'.pt')
                init.load_state_dict(torch.load(path,map_location='cpu')['state_dict'])
                with torch.no_grad():actual=ref.rep(kind,base,init,full[te],torch.zeros_like(full[te]))[0].float().softmax(-1).cpu().numpy()
                expected=read_saved(kind,path.with_suffix('.npz'),tr,te,y)
                replay_error=float(np.max(np.abs(actual-expected)))
                assert np.array_equal(actual.argmax(-1),expected.argmax(-1)) and replay_error<1e-6
            else:
                yt=torch.from_numpy(y[tr]).cuda()
                opt=torch.optim.AdamW(init.parameters(),lr=.001,weight_decay=.01)
                logits,q,gate,delta=ref.rep(kind,base,init,full[tr],torch.zeros_like(full[tr]))
                loss=F.cross_entropy(logits,yt)+.3*F.cross_entropy(4*ref.ridge(kind,q,yt),yt)+.01*delta.square().mean()
                loss.backward();assert torch.isfinite(loss)
                assert all(p.grad is None or torch.isfinite(p.grad).all() for p in init.parameters())
                opt.step()
                assert ref.main_ref.tensorhash(base)==before and all(p.grad is None for p in base.parameters())
                replay_error=None
            # Ensure a representative high-dimensional and matched probe converge.
            t=time.time()
            for key in ['regional_flat','regional_pca32','token_pca32','cls32']:
                scaler=StandardScaler().fit(matrices[key][tr]);a=scaler.transform(matrices[key][tr])
                with warnings.catch_warnings(record=True) as ws:
                    warnings.simplefilter('always',ConvergenceWarning)
                    LogisticRegression(C=1.,max_iter=2000,tol=1e-4,random_state=42).fit(a,y[tr])
                assert not any(issubclass(w.category,ConvergenceWarning) for w in ws)
            passed[kind+'/'+method]={'source_replay_max_error':error,'zero_init_exact':True,
                'generic_loo_replay_max_error':replay_error,'train_only_transforms_verified':True,
                'dimensions':{k:int(a.shape[1]) for k,a in matrices.items()},'four_probe_smoke_seconds':time.time()-t}
            del base,full,old,init,values,matrices,changed,changed_matrices
            torch.cuda.empty_cache()
    save(OUT/'smoke.json',{'passed':True,'checks':passed,'source_checkpoints':210,
                          'reused_generic_fits':105,'seconds':time.time()-total_start,
                          'smoke_not_counted_in_study':True})
    print('SMOKE_PASS',json.dumps(passed),flush=True)


def main():
    torch.set_num_threads(4)
    OUT.mkdir(parents=True,exist_ok=True)
    with (OUT/'run.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        assert json.loads((OUT/'smoke.json').read_text())['passed']
        p=protocol()
        if (OUT/'protocol.json').exists():
            previous=json.loads((OUT/'protocol.json').read_text())
            p['created_utc']=previous['created_utc']
            assert p==previous
        else:save(OUT/'protocol.json',p)
        start=time.time()
        status(start,'running')
        try:
            for kind in ['main','external']:
                for s in ref.subjects(kind):
                    x,y=ref.dataset(kind,s)
                    for fold,(tr,te) in enumerate(ref.splits(kind,x,y)):
                        name=ref.name(kind,s,fold)
                        for method in ['ce','loo']:
                            probed=(OUT/'probes'/kind/method/(name+'.npz')).exists()
                            adapted=(OUT/'ce_generic_adapter'/kind/(name+'.npz')).exists()
                            if probed and (method=='loo' or adapted):continue
                            status(start,'running',dataset=kind,subject=s,fold=fold+1,source_method=method,phase='source_replay')
                            base,full,old,saved,norm,error=load_source(kind,method,s,fold,tr,te,x,y)
                            before=ref.main_ref.tensorhash(base)
                            if not probed:
                                values=extract_views(kind,base,full,tr,te,old)
                                save_npz(OUT/'feature_cache'/kind/method/(name+'.npz'),train_idx=tr,test_idx=te,y=y,**values)
                                status(start,'running',dataset=kind,subject=s,fold=fold+1,source_method=method,phase='linear_probes')
                                fit_probes(kind,method,s,fold,values,tr,te,y,saved,error)
                            if method=='ce' and not adapted:
                                status(start,'running',dataset=kind,subject=s,fold=fold+1,source_method=method,phase='adapter_training')
                                fit_ce_adapter(kind,s,fold,base,full,old,y,tr,te,saved,error,norm)
                            assert ref.main_ref.tensorhash(base)==before and all(p.grad is None for p in base.parameters())
                            status(start,'running',dataset=kind,subject=s,fold=fold+1,source_method=method)
                            del base,full,old
                            torch.cuda.empty_cache()
                        if fold==4:report()
            assert counts()==(210,105),counts()
            report();assert json.loads((OUT/'summary.json').read_text())['complete']
            status(start,'complete')
        except Exception as e:
            report();status(start,'failed',error=repr(e));raise


if __name__=='__main__':
    OUT.mkdir(parents=True,exist_ok=True)
    parser=argparse.ArgumentParser()
    parser.add_argument('--smoke',action='store_true')
    args=parser.parse_args()
    smoke() if args.smoke else main()
