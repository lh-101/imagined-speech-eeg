"""V3: frozen FAST representation, full regional residual readout.

Source: each saved spectral outer-fold checkpoint (57.714% full cohort), NOT
the original 57.790% baseline, whose predictions remain the comparison target.
No backbone optimization, no 32->4 projection, no test-dependent selection.
"""
import argparse
import hashlib
import json
import pathlib
import time
import h5py
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.model_selection import KFold
from sklearn.metrics import f1_score
from run_residual import config, band_cov, seed_all
from fast_residual import ResidualFAST

ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/'isolated_readout_v3'
SETTINGS=dict(steps=400,learning_rate=.003,l2=.01,auxiliary_weight=.3,
              correction_bound=1.5,feature_clip=6.,seed=42,
              source='results/spectral',subjects=list(range(15)),
              note='Exploratory. Frozen saved spectral weights; original baseline not retrained. Fixed all-subject recipe.')


class Readout(nn.Module):
    def __init__(self, train_features):
        super().__init__()
        self.register_buffer('mean',train_features.mean(0))
        self.register_buffer('scale',train_features.std(0,unbiased=False).clamp_min(1e-3))
        self.linear=nn.Linear(train_features.shape[1],5)
        nn.init.zeros_(self.linear.weight)
        nn.init.zeros_(self.linear.bias)

    def forward(self, features, base_logits):
        z=((features-self.mean)/self.scale).clamp(-SETTINGS['feature_clip'],SETTINGS['feature_clip'])
        raw=self.linear(z)
        centered=raw-raw.mean(-1,keepdim=True)
        bound=SETTINGS['correction_bound']
        correction=bound*torch.tanh(centered/bound)
        return base_logits+correction,raw,correction


def fit_head(features, logits, labels, steps=None):
    assert not features.requires_grad and not logits.requires_grad
    head=Readout(features).to(features.device)
    opt=torch.optim.Adam(head.parameters(),lr=SETTINGS['learning_rate'])
    trace=[]
    n=steps or SETTINGS['steps']
    for step in range(n):
        lr=SETTINGS['learning_rate']*(.1+.9*.5*(1+np.cos(np.pi*step/max(n-1,1))))
        for group in opt.param_groups: group['lr']=lr
        opt.zero_grad(set_to_none=True)
        fused,raw,_=head(features,logits)
        ce=F.cross_entropy(fused,labels)
        aux=F.cross_entropy(raw,labels)
        penalty=SETTINGS['l2']*head.linear.weight.square().sum()
        loss=ce+SETTINGS['auxiliary_weight']*aux+penalty
        if not torch.isfinite(loss): raise RuntimeError('Non-finite readout loss')
        loss.backward()
        if not all(torch.isfinite(p.grad).all() for p in head.parameters()):
            raise RuntimeError('Non-finite readout gradients')
        opt.step()
        if step==0 or (step+1)%100==0 or step==n-1:
            trace.append(dict(step=step+1,loss=float(loss.detach()),fused_ce=float(ce.detach()),
                              auxiliary_ce=float(aux.detach()),penalty=float(penalty.detach())))
    return head,trace


@torch.no_grad()
def extract(model,x,cov):
    # Same per-fold batch sizes and float32 inference as the saved predictor.
    features=model.forward_head(x)
    base=model.forward_transformer(features)
    h=F.gelu(model.stat_hidden(model.stat_norm(model.spectral_descriptor(cov))))
    logits=base+model.stat_out(h)
    return torch.asinh(features.float()).flatten(1).detach(),logits.detach()


def tensor_hash(model):
    h=hashlib.sha256()
    for key,v in model.state_dict().items():
        h.update(key.encode());h.update(v.detach().cpu().numpy().tobytes())
    return h.hexdigest()


def summarize():
    rows=[]
    for s in range(15):
        path=OUT/f'{s}-predictions.npz'
        if not path.exists(): continue
        d=np.load(path)
        b=np.loadtxt(f'/root/FAST/Results/FAST/{s}-Tune.csv',delimiter=',',dtype=int)
        assert np.array_equal(d['y'],b[:,1])
        rows.append(dict(subject=s,accuracy=float((d['pred']==d['y']).mean()),
                         original_baseline=float((b[:,0]==b[:,1]).mean()),
                         frozen_source=float((d['source_pred']==d['y']).mean()),
                         auxiliary_accuracy=float((d['aux_pred']==d['y']).mean()),
                         macro_f1=float(f1_score(d['y'],d['pred'],average='macro'))))
    r=dict(n_subjects=len(rows),complete=len(rows)==15,subjects=rows)
    if rows:
        r.update(accuracy=float(np.mean([v['accuracy'] for v in rows])),
                 delta_original_pp=float(np.mean([v['accuracy']-v['original_baseline'] for v in rows])*100),
                 delta_source_pp=float(np.mean([v['accuracy']-v['frozen_source'] for v in rows])*100))
    (OUT/'summary.json').write_text(json.dumps(r,indent=2))
    return r


def subject(s):
    if (OUT/f'{s}-predictions.npz').exists(): return
    with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5','r') as f:
        x=f[f'{s+1:02d}/X'][:]
        y=f[f'{s+1:02d}/Y'][:].astype(np.int64)
    cov=band_cov(x)
    saved=np.load(ROOT/'results/spectral'/f'{s}-predictions.npz')
    assert np.array_equal(saved['y'],y)
    prob=np.zeros((len(y),5),np.float32)
    source_pred=np.full(len(y),-1)
    aux_pred=np.full(len(y),-1)
    fold=np.full(len(y),-1)
    for fi,(tr,te) in enumerate(KFold(5,shuffle=False).split(x)):
        path=OUT/f'{s}-fold{fi}.npz'
        if path.exists():
            d=np.load(path)
            assert np.array_equal(d['train_idx'],tr) and np.array_equal(d['test_idx'],te)
            prob[te],source_pred[te],aux_pred[te],fold[te]=d['prob'],d['source_pred'],d['aux_pred'],fi
            continue
        start=time.time();seed_all(42)
        source=ROOT/'results/spectral'/f'{s}-fold{fi}.pt'
        ck=torch.load(source,map_location='cpu',weights_only=False)
        assert np.array_equal(ck['train_idx'],tr) and np.array_equal(ck['test_idx'],te)
        m=ResidualFAST(config(),'spectral').cuda().eval()
        m.load_state_dict(ck['state_dict'])
        m.requires_grad_(False)
        before=tensor_hash(m)
        w=ck['whitener']
        c=(w[None]@cov@w.transpose(0,2,1)[None]).astype(np.float32)
        ft,bt=extract(m,torch.from_numpy(x[tr]).cuda(),torch.from_numpy(c[tr]).cuda())
        # Train and evaluate the head on explicit disjoint indices.
        head,trace=fit_head(ft,bt,torch.from_numpy(y[tr]).cuda())
        fv,bv=extract(m,torch.from_numpy(x[te]).cuda(),torch.from_numpy(c[te]).cuda())
        src=bv.argmax(-1).cpu().numpy()
        assert np.array_equal(src,saved['pred'][te]), 'Frozen source prediction mismatch'
        assert tensor_hash(m)==before, 'Backbone mutated'
        assert all(p.grad is None for p in m.parameters()), 'Unexpected backbone gradient'
        with torch.no_grad():
            logits,raw,correction=head(fv,bv)
            pp=logits.softmax(-1).cpu().numpy()
            ap=raw.argmax(-1).cpu().numpy()
            train_fused,train_aux,_=head(ft,bt)
            train_acc=float((train_fused.argmax(-1)==torch.from_numpy(y[tr]).cuda()).float().mean())
            train_aux_acc=float((train_aux.argmax(-1)==torch.from_numpy(y[tr]).cuda()).float().mean())
        diag=dict(subject=s,fold=fi,accuracy=float((pp.argmax(-1)==y[te]).mean()),
                  source_accuracy=float((src==y[te]).mean()),auxiliary_accuracy=float((ap==y[te]).mean()),
                  train_accuracy=train_acc,train_auxiliary_accuracy=train_aux_acc,
                  max_abs_correction=float(correction.abs().max()),backbone_hash=before,
                  unchanged_backbone=True,seconds=round(time.time()-start,1),loss_trace=trace)
        torch.save(dict(state_dict=head.cpu().state_dict(),source_checkpoint=str(source),
                        source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                        train_idx=tr,test_idx=te,settings=SETTINGS),OUT/f'{s}-fold{fi}.pt')
        (OUT/f'{s}-fold{fi}-diagnostics.json').write_text(json.dumps(diag,indent=2))
        np.savez(path,prob=pp,source_pred=src,aux_pred=ap,y=y[te],train_idx=tr,test_idx=te)
        prob[te],source_pred[te],aux_pred[te],fold[te]=pp,src,ap,fi
        print('FOLD',json.dumps(diag),flush=True)
        del m,head,ft,bt,fv,bv,ck
    assert (fold>=0).all()
    np.savez(OUT/f'{s}-predictions.npz',prob=prob,pred=prob.argmax(-1),y=y,
             source_pred=source_pred,aux_pred=aux_pred,fold=fold)


def smoke():
    seed_all(42)
    features=torch.randn(40,1280,device='cuda')
    logits=torch.randn(40,5,device='cuda')
    labels=torch.arange(40,device='cuda')%5
    h=Readout(features).cuda()
    with torch.no_grad():
        out,_,corr=h(features,logits)
        assert torch.equal(out,logits) and torch.count_nonzero(corr)==0
    fitted,trace=fit_head(features,logits,labels,steps=25)
    with torch.no_grad():
        out,_,corr=fitted(features,logits)
        assert corr.abs().max()<=SETTINGS['correction_bound']
        assert torch.isfinite(out).all()
        one=fitted(features[:1],logits[:1])[0]
        assert torch.allclose(one,out[:1],atol=1e-4,rtol=1e-4)
        before={k:v.clone() for k,v in fitted.state_dict().items()}
        fitted(features*100,logits)
        assert all(torch.equal(v,before[k]) for k,v in fitted.state_dict().items())
    assert trace[-1]['loss']<trace[0]['loss']
    print('SMOKE_OK zero-init identity; bounded correction; finite decreasing loss; immutable train-only normalization',flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');args=ap.parse_args()
    if args.smoke:
        smoke()
    else:
        OUT.mkdir(exist_ok=True)
        manifest=dict(**SETTINGS,code_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest())
        (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
        status=dict(state='running',started=time.time(),completed=[])
        try:
            for s in SETTINGS['subjects']:
                status['current_subject']=s
                (OUT/'status.json').write_text(json.dumps(status,indent=2))
                subject(s)
                status['completed'].append(s)
                print('SUMMARY',json.dumps(summarize()),flush=True)
            status['state']='complete'
        except Exception as exc:
            status.update(state='failed',error=str(exc));raise
        finally:
            status['updated']=time.time()
            (OUT/'status.json').write_text(json.dumps(status,indent=2))
