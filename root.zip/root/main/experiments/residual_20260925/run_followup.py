"""Fixed protocols; no baseline retraining or test-driven checkpoint selection."""
import argparse
import hashlib
import json
import pathlib
import time
import h5py
import numpy as np
import torch
import lightning as pl
from torch.nn import functional as F
from sklearn.model_selection import KFold
from sklearn.metrics import f1_score
import run_residual as previous
from fast_residual import ResidualFAST
from zone_gaussian import ZoneGaussianFAST, sqrt_spd

ROOT = pathlib.Path(__file__).resolve().parent
OUT = ROOT / 'followup_results'


class ZoneModule(pl.LightningModule):
    def __init__(self, mode, epochs):
        super().__init__()
        self.model = ZoneGaussianFAST(previous.config())
        self.schedule = previous.cosine_scheduler(1, .1, epochs, 1, warmup_epochs=10)
        self.losses = []

    def training_step(self, batch, batch_idx):
        x, _, y = batch
        fused, main, auxiliary = self.model(x, return_parts=True)
        loss = F.cross_entropy(fused, y) + .3 * F.cross_entropy(auxiliary, y)
        if not torch.isfinite(loss):
            raise RuntimeError('Non-finite loss')
        self.losses.append(float(loss.detach()))
        return loss

    def configure_optimizers(self):
        opt = torch.optim.AdamW(self.parameters(), lr=.0005)
        sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda ep: self.schedule[self.global_step - 1])
        return [opt], [{'scheduler': sched, 'interval': 'step'}]


def summarize():
    report = {}
    for mode in ['zone_gaussian', 'late_sam']:
        rows = []
        for file in sorted((OUT / mode).glob('*-predictions.npz')):
            s = int(file.name.split('-')[0])
            d = np.load(file)
            b = np.loadtxt(f'/root/FAST/Results/FAST/{s}-Tune.csv', delimiter=',', dtype=int)
            assert np.array_equal(d['y'], b[:, 1])
            rows.append(dict(subject=s, accuracy=float(np.mean(d['pred'] == d['y'])),
                             baseline=float(np.mean(b[:, 0] == b[:, 1])),
                             macro_f1=float(f1_score(d['y'], d['pred'], average='macro'))))
        if rows:
            delta = np.array([r['accuracy'] - r['baseline'] for r in rows]) * 100
            report[mode] = dict(n_subjects=len(rows), complete=len(rows) == 15,
                                accuracy=float(np.mean([r['accuracy'] for r in rows])),
                                delta_pp=float(delta.mean()), improved=int((delta > 0).sum()),
                                subjects=rows)
    OUT.mkdir(exist_ok=True)
    (OUT / 'summary.json').write_text(json.dumps(report, indent=2))
    return report


def sam_step(model, optimizer, x, cov, y, rho=.05):
    """Same dropout mask in both passes; exact weight restoration before AdamW."""
    model.train()
    optimizer.zero_grad(set_to_none=True)
    rng_cpu, rng_gpu = torch.get_rng_state(), torch.cuda.get_rng_state()
    with torch.autocast('cuda', dtype=torch.bfloat16):
        loss = F.cross_entropy(model(x, cov), y)
    loss.backward()
    params = [p for p in model.parameters() if p.grad is not None]
    norm = torch.linalg.vector_norm(torch.stack([p.grad.float().norm() for p in params]))
    if not torch.isfinite(norm) or not torch.isfinite(loss):
        raise RuntimeError('Non-finite SAM first pass')
    old = [p.detach().clone() for p in params]
    with torch.no_grad():
        for p in params:
            p.add_(p.grad, alpha=float(rho / (norm + 1e-12)))
    optimizer.zero_grad(set_to_none=True)
    torch.set_rng_state(rng_cpu)
    torch.cuda.set_rng_state(rng_gpu)
    try:
        with torch.autocast('cuda', dtype=torch.bfloat16):
            sharp_loss = F.cross_entropy(model(x, cov), y)
        sharp_loss.backward()
    finally:
        with torch.no_grad():
            for p, v in zip(params, old):
                p.copy_(v)
    if not torch.isfinite(sharp_loss) or any(p.grad is not None and not torch.isfinite(p.grad).all() for p in params):
        raise RuntimeError('Non-finite SAM second pass')
    optimizer.step()
    return float(loss.detach()), float(sharp_loss.detach())


def run_late_sam(s):
    output = OUT / 'late_sam'
    output.mkdir(parents=True, exist_ok=True)
    if (output / f'{s}-predictions.npz').exists():
        return
    source = ROOT / 'results' / 'spectral'
    with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5', 'r') as h:
        x = h[f'{s+1:02d}/X'][:]
        y = h[f'{s+1:02d}/Y'][:].astype(np.int64)
    cov = previous.band_cov(x)
    prob = np.zeros((len(y), 5), dtype=np.float32)
    fold = np.full(len(y), -1)
    for fi, (tr, te) in enumerate(KFold(5, shuffle=False).split(x)):
        final = output / f'{s}-fold{fi}.npz'
        if final.exists():
            d = np.load(final)
            assert np.array_equal(d['test_idx'], te)
            prob[te], fold[te] = d['prob'], fi
            continue
        previous.seed_all(20260926 + s * 5 + fi)
        ck = torch.load(source / f'{s}-fold{fi}.pt', map_location='cpu', weights_only=False)
        assert np.array_equal(tr, ck['train_idx']) and np.array_equal(te, ck['test_idx'])
        model = ResidualFAST(previous.config(), 'spectral').cuda()
        model.load_state_dict(ck['state_dict'])
        w = ck['whitener']
        c = (w[None] @ cov @ w.transpose(0, 2, 1)[None]).astype(np.float32)
        xt, ct, yt = [torch.from_numpy(a).cuda() for a in (x[tr], c[tr], y[tr])]
        optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=.01)
        losses = []
        start = time.time()
        for step in range(50):
            lr = 1e-4 * (.1 + .9 * .5 * (1 + np.cos(np.pi * step / 49)))
            for group in optimizer.param_groups:
                group['lr'] = lr
            losses.append(sam_step(model, optimizer, xt, ct, yt))
        model.eval()
        with torch.no_grad():
            p = model(torch.from_numpy(x[te]).cuda(), torch.from_numpy(c[te]).cuda()).softmax(-1).cpu().numpy()
            ta = float((model(xt, ct).argmax(-1) == yt).float().mean())
        prob[te], fold[te] = p, fi
        np.savez(final, prob=p, y=y[te], train_idx=tr, test_idx=te, losses=losses)
        torch.save(dict(state_dict=model.cpu().state_dict(), train_idx=tr, test_idx=te,
                        whitener=w, steps=50, rho=.05, source=str(source / f'{s}-fold{fi}.pt')),
                   output / f'{s}-fold{fi}.pt')
        print(json.dumps(dict(event='fold', mode='late_sam', subject=s, fold=fi,
                              accuracy=float((p.argmax(-1) == y[te]).mean()), train_acc=ta,
                              first=losses[0], last=losses[-1], seconds=round(time.time()-start, 1))), flush=True)
        del model, xt, ct, yt, optimizer, ck
    assert (fold >= 0).all()
    np.savez(output / f'{s}-predictions.npz', pred=prob.argmax(-1), prob=prob, y=y, fold=fold)


def smoke():
    previous.seed_all(42)
    model = ZoneGaussianFAST(previous.config()).cuda()
    x = torch.randn(8, 64, 800, device='cuda')
    y = torch.arange(8, device='cuda') % 5
    with torch.autocast('cuda', dtype=torch.bfloat16):
        fused, main, aux = model(x, return_parts=True)
        loss = F.cross_entropy(fused, y) + .3 * F.cross_entropy(aux, y)
    loss.backward()
    assert all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters())
    assert model.stat_projection.weight.grad.abs().sum() > 0
    assert model.stat_classifier.weight.grad.abs().sum() > 0
    model.eval()
    with torch.no_grad():
        a = model(x[:1])
        b = model(x)[:1]
        assert torch.allclose(a, b, atol=1e-4, rtol=1e-4), 'Cross-trial mixing'
        identical = torch.ones(2, 5, 8, 32, device='cuda')
        assert torch.isfinite(model.descriptor(identical)).all()
        v = torch.randn(2, 4, 4, device='cuda', dtype=torch.float64)
        v = v @ v.transpose(-1,-2) + torch.eye(4, device='cuda')
        root, trace = sqrt_spd(v)
        assert torch.allclose(root @ root, v / trace[:,None,None], atol=1e-4)
    # lr=0 must restore every parameter exactly after adversarial perturbation.
    rm = ResidualFAST(previous.config(), 'spectral').cuda()
    cov = torch.eye(64, device='cuda').expand(8, 5, 64, 64).clone()
    old = {n:p.detach().clone() for n,p in rm.named_parameters()}
    sam_step(rm, torch.optim.AdamW(rm.parameters(), lr=0), x, cov, y)
    assert all(torch.equal(p, old[n]) for n,p in rm.named_parameters())
    print('SMOKE_OK: finite branch gradients, trial independence, SPD root, exact SAM restore', flush=True)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--smoke', action='store_true')
    ap.add_argument('--mode', choices=['zone_gaussian', 'late_sam'], default='zone_gaussian')
    ap.add_argument('--subjects', default='0-14')
    args = ap.parse_args()
    if args.smoke:
        smoke()
    else:
        OUT.mkdir(exist_ok=True)
        manifest = dict(mode=args.mode, subjects=args.subjects, date='2026-09-26',
                        target_accuracy=.6479047619, baseline=.5779047619,
                        epochs=200 if args.mode == 'zone_gaussian' else 50,
                        source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest()
                                       for p in [ROOT/'run_followup.py', ROOT/'zone_gaussian.py']},
                        note='Exploratory. Fixed recipe. No test-label checkpoint selection. Baseline not retrained.')
        (OUT / f'{args.mode}-manifest.json').write_text(json.dumps(manifest, indent=2))
        subjects = list(range(int(args.subjects.split('-')[0]), int(args.subjects.split('-')[1])+1)) if '-' in args.subjects else list(map(int, args.subjects.split(',')))
        previous.RUN = OUT
        previous.Module = ZoneModule
        for s in subjects:
            if args.mode == 'zone_gaussian':
                previous.run_subject(args.mode, s)
            else:
                run_late_sam(s)
            print('SUMMARY', json.dumps(summarize()), flush=True)
        print('FOLLOWUP_COMPLETE', args.mode, flush=True)
