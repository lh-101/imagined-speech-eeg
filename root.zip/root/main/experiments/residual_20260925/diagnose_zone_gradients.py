"""Checkpoint-local gradient diagnostic; no optimizer updates or test fitting."""
import json
import pathlib
import h5py
import numpy as np
import torch
from torch.nn import functional as F
from run_residual import config, seed_all
from zone_gaussian import ZoneGaussianFAST

root=pathlib.Path(__file__).resolve().parent
records=[]
torch.set_num_threads(8)
seed_all(42)
for s in [0,7,10]:
    ck=torch.load(root/'followup_results/zone_gaussian'/f'{s}-fold0.pt',map_location='cpu',weights_only=False)
    with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5','r') as h:
        x=h[f'{s+1:02d}/X'][:]; y=h[f'{s+1:02d}/Y'][:].astype(np.int64)
    tr=ck['train_idx']
    m=ZoneGaussianFAST(config()).cuda().eval()
    m.load_state_dict(ck['state_dict'])
    xx=torch.from_numpy(x[tr]).cuda(); yy=torch.from_numpy(y[tr]).cuda()
    fused,main,aux=m(xx,return_parts=True)
    fusion_loss=F.cross_entropy(fused,yy)
    aux_loss=.3*F.cross_entropy(aux,yy)
    params=list(m.head.parameters())
    g1=torch.autograd.grad(fusion_loss,params,retain_graph=True)
    g2=torch.autograd.grad(aux_loss,params)
    a=torch.cat([g.flatten() for g in g1]); b=torch.cat([g.flatten() for g in g2])
    record=dict(subject=s,fold=0,train_size=len(tr),eval_mode=True,
                fusion_train_loss=float(fusion_loss.detach()),weighted_aux_train_loss=float(aux_loss.detach()),
                main_train_accuracy=float((main.argmax(-1)==yy).float().mean()),
                aux_train_accuracy=float((aux.argmax(-1)==yy).float().mean()),
                encoder_gradient_cosine=float(F.cosine_similarity(a,b,dim=0)),
                weighted_aux_to_fusion_gradient_norm=float(b.norm()/a.norm().clamp_min(1e-12)))
    records.append(record); print(json.dumps(record),flush=True)
    del m,xx,yy,g1,g2,a,b,fused,main,aux,fusion_loss,aux_loss
(root/'followup_results/zone_gradient_diagnosis.json').write_text(json.dumps(dict(
    note='Final checkpoint, fold 0 only, training data, eval-mode gradients. Diagnostic association, not causal proof.',records=records),indent=2))
