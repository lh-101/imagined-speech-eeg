"""Bounded architecture screening; predetermined expansion and stopping rules.

All screen scores are exploratory outer-fold results, never claimed unbiased.
Only a common recipe can proceed; no per-subject model selection.
"""
import json
import hashlib
import pathlib
import time
import numpy as np
import torch
import h5py
import run_residual as previous
from run_followup import ZoneModule, OUT, summarize
from zone_gaussian import ZoneGaussianFAST

root = pathlib.Path(__file__).resolve().parent
status_path = root/'next_screen_status.json'
status = dict(state='running', mode='zone_gaussian', started=time.time(),
              stages=[[0,7,10],[1,4,11]], completed=[],
              expansion_rule='3 subjects: mean delta >=1pp and >=2 improved; 6 subjects: mean delta >=1pp and >=4 improved',
              note='Exploratory test-fold screening. Early stopping does not prove impossibility.')


def save_status():
    status['updated'] = time.time()
    status_path.write_text(json.dumps(status, indent=2))


def branch_diagnostics(s):
    folder=OUT/'zone_gaussian'
    with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5','r') as f:
        x=f[f'{s+1:02d}/X'][:]
        y=f[f'{s+1:02d}/Y'][:]
    pred={k:np.full(len(y),-1) for k in ['fused','main','auxiliary']}
    for fi in range(5):
        ck=torch.load(folder/f'{s}-fold{fi}.pt',map_location='cpu',weights_only=False)
        m=ZoneGaussianFAST(previous.config()).cuda().eval()
        m.load_state_dict(ck['state_dict'])
        te=ck['test_idx']
        with torch.no_grad():
            values=m(torch.from_numpy(x[te]).cuda(),return_parts=True)
        for key,value in zip(pred,values):
            pred[key][te]=value.argmax(-1).cpu().numpy()
        del m,ck
    saved=np.load(folder/f'{s}-predictions.npz')
    assert np.array_equal(pred['fused'],saved['pred']), 'Saved predictions mismatch'
    result=dict(subject=s, **{k+'_accuracy':float((v==y).mean()) for k,v in pred.items()},
                changed_predictions=int((pred['fused']!=pred['main']).sum()))
    (folder/f'{s}-branch_diagnostics.json').write_text(json.dumps(result,indent=2))
    print('BRANCH_DIAGNOSTICS',json.dumps(result),flush=True)


try:
    OUT.mkdir(exist_ok=True)
    manifest=dict(mode='zone_gaussian',epochs=200,auxiliary_loss_weight=.3,fusion_weight=.3,
                  config=previous.config().to_dict(),seed_per_subject=42,
                  screening=status['stages'],expansion_rule=status['expansion_rule'],
                  sources={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in
                           ['screen_next.py','run_followup.py','zone_gaussian.py','run_residual.py']})
    (OUT/'zone_gaussian-manifest.json').write_text(json.dumps(manifest,indent=2))
    previous.RUN=OUT
    previous.Module=ZoneModule
    save_status()
    for subjects in status['stages']:
        for s in subjects:
            status['current_subject']=s
            save_status()
            previous.run_subject('zone_gaussian',s)
            # Isolate diagnostic RNG; the next subject is independently seeded anyway.
            with torch.random.fork_rng(devices=[0]):
                branch_diagnostics(s)
            status['completed'].append(s)
            r=summarize()['zone_gaussian']
            print('SCREEN_SUMMARY',json.dumps(r),flush=True)
            save_status()
        need=2 if len(status['completed'])==3 else 4
        if r['delta_pp']<1.0 or r['improved']<need:
            status.update(state='stopped_for_low_gain',summary=r)
            break
    else:
        status['state']='expanding'
        save_status()
        for s in range(15):
            if s in status['completed']:
                continue
            status['current_subject']=s
            save_status()
            previous.run_subject('zone_gaussian',s)
            with torch.random.fork_rng(devices=[0]):
                branch_diagnostics(s)
            status['completed'].append(s)
            summarize()
        status.update(state='complete',summary=summarize()['zone_gaussian'])
except Exception as exc:
    status.update(state='failed',error=str(exc))
    raise
finally:
    save_status()
    print('SCREEN_FINISHED',json.dumps(status),flush=True)
