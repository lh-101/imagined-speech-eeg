"""Sequential GPU jobs, durable log and explicit final status."""
import json
import os
import pathlib
import subprocess
import sys
import time

root = pathlib.Path(__file__).resolve().parent
env = dict(os.environ, PYTHONPATH='/root/FAST', PYTHONUNBUFFERED='1', OMP_NUM_THREADS='8', OPENBLAS_NUM_THREADS='8')
jobs = [
    ['ablate_saved.py'],
    ['run_followup.py', '--mode', 'late_sam'],
    ['run_followup.py', '--mode', 'zone_gaussian'],
]
status = {'started': time.time(), 'completed': [], 'state': 'running'}
try:
    for args in jobs:
        status['current'] = args
        (root / 'followup_status.json').write_text(json.dumps(status, indent=2))
        print('JOB_START', args, flush=True)
        subprocess.run([sys.executable, str(root / args[0]), *args[1:]], cwd='/root/FAST', env=env, check=True)
        status['completed'].append(args)
    status['state'] = 'complete'
except Exception as exc:
    status['state'] = 'failed'
    status['error'] = str(exc)
    raise
finally:
    status['updated'] = time.time()
    (root / 'followup_status.json').write_text(json.dumps(status, indent=2))
