import json,pathlib,numpy as np
root=pathlib.Path(__file__).resolve().parent
out=[]
for s in range(15):
    d=np.load(root/'isolated_readout_v3'/f'{s}-predictions.npz')
    source=d['source_pred']==d['y']; new=d['pred']==d['y']; aux=d['aux_pred']==d['y']
    out.append(dict(subject=s,source_wrong=int((~source).sum()),aux_rescues=int((~source & aux).sum()),
                    fused_rescues=int((~source & new).sum()),fused_damages=int((source & ~new).sum())))
diagnostics=[json.loads(p.read_text()) for p in (root/'isolated_readout_v3').glob('*-diagnostics.json')]
r=dict(totals={k:sum(x[k] for x in out) for k in out[0] if k!='subject'},records=out,
       train_aux_mean=float(np.mean([d['train_auxiliary_accuracy'] for d in diagnostics])),
       aux_test_mean=float(np.mean([d['auxiliary_accuracy'] for d in diagnostics])))
(root/'isolated_readout_v3/error_diagnosis.json').write_text(json.dumps(r,indent=2))
print(json.dumps({k:v for k,v in r.items() if k!='records'}))
