"""FAST residual candidates. Preserve published backbone; no external weights.
Bilinear: low-rank multiplicative cross-zone residual on token embeddings.
Spectral: train-fold whitened band covariance, learned low-rank spatial projection,
          matrix-square-root descriptor with separate log-scale and zero-logit fusion.
Inspired by low-rank bilinear pooling, GREEN (2025), and robust SPD EEG work (2026).
This is a task-specific implementation, not a reproduction of those papers.
"""
import torch
from torch import nn
from torch.nn import functional as F
from FAST import FAST

class ResidualFAST(FAST):
    def __init__(self, config, mode='bilinear'):
        super().__init__(config)
        self.mode=mode
        # New parameter initialization must not shift the backbone's RNG stream.
        with torch.random.fork_rng(devices=[]):
            if mode=='bilinear':
                self.cross_norm=nn.LayerNorm(256)
                self.cross_u=nn.Linear(256,16,bias=False)
                self.cross_v=nn.Linear(256,16,bias=False)
                self.cross_out=nn.Linear(16,32,bias=False)
                nn.init.zeros_(self.cross_out.weight)
            elif mode=='spectral':
                self.spatial=nn.Parameter(torch.empty(5,8,64))
                for w in self.spatial: nn.init.orthogonal_(w)
                self.stat_norm=nn.LayerNorm(185)
                self.stat_hidden=nn.Linear(185,32)
                self.stat_out=nn.Linear(32,5,bias=False)
                nn.init.zeros_(self.stat_out.weight)
                self.register_buffer('tri',torch.triu_indices(8,8),persistent=False)
            else: raise ValueError(mode)

    def spectral_descriptor(self,c):
        with torch.autocast(device_type=c.device.type,enabled=False):
            w=F.normalize(self.spatial.float(),dim=-1)
            a=w.unsqueeze(0) @ c.float() @ w.transpose(-1,-2).unsqueeze(0)
            eye=torch.eye(8,device=c.device)
            trace=a.diagonal(dim1=-2,dim2=-1).sum(-1).clamp_min(1e-8)
            a=.95*a+.05*(trace[...,None,None]/8)*eye
            # Trace-normalized Newton-Schulz square root; no eigenvector gradients.
            y=a/trace[...,None,None]; z=eye.expand_as(y)
            for _ in range(6):
                t=.5*(3*eye-z@y);y=y@t;z=t@z
            desc=y[...,self.tri[0],self.tri[1]]
            desc=torch.cat([desc,trace.log().unsqueeze(-1)],dim=-1).flatten(1)
        return desc

    def forward(self,x,cov=None):
        features=self.forward_head(x)
        if self.mode=='bilinear':
            flat=features.flatten(2)
            tokens=self.input_layer(flat)
            norm=self.cross_norm(flat)
            cross=torch.tanh(self.cross_u(norm))*torch.tanh(self.cross_v(norm))
            tokens=tokens+self.cross_out(cross)
            cls=self.cls_token.expand(x.shape[0],-1,-1)
            tokens=torch.cat([cls,tokens],dim=1)+self.pos_embedding[:,:self.n_tokens+1]
            return self.last_layer(self.dropout(self.transformer(tokens)[:,0]))
        logits=self.forward_transformer(features)
        h=F.gelu(self.stat_hidden(self.stat_norm(self.spectral_descriptor(cov))))
        return logits+self.stat_out(h)
