import os
import pathlib
import subprocess
import sys

root=pathlib.Path(__file__).resolve().parent
out=root/'isolated_readout_v3'
out.mkdir(exist_ok=True)
with (out/'train.log').open('a') as log:
    p=subprocess.Popen([sys.executable,'-u',str(root/'run_isolated_readout.py')],cwd='/root/FAST',
                       stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,
                       start_new_session=True,env=dict(os.environ,PYTHONPATH='/root/FAST',
                       PYTHONUNBUFFERED='1',OMP_NUM_THREADS='8',OPENBLAS_NUM_THREADS='8'))
(out/'pid').write_text(str(p.pid))
print('V3_LAUNCHED',p.pid,str(out/'train.log'))
