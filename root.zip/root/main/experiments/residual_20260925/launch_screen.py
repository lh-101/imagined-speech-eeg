import os
import pathlib
import subprocess
import sys

root=pathlib.Path(__file__).resolve().parent
with (root/'next_screen.log').open('a') as log:
    p=subprocess.Popen([sys.executable,'-u',str(root/'screen_next.py')],cwd='/root/FAST',
                       stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,
                       start_new_session=True,env=dict(os.environ,PYTHONPATH='/root/FAST',
                       PYTHONUNBUFFERED='1',OMP_NUM_THREADS='8',OPENBLAS_NUM_THREADS='8'))
(root/'next_screen.pid').write_text(str(p.pid))
print('SCREEN_LAUNCHED',p.pid)
