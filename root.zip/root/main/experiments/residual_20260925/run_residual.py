import argparse,hashlib,json,logging,os,pathlib,time
import h5py,numpy as np,torch
from scipy.linalg import eigh
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score,f1_score,cohen_kappa_score
from torch.utils.data import TensorDataset,DataLoader
import lightning as pl
from transformers import PretrainedConfig
from BCIC2020Track3_train import seed_all,cosine_scheduler
from BCIC2020Track3_preprocess import Electrodes,Zones
from fast_residual import ResidualFAST
logging.getLogger('lightning.pytorch').setLevel(logging.ERROR)
torch.set_num_threads(8)
ROOT=pathlib.Path(__file__).resolve().parent
RUN=ROOT/'results'

def config():
    return PretrainedConfig(electrodes=Electrodes,zone_dict=Zones,dim_cnn=32,dim_token=32,seq_len=800,window_len=250,slide_step=125,head='Conv4Layers',n_classes=5,num_layers=4,num_heads=8,dropout=.1)

def band_cov(x):
    # All operations are per-trial. No labels, fitted transform, or pooled test stats.
    xf=np.fft.rfft(x.astype(np.float64),axis=-1,norm='ortho');freq=np.fft.rfftfreq(x.shape[-1],1/256.)
    out=[]
    for lo,hi in [(1,8),(8,30),(30,50),(50,80),(80,127.0001)]:
        z=xf[:,:,(freq>=lo)&(freq<hi)]
        c=np.einsum('ncf,ndf->ncd',z,z.conj()).real/max(z.shape[-1],1)
        out.append(c.astype(np.float32))
    return np.stack(out,axis=1)

def whiten(c,tr):
    # Fit whitening reference on the outer TRAIN fold only.
    reference=c[tr].astype(np.float64).mean(0); eye=np.eye(64)
    trace=np.trace(reference,axis1=-2,axis2=-1)/64
    reference=.95*reference+.05*trace[:,None,None]*eye
    vals,vecs=np.linalg.eigh(reference)
    w=(vecs*(np.maximum(vals,trace[:,None]*1e-6)**-.5)[:,None,:])@vecs.transpose(0,2,1)
    return (w[None]@c@w.transpose(0,2,1)[None]).astype(np.float32),w

class Module(pl.LightningModule):
    def __init__(self,mode,epochs):
        super().__init__();self.model=ResidualFAST(config(),mode);self.epochs=epochs
        self.schedule=cosine_scheduler(1,.1,epochs,1,warmup_epochs=min(10,epochs-1))
        self.losses=[]
    def training_step(self,batch,batch_idx):
        x,c,y=batch; loss=torch.nn.functional.cross_entropy(self.model(x,c),y)
        if not torch.isfinite(loss):raise RuntimeError('Non-finite training loss')
        self.losses.append(float(loss.detach()))
        return loss
    def configure_optimizers(self):
        opt=torch.optim.AdamW(self.parameters(),lr=.0005)
        sched=torch.optim.lr_scheduler.LambdaLR(opt,lambda epoch:self.schedule[self.global_step-1])
        return [opt],[{'scheduler':sched,'interval':'step'}]

def evaluate(model,loader):
    model.cuda().eval();pred=[];truth=[];prob=[]
    with torch.no_grad():
        for x,c,y in loader:
            logits=model(x.cuda(),c.cuda());p=logits.softmax(-1).cpu().numpy()
            pred.extend(p.argmax(-1));prob.extend(p);truth.extend(y.numpy())
    return np.asarray(pred),np.asarray(truth),np.asarray(prob)

def run_subject(mode,s,epochs=200):
    out=RUN/mode;out.mkdir(parents=True,exist_ok=True)
    final=out/f'{s}-predictions.npz'
    if final.exists():
        d=np.load(final);return float(np.mean(d['pred']==d['y']))
    with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5','r') as f:
        x=f[f'{s+1:02d}/X'][:];y=f[f'{s+1:02d}/Y'][:].astype(np.int64)
    c=band_cov(x) if mode=='spectral' else np.zeros((350,1),np.float32)
    pred=np.full(350,-1);probs=np.zeros((350,5));fold=np.full(350,-1);trainacc=[]
    seed_all(42);start=time.time()
    for fi,(tr,te) in enumerate(KFold(5,shuffle=False).split(x)):
        wc,w=whiten(c,tr) if mode=='spectral' else (c,None)
        train=TensorDataset(torch.from_numpy(x[tr]),torch.from_numpy(wc[tr]),torch.from_numpy(y[tr]))
        test=TensorDataset(torch.from_numpy(x[te]),torch.from_numpy(wc[te]),torch.from_numpy(y[te]))
        train_loader=DataLoader(train,batch_size=len(tr),shuffle=True,num_workers=0,pin_memory=True)
        test_loader=DataLoader(test,batch_size=len(te),shuffle=False,num_workers=0,pin_memory=True)
        # Keep published order/lifetime and single seed per subject.
        module=Module(mode,epochs)
        trainer=pl.Trainer(accelerator='gpu',devices=[0],max_epochs=epochs,callbacks=[],enable_progress_bar=False,enable_checkpointing=False,enable_model_summary=False,precision='bf16-mixed',logger=False)
        trainer.fit(module,train_dataloaders=train_loader)
        p,t,pp=evaluate(module.model,test_loader)
        assert np.array_equal(t,y[te]);pred[te]=p;probs[te]=pp;fold[te]=fi
        # Diagnostic evaluation must not advance RNG for the next fold.
        with torch.random.fork_rng(devices=[0]):
            tp,ty,_=evaluate(module.model,DataLoader(train,batch_size=len(tr),shuffle=False))
            ta=float((tp==ty).mean());trainacc.append(ta)
            torch.save({'state_dict':module.model.state_dict(),'whitener':w,'train_idx':tr,'test_idx':te,'mode':mode,'config':config().to_dict()},out/f'{s}-fold{fi}.pt')
        print(json.dumps({'event':'fold','mode':mode,'subject':s,'fold':fi,'acc':float((p==t).mean()),'train_acc':ta,'loss_first':module.losses[0],'loss_last':module.losses[-1],'seconds':round(time.time()-start,1)}),flush=True)
    assert (pred>=0).all()
    np.savez(final,pred=pred,y=y,prob=probs,fold=fold,train_acc=trainacc)
    acc=float((pred==y).mean()); print(json.dumps({'event':'subject','mode':mode,'subject':s,'acc':acc,'seconds':round(time.time()-start,1)}),flush=True)
    return acc

def summarize():
    result={}
    for mode in ['bilinear','spectral']:
        records=[]
        for f in sorted((RUN/mode).glob('*-predictions.npz')):
            s=int(f.name.split('-')[0]);d=np.load(f)
            b=np.loadtxt(f'/root/FAST/Results/FAST/{s}-Tune.csv',delimiter=',',dtype=int)
            assert np.array_equal(d['y'],b[:,1])
            records.append({'subject':s,'accuracy':float((d['pred']==d['y']).mean()),'stored_baseline':float((b[:,0]==b[:,1]).mean()),'macro_f1':float(f1_score(d['y'],d['pred'],average='macro'))})
        if records:
            mean=np.mean([r['accuracy'] for r in records]);base=np.mean([r['stored_baseline'] for r in records])
            result[mode]={'n_subjects':len(records),'accuracy':float(mean),'vs_paper_pp':float((mean-.548)*100),'vs_same_subject_stored_baseline_pp':float((mean-base)*100),'complete':len(records)==15,'subjects':records}
    (RUN/'summary.json').write_text(json.dumps(result,indent=2))
    return result

def smoke():
    seed_all(42)
    from FAST import FAST
    reference=FAST(config()).cuda().eval()
    x=torch.randn(4,64,800,device='cuda');cov=torch.eye(64,device='cuda').expand(4,5,64,64).clone()
    with torch.no_grad():expected=reference(x)
    for mode in ['bilinear','spectral']:
        seed_all(42);m=ResidualFAST(config(),mode).cuda().eval()
        with torch.no_grad():actual=m(x,cov)
        assert torch.allclose(actual,expected,atol=1e-6,rtol=1e-5),(mode,(actual-expected).abs().max())
        m.train()
        with torch.autocast('cuda',dtype=torch.bfloat16):loss=torch.nn.functional.cross_entropy(m(x,cov),torch.tensor([0,1,2,3],device='cuda'))
        loss.backward();assert all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters())
        print('SMOKE',mode,'params',sum(p.numel() for p in m.parameters()),'init_match',True,'finite_grad',True,flush=True)
    rng=np.random.RandomState(0);xx=rng.randn(6,64,800).astype(np.float32);cc=band_cov(xx);tr=np.arange(4)
    a,w=whiten(cc,tr);cc[4:]*=100;b,v=whiten(cc,tr);assert np.array_equal(w,v);assert np.array_equal(a[:4],b[:4])
    print('TRAIN_ONLY_WHITENING_OK',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');ap.add_argument('--screen',action='store_true');ap.add_argument('--mode',choices=['bilinear','spectral']);ap.add_argument('--subjects',default='0-14');ap.add_argument('--report',action='store_true');args=ap.parse_args();RUN.mkdir(exist_ok=True)
    if args.smoke:smoke()
    elif args.report:print(json.dumps(summarize(),indent=2))
    elif args.screen:
        # Fixed, shared screening subjects; all screening outcomes retained.
        subjects=[0,7,10]
        for mode in ['bilinear','spectral']:
            for s in subjects:run_subject(mode,s);summarize()
        scores={m:np.mean([run_subject(m,s) for s in subjects]) for m in ['bilinear','spectral']}
        winner=max(scores,key=scores.get)
        print(json.dumps({'event':'screen_selection','scores':scores,'selected':winner,'exploratory':True}),flush=True)
        for s in range(15):run_subject(winner,s);summarize()
        print('EXPERIMENT_COMPLETE',json.dumps(summarize()),flush=True)
    else:
        assert args.mode
        subjects=list(range(int(args.subjects.split('-')[0]),int(args.subjects.split('-')[1])+1)) if '-' in args.subjects else list(map(int,args.subjects.split(',')))
        for s in subjects:run_subject(args.mode,s);summarize()
        print('EXPERIMENT_COMPLETE',json.dumps(summarize()),flush=True)

