"""No retraining: evaluate saved spectral checkpoints with/without residual logits."""
import pathlib,json,h5py,numpy as np,torch
from run_residual import config,band_cov,seed_all
from fast_residual import ResidualFAST
root=pathlib.Path(__file__).resolve().parent
folder=root/'results'/'spectral';records=[]
torch.set_num_threads(8)
seed_all(42)
for s in range(15):
    f=folder/f'{s}-predictions.npz'
    if not f.exists():continue
    saved=np.load(f);pred=np.full(350,-1);ablated=np.full(350,-1)
    with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5','r') as h:
        x=h[f'{s+1:02d}/X'][:];y=h[f'{s+1:02d}/Y'][:]
    c=band_cov(x)
    for fi in range(5):
        ck=torch.load(folder/f'{s}-fold{fi}.pt',map_location='cpu',weights_only=False)
        model=ResidualFAST(config(),'spectral');model.load_state_dict(ck['state_dict']);model.cuda().eval()
        te=ck['test_idx'];w=ck['whitener'];wc=(w[None]@c[te]@w.transpose(0,2,1)[None]).astype(np.float32)
        xx=torch.from_numpy(x[te]).cuda();cc=torch.from_numpy(wc).cuda()
        with torch.no_grad():
            pred[te]=model(xx,cc).argmax(-1).cpu().numpy()
            model.stat_out.weight.zero_()
            ablated[te]=model(xx,cc).argmax(-1).cpu().numpy()
        del model,xx,cc,ck
    rec={'subject':s,'full_acc':float((pred==y).mean()),'branch_disabled_acc':float((ablated==y).mean()),'changed_predictions':int((pred!=ablated).sum()),'saved_prediction_mismatches':int((pred!=saved['pred']).sum())}
    records.append(rec);print(json.dumps(rec),flush=True)
result={'note':'Branch-disabled backbone was jointly trained; it is NOT a rerun of baseline. Exploratory post-hoc ablation.','n':len(records),'full_mean':float(np.mean([r['full_acc'] for r in records])),'branch_disabled_mean':float(np.mean([r['branch_disabled_acc'] for r in records])),'records':records}
(root/'results'/'branch_ablation.json').write_text(json.dumps(result,indent=2))
print('ABLATION_COMPLETE',json.dumps(result),flush=True)
