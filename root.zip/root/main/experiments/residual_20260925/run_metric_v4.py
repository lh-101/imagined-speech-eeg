"""V4: FAST with leave-one-out kernel supervision and protected main gradients.

Classical differentiable ridge/gradient projection adapted to FAST; no novelty
claim. LOO excludes a sample from the kernel fit, not from encoder training.
It is a training objective, NOT an unbiased validation estimate.
"""
import argparse,hashlib,json,pathlib,time
import h5py,numpy as np,torch
from torch.nn import functional as F
from sklearn.model_selection import KFold
from FAST import FAST
from run_residual import config,seed_all,cosine_scheduler

ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/'metric_v4'
CFG=dict(epochs=200,ridge=.1,kernel_gamma=2.,aux_weight=.3,aux_gradient_cap=.5,
         correction_bound=1.5,score_scale=4.,lr=.0005,seed=42,subjects=list(range(15)))


def representation(model,x):
    f=model.forward_head(x)
    tokens=model.input_layer(f.flatten(2))
    tokens=torch.cat([model.cls_token.expand(len(x),-1,-1),tokens],1)
    hidden=model.transformer(tokens+model.pos_embedding[:,:model.n_tokens+1])[:,0]
    main=model.last_layer(model.dropout(hidden))
    with torch.autocast('cuda',enabled=False):
        # Equal norm for full regional-window features and CLS; no 32->4 branch.
        regional=F.normalize(torch.asinh(f.float()).flatten(1),dim=-1)
        cls=F.normalize(hidden.float(),dim=-1)
        q=torch.cat([regional,cls],-1)/(2.**.5)
    return main,q


def kernel(a,b):
    # Double precision keeps the small SPD solve stable even under bf16 CNNs.
    return torch.exp(-CFG['kernel_gamma']*(1-a.double()@b.double().T))


def ridge_fit(q,y):
    k=kernel(q,q)
    a=k+CFG['ridge']*torch.eye(len(q),device=q.device,dtype=k.dtype)
    chol=torch.linalg.cholesky(a)
    inverse=torch.cholesky_inverse(chol)
    target=F.one_hot(y,5).to(k.dtype)
    alpha=inverse@target
    loo=target-alpha/inverse.diag()[:,None]
    return alpha,loo.float()


def protect(gmain,gaux,params):
    main=[torch.zeros_like(p) if g is None else g for g,p in zip(gmain,params)]
    aux=[torch.zeros_like(p) if g is None else g for g,p in zip(gaux,params)]
    mm=sum(g.float().square().sum() for g in main)
    dot=sum((a.float()*b.float()).sum() for a,b in zip(main,aux))
    factor=torch.minimum(dot,torch.zeros_like(dot))/mm.clamp_min(1e-20)
    projected=[b-factor*a for a,b in zip(main,aux)]
    aa=sum(b.float().square().sum() for b in projected)
    scale=torch.minimum(torch.ones_like(mm),CFG['aux_gradient_cap']*mm.sqrt()/aa.sqrt().clamp_min(1e-20))
    for p,a,b in zip(params,main,projected):
        p.grad=(a+scale*b).detach()
    return float(dot.detach()),float(scale.detach())


def corrected(main,scores):
    b=CFG['correction_bound']
    centered=scores-scores.mean(-1,keepdim=True)
    return main+b*torch.tanh(CFG['score_scale']*centered/b)


def report():
    rows=[]
    for s in CFG['subjects']:
        path=OUT/f'{s}-predictions.npz'
        if not path.exists():continue
        d=np.load(path);baseline=np.loadtxt(f'/root/FAST/Results/FAST/{s}-Tune.csv',delimiter=',',dtype=int)
        assert np.array_equal(d['y'],baseline[:,1])
        rows.append(dict(subject=s,accuracy=float((d['pred']==d['y']).mean()),
                         primary_accuracy=float((d['primary_pred']==d['y']).mean()),
                         kernel_accuracy=float((d['kernel_pred']==d['y']).mean()),
                         baseline=float((baseline[:,0]==baseline[:,1]).mean())))
    r=dict(n_subjects=len(rows),complete=len(rows)==15,subjects=rows)
    if rows:r.update(accuracy=float(np.mean([r['accuracy'] for r in rows])),
                     delta_baseline_pp=float(np.mean([r['accuracy']-r['baseline'] for r in rows])*100))
    (OUT/'summary.json').write_text(json.dumps(r,indent=2))
    return r


def run_subject(s):
    if (OUT/f'{s}-predictions.npz').exists():return
    with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5','r') as h:
        x=h[f'{s+1:02d}/X'][:];y=h[f'{s+1:02d}/Y'][:].astype(np.int64)
    probability=np.zeros((len(y),5),np.float32)
    primary=np.full(len(y),-1);metric=np.full(len(y),-1);fold=np.full(len(y),-1)
    schedule=cosine_scheduler(1,.1,CFG['epochs'],1,warmup_epochs=10)
    for fi,(tr,te) in enumerate(KFold(5,shuffle=False).split(x)):
        saved=OUT/f'{s}-fold{fi}.npz'
        if saved.exists():
            d=np.load(saved);assert np.array_equal(d['test_idx'],te) and np.array_equal(d['train_idx'],tr)
            probability[te],primary[te],metric[te],fold[te]=d['prob'],d['primary_pred'],d['kernel_pred'],fi
            continue
        seed_all(CFG['seed']+s*5+fi)
        model=FAST(config()).cuda()
        params=list(model.parameters())
        opt=torch.optim.AdamW(params,lr=CFG['lr'])
        xt=torch.from_numpy(x[tr]).cuda();yt=torch.from_numpy(y[tr]).cuda()
        traces=[];start=time.time();conflicts=0
        for epoch in range(CFG['epochs']):
            model.train();opt.zero_grad(set_to_none=True)
            for group in opt.param_groups:group['lr']=CFG['lr']*float(schedule[epoch-1])
            with torch.autocast('cuda',dtype=torch.bfloat16):
                logits,q=representation(model,xt)
                main_loss=F.cross_entropy(logits,yt)
            # Never include test features or labels in this solve.
            _,loo=ridge_fit(q,yt)
            aux_loss=CFG['aux_weight']*F.cross_entropy(CFG['score_scale']*loo,yt)
            if not torch.isfinite(main_loss+aux_loss):raise RuntimeError('Non-finite objective')
            gm=torch.autograd.grad(main_loss,params,retain_graph=True,allow_unused=True)
            ga=torch.autograd.grad(aux_loss,params,allow_unused=True)
            dot,scale=protect(gm,ga,params)
            if not all(p.grad is None or torch.isfinite(p.grad).all() for p in params):
                raise RuntimeError('Non-finite projected gradient')
            opt.step();conflicts+=int(dot<0)
            if epoch==0 or (epoch+1)%50==0:
                row=dict(epoch=epoch+1,main_loss=float(main_loss.detach()),
                         weighted_aux_loss=float(aux_loss.detach()),
                         loo_train_accuracy=float((loo.argmax(-1)==yt).float().mean()),
                         auxiliary_scale=scale)
                traces.append(row)
                print('TRAIN',s,fi,json.dumps(row),flush=True)
        model.eval()
        with torch.no_grad():
            train_main,support=representation(model,xt)
            alpha,train_loo=ridge_fit(support,yt)
            test_main,query=representation(model,torch.from_numpy(x[te]).cuda())
            scores=(kernel(query,support)@alpha).float()
            fused=corrected(test_main,scores)
            pp=fused.softmax(-1).cpu().numpy()
            pm=test_main.argmax(-1).cpu().numpy();km=scores.argmax(-1).cpu().numpy()
        info=dict(subject=s,fold=fi,accuracy=float((pp.argmax(-1)==y[te]).mean()),
                  primary_accuracy=float((pm==y[te]).mean()),kernel_accuracy=float((km==y[te]).mean()),
                  primary_train_accuracy=float((train_main.argmax(-1)==yt).float().mean()),
                  loo_head_train_accuracy=float((train_loo.argmax(-1)==yt).float().mean()),
                  conflict_steps=conflicts,seconds=round(time.time()-start,1),trace=traces)
        torch.save(dict(state_dict=model.cpu().state_dict(),support=support.cpu(),alpha=alpha.cpu(),
                        train_idx=tr,test_idx=te,config=config().to_dict(),settings=CFG),OUT/f'{s}-fold{fi}.pt')
        (OUT/f'{s}-fold{fi}-diagnostics.json').write_text(json.dumps(info,indent=2))
        np.savez(saved,prob=pp,primary_pred=pm,kernel_pred=km,train_idx=tr,test_idx=te,y=y[te])
        probability[te],primary[te],metric[te],fold[te]=pp,pm,km,fi
        print('FOLD',json.dumps(info),flush=True)
        del model,opt,xt,yt,gm,ga,logits,q,main_loss,aux_loss,support,alpha
    assert (fold>=0).all()
    np.savez(OUT/f'{s}-predictions.npz',prob=probability,pred=probability.argmax(-1),
             primary_pred=primary,kernel_pred=metric,y=y,fold=fold)


def smoke():
    seed_all(42)
    q=F.normalize(torch.randn(10,16,device='cuda'),dim=-1).requires_grad_()
    y=torch.arange(10,device='cuda')%5
    alpha,loo=ridge_fit(q,y)
    for i in [0,3]:
        keep=torch.arange(10,device='cuda')!=i
        a,_=ridge_fit(q[keep],y[keep])
        exact=(kernel(q[i:i+1],q[keep])@a).float()[0]
        assert torch.allclose(exact,loo[i],atol=1e-5), 'LOO identity incorrect'
    changed=y.clone();changed[0]=(changed[0]+1)%5
    assert torch.allclose(ridge_fit(q,changed)[1][0],loo[0],atol=1e-5), 'Self-label leakage in head'
    F.cross_entropy(loo*4,y).backward();assert torch.isfinite(q.grad).all()
    p=torch.nn.Parameter(torch.zeros(2,device='cuda'))
    a=torch.tensor([1.,0.],device='cuda');b=torch.tensor([-3.,4.],device='cuda')
    protect([a],[b],[p]);extra=p.grad-a
    assert torch.dot(extra,a)>=-1e-6 and extra.norm()<=CFG['aux_gradient_cap']*a.norm()+1e-6
    model=FAST(config()).cuda();x=torch.randn(10,64,800,device='cuda')
    with torch.autocast('cuda',dtype=torch.bfloat16):
        main,z=representation(model,x);loss=F.cross_entropy(main,y)
    aux=F.cross_entropy(ridge_fit(z,y)[1]*4,y)*.3
    params=list(model.parameters())
    gm=torch.autograd.grad(loss,params,retain_graph=True,allow_unused=True)
    ga=torch.autograd.grad(aux,params,allow_unused=True)
    protect(gm,ga,params)
    assert all(torch.isfinite(p.grad).all() for p in params)
    print('SMOKE_OK exact LOO refits; no self-label in kernel head; finite mixed-precision gradients; conflict removal and norm cap',flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');args=ap.parse_args()
    torch.set_num_threads(8)
    if args.smoke:smoke()
    else:
        OUT.mkdir(exist_ok=True)
        (OUT/'manifest.json').write_text(json.dumps(dict(settings=CFG,config=config().to_dict(),
            code_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
            note='Fresh new-objective training; per-fold seeds differ from historical baseline. Test splits unchanged. Exploratory.'),indent=2))
        status=dict(state='running',started=time.time(),completed=[])
        try:
            for s in CFG['subjects']:
                status['current_subject']=s
                (OUT/'status.json').write_text(json.dumps(status,indent=2))
                run_subject(s);status['completed'].append(s)
                print('SUMMARY',json.dumps(report()),flush=True)
            status['state']='complete'
        except Exception as e:status.update(state='failed',error=str(e));raise
        finally:
            status['updated']=time.time();(OUT/'status.json').write_text(json.dumps(status,indent=2))
