"""Read-only weight/prediction diagnostics for the stopped SAM run."""
import json
import pathlib
import numpy as np
import torch

root = pathlib.Path(__file__).resolve().parent
records = []
torch.set_num_threads(4)
for file in sorted((root/'followup_results/late_sam').glob('*-fold*.pt')):
    name = file.name
    old = torch.load(root/'results/spectral'/name, map_location='cpu', weights_only=False)['state_dict']
    new = torch.load(file, map_location='cpu', weights_only=False)['state_dict']
    groups = {}
    for key, value in old.items():
        if not value.is_floating_point():
            continue
        group = 'regional_encoder' if key.startswith('head.') else 'spectral_branch' if key.startswith(('stat_', 'spatial')) else 'transformer_readout'
        row = groups.setdefault(group, [0., 0.])
        row[0] += float((new[key].double()-value.double()).square().sum())
        row[1] += float(value.double().square().sum())
    d = np.load(file.with_suffix('.npz'))
    losses = d['losses']
    records.append(dict(file=name, relative_weight_change={k:float(np.sqrt(a/max(b,1e-20))) for k,(a,b) in groups.items()},
                        first_clean=float(losses[0,0]), first_perturbed=float(losses[0,1]),
                        last_clean=float(losses[-1,0]), last_perturbed=float(losses[-1,1])))
summary = dict(n_folds=len(records),
               median_weight_change={k:float(np.median([r['relative_weight_change'][k] for r in records])) for k in records[0]['relative_weight_change']},
               median_losses={k:float(np.median([r[k] for r in records])) for k in ['first_clean','first_perturbed','last_clean','last_perturbed']},
               note='Weight changes and training losses are descriptive, not causal attribution.', records=records)
(root/'followup_results/sam_diagnosis.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='records'},indent=2))
