"""Region-preserving first/second-order head inspired by RHOP (ICLR 2026).

This is a small FAST-specific adaptation, NOT the full quotient-Gaussian RHOP.
It bypasses the 256 -> 32 bottleneck using learned regional features, while
retaining the existing CLS path. Auxiliary supervision prevents a zero-gated
branch from depending entirely on the already-confident main classifier.
"""
import torch
from torch import nn
from torch.nn import functional as F
from FAST import FAST


def sqrt_spd(a):
    eye = torch.eye(a.shape[-1], device=a.device, dtype=a.dtype)
    trace = a.diagonal(dim1=-2, dim2=-1).sum(-1).clamp_min(1e-8)
    y = a / trace[..., None, None]
    z = eye.expand_as(y)
    for _ in range(6):
        t = 0.5 * (3 * eye - z @ y)
        y, z = y @ t, t @ z
    return y, trace


class ZoneGaussianFAST(FAST):
    def __init__(self, config):
        super().__init__(config)
        with torch.random.fork_rng(devices=[]):
            self.stat_projection = nn.Linear(32, 4, bias=False)
            nn.init.orthogonal_(self.stat_projection.weight)
            self.stat_norm = nn.LayerNorm(120)
            self.stat_classifier = nn.Linear(120, 5)
            nn.init.normal_(self.stat_classifier.weight, std=0.01)
            nn.init.zeros_(self.stat_classifier.bias)
        self.register_buffer('tri', torch.triu_indices(4, 4), persistent=False)

    def descriptor(self, features):
        with torch.autocast(device_type=features.device.type, enabled=False):
            # B, windows, regions, learned features. Preserve region identities.
            z = F.linear(torch.asinh(features.float()), self.stat_projection.weight.float())
            z = z.transpose(1, 2)
            mean = z.mean(-2)
            centered = z - mean.unsqueeze(-2)
            cov = centered.transpose(-1, -2) @ centered / max(z.shape[-2] - 1, 1)
            scale = cov.diagonal(dim1=-2, dim2=-1).mean(-1).clamp_min(1e-6)
            eye = torch.eye(4, device=z.device)
            cov = 0.9 * cov + 0.1 * scale[..., None, None] * eye
            root, trace = sqrt_spd(cov)
            upper = root[..., self.tri[0], self.tri[1]]
            weight = torch.where(self.tri[0] == self.tri[1], 1., 2.**0.5)
            return torch.cat([mean, upper * weight, trace.log().unsqueeze(-1)], -1).flatten(1)

    def forward(self, x, cov=None, return_parts=False):
        features = self.forward_head(x)
        main = self.forward_transformer(features)
        auxiliary = self.stat_classifier(self.stat_norm(self.descriptor(features)))
        fused = main + 0.3 * auxiliary
        return (fused, main, auxiliary) if return_parts else fused
