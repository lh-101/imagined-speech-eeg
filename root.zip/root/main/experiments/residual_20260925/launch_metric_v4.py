import pathlib,subprocess,sys,os
root=pathlib.Path(__file__).resolve().parent
out=root/'metric_v4';out.mkdir(exist_ok=True)
with (out/'train.log').open('a') as f:
    p=subprocess.Popen([sys.executable,'-u',str(root/'run_metric_v4.py')],cwd='/root/FAST',
        stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True,
        env=dict(os.environ,PYTHONPATH='/root/FAST',PYTHONUNBUFFERED='1',OMP_NUM_THREADS='8',OPENBLAS_NUM_THREADS='8'))
(out/'pid').write_text(str(p.pid))
print('V4_LAUNCHED',p.pid,str(out/'train.log'))
