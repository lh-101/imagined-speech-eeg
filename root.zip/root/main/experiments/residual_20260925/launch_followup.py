import os
import pathlib
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent
with (root / 'followup.log').open('a') as log:
    p = subprocess.Popen([sys.executable, '-u', str(root/'queue_followup.py')],
                         cwd='/root/FAST', stdout=log, stderr=subprocess.STDOUT,
                         stdin=subprocess.DEVNULL, start_new_session=True,
                         env=dict(os.environ, PYTHONPATH='/root/FAST', PYTHONUNBUFFERED='1',
                                  OPENBLAS_NUM_THREADS='8', OMP_NUM_THREADS='8'))
(root/'followup.pid').write_text(str(p.pid))
print('LAUNCHED', p.pid, str(root/'followup.log'))
