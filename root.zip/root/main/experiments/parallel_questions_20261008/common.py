import os
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[key]='2'
import sys,json,time
from pathlib import Path
sys.path[:0]=['/root/FAST/experiments/adapter_specificity_20261006','/root/FAST/experiments/compression_source_20261006','/root/FAST/experiments/parallel_principles_20261007/temporal','/root/FAST/experiments/design_value_20261007']
import numpy as np,torch
from torch.nn import functional as F
import run_specificity as ref
import run_temporal as temporal
import run_study as old
ROOT=Path(__file__).resolve().parent
CASES=[('main',0,0),('main',7,0),('external',1,0),('external',4,0)]

def save(path,value):
 path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2));tmp.replace(path)

def build(kind,s,f):
 ref.main_ref.v4.seed_all(ref.seed(kind,s,f))
 if kind=='main':return ref.main_ref.v4.FAST(ref.main_ref.v4.config()).cuda()
 return ref.external_ref.build(json.loads((ref.external_ref.ROOT/'geometry.json').read_text()))

def normalize(kind,x,tr):
 if kind=='main':return x
 mu=x[tr].mean((0,2),keepdims=True,dtype=np.float64).astype(np.float32)
 sd=np.maximum(x[tr].std((0,2),keepdims=True,dtype=np.float64).astype(np.float32),1e-6)
 return ((x-mu)/sd).astype(np.float32)

def auxiliary(q,y,method,classes):
 k=torch.exp(-2*(1-q.double()@q.double().T));target=F.one_hot(y,classes).to(k.dtype)
 if method=='loo':
  inverse=torch.cholesky_inverse(torch.linalg.cholesky(k+.1*torch.eye(len(y),device=q.device,dtype=k.dtype)))
  score=(target-(inverse@target)/inverse.diag()[:,None]).float()
  return .3*F.cross_entropy(4*score,y)
 # Both comparators explicitly exclude self support, exactly as LOO fit does.
 weights=k*(1-torch.eye(len(y),device=q.device,dtype=k.dtype))
 probability=(weights@target)/weights.sum(1,keepdim=True).clamp_min(1e-12)
 if method=='similarity_nll':return -.3*probability[torch.arange(len(y),device=y.device),y].clamp_min(1e-12).log().mean()
 if method=='similarity_scaled':return .3*F.cross_entropy(4*probability.float(),y)
 raise ValueError(method)

def fit_base(kind,s,f,x,y,tr,method,steps=200):
 model=build(kind,s,f).train().requires_grad_(True);xx=normalize(kind,x,tr)
 xt=torch.from_numpy(xx[tr]).cuda();yt=torch.from_numpy(y[tr]).cuda()
 optimizer=torch.optim.AdamW(model.parameters(),lr=.0005)
 schedule=ref.main_ref.v4.cosine_scheduler(1,.1,steps,1,warmup_epochs=min(10,steps//5))
 trace=[]
 for step in range(steps):
  model.train();optimizer.zero_grad(set_to_none=True)
  for g in optimizer.param_groups:g['lr']=.0005*float(schedule[step-1])
  with torch.autocast('cuda',dtype=torch.bfloat16):logits,q=ref.main_ref.v4.representation(model,xt);ce=F.cross_entropy(logits,yt)
  aux=auxiliary(q,yt,method,len(np.unique(y))) if method!='ce' else ce*0
  loss=ce+aux;assert torch.isfinite(loss);loss.backward()
  assert all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters());optimizer.step()
  if step in (0,steps-1):trace.append(dict(step=step+1,ce=float(ce.detach()),aux=float(aux.detach())))
 model.eval().requires_grad_(False)
 for p in model.parameters():p.grad=None
 return model,xx,trace

@torch.no_grad()
def predict_base(model,x):
 with torch.autocast('cuda',dtype=torch.bfloat16):logits,_=ref.main_ref.v4.representation(model,torch.from_numpy(x).cuda())
 return logits.float().softmax(1).cpu().numpy()

def pipeline(kind,s,f,x,y,tr,te,steps=200):
 base,xx,_=fit_base(kind,s,f,x,y,tr,'loo',steps)
 with torch.no_grad():
  if kind=='external':train=ref.external_ref.cache(base,xx[tr]);test=ref.external_ref.cache(base,xx[te])
  else:train=base.forward_head(torch.from_numpy(xx[tr]).cuda()).detach();test=base.forward_head(torch.from_numpy(xx[te]).cuda()).detach()
 yt=torch.from_numpy(y[tr]).cuda();seed=ref.seed(kind,s,f)
 reference=ref.initialize(kind,train,torch.zeros_like(train))
 ref.main_ref.v4.seed_all(seed+10000);generic=ref.GenericAdapter(reference).cuda();del reference
 def fit(adapter,correction=False):
  params=[p for p in adapter.parameters() if p.requires_grad];opt=torch.optim.AdamW(params,lr=.001,weight_decay=.01)
  for step in range(steps):
   for g in opt.param_groups:g['lr']=.001*(.1+.9*.5*(1+np.cos(np.pi*step/max(steps-1,1))))
   opt.zero_grad(set_to_none=True);logits,q,_,d=ref.rep(kind,base,adapter,train,torch.zeros_like(train))
   if correction:
    with torch.no_grad():previous=generic(train,torch.zeros_like(train))[0]
    d=d-previous
   loss=F.cross_entropy(logits,yt)+auxiliary(q,yt,'loo',len(np.unique(y)))+.01*d.square().mean()
   assert torch.isfinite(loss);loss.backward();assert all(p.grad is None or torch.isfinite(p.grad).all() for p in params);opt.step()
 fit(generic);generic.eval().requires_grad_(False)
 for p in generic.parameters():p.grad=None
 with torch.no_grad():pold=ref.rep(kind,base,generic,test,torch.zeros_like(test))[0].float().softmax(1).cpu().numpy()
 ref.main_ref.v4.seed_all(seed+20000);adapter=temporal.Temporal(generic,'multiscale').cuda();fit(adapter,True)
 with torch.no_grad():pnew=ref.rep(kind,base,adapter,test,torch.zeros_like(test))[0].float().softmax(1).cpu().numpy()
 del base,train,test,generic,adapter;torch.cuda.empty_cache()
 return pold,pnew
