from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import subprocess,json,time,sys
ROOT=Path(__file__).resolve().parent
def save(value):
 p=ROOT/'queue_status.json';t=p.with_suffix('.tmp');t.write_text(json.dumps(value,indent=2));t.replace(p)
def run(route,smoke=False):
 folder=ROOT/(route+('_smoke' if smoke else ''))
 status=folder/'status.json'
 if status.exists():
  assert json.loads(status.read_text())['state']=='complete','Prior route not complete'
  return route
 command=['/root/venv_fast/bin/python','-u',str(ROOT/'run_validation.py'),route]
 if smoke:command.append('--smoke')
 with (ROOT/(route+('_smoke' if smoke else '')+'.log')).open('ab') as log:
  p=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,cwd=ROOT)
  rc=p.wait()
 assert rc==0,(route,rc)
 return route
start=time.time()
try:
 save(dict(state='smoke',started=time.time()))
 for route in ('supervision','correction','readout'):run(route,True)
 save(dict(state='running',smoke_passed=True,completed_routes=[],max_parallel_gpu_processes=2))
 completed=[]
 with ThreadPoolExecutor(max_workers=2) as pool:
  futures=[pool.submit(run,route) for route in ('correction','supervision','readout')]
  for future in as_completed(futures):
   completed.append(future.result());save(dict(state='running',smoke_passed=True,completed_routes=completed,max_parallel_gpu_processes=2,elapsed_seconds=time.time()-start))
 save(dict(state='complete',completed_routes=completed,elapsed_seconds=time.time()-start))
except BaseException as e:
 save(dict(state='failed',error=repr(e),elapsed_seconds=time.time()-start));raise
