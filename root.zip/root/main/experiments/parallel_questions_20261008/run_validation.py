import argparse,time,json,traceback
from pathlib import Path
import common as c
import numpy as np,torch
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
ROOT=c.ROOT

def meta(a,b):
 def part(p):
  ordered=np.sort(p,axis=1)
  return np.column_stack([ordered[:,-1],ordered[:,-1]-ordered[:,-2],-(p*np.log(np.maximum(p,1e-9))).sum(1)])
 return np.concatenate([part(a),part(b),b-a,(a.argmax(1)!=b.argmax(1))[:,None]],1)

def correction(out,steps):
 import run_budget_factorial as budgets
 rows=[]
 for i,(kind,s,f) in enumerate(c.CASES):
  x,y=c.ref.dataset(kind,s);outer,te=list(c.ref.splits(kind,x,y))[f]
  train=budgets.subsets(outer,y,c.ref.seed(kind,s,f)+7000)[.5]
  dest=out/(kind+'_'+str(s));dest.mkdir(exist_ok=True)
  original=np.zeros((len(train),len(np.unique(y))));modified=np.zeros_like(original)
  inner=StratifiedKFold(3,shuffle=True,random_state=20261008)
  for j,(fit,validate) in enumerate(inner.split(train,y[train])):
   tr=train[fit];va=train[validate];assert not np.intersect1d(tr,va).size and not np.intersect1d(tr,te).size
   path=dest/f'inner{j}.npz'
   if path.exists():
    with np.load(path) as z:assert np.array_equal(z['train'],tr) and np.array_equal(z['validation'],va);a=z['original'];b=z['modified']
   else:
    a,b=c.pipeline(kind,s,f,x,y,tr,va,steps);np.savez_compressed(path,original=a,modified=b,train=tr,validation=va,y=y[va])
   original[validate]=a;modified[validate]=b
   c.save(out/'status.json',dict(state='running',completed_cases=i,total_cases=4,current_inner_fold=j+1))
  feature=meta(original,modified);scaler=StandardScaler().fit(feature)
  reward=(modified.argmax(1)==y[train]).astype(float)-(original.argmax(1)==y[train]).astype(float)
  gate=Ridge(alpha=10.).fit(scaler.transform(feature),reward)
  alphas=[0,.25,.5,.75,1.]
  scores=[float((((1-a)*original+a*modified).argmax(1)==y[train]).mean()) for a in alphas]
  alpha=alphas[int(np.argmax(scores))]
  threshold=[0,.1,.2,.4,1.]
  margin=np.sort(original,axis=1)[:,-1]-np.sort(original,axis=1)[:,-2]
  accuracies=[float((np.where((margin<t)[:,None],modified,original).argmax(1)==y[train]).mean()) for t in threshold]
  cutoff=threshold[int(np.argmax(accuracies))]
  # Outer final models are exactly the earlier matched recipe; reused only here.
  candidates=[Path('/root/FAST/experiments/design_value_20261007')/f'full50_worker{w}'/kind/f'sub{s}_fold{f}_budget50' for w in (0,1)]
  saved=next(p for p in candidates if (p/'complete.json').exists())
  with np.load(saved/'loo_generic.npz') as z:assert np.array_equal(z['train_idx'],train) and np.array_equal(z['test_idx'],te);a=z['prob'];assert np.array_equal(z['y'],y[te])
  with np.load(saved/'loo_multiscale.npz') as z:assert np.array_equal(z['train_idx'],train);b=z['prob']
  prediction=gate.predict(scaler.transform(meta(a,b)));decision=prediction>0
  margin=np.sort(a,axis=1)[:,-1]-np.sort(a,axis=1)[:,-2]
  arms={'original':a,'always_correct':b,'static_scale':(1-alpha)*a+alpha*b,
   'confidence_threshold':np.where((margin<cutoff)[:,None],b,a),'learned_acceptance':np.where(decision[:,None],b,a)}
  row=dict(dataset=kind,subject=s,fold=f,alpha=alpha,confidence_cutoff=cutoff,acceptance_fraction=float(decision.mean()),
   accuracy={k:float((p.argmax(1)==y[te]).mean()) for k,p in arms.items()},inner_reward_counts={str(v):int((reward==v).sum()) for v in (-1,0,1)})
  rows.append(row);np.savez_compressed(dest/'outer_predictions.npz',y=y[te],train=train,test=te,**{k:p.argmax(1) for k,p in arms.items()})
  c.save(out/'summary.json',dict(complete=i==3,rows=rows,limits='Fixed 2 people per dataset, 1 outer fold. Strict inner-pipeline fits exclude validation labels. Inner small-label source and outer refit differ; no guarantee calibration transfers. Pilot, no unique network claim.'))
  c.save(out/'status.json',dict(state='running',completed_cases=i+1,total_cases=4))

def supervision(out,steps):
 rows=[]
 for i,(kind,s,f) in enumerate(c.CASES):
  x,y=c.ref.dataset(kind,s);tr,te=list(c.ref.splits(kind,x,y))[f]
  for method in ('ce','loo','similarity_nll','similarity_scaled'):
   model,xx,trace=c.fit_base(kind,s,f,x,y,tr,method,steps);prob=c.predict_base(model,xx[te])
   rows.append(dict(dataset=kind,subject=s,fold=f,method=method,accuracy=float((prob.argmax(1)==y[te]).mean()),trace=trace))
   np.savez_compressed(out/f'{kind}_{s}_{method}.npz',prob=prob,y=y[te],train=tr,test=te)
   del model;torch.cuda.empty_cache();c.save(out/'status.json',dict(state='running',completed_fits=len(rows),total_fits=16))
  c.save(out/'summary.json',dict(complete=i==3,rows=rows,limits='Pilot fixed 2 people per dataset, one fold, fixed auxiliary .3. Loss scales differ; shared coefficient not matched gradients. No claims of reproducing full DWAC or uniqueness.'))

def readout(out,steps):
 # Fixed tokens already contain full-label source information. No backbone fits.
 from sklearn.linear_model import LogisticRegression
 from sklearn.metrics import f1_score
 rows=[]
 for kind in ('main','external'):
  for s in c.ref.subjects(kind):
   for f in range(5):
    name=c.ref.name(kind,s,f)
    with np.load(c.old.OUT/'feature_cache'/kind/'loo'/(name+'.npz')) as z:r=z['regional'];tr=z['train_idx'];te=z['test_idx'];y=z['y']
    base=c.build(kind,s,f);ck=torch.load(c.old.source_path(kind,'loo',s,f),map_location='cpu');base.load_state_dict(ck['state_dict']);base.eval().requires_grad_(False)
    full=torch.from_numpy(r.reshape(len(r),r.shape[1],8,32)).cuda()
    if kind=='external':full=full.to(torch.bfloat16)
    init=c.ref.initialize(kind,full[tr],torch.zeros_like(full[tr]));adapter=c.ref.GenericAdapter(init).cuda()
    path=c.ref.OUT/kind/'generic_adapter'/(name+'.pt');adapter.load_state_dict(torch.load(path,map_location='cpu')['state_dict']);adapter.eval().requires_grad_(False)
    cls=np.empty((len(r),32),np.float32);token=np.empty((len(r),r.shape[1],32),np.float32)
    with torch.no_grad():
     for ix in (tr,te):
      ft=full[ix];d=adapter(ft,torch.zeros_like(ft))[0]
      with torch.autocast('cuda',dtype=torch.bfloat16,enabled=kind=='external'):
       t=base.input_layer(ft.flatten(2))+d;sequence=torch.cat([base.cls_token.expand(len(ix),-1,-1),t],1);h=base.transformer(sequence+base.pos_embedding[:,:base.n_tokens+1])[:,0];logit=base.last_layer(h)
      cls[ix]=h.float().cpu().numpy();token[ix]=t.float().cpu().numpy()
      if np.array_equal(ix,te):p=logit.float().softmax(1).cpu().numpy()
    with np.load(path.with_suffix('.npz')) as z:assert np.max(np.abs(z['prob']-p))<1e-6;source=z['prob'].argmax(1)
    # Matched 32->64->K heads: CLS versus simple window mean; no extra features.
    views={'cls':cls,'mean_token':token.mean(1)}
    preds={'saved_network':source}
    for label,a in views.items():
     scaler=StandardScaler().fit(a[tr]);a=scaler.transform(a).astype(np.float32)
     c.ref.main_ref.v4.seed_all(c.ref.seed(kind,s,f)+30000)
     head=torch.nn.Sequential(torch.nn.Linear(32,64),torch.nn.GELU(),torch.nn.Linear(64,len(np.unique(y)))).cuda()
     tx=torch.from_numpy(a[tr]).cuda();yt=torch.from_numpy(y[tr]).cuda();opt=torch.optim.AdamW(head.parameters(),lr=.001,weight_decay=.01)
     for step in range(steps):
      opt.zero_grad(set_to_none=True);loss=torch.nn.functional.cross_entropy(head(tx),yt);assert torch.isfinite(loss);loss.backward();opt.step()
     with torch.no_grad():preds[label+'_mlp']=head(torch.from_numpy(a[te]).cuda()).argmax(1).cpu().numpy()
     linear=LogisticRegression(C=1,max_iter=2000,random_state=42).fit(a[tr],y[tr]);preds[label+'_linear']=linear.predict(a[te])
     del head,opt,tx,yt
    np.savez_compressed(out/(kind+'_'+name+'.npz'),y=y[te],train=tr,test=te,**preds)
    rows.append(dict(dataset=kind,subject=s,fold=f,accuracy={k:float(np.mean(v==y[te])) for k,v in preds.items()}));del base,adapter,init,full;torch.cuda.empty_cache()
    c.save(out/'status.json',dict(state='running',completed_folds=len(rows),total_folds=105))
 c.save(out/'summary.json',dict(complete=True,rows=rows,limits='Matched32-dimensional heads, CLS and token mean. Mean pooling may discard useful window position; failed mean is not proof CLS optimal. Fixed 200 steps, source train/test folds repeatedly explored.'))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('route',choices=('correction','supervision','readout'));ap.add_argument('--smoke',action='store_true');args=ap.parse_args()
 torch.set_num_threads(2);out=ROOT/(args.route+('_smoke' if args.smoke else ''));out.mkdir(exist_ok=True)
 if (out/'status.json').exists():raise RuntimeError('Preserve previous run')
 start=time.time();steps=3 if args.smoke else 200
 c.save(out/'protocol.json',dict(route=args.route,steps=steps,cases=c.CASES,source_sha256=c.old.sha(Path(__file__)),common_sha256=c.old.sha(Path(c.__file__))))
 try:
  {'correction':correction,'supervision':supervision,'readout':readout}[args.route](out,steps)
  c.save(out/'status.json',dict(state='complete',elapsed_seconds=time.time()-start))
 except BaseException:
  c.save(out/'status.json',dict(state='failed',error=traceback.format_exc(),elapsed_seconds=time.time()-start));raise
if __name__=='__main__':main()
