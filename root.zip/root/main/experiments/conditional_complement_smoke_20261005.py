"""Behavioral checks for conditioning, complement separation, and zero correction."""
import sys,json
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments')
import torch
from torch.nn import functional as F
import conditional_complement_pilot_20261005 as run
torch.set_num_threads(2);torch.manual_seed(721)
x=torch.randn(3,5,8,32)
w=torch.randn(32,256)/16;b=torch.randn(32)
a=run.Adapter(x,torch.zeros_like(x),'conditional_complement',w,b)
assert sum(p.numel() for p in a.parameters())==9377
assert torch.equal(a.token_context(x).squeeze(2),F.gelu(F.linear(x.flatten(2),w,b)))
delta,gate=a(x,torch.zeros_like(x))
assert torch.equal(delta,torch.zeros_like(delta))
# Change retained coordinates only: complement unchanged, conditional gate changes.
shift=torch.ones(3,5,32)@a.basis.T
altered=x+shift.reshape_as(x)
relative=float((a.complement(altered)-a.complement(x)).norm()/a.complement(x).norm())
assert relative<2e-6
_,changed=a(altered,torch.zeros_like(x))
gate_change=float((changed-gate).abs().max())
assert gate_change>1e-5
result={'passed':True,'parameters':9377,'zero_correction':True,'token_context_matches_original':True,
        'complement_change_under_rowspace_shift_relative':relative,'gate_change_under_rowspace_shift_max':gate_change,
        'interpretation':'Synthetic behavioral check only; not proof of performance or mechanism in EEG.'}
path=Path('/root/FAST/experiments/conditional_complement_pilot_20261005/smoke.json')
path.write_text(json.dumps(result,indent=2))
print(json.dumps(result))
