import os
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[key]='2'
import sys,time,json,math,argparse,traceback
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/parallel_questions_20261008')
import common as c
import numpy as np,torch
from torch.nn import functional as F
ROOT=Path(__file__).resolve().parent
ARMS=('continued_cls','mean','concat','evidence')

def representation(base,adapter,x,arm,local):
 full=base.forward_head(x)
 # Adapter remains float32 and its inherited training-only normalization is fixed.
 with torch.autocast('cuda',enabled=False):delta=adapter(full.float(),torch.zeros_like(full.float()))[0]
 token=base.input_layer(full.flatten(2))+delta
 seq=torch.cat([base.cls_token.expand(len(x),-1,-1),token],1)
 h=base.transformer(seq+base.pos_embedding[:,:base.n_tokens+1])[:,0]
 if arm=='mean':logits=base.last_layer(base.dropout(token.mean(1)))
 else:
  logits=base.last_layer(base.dropout(h))
  if arm in ('concat','evidence'):
   e=local(F.layer_norm(token,(32,)))
   logits=logits+(e.mean(1) if arm=='concat' else torch.logsumexp(e,1)-math.log(token.shape[1]))
 q=torch.cat([F.normalize(torch.asinh(full.float()).flatten(1),dim=-1),F.normalize(h.float(),dim=-1)],-1)/2**.5
 return logits,q

def run(smoke):
 torch.set_num_threads(2);out=ROOT/('smoke' if smoke else 'formal');out.mkdir(exist_ok=True)
 start=time.time();steps=2 if smoke else 50;total=(2 if smoke else 105)*4
 assert not (out/'status.json').exists(),'Preserve previous run'
 c.save(out/'protocol.json',dict(steps=steps,total_fits=total,arms=ARMS,source_sha256=c.old.sha(Path(__file__)),lr_base=.0001,lr_adapter=.0001,lr_new_local=.001,weight_decay=.01,objective='CE + existing .3 CE(4*LOO)',all_backbone_parameters_trainable=True,primary='evidence vs concat matched linear branches',scope='Warm-start end-to-end finetuning; not training from scratch, novel principle or independent confirmation. No test-based selection or tuning.'))
 rows=[]
 try:
  for kind in ('main','external'):
   for s in (c.ref.subjects(kind)[:1] if smoke else c.ref.subjects(kind)):
    x,y=c.ref.dataset(kind,s)
    for f,(tr,te) in enumerate(c.ref.splits(kind,x,y)):
     if smoke and f:break
     assert not np.intersect1d(tr,te).size
     name=c.ref.name(kind,s,f);xx=c.normalize(kind,x,tr);xt=torch.from_numpy(xx[tr]).cuda();yt=torch.from_numpy(y[tr]).cuda();xte=torch.from_numpy(xx[te]).cuda()
     source=c.old.source_path(kind,'loo',s,f);adapter_path=c.ref.OUT/kind/'generic_adapter'/(name+'.pt')
     sourceck=torch.load(source,map_location='cpu');adapterck=torch.load(adapter_path,map_location='cpu')
     with np.load(adapter_path.with_suffix('.npz')) as z:
      assert np.array_equal(z['train_idx'],tr) and np.array_equal(z['test_idx'],te) and np.array_equal(z['y'],y[te]);saved=z['prob'].copy()
     for arm in ARMS:
      t0=time.time();c.ref.main_ref.v4.seed_all(c.ref.seed(kind,s,f)+50000)
      base=c.build(kind,s,f);base.load_state_dict(sourceck['state_dict']);base.eval()
      with np.load(c.old.OUT/'feature_cache'/kind/'loo'/(name+'.npz')) as z:r=z['regional'];assert np.array_equal(z['train_idx'],tr)
      trainfeatures=torch.from_numpy(r[tr].reshape(len(tr),r.shape[1],8,32)).cuda();init=c.ref.initialize(kind,trainfeatures,torch.zeros_like(trainfeatures));adapter=c.ref.GenericAdapter(init).cuda();adapter.load_state_dict(adapterck['state_dict']);del trainfeatures,init,r
      local=torch.nn.Linear(32,len(np.unique(y)),bias=False).cuda();torch.nn.init.zeros_(local.weight)
      base.requires_grad_(True);adapter.requires_grad_(True)
      with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16,enabled=kind=='external'):
       pp=representation(base,adapter,xte,'continued_cls',local)[0].float().softmax(1).cpu().numpy()
       if arm in ('concat','evidence'):initial=representation(base,adapter,xte,arm,local)[0].float().softmax(1).cpu().numpy();assert np.max(np.abs(initial-pp))<1e-6
      error=float(np.max(np.abs(pp-saved)));assert error<1e-6,f'Source replay mismatch {kind} {s} {f}: {error}'
      groups=[{'params':base.parameters(),'lr':.0001},{'params':adapter.parameters(),'lr':.0001}]
      if arm in ('concat','evidence'):groups.append({'params':local.parameters(),'lr':.001})
      opt=torch.optim.AdamW(groups,weight_decay=.01);trace=[];c.ref.main_ref.v4.seed_all(c.ref.seed(kind,s,f)+60000)
      before=next(base.head.parameters()).detach().clone()
      for step in range(steps):
       base.train();adapter.train();opt.zero_grad(set_to_none=True)
       for i,g in enumerate(opt.param_groups):g['lr']=(.001 if i==2 else .0001)*(.1+.9*.5*(1+math.cos(math.pi*step/max(steps-1,1))))
       with torch.autocast('cuda',dtype=torch.bfloat16):logits,q=representation(base,adapter,xt,arm,local);ce=F.cross_entropy(logits,yt)
       aux=c.auxiliary(q,yt,'loo',len(np.unique(y)));loss=ce+aux
       assert torch.isfinite(loss);loss.backward();params=[p for g in opt.param_groups for p in g['params']];assert all(p.grad is None or torch.isfinite(p.grad).all() for p in params)
       if step==0:assert any(p.grad is not None and p.grad.abs().max()>0 for p in base.head.parameters()),'CNN gradient absent'
       opt.step()
       if step in (0,steps-1):trace.append(dict(step=step+1,ce=float(ce.detach()),aux=float(aux.detach())))
      update=float((next(base.head.parameters()).detach()-before).abs().max());assert update>0,'CNN not updated'
      base.eval();adapter.eval()
      with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):prob=representation(base,adapter,xte,arm,local)[0].float().softmax(1).cpu().numpy()
      pred=prob.argmax(1);dest=out/kind/arm;dest.mkdir(parents=True,exist_ok=True)
      np.savez_compressed(dest/(name+'.npz'),prob=prob,y=y[te],train=tr,test=te,source_prob=saved)
      torch.save(dict(base=base.cpu().state_dict(),adapter=adapter.cpu().state_dict(),local=local.cpu().state_dict(),arm=arm,train=tr,test=te,source=str(source),normalization='training-only common.normalize'),dest/(name+'.pt'))
      row=dict(dataset=kind,subject=s,fold=f,arm=arm,accuracy=float((pred==y[te]).mean()),source_accuracy=float((saved.argmax(1)==y[te]).mean()),seconds=time.time()-t0,trace=trace,cnn_max_update=update,replay_max_error=error,parameters=sum(p.numel() for p in params))
      rows.append(row);del base,adapter,local,opt,params,before;torch.cuda.empty_cache();elapsed=time.time()-start
      c.save(out/'summary.json',dict(complete=len(rows)==total,rows=rows))
      c.save(out/'status.json',dict(state='running',completed_fits=len(rows),total_fits=total,elapsed_seconds=elapsed,eta_seconds=elapsed/len(rows)*(total-len(rows)),current=dict(dataset=kind,subject=s,fold=f,arm=arm)))
     del xt,yt,xte
  c.save(out/'status.json',dict(state='complete',completed_fits=len(rows),elapsed_seconds=time.time()-start))
 except BaseException:
  c.save(out/'status.json',dict(state='failed',error=traceback.format_exc(),elapsed_seconds=time.time()-start));raise
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');run(ap.parse_args().smoke)
