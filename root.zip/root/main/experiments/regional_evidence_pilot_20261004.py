"""Bounded paired development test of contextual token adapters; no novelty guarantee."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='4'
from pathlib import Path
import sys,time,json,hashlib,fcntl
sys.path[:0]=['/root/FAST','/root/FAST/experiments/residual_20260925']
import numpy as np,h5py,torch
from torch import nn
from torch.nn import functional as F
from sklearn.model_selection import KFold
import run_metric_v4 as v4
OUT=Path('/root/FAST/experiments/regional_evidence_pilot_20261004');OUT.mkdir(exist_ok=True)
SOURCE=Path('/root/FAST/experiments/mechanism_20260927/results/full_additive_seed42')
SUBJECTS=[0,7,10];ARMS=['regional_evidence'];STEPS=200

def save(p,d):
    t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(d,indent=2));t.replace(p)

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
    return h.hexdigest()

def tensorhash(m):
    h=hashlib.sha256()
    for k,t in m.state_dict().items():h.update(k.encode());h.update(t.cpu().numpy().tobytes())
    return h.hexdigest()

class Adapter(nn.Module):
    def __init__(self,full,mean,mode):
        super().__init__();self.mode=mode
        # Training-only regional/feature scales; window dimension pooled.
        for label,z in [('full',full),('mean',mean),('increment',full-mean)]:
            z=torch.asinh(z.float());self.register_buffer(label+'_center',z.mean((0,1),keepdim=True));self.register_buffer(label+'_scale',z.std((0,1),unbiased=False,keepdim=True).clamp_min(.1))
        self.evidence_weight=nn.Parameter(torch.empty(8,32,5))
        self.evidence_bias=nn.Parameter(torch.zeros(8,5))
        nn.init.normal_(self.evidence_weight,std=.02)
        self.gate=nn.Sequential(nn.LayerNorm(74),nn.Linear(74,16),nn.GELU(),nn.Linear(16,1))
        self.out=nn.Linear(256,32,bias=False);nn.init.zeros_(self.out.weight)

    def norm(self,z,label):return ((torch.asinh(z.float())-getattr(self,label+'_center'))/getattr(self,label+'_scale')).clamp(-6,6)

    def evidence(self,z):
        return torch.einsum('bnrd,rdc->bnrc',z,self.evidence_weight)+self.evidence_bias

    def forward(self,full,mean):
        if self.mode=='context_adapter':
            first=self.norm(mean,'mean');second=self.norm(full-mean,'increment')
        else:first=self.norm(full,'full');second=first
        evidence_logits=self.evidence(first)
        probability=evidence_logits.softmax(-1)
        consensus=probability.mean(2,keepdim=True).expand_as(probability)
        gate=torch.sigmoid(self.gate(torch.cat([first,second,probability,probability-consensus],-1)))
        return .5*torch.tanh(self.out((gate*second).flatten(2))/.5),gate

@torch.no_grad()
def regional_teacher(full,y):
    probabilities=[]
    for region in range(8):
        q=F.normalize(torch.asinh(full[:,:,region,:].float()).flatten(1),dim=-1)
        loo=v4.ridge_fit(q,y)[1]
        probabilities.append((4*loo).softmax(-1))
    targets=torch.stack(probabilities,1).detach()
    assert targets.shape==(len(full),8,5) and torch.isfinite(targets).all()
    return targets

def verify_teacher_excludes_self():
    # Analytic LOO must agree with literal seven-point support fits.
    gen=torch.Generator(device='cuda').manual_seed(1704)
    q=F.normalize(torch.randn(8,11,device='cuda',generator=gen),dim=-1)
    y=torch.arange(8,device='cuda')%5
    analytic=v4.ridge_fit(q,y)[1].double()
    for i in range(8):
        mask=torch.arange(8,device='cuda')!=i
        k=v4.kernel(q[mask],q[mask])
        a=k+v4.CFG['ridge']*torch.eye(7,device='cuda',dtype=k.dtype)
        alpha=torch.linalg.solve(a,F.one_hot(y[mask],5).double())
        direct=(v4.kernel(q[i:i+1],q[mask])@alpha)[0]
        assert torch.allclose(analytic[i],direct,atol=2e-6,rtol=2e-6)

def representation(base,adapter,full,mean):
    delta,gate=adapter(full,mean);tokens=base.input_layer(full.flatten(2))+delta
    tokens=torch.cat([base.cls_token.expand(len(full),-1,-1),tokens],1)
    hidden=base.transformer(tokens+base.pos_embedding[:,:base.n_tokens+1])[:,0]
    logits=base.last_layer(hidden)
    with torch.autocast('cuda',enabled=False):q=torch.cat([F.normalize(torch.asinh(full.float()).flatten(1),dim=-1),F.normalize(hidden.float(),dim=-1)],-1)/(2**.5)
    return logits,q,gate,delta

def load_fold(s,fi,tr,te,x,y):
    ck=torch.load(SOURCE/f'{s}-fold{fi}.pt',map_location='cpu');assert np.array_equal(ck['train_idx'],tr) and np.array_equal(ck['test_idx'],te)
    base=v4.FAST(v4.config()).cuda().eval();base.load_state_dict(ck['state_dict']);base.requires_grad_(False)
    with torch.no_grad():
        tx=torch.from_numpy(x).cuda();full=base.forward_head(tx)
        visible=(base.n_tokens-1)*base.config.slide_step+base.config.window_len;assert visible==750
        mu=tx[:,:,:visible].mean(-1,keepdim=True);mean=base.forward_head(mu.expand_as(tx).contiguous())
        old=base.forward_transformer(full[te]);pred=old.argmax(-1).cpu().numpy()
    with np.load(SOURCE/f'{s}-fold{fi}.npz') as z:
        assert np.array_equal(z['y'],y[te]) and np.array_equal(z['test_idx'],te)
        assert np.array_equal(pred,z['primary_pred']),'Original checkpoint prediction mismatch'
    return base,full.detach(),mean.detach(),old.detach(),pred

def report():
    groups=[]
    for arm in ARMS:
        subjects=[]
        for s in SUBJECTS:
            ps=[OUT/arm/f'{s}-fold{fi}.npz' for fi in range(5)]
            if not all(p.exists() for p in ps):continue
            truth=[];pred=[];source=[]
            for p in ps:
                with np.load(p) as z:truth.extend(z['y']);pred.extend(z['pred']);source.extend(z['source_pred'])
            yy=np.array(truth);subjects.append({'subject':s,'accuracy':float((np.array(pred)==yy).mean()),'source':float((np.array(source)==yy).mean()),'rescued':int(((np.array(source)!=yy)&(np.array(pred)==yy)).sum()),'harmed':int(((np.array(source)==yy)&(np.array(pred)!=yy)).sum())})
        groups.append({'arm':arm,'subjects':subjects,'n_subjects':len(subjects),'mean_accuracy':float(np.mean([z['accuracy'] for z in subjects])) if subjects else None,'mean_source':float(np.mean([z['source'] for z in subjects])) if subjects else None})
    for group in groups:
        for row in group['subjects']:
            truth=[];plain=[]
            for fi in range(5):
                path=Path('/root/FAST/experiments/regional_adapter_full_20261004/plain_adapter')/f"{row['subject']}-fold{fi}.npz"
                with np.load(path) as z:
                    truth.extend(z['y']);plain.extend(z['pred'])
            row['plain_adapter']=float((np.array(plain)==np.array(truth)).mean())
            row['delta_plain_pp']=100*(row['accuracy']-row['plain_adapter'])
        group['mean_plain_adapter']=float(np.mean([z['plain_adapter'] for z in group['subjects']])) if group['subjects'] else None
        group['delta_plain_pp']=100*(group['mean_accuracy']-group['mean_plain_adapter']) if group['subjects'] else None
    save(OUT/'summary.json',{'complete':all(z['n_subjects']==3 for z in groups),'groups':groups,'interpretation':'Three previouslyselecteddevelopment participants, not fullcohort or independentconfirmation. Comparison with saved plain-adapter results is not parameter matched; no biological claim. Initial identity not final performance guarantee.'})

def main():
    torch.set_num_threads(4)
    verify_teacher_excludes_self()
    with (OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);started=time.time()
        protocol={'design':'Preserve learnedfull-inputFAST+LOO checkpoint, freezeallsourceweights; newadapter injectsbounded32dim residual into5tokensbeforeTransformer. Initializeoutzero, exactoriginalpredictor atstart.','candidate':'Region-specific five-class evidence heads feed probability and disagreement from within-window regional consensus to gate. Distill each region head from fixed region-specific analytic kernel LOO predictions on training folds only. Zero-initialized residual injected before Transformer.','comparison':'Load previously completed plain-adapter predictions on identical folds; no baseline retraining. Evidence head and enlarged gate add capacity, so this cannot isolate supervision from capacity.','subjects':SUBJECTS,'folds':5,'arms':ARMS,'new_fits':15,'steps':STEPS,'optimizer':'AdamW lr.001 cosine to.0001, weight_decay.01; CE+.3CE(4×LOO) unchangedparameters; additional.01mean(delta_token^2) and .1 regional soft-target cross entropy. Fixedfinalstep, no testtuning.','limits':['Previously selected0/7/10, allfoldsseen repeatedly, development only','Fitsonlyadapter on memorizedsource; possibleweakgradientand overfitting','RNG seed42+s*5+fireset for samefulladapter init','Complete fixed15 pilot fits then stop; full-cohort expansion requires explicit recorded selection after pilot; not independent confirmation','No retrainingoldbaseline; loadandverify savedpredictions','Exact novelty not established by bounded search; regional heads, gating and distillation individually have precedents','LOO excludes query only from kernel support, not from source encoder training; this is not unbiased out-of-sample validation','No biological or causal interpretation of learned gate','Earlierfrozenlinearlogitreadoutfailed; this is preTransformer nonlinear conditional featureadapter, not claim guaranteedsolution'],'sources':{str(Path(__file__)):sha(__file__),str(SOURCE):'perfoldhashstoredwithoutput'}}
        if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==protocol
        else:save(OUT/'protocol.json',protocol)
        try:
            for s in SUBJECTS:
                with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5') as h:x=h[f'{s+1:02d}/X'][:];y=h[f'{s+1:02d}/Y'][:].astype(np.int64)
                for fi,(tr,te) in enumerate(KFold(5,shuffle=False).split(x)):
                    if all((OUT/a/f'{s}-fold{fi}.npz').exists() for a in ARMS):continue
                    v4.seed_all(42+s*5+fi);base,full,mean,old,oldpred=load_fold(s,fi,tr,te,x,y);before=tensorhash(base);yt=torch.from_numpy(y[tr]).cuda();teacher=regional_teacher(full[tr],yt)
                    for arm in ARMS:
                        dest=OUT/arm;dest.mkdir(exist_ok=True);p=dest/f'{s}-fold{fi}.npz'
                        if p.exists():continue
                        v4.seed_all(42+s*5+fi);adapter=Adapter(full[tr],mean[tr],arm).cuda()
                        with torch.no_grad():initial=representation(base,adapter,full[te],mean[te])[0]
                        assert torch.equal(initial,old),'Zero adapter not identical'
                        opt=torch.optim.AdamW(adapter.parameters(),lr=.001,weight_decay=.01);trace=[];t=time.time()
                        for step in range(STEPS):
                            opt.zero_grad(set_to_none=True)
                            for group in opt.param_groups:group['lr']=.001*(.1+.9*.5*(1+np.cos(np.pi*step/(STEPS-1))))
                            logits,q,gate,delta=representation(base,adapter,full[tr],mean[tr]);mainloss=F.cross_entropy(logits,yt);aux=.3*F.cross_entropy(4*v4.ridge_fit(q,yt)[1],yt);evidence_logits=adapter.evidence(adapter.norm(full[tr],'full')).mean(1)
                            distill=-(teacher*F.log_softmax(evidence_logits,-1)).sum(-1).mean()
                            loss=mainloss+aux+.01*delta.square().mean()+.1*distill
                            assert torch.isfinite(loss);loss.backward();assert all(z.grad is None or torch.isfinite(z.grad).all() for z in adapter.parameters());opt.step()
                            if step in [0,49,99,199]:trace.append({'step':step+1,'main_loss':float(mainloss.detach()),'aux_loss':float(aux.detach()),'delta_rms':float(delta.detach().square().mean().sqrt()),'evidence_distill':float(distill.detach())})
                        assert tensorhash(base)==before,'Frozen source changed'
                        with torch.no_grad():logits,q,gate,delta=representation(base,adapter,full[te],mean[te]);pred=logits.argmax(-1).cpu().numpy()
                        save(dest/f'{s}-fold{fi}.json',{'subject':s,'fold':fi,'arm':arm,'accuracy':float((pred==y[te]).mean()),'source_accuracy':float((oldpred==y[te]).mean()),'source_sha256':sha(SOURCE/f'{s}-fold{fi}.pt'),'source_unchanged':True,'zero_init_exact':True,'trace':trace,'seconds':time.time()-t,'parameters':sum(z.numel() for z in adapter.parameters())})
                        torch.save({'state_dict':adapter.cpu().state_dict(),'arm':arm,'train_idx':tr,'test_idx':te,'source':str(SOURCE/f'{s}-fold{fi}.pt')},dest/f'{s}-fold{fi}.pt')
                        with p.with_suffix('.npz.tmp').open('wb') as f:np.savez_compressed(f,pred=pred,source_pred=oldpred,y=y[te],train_idx=tr,test_idx=te,prob=logits.softmax(-1).cpu().numpy())
                        p.with_suffix('.npz.tmp').replace(p);n=sum(len(list((OUT/a).glob('*-fold*.npz'))) for a in ARMS);save(OUT/'status.json',{'state':'running','pid':os.getpid(),'completed_folds':n,'total_folds':15,'elapsed_seconds':time.time()-started,'estimated_remaining_seconds':(time.time()-started)*(15-n)/n,'updated':time.time()});print('ADAPTER_FOLD_DONE',arm,s,fi,float((pred==y[te]).mean()),flush=True);report()
                    del base,full,mean,old,adapter,opt,logits,q,loss;torch.cuda.empty_cache()
            report();save(OUT/'status.json',{'state':'complete','completed_folds':15,'total_folds':15,'elapsed_seconds':time.time()-started,'updated':time.time()})
        except Exception as e:save(OUT/'status.json',{'state':'failed','error':repr(e),'updated':time.time()});raise
if __name__=='__main__':main()
