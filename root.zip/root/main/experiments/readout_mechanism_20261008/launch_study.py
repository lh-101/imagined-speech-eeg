from pathlib import Path
import subprocess,time,json
p=Path(__file__).resolve().parent
start=time.time()
for mode,args in [('smoke',['--smoke']),('formal',[])]:
 with (p/(mode+'.log')).open('ab') as log:
  child=subprocess.Popen(['/root/venv_fast/bin/python','-u',str(p/'run_readout_mechanism.py'),*args],cwd=p,stdout=log,stderr=subprocess.STDOUT)
  (p/'launch_status.json').write_text(json.dumps(dict(state='running',stage=mode,child_pid=child.pid)))
  code=child.wait()
 if code:
  (p/'launch_status.json').write_text(json.dumps(dict(state='failed',stage=mode,exit_code=code)));raise SystemExit(code)
(p/'launch_status.json').write_text(json.dumps(dict(state='complete',elapsed_seconds=time.time()-start)))
