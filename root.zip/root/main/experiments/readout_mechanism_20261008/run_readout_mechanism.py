import os
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[key]='2'
import sys,time,json,traceback,argparse,math
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/parallel_questions_20261008')
import common as c
import numpy as np,torch
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
ROOT=Path(__file__).resolve().parent

class Readout(torch.nn.Module):
 def __init__(self,classes,mode):
  super().__init__();self.global_head=torch.nn.Linear(32,classes);self.local_head=torch.nn.Linear(32,classes);self.mode=mode
  if mode=='attention':self.query=torch.nn.Parameter(torch.zeros(32))
 def forward(self,h,t):
  evidence=self.local_head(t)
  if self.mode=='mean':local=evidence.mean(1)
  elif self.mode=='evidence':local=torch.logsumexp(evidence,1)-math.log(t.shape[1])
  elif self.mode=='attention':local=(evidence*(t@self.query).softmax(1)[...,None]).sum(1)
  else:raise ValueError(self.mode)
  return self.global_head(h)+local

def run(smoke=False):
 torch.set_num_threads(2);start=time.time();out=ROOT/('smoke' if smoke else 'formal');out.mkdir(exist_ok=True)
 assert not (out/'status.json').exists(),'Preserve old run'
 rows=[];steps=3 if smoke else 200
 c.save(out/'protocol.json',dict(steps=steps,source_sha256=c.old.sha(Path(__file__)),source='frozen full-label LOO + generic adapter',temperature=1,primary_contrast='evidence vs parameter-matched mean; attention and concat controls',limits='Exploratory reused folds. Fixed-feature heads, not end-to-end novel network. Linear probes do not prove information destruction. Log-mean-exp evidence aggregation has prior MIL precedents.'))
 try:
  for kind in ('main','external'):
   for s in (c.ref.subjects(kind)[:1] if smoke else c.ref.subjects(kind)):
    for f in (range(1) if smoke else range(5)):
     name=c.ref.name(kind,s,f)
     with np.load(c.old.OUT/'feature_cache'/kind/'loo'/(name+'.npz')) as z:r=z['regional'];tr=z['train_idx'];te=z['test_idx'];y=z['y']
     base=c.build(kind,s,f);base.load_state_dict(torch.load(c.old.source_path(kind,'loo',s,f),map_location='cpu')['state_dict']);base.eval().requires_grad_(False)
     full=torch.from_numpy(r.reshape(len(r),r.shape[1],8,32)).cuda()
     if kind=='external':full=full.to(torch.bfloat16)
     init=c.ref.initialize(kind,full[tr],torch.zeros_like(full[tr]));adapter=c.ref.GenericAdapter(init).cuda()
     path=c.ref.OUT/kind/'generic_adapter'/(name+'.pt');adapter.load_state_dict(torch.load(path,map_location='cpu')['state_dict']);adapter.eval().requires_grad_(False)
     pre=np.empty((len(r),r.shape[1],32),np.float32);post=np.empty_like(pre);cls=np.empty((len(r),32),np.float32)
     with torch.no_grad():
      for ix in (tr,te):
       ft=full[ix];d=adapter(ft,torch.zeros_like(ft))[0]
       with torch.autocast('cuda',dtype=torch.bfloat16,enabled=kind=='external'):
        t=base.input_layer(ft.flatten(2))+d;seq=torch.cat([base.cls_token.expand(len(ix),-1,-1),t],1);h=base.transformer(seq+base.pos_embedding[:,:base.n_tokens+1]);logits=base.last_layer(h[:,0])
       pre[ix]=t.float().cpu().numpy();post[ix]=h[:,1:].float().cpu().numpy();cls[ix]=h[:,0].float().cpu().numpy()
       if np.array_equal(ix,te):prob=logits.float().softmax(1).cpu().numpy()
     with np.load(path.with_suffix('.npz')) as z:assert np.max(np.abs(z['prob']-prob))<1e-6
     predictions={'saved_network':prob.argmax(1)}
     views={'cls':cls,'pre_mean':pre.mean(1),'post_mean':post.mean(1),'concat':np.concatenate([cls,pre.mean(1)],1)}
     for label,t in [('pre_pca',pre),('post_pca',post)]:
      a=t.reshape(len(t),-1);sc=StandardScaler().fit(a[tr]);a=sc.transform(a);pc=PCA(n_components=32,svd_solver='full').fit(a[tr]);views[label]=pc.transform(a)
     for label,a in views.items():
      sc=StandardScaler().fit(a[tr]);aa=sc.transform(a);lr=LogisticRegression(C=1,max_iter=2000,random_state=42).fit(aa[tr],y[tr]);predictions[label+'_linear']=lr.predict(aa[te])
     # One shared train-only token normalization retains between-window differences.
     hs=StandardScaler().fit(cls[tr]);ts=StandardScaler().fit(pre[tr].reshape(-1,32))
     hh=torch.from_numpy(hs.transform(cls).astype(np.float32)).cuda();tt=torch.from_numpy(ts.transform(pre.reshape(-1,32)).reshape(pre.shape).astype(np.float32)).cuda();yt=torch.from_numpy(y[tr]).cuda()
     counts={}
     for mode in ('mean','attention','evidence'):
      c.ref.main_ref.v4.seed_all(c.ref.seed(kind,s,f)+40000);head=Readout(len(np.unique(y)),mode).cuda();counts[mode]=sum(p.numel() for p in head.parameters());opt=torch.optim.AdamW(head.parameters(),lr=.001,weight_decay=.01)
      for step in range(steps):
       opt.zero_grad(set_to_none=True);loss=torch.nn.functional.cross_entropy(head(hh[tr],tt[tr]),yt);assert torch.isfinite(loss);loss.backward();assert all(p.grad is None or torch.isfinite(p.grad).all() for p in head.parameters());opt.step()
      with torch.no_grad():pp=head(hh[te],tt[te]).softmax(1).cpu().numpy()
      predictions[mode+'_head']=pp.argmax(1);del head,opt
     assert counts['mean']==counts['evidence']
     np.savez_compressed(out/(kind+'_'+name+'.npz'),y=y[te],train=tr,test=te,**predictions)
     rows.append(dict(dataset=kind,subject=s,fold=f,accuracy={k:float((v==y[te]).mean()) for k,v in predictions.items()},parameters=counts))
     del base,adapter,init,full,hh,tt,yt;torch.cuda.empty_cache()
     elapsed=time.time()-start;total=2 if smoke else 105
     c.save(out/'summary.json',dict(complete=len(rows)==total,rows=rows))
     c.save(out/'status.json',dict(state='running',completed_folds=len(rows),total_folds=total,elapsed_seconds=elapsed,eta_seconds=elapsed/len(rows)*(total-len(rows))))
  c.save(out/'status.json',dict(state='complete',completed_folds=len(rows),elapsed_seconds=time.time()-start))
 except BaseException:
  c.save(out/'status.json',dict(state='failed',error=traceback.format_exc()));raise
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');a=ap.parse_args();run(a.smoke)
