from pathlib import Path
import subprocess,json,time
p=Path(__file__).resolve().parent;start=time.time()
with (p/'smoke.log').open('ab') as log:code=subprocess.call(['/root/venv_fast/bin/python','-u',str(p/'run_comparison.py'),'--smoke'],cwd=p,stdout=log,stderr=subprocess.STDOUT)
if code:
 (p/'launch_status.json').write_text(json.dumps(dict(state='failed',stage='smoke',code=code)));raise SystemExit(code)
children=[];logs=[]
for worker in range(2):
 log=(p/f'worker{worker}.log').open('ab');logs.append(log);children.append(subprocess.Popen(['/root/venv_fast/bin/python','-u',str(p/'run_comparison.py'),'--worker',str(worker)],cwd=p,stdout=log,stderr=subprocess.STDOUT))
(p/'launch_status.json').write_text(json.dumps(dict(state='running',pids=[c.pid for c in children])))
codes=[c.wait() for c in children]
for log in logs:log.close()
(p/'launch_status.json').write_text(json.dumps(dict(state='complete' if codes==[0,0] else 'failed',codes=codes,elapsed_seconds=time.time()-start)))
