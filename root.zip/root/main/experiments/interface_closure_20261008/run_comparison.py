import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[k]='2'
import sys,time,math,json,traceback,argparse
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/parallel_questions_20261008')
import common as c
import numpy as np,torch
from torch.nn import functional as F
ROOT=Path(__file__).resolve().parent
RATES=[.0001,.0003,.001]

def rep(base,adapter,x,external):
 with torch.autocast('cuda',dtype=torch.bfloat16,enabled=external or base.training):
  full=base.forward_head(x)
  with torch.autocast('cuda',enabled=False):d=adapter(full.float(),torch.zeros_like(full.float()))[0]
  t=base.input_layer(full.flatten(2))+d
  h=base.transformer(torch.cat([base.cls_token.expand(len(x),-1,-1),t],1)+base.pos_embedding[:,:base.n_tokens+1])[:,0]
  logits=base.last_layer(h)
 q=torch.cat([F.normalize(torch.asinh(full.float()).flatten(1),dim=-1),F.normalize(h.float(),dim=-1)],-1)/math.sqrt(2)
 return logits.float(),q,d

def run(worker,smoke):
 torch.set_num_threads(2);out=ROOT/('smoke' if smoke else f'worker{worker}');out.mkdir(exist_ok=True)
 assert not (out/'status.json').exists(),'Preserve previous runs'
 cases=[(k,s,f) for k in ('main','external') for s in c.ref.subjects(k) for f in range(5)]
 cases=[('main',0,0),('external',1,0)] if smoke else cases[worker::2]
 steps=2 if smoke else 200;start=time.time();rows=[]
 c.save(out/'protocol.json',dict(steps=steps,rates=RATES,primary_lr=.0003,cases=cases,source_sha256=c.old.sha(Path(__file__)),mode='same source + same zero adapter; full network vs saved frozen adapter',limits='Exploratory, same update count not same FLOPs, fixed LR robustness not equal HPO budget. Efficiency study not proof novel computational principle.'))
 try:
  for kind,s,f in cases:
   x,y=c.ref.dataset(kind,s);tr,te=list(c.ref.splits(kind,x,y))[f];assert not np.intersect1d(tr,te).size
   xx=c.normalize(kind,x,tr);xt=torch.from_numpy(xx[tr]).cuda();xte=torch.from_numpy(xx[te]).cuda();yt=torch.from_numpy(y[tr]).cuda();name=c.ref.name(kind,s,f)
   ck=torch.load(c.old.source_path(kind,'loo',s,f),map_location='cpu')
   with np.load(c.old.OUT/'feature_cache'/kind/'loo'/(name+'.npz')) as z:regional=z['regional'];assert np.array_equal(z['train_idx'],tr) and np.array_equal(z['test_idx'],te)
   path=c.ref.OUT/kind/'generic_adapter'/(name+'.npz')
   with np.load(path) as z:assert np.array_equal(z['train_idx'],tr) and np.array_equal(z['test_idx'],te);assert np.array_equal(z['y'],y[te]);frozen=z['prob'].copy()
   for lr in RATES:
    t0=time.time();base=c.build(kind,s,f);base.load_state_dict(ck['state_dict']);base.eval()
    features=torch.from_numpy(regional[tr].reshape(len(tr),regional.shape[1],8,32)).cuda()
    c.ref.main_ref.v4.seed_all(c.ref.seed(kind,s,f));reference=c.ref.initialize(kind,features,torch.zeros_like(features));adapter=c.ref.GenericAdapter(reference).cuda();del reference,features
    # Reconstruct saved adapter's exact initialization and frozen final replay.
    zerostate={k:v.detach().clone() for k,v in adapter.state_dict().items()}
    adapter.load_state_dict(torch.load(path.with_suffix('.pt'),map_location='cpu')['state_dict']);adapter.eval()
    with torch.no_grad():replay=rep(base,adapter,xte,kind=='external')[0].softmax(1).cpu().numpy()
    error=float(np.max(abs(replay-frozen)));assert error<1e-6,f'Saved comparator mismatch {error}'
    adapter.load_state_dict(zerostate);del zerostate
    base.requires_grad_(True);adapter.requires_grad_(True);params=list(base.parameters())+list(adapter.parameters());nfull=sum(p.numel() for p in params);nsmall=sum(p.numel() for p in adapter.parameters());assert nsmall==9280
    before=next(base.head.parameters()).detach().clone();opt=torch.optim.AdamW(params,lr=lr,weight_decay=.01);trace=[]
    c.ref.main_ref.v4.seed_all(c.ref.seed(kind,s,f));torch.cuda.reset_peak_memory_stats()
    for step in range(steps):
     base.train();adapter.train();opt.zero_grad(set_to_none=True)
     for group in opt.param_groups:group['lr']=lr*(.1+.9*.5*(1+math.cos(math.pi*step/max(steps-1,1))))
     logits,q,d=rep(base,adapter,xt,kind=='external');ce=F.cross_entropy(logits,yt);aux=c.auxiliary(q,yt,'loo',len(np.unique(y)));loss=ce+aux+.01*d.square().mean()
     assert torch.isfinite(loss);loss.backward();assert all(p.grad is None or torch.isfinite(p.grad).all() for p in params);opt.step()
     if step in (0,steps-1):trace.append(dict(step=step+1,ce=float(ce.detach()),aux=float(aux.detach())))
    moved=float((next(base.head.parameters()).detach()-before).abs().max());assert moved>0
    base.eval();adapter.eval()
    with torch.no_grad():prob=rep(base,adapter,xte,kind=='external')[0].softmax(1).cpu().numpy()
    dest=out/kind/f'lr{lr}';dest.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(dest/(name+'.npz'),prob=prob,frozen_prob=frozen,y=y[te],train=tr,test=te)
    torch.save(dict(base=base.cpu().state_dict(),adapter=adapter.cpu().state_dict(),train=tr,test=te,lr=lr),dest/(name+'.pt'))
    row=dict(dataset=kind,subject=s,fold=f,lr=lr,accuracy=float((prob.argmax(1)==y[te]).mean()),frozen_accuracy=float((frozen.argmax(1)==y[te]).mean()),seconds=time.time()-t0,trainable_full=nfull,trainable_frozen=nsmall,peak_allocated_bytes=torch.cuda.max_memory_allocated(),replay_error=error,cnn_update=moved,trace=trace)
    rows.append(row);c.save(out/'summary.json',dict(complete=len(rows)==len(cases)*3,rows=rows));elapsed=time.time()-start
    c.save(out/'status.json',dict(state='running',completed_fits=len(rows),total_fits=len(cases)*3,elapsed_seconds=elapsed,eta_seconds=elapsed/len(rows)*(len(cases)*3-len(rows)),current=dict(dataset=kind,subject=s,fold=f,lr=lr)))
    del base,adapter,opt,params,before;torch.cuda.empty_cache()
   del xt,xte,yt
  c.save(out/'status.json',dict(state='complete',completed_fits=len(rows),elapsed_seconds=time.time()-start))
 except BaseException:
  c.save(out/'status.json',dict(state='failed',error=traceback.format_exc(),elapsed_seconds=time.time()-start));raise
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--worker',type=int,choices=[0,1],default=0);ap.add_argument('--smoke',action='store_true');a=ap.parse_args();run(a.worker,a.smoke)
