"""Frozen-model residual-information test; no backbone or adapter retraining."""
import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[k]='2'
import sys,json,time,hashlib,traceback,fcntl,itertools,warnings
from pathlib import Path
import numpy as np
import torch
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import Ridge,LogisticRegression
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import f1_score
sys.path[:0]=['/root/FAST/experiments/compression_source_20261006','/root/FAST/experiments/adapter_specificity_20261006']
import run_study as old
ref=old.ref
ROOT=Path(__file__).resolve().parent
ARMS=['token','token_null','token_row','token_nonlinear','token_shuffled_null','null_only']

def save(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2));tmp.replace(path)

def features(kind,s,f):
    name=ref.name(kind,s,f)
    path=old.OUT/'feature_cache'/kind/'loo'/(name+'.npz')
    with np.load(path) as z:
        r=z['regional'].copy();tr=z['train_idx'].copy();te=z['test_idx'].copy();y=z['y'].copy()
    assert r.ndim==3 and r.shape[-1]==256
    ck=torch.load(old.source_path(kind,'loo',s,f),map_location='cpu')
    ref.main_ref.v4.seed_all(ref.seed(kind,s,f))
    if kind=='main':base=ref.main_ref.v4.FAST(ref.main_ref.v4.config()).cuda().eval()
    else:base=ref.external_ref.build(json.loads((ref.external_ref.ROOT/'geometry.json').read_text()))
    base.load_state_dict(ck['state_dict']);base.eval().requires_grad_(False)
    full=torch.from_numpy(r.reshape(len(r),r.shape[1],8,32)).cuda()
    if kind=='external':full=full.to(torch.bfloat16)
    common=ref.initialize(kind,full[tr],torch.zeros_like(full[tr]))
    adapter=ref.GenericAdapter(common).cuda()
    adapter_path=ref.OUT/kind/'generic_adapter'/(name+'.pt')
    adapter.load_state_dict(torch.load(adapter_path,map_location='cpu')['state_dict'])
    adapter.eval().requires_grad_(False)
    tokens=np.empty((len(r),r.shape[1],32),dtype=np.float32)
    with torch.no_grad():
        for indices in (tr,te):
            a=full[indices];delta=adapter(a,torch.zeros_like(a))[0]
            with torch.autocast('cuda',dtype=torch.bfloat16,enabled=kind=='external'):
                value=base.input_layer(a.flatten(2))+delta
            tokens[indices]=value.float().cpu().numpy()
        replay=ref.rep(kind,base,adapter,full[te],torch.zeros_like(full[te]))[0].float().softmax(-1).cpu().numpy()
    with np.load(adapter_path.with_suffix('.npz')) as z:
        assert np.array_equal(z['train_idx'],tr) and np.array_equal(z['test_idx'],te)
        assert np.array_equal(z['y'],y[te])
        expected=z['prob'].copy()
    replayerr=float(np.max(np.abs(replay-expected)))
    assert replayerr<1e-6 and np.array_equal(replay.argmax(1),expected.argmax(1))
    weight=base.input_layer[0].weight.detach().cpu().double().numpy()
    _,singular,vh=np.linalg.svd(weight,full_matrices=False)
    assert singular[-1]>singular[0]*1e-10,'Unexpected low projection rank'
    row=r.astype(np.float64)@vh.T
    null=r.astype(np.float64)-row@vh
    error=float(np.linalg.norm(null@weight.T)/max(np.linalg.norm(r@weight.T),1e-15))
    assert error<1e-10
    scaler=StandardScaler().fit(null[tr].reshape(-1,256))
    pca=PCA(n_components=32,svd_solver='randomized',iterated_power=7,random_state=42)
    pca.fit(scaler.transform(null[tr].reshape(-1,256)))
    compressed=pca.transform(scaler.transform(null.reshape(-1,256))).reshape(len(r),-1)
    token=tokens.reshape(len(r),-1).astype(np.float64)
    token_scaler=StandardScaler().fit(token[tr]);t=token_scaler.transform(token)
    def residual(a):
        a=a.reshape(len(r),-1)
        scale=StandardScaler().fit(a[tr]);a=scale.transform(a)
        model=Ridge(alpha=1.).fit(t[tr],a[tr])
        out=a-model.predict(t)
        # Fitting never sees heldout inputs. Rerun predictor with altered heldout
        # tokens and verify unchanged train predictions as a local isolation check.
        changed=t.copy();changed[te]+=100
        assert np.array_equal(model.predict(changed[tr]),model.predict(t[tr]))
        return out
    nr=residual(compressed);rr=residual(row)
    shuffled=nr.copy();rng=np.random.default_rng(ref.seed(kind,s,f)+18000)
    shuffled[tr]=nr[rng.permutation(tr)];shuffled[te]=nr[rng.permutation(te)]
    views={'token':t,'token_null':np.concatenate([t,nr],1),'token_row':np.concatenate([t,rr],1),
        'token_nonlinear':np.concatenate([t,np.tanh(t)],1),'token_shuffled_null':np.concatenate([t,shuffled],1),'null_only':nr}
    assert all(views[a].shape==views['token_null'].shape for a in ['token_row','token_nonlinear','token_shuffled_null'])
    metadata=dict(projection_rank=32,null_annihilation_relative_error=error,adapter_replay_max_error=replayerr,
        source_sha256=old.sha(old.source_path(kind,'loo',s,f)),adapter_sha256=old.sha(adapter_path),
        feature_cache_sha256=old.sha(path),null_pca_train_variance=float(pca.explained_variance_ratio_.sum()))
    del base,adapter,common,full;torch.cuda.empty_cache()
    return views,tr,te,y,expected.argmax(1),metadata

def statistics(d):
    d=np.asarray(d);rng=np.random.default_rng(20261008)
    boots=d[rng.integers(0,len(d),(10000,len(d)))].mean(1)
    signed=np.array(list(itertools.product((-1,1),repeat=len(d))))@d/len(d)
    return dict(mean_pp=float(d.mean()),bootstrap95_pp=np.quantile(boots,[.025,.975]).tolist(),
        exact_signflip_p=float(np.mean(np.abs(signed)>=abs(d.mean())-1e-12)),
        positive_subjects=int(np.sum(d>1e-8)),negative_subjects=int(np.sum(d<-1e-8)))

def report():
    groups={};ps={}
    for kind in ('main','external'):
        subjects=[]
        for s in ref.subjects(kind):
            paths=[ROOT/'results'/kind/(ref.name(kind,s,f)+'.npz') for f in range(5)]
            if not all(p.exists() for p in paths):continue
            ys=[];preds={a:[] for a in ARMS+['saved_network']}
            for p in paths:
                with np.load(p) as z:
                    ys.extend(z['y'])
                    for a in preds:preds[a].extend(z[a])
            yy=np.asarray(ys)
            subjects.append(dict(subject=s,**{a:dict(accuracy=float(np.mean(yy==p)),macro_f1=float(f1_score(yy,p,average='macro',zero_division=0))) for a,p in preds.items()}))
        group=dict(completed_subjects=len(subjects),total_subjects=len(ref.subjects(kind)),subjects=subjects)
        if subjects:
            group['means']={a:{m:float(np.mean([s[a][m] for s in subjects])) for m in ('accuracy','macro_f1')} for a in ARMS+['saved_network']}
            group['contrasts']={}
            for control in ('token','token_row','token_nonlinear','token_shuffled_null','saved_network'):
                d=[100*(s['token_null']['accuracy']-s[control]['accuracy']) for s in subjects]
                key='token_null_minus_'+control;group['contrasts'][key]=statistics(d)
                if control in ('token','token_row','token_nonlinear'):ps[kind+'/'+control]=group['contrasts'][key]['exact_signflip_p']
        groups[kind]=group
    complete=all(g['completed_subjects']==g['total_subjects'] for g in groups.values())
    adjusted={}
    if complete:
        ordered=sorted(ps,key=ps.get);running=0
        for i,k in enumerate(ordered):running=max(running,(len(ps)-i)*ps[k]);adjusted[k]=min(1.,running)
    save(ROOT/'summary.json',dict(complete=complete,datasets=groups,primary_holm_p=adjusted,
        interpretation='Exploratory fixed-probe predictability after adapter, not conditional mutual information, irrecoverable information loss, novel principle or biological finding.'))

def main():
    torch.set_num_threads(2)
    protocol=dict(arms=ARMS,conditions=105,new_linear_fits=630,source='frozen full-label LOO backbone and ordinary generic adapter',
        training='train-only PCA, scaler, Ridge alpha1; fixed LogisticRegression C1 max_iter2000 tol1e-4',
        hashes={str(p):old.sha(p) for p in [Path(__file__),Path(old.__file__),Path(ref.__file__)]},
        previous_compression_diagnostic='Complete negative broad evidence already known; this conditional residual test is distinct.')
    if (ROOT/'protocol.json').exists():assert json.loads((ROOT/'protocol.json').read_text())==protocol
    else:save(ROOT/'protocol.json',protocol)
    start=time.time();done=0
    with (ROOT/'run.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            for kind in ('main','external'):
                for s in ref.subjects(kind):
                    for f in range(5):
                        dest=ROOT/'results'/kind;dest.mkdir(parents=True,exist_ok=True);name=ref.name(kind,s,f)
                        target=dest/(name+'.npz')
                        if target.exists():done+=1;continue
                        views,tr,te,y,pred,metadata=features(kind,s,f)
                        values={'y':y[te],'train_idx':tr,'test_idx':te,'saved_network':pred}
                        for a in ARMS:
                            scaler=StandardScaler().fit(views[a][tr]);train=scaler.transform(views[a][tr]);test=scaler.transform(views[a][te])
                            model=LogisticRegression(C=1.,max_iter=2000,tol=1e-4,random_state=42)
                            with warnings.catch_warnings(record=True) as caught:
                                warnings.simplefilter('always',ConvergenceWarning);model.fit(train,y[tr])
                            assert not any(issubclass(w.category,ConvergenceWarning) for w in caught),'Fixed classifier did not converge'
                            values[a]=model.predict(test)
                        tmp=target.with_suffix('.npz.tmp')
                        with tmp.open('wb') as h:np.savez_compressed(h,**values)
                        tmp.replace(target);save(dest/(name+'.json'),metadata)
                        done+=1;elapsed=time.time()-start
                        save(ROOT/'status.json',dict(state='running',completed_folds=done,total_folds=105,elapsed_seconds=elapsed,estimated_remaining_seconds=elapsed*(105-done)/done))
                        print('FOLD_DONE',kind,s,f,flush=True)
                    report()
            report();save(ROOT/'status.json',dict(state='complete',completed_folds=done,total_folds=105,elapsed_seconds=time.time()-start))
        except BaseException:
            save(ROOT/'status.json',dict(state='failed',completed_folds=done,error=traceback.format_exc()));raise

if __name__=='__main__':main()
