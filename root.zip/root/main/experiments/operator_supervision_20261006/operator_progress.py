from pathlib import Path
import json,time,statistics,os,argparse
ROOT=Path('/root/FAST/experiments/operator_supervision_20261006')
def show():
 status=json.loads((ROOT/'status.json').read_text()) if (ROOT/'status.json').exists() else {'state':'not_started'}
 rows=[json.loads(p.read_text()) for p in (ROOT/'results').glob('*/*/*.json') if p.with_suffix('.npz').exists()]
 estimates={};remaining=0
 protocol=json.loads((ROOT/'protocol.json').read_text())
 for dataset,n in [('BCI2020',150),('Nguyen2017',60)]:
  a=[r for r in rows if r['dataset']==dataset]
  med=statistics.median(r['seconds'] for r in a) if a else protocol['historical_median_seconds_per_krr_fold'][dataset]
  estimates[dataset]={'completed':len(a),'total':n,'seconds_per_fold':round(med,2),'basis':'measured' if a else 'historical KRR initial estimate'}
  remaining+=(n-len(a))*med
 pid=status.get('pid');alive=pid is not None and Path('/proc',str(pid)).exists()
 print(json.dumps({'state':status['state'],'process_present':alive,'pid':pid,'completed_new_folds':len(rows),'total_new_folds':210,'percent':round(len(rows)/210*100,1),'current':{k:status.get(k) for k in ['dataset','subject','fold','arm']},'elapsed_minutes':round((time.time()-status.get('started',time.time()))/60,1),'estimated_remaining_minutes':round(remaining/60,1),'heuristic_range_minutes':[round(remaining*.7/60,1),round(remaining*1.5/60,1)],'timing':estimates,'ETA_limit':'Approximate, includes no formal uncertainty; initial NLL calibration adds overhead. No live score-based decisions.'},indent=2),flush=True)
ap=argparse.ArgumentParser();ap.add_argument('--watch',action='store_true');a=ap.parse_args()
while True:
 if a.watch:print('\033[2J\033[H',end='')
 show()
 if not a.watch:break
 time.sleep(5)
