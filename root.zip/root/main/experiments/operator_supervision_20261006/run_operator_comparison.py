"""Bounded, fixed two-cohort comparison of self-excluded auxiliary operators.

DWAC-inspired auxiliary controls, not reproductions of the DWAC full predictor.
Uses all existing folds; no test-label selection or performance-based stopping.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='4'
from pathlib import Path
import sys,json,time,hashlib,fcntl,argparse,importlib.util,itertools
sys.path[:0]=['/root/FAST/experiments','/root/FAST',
 '/root/FAST/experiments/residual_20260925',
 '/root/FAST/experiments/nature_stage_20261002']
import numpy as np,h5py,torch
from torch.nn import functional as F
from sklearn.model_selection import KFold,StratifiedKFold
from sklearn.metrics import f1_score
import run_metric_v4 as v4
import nguyen_regional_adapter_20261005 as ext
import run_inner_study as inner

OUT=Path('/root/FAST/experiments/operator_supervision_20261006')
ARMS=['nw_score_ce','nw_native_nll_gradmatched']
KINDS=['BCI2020','Nguyen2017']
OLD={'BCI2020':Path('/root/FAST/experiments/mechanism_20260927/results'),
 'Nguyen2017':ext.ROOT/'results'}
SUBJECTS={'BCI2020':list(range(15)),'Nguyen2017':list(range(1,7))}
CLASSES={'BCI2020':5,'Nguyen2017':3}
TOTAL=210

def save(p,obj):
 p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.tmp')
 t.write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf8');t.replace(p)

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
 return h.hexdigest()

def state_hash(m):return inner.state_hash(m)
def name(kind,s,f):return f'{s}-fold{f}' if kind=='BCI2020' else f'sub{s:02d}_fold{f}'
def seed(kind,s,f):return 42+s*5+f if kind=='BCI2020' else 42+s*101+f*17
def oldpath(kind,arm,s,f):
 return OLD[kind]/({'ce':'full_ce_seed42','krr':'full_additive_seed42'}[arm] if kind=='BCI2020' else {'ce':'fast_ce','krr':'fast_loo'}[arm])/name(kind,s,f)
def dataset(kind,s):
 if kind=='BCI2020':
  with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5') as h:
   return h[f'{s+1:02d}/X'][:],h[f'{s+1:02d}/Y'][:].astype(np.int64)
 with np.load(ext.ROOT/f'sub-{s:02d}.npz') as z:return z['X'],z['y'].astype(np.int64)
def folds(kind,x,y):
 return list(KFold(5,shuffle=False).split(x)) if kind=='BCI2020' else list(StratifiedKFold(5,shuffle=True,random_state=42).split(x,y))
def rep(m,x):return v4.representation(m,x)
def build(kind):
 return v4.FAST(v4.config()).cuda() if kind=='BCI2020' else ext.build(json.loads((ext.ROOT/'geometry.json').read_text()))
def targets(y,c):return F.one_hot(y,c).double()
def kernel(q):return torch.exp(-2*(1-q.double()@q.double().T))
def krr(q,y,c):
 k=kernel(q);a=k+.1*torch.eye(len(q),device=q.device,dtype=k.dtype)
 b=torch.cholesky_inverse(torch.linalg.cholesky(a));t=targets(y,c)
 return (t-(b@t)/b.diag()[:,None]).float()
def nw(q,y,c):
 k=kernel(q);keep=~torch.eye(len(q),device=q.device,dtype=torch.bool)
 k=k.masked_fill(~keep,0);w=k/k.sum(1,keepdim=True)
 return (w@targets(y,c)).float()
def base_losses(q,y,c):
 p=nw(q,y,c)
 nll=-torch.log(p.gather(1,y[:,None]).clamp_min(1e-12)).mean()
 return F.cross_entropy(4*p,y),nll

def calibrated_weight(m,xt,yt,c):
 """Training-only initial gradient norm matching; eval mode uses no RNG draws.

No performance tuning. One scalar fixed for the complete training trajectory.
This modifies loss strength, not NW's probability/NLL definition.
"""
 before=state_hash(m);m.eval()
 with torch.autocast('cuda',dtype=torch.bfloat16):_,q=rep(m,xt)
 reference=F.cross_entropy(4*krr(q,yt,c),yt)
 _,native=base_losses(q,yt,c)
 params=list(m.parameters())
 gr=torch.autograd.grad(reference,params,retain_graph=True,allow_unused=True)
 gn=torch.autograd.grad(native,params,allow_unused=True)
 norm=lambda gs:float(sum(g.double().square().sum() for g in gs if g is not None).sqrt())
 nr,nn=norm(gr),norm(gn)
 assert np.isfinite(nr+nn) and nr>0 and nn>0
 beta=.3*nr/nn
 assert np.isfinite(beta) and beta>0 and state_hash(m)==before
 return beta,{'reference_unweighted_gradient_norm':nr,'native_unweighted_gradient_norm':nn,
  'fixed_native_weight':beta,'reference_weight':.3,
  'definition':'Full encoder parameter gradient norm at initial eval representation, all outer-training trials only; frozen after calibration'}

def old_prediction(kind,arm,s,f,tr,te,y):
 p=oldpath(kind,arm,s,f)
 with np.load(p.with_suffix('.npz')) as z:
  tk='train_idx' if 'train_idx' in z else 'train';ek='test_idx' if 'test_idx' in z else 'test'
  assert np.array_equal(z[tk],tr) and np.array_equal(z[ek],te) and np.array_equal(z['y'],y[te])
  prob=z['primary_prob' if 'primary_prob' in z else 'prob'].copy()
 assert np.isfinite(prob).all() and np.allclose(prob.sum(1),1,atol=1e-5)
 return prob

def protocol():
 OUT.mkdir(parents=True,exist_ok=True)
 deps=[Path(__file__),Path(v4.__file__),Path(inner.__file__),Path(ext.__file__),
  Path('/root/FAST/FAST.py'),Path('/root/FAST/experiments/residual_20260925/run_residual.py'),
  Path('/root/FAST/experiments/nature_stage_20261002/inner_models.py')]
 inputpaths=[Path('/root/FAST/Processed/BCIC2020Track3.h5'),ext.ROOT/'geometry.json']+[ext.ROOT/f'sub-{s:02d}.npz' for s in SUBJECTS['Nguyen2017']]
 cfg={'version':1,'question':'Does regularized inverse-based LOO supervision add predictive value over nonnegative self-excluded weighting?',
  'arms':ARMS,'reused':['CE first-stage','KRR-LOO first-stage'], 'new_fits':TOTAL,'reused_fits':210,
  'subjects':SUBJECTS,'folds':5,'epochs':200,'base_seed':42,'optimizer':'AdamW lr=.0005 default weight_decay=.01',
  'kernel':'exp(-2*(1-q qT)); same normalized regional/CLS q in every arm',
  'objectives':{'nw_score_ce':'CE(main,y)+.3 CE(4 P_nw,y)',
   'nw_native_nll_gradmatched':'CE(main,y)+beta*(-log(P_nw true_class)); beta=.3 initial_encoder_gradient_norm(KRR_CE)/initial_encoder_gradient_norm(NW_NLL), frozen per fold'},
  'calibration':'Only outer-training labels at untrained model eval; no inner or outer validation performance selection. This matches initial gradient norm only, not all training dynamics.',
  'schedule':'BCI retains schedule[epoch-1], two autograd streams; Nguyen retains schedule[epoch], sum-loss backward; matches historical within each dataset',
  'evaluation':'Fixed epoch200, original main classifier only; probabilities/OOF predictions saved. No auxiliary support at inference.',
  'primary':'subject-mean accuracy KRR minus native-NLL control, separate per dataset; Holm across two datasets on completion',
  'secondary':'score-CE operator control; macro F1; paired subject changes; training time and calibration weights',
  'stopping':'All 21 subjects, all5folds, both arms. Stop only completion/technical error/user pause; do not stop on poor scores or select positive subjects.',
  'limitations':['One seed family requested to limit time; not repeat-seed confirmation','All outer folds repeatedly explored; hypothesis now fixed but data are not new confirmation','NW controls adapt DWAC weighting as auxiliary on FAST; not original DWAC architecture or inference reproduction','No performance hyperparameter search for either operator; matching initial gradients does not guarantee globally equal effective loss strength','Known KRR property; positive performance would not establish first-ever network principle or biological mechanism'],
  'sources':{str(p):sha(p) for p in deps},'input_sha256':{str(p):sha(p) for p in inputpaths},
  'method_references':['https://arxiv.org/abs/1811.02579','https://arxiv.org/abs/1805.08136','https://arxiv.org/abs/1903.08560']}
 records=[];times={kind:[] for kind in KINDS}
 for kind in KINDS:
  for s in SUBJECTS[kind]:
   x,y=dataset(kind,s)
   assert np.isfinite(x).all() and set(y)==set(range(CLASSES[kind]))
   for f,(tr,te) in enumerate(folds(kind,x,y)):
    initials=[]
    for arm in ['ce','krr']:
     p=oldpath(kind,arm,s,f);old_prediction(kind,arm,s,f,tr,te,y)
     j=json.loads(p.with_suffix('.json').read_text());initials.append(j['initial_state_sha256'])
     assert p.with_suffix('.pt').exists()
     records.append({'dataset':kind,'subject':s,'fold':f,'arm':arm,'prediction_sha256':sha(p.with_suffix('.npz')),'info_sha256':sha(p.with_suffix('.json'))})
     if arm=='krr':times[kind].append(float(j['seconds']))
    assert initials[0]==initials[1]
 cfg['historical_median_seconds_per_krr_fold']={k:float(np.median(v)) for k,v in times.items()}
 path=OUT/'protocol.json'
 if path.exists():assert json.loads(path.read_text())==cfg,'Protocol changed; refuse mixed study'
 else:save(path,cfg)
 refpath=OUT/'reused_predictions_manifest.json'
 if refpath.exists():assert json.loads(refpath.read_text())==records
 else:save(refpath,records)
 return cfg

def train_fold(kind,arm,s,f,x,y,tr,te):
 dest=OUT/'results'/kind/arm;dest.mkdir(parents=True,exist_ok=True);p=dest/name(kind,s,f)
 if p.with_suffix('.npz').exists():
  assert p.with_suffix('.json').exists() and p.with_suffix('.pt').exists()
  with np.load(p.with_suffix('.npz')) as z:
   assert np.array_equal(z['train_idx'],tr) and np.array_equal(z['test_idx'],te) and np.array_equal(z['y'],y[te])
  return
 v4.seed_all(seed(kind,s,f));m=build(kind);initial=state_hash(m)
 for a in ['ce','krr']:assert initial==json.loads(oldpath(kind,a,s,f).with_suffix('.json').read_text())['initial_state_sha256']
 norm=None
 if kind=='Nguyen2017':
  norm=inner.normalization(x[tr]);x=((x-norm[0])/norm[1]).astype(np.float32)
 xt=torch.from_numpy(x[tr]).cuda();yt=torch.from_numpy(y[tr]).cuda()
 beta,calibration=calibrated_weight(m,xt,yt,CLASSES[kind]) if arm=='nw_native_nll_gradmatched' else (.3,None)
 opt=torch.optim.AdamW(m.parameters(),lr=.0005);params=list(m.parameters())
 schedule=v4.cosine_scheduler(1,.1,200,1,warmup_epochs=10)
 torch.cuda.synchronize();start=time.time();trace=[]
 for epoch in range(200):
  m.train();opt.zero_grad(set_to_none=True)
  lr=.0005*float(schedule[epoch-1 if kind=='BCI2020' else epoch])
  for g in opt.param_groups:g['lr']=lr
  with torch.autocast('cuda',dtype=torch.bfloat16):
   logits,q=rep(m,xt);main=F.cross_entropy(logits,yt)
   score,native=base_losses(q,yt,CLASSES[kind]);extra=beta*(score if arm=='nw_score_ce' else native)
  if kind=='BCI2020':
   gm=torch.autograd.grad(main,params,retain_graph=True,allow_unused=True)
   ga=torch.autograd.grad(extra,params,allow_unused=True)
   for param,a,b in zip(params,gm,ga):
    param.grad=((torch.zeros_like(param) if a is None else a)+(torch.zeros_like(param) if b is None else b)).detach()
  else:(main+extra).backward()
  assert torch.isfinite(main+extra) and all(p.grad is None or torch.isfinite(p.grad).all() for p in params),'Nonfinite training'
  opt.step()
  if epoch==0 or (epoch+1)%50==0:
   row={'epoch':epoch+1,'lr':lr,'main_loss':float(main.detach()),'aux_loss':float(extra.detach()),'aux_weight':beta}
   trace.append(row);print('TRAIN',kind,arm,s,f,json.dumps(row),flush=True)
 m.eval()
 with torch.no_grad():
  if kind=='BCI2020':prob=rep(m,torch.from_numpy(x[te]).cuda())[0].float().softmax(-1).cpu().numpy()
  else:prob=inner.predict(m,x[te])
 torch.cuda.synchronize();elapsed=time.time()-start
 assert np.isfinite(prob).all() and np.allclose(prob.sum(1),1,atol=1e-5)
 tmp=p.with_suffix('.pt.tmp');torch.save({'state_dict':m.cpu().state_dict(),'normalization':norm,'train_idx':tr,'test_idx':te,'dataset':kind,'arm':arm,'calibration':calibration},tmp);tmp.replace(p.with_suffix('.pt'))
 save(p.with_suffix('.json'),{'dataset':kind,'arm':arm,'subject':s,'fold':f,'seed':seed(kind,s,f),'initial_state_sha256':initial,'calibration':calibration,'seconds':elapsed,'accuracy':float((prob.argmax(-1)==y[te]).mean()),'trace':trace})
 tmp=p.with_suffix('.npz.tmp')
 with tmp.open('wb') as h:np.savez_compressed(h,prob=prob,y=y[te],train_idx=tr,test_idx=te)
 tmp.replace(p.with_suffix('.npz'))
 print('FOLD_DONE',kind,arm,s,f,elapsed,flush=True)
 del m,opt,xt,yt,params,logits,q,main,extra;torch.cuda.empty_cache()

def stats(delta):
 a=np.asarray(delta,float);n=len(a)
 # Subjects, not folds, form the paired inference unit.
 rng=np.random.default_rng(20261006);boot=a[rng.integers(n,size=(20000,n))].mean(1)
 values=np.array([np.mean(a*np.array(sign)) for sign in itertools.product([-1,1],repeat=n)])
 return {'difference_pp':100*float(a.mean()),'descriptive_bootstrap95_pp':(100*np.quantile(boot,[.025,.975])).tolist(),'exact_two_sided_signflip_p':float(np.mean(np.abs(values)>=abs(a.mean())-1e-12)), 'positive_subjects':int((a>1e-12).sum()),'negative_subjects':int((a< -1e-12).sum()),'ties':int((abs(a)<=1e-12).sum())}

def summarize():
 rows=[];comparisons=[];counts=0
 for kind in KINDS:
  subjects={}
  for arm in ['ce','krr']+ARMS:
   complete=[]
   for s in SUBJECTS[kind]:
    x,y=dataset(kind,s);prob=np.zeros((len(y),CLASSES[kind]),np.float32);coverage=np.zeros(len(y),int);ready=True
    for f,(tr,te) in enumerate(folds(kind,x,y)):
     if arm in ['ce','krr']:pold=old_prediction(kind,arm,s,f,tr,te,y)
     else:
      path=OUT/'results'/kind/arm/(name(kind,s,f)+'.npz')
      if not path.exists():ready=False;continue
      counts+=1
      with np.load(path) as z:
       assert np.array_equal(z['train_idx'],tr) and np.array_equal(z['test_idx'],te) and np.array_equal(z['y'],y[te]);pold=z['prob']
     prob[te]=pold;coverage[te]+=1
    if not ready:continue
    assert np.all(coverage==1)
    complete.append({'subject':s,'accuracy':float((prob.argmax(-1)==y).mean()),'macro_f1':float(f1_score(y,prob.argmax(-1),labels=np.arange(CLASSES[kind]),average='macro',zero_division=0))})
   subjects[arm]={v['subject']:v for v in complete}
   rows.append({'dataset':kind,'arm':arm,'n_subjects':len(complete),'complete':len(complete)==len(SUBJECTS[kind]),'subjects':complete,'mean_accuracy':float(np.mean([r['accuracy'] for r in complete])) if complete else None,'mean_macro_f1':float(np.mean([r['macro_f1'] for r in complete])) if complete else None})
  for arm in ARMS:
   ix=[s for s in SUBJECTS[kind] if s in subjects[arm]]
   if len(ix)==len(SUBJECTS[kind]):comparisons.append({'dataset':kind,'contrast':'krr minus '+arm,'primary':arm=='nw_native_nll_gradmatched',**stats([subjects['krr'][s]['accuracy']-subjects[arm][s]['accuracy'] for s in ix])})
 primary=[v for v in comparisons if v['primary']]
 if len(primary)==2:
  order=sorted(primary,key=lambda v:v['exact_two_sided_signflip_p']);last=0
  for i,r in enumerate(order):last=max(last,min(1,(2-i)*r['exact_two_sided_signflip_p']));r['holm_p_2datasets']=last
 save(OUT/'summary.json',{'complete':counts==TOTAL,'completed_new_folds':counts,'total_new_folds':TOTAL,'groups':rows,'comparisons':comparisons,'limits':'Exploratory reused outer folds, one seed family; no foundational or biological novelty established.'})
 return counts

def smoke():
 torch.set_num_threads(4);cfg=protocol();checks=[]
 for kind in KINDS:
  c=CLASSES[kind];v4.seed_all(9)
  q=F.normalize(torch.randn(12,16,device='cuda',dtype=torch.float64),dim=1).requires_grad_();y=torch.arange(12,device='cuda')%c
  p=nw(q,y,c);assert (p>=0).all() and torch.allclose(p.sum(1),torch.ones(12,device='cuda'),atol=1e-6)
  changed=y.clone();changed[0]=(changed[0]+1)%c;assert torch.allclose(nw(q,y,c)[0],nw(q,changed,c)[0],atol=1e-6)
  # Gradient check includes differentiating the self-excluded denominator.
  assert torch.autograd.gradcheck(lambda z:nw(z,y,c).double(),(q,),eps=1e-3,atol=1e-3,rtol=1e-2)
  del q
  s=SUBJECTS[kind][0];x,y=dataset(kind,s);tr,te=folds(kind,x,y)[0]
  for arm in ARMS:
   v4.seed_all(seed(kind,s,0));m=build(kind);assert state_hash(m)==json.loads(oldpath(kind,'krr',s,0).with_suffix('.json').read_text())['initial_state_sha256']
   xx=x[tr]
   if kind=='Nguyen2017':mu,sd=inner.normalization(xx);xx=((xx-mu)/sd).astype(np.float32)
   # Finite full-model gradient checks on a balanced training-only mini-slice.
   ix=np.concatenate([np.flatnonzero(y[tr]==k)[:3] for k in range(c)])
   xt=torch.from_numpy(xx[ix]).cuda();yt=torch.from_numpy(y[tr][ix]).cuda()
   beta,cal=calibrated_weight(m,xt,yt,c) if arm=='nw_native_nll_gradmatched' else (.3,None)
   m.train()
   with torch.autocast('cuda',dtype=torch.bfloat16):
    logits,q=rep(m,xt);ce,nll=base_losses(q,yt,c);loss=F.cross_entropy(logits,yt)+beta*(ce if arm=='nw_score_ce' else nll)
   loss.backward();assert torch.isfinite(loss) and all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters())
   checks.append({'dataset':kind,'arm':arm,'initial_matches_historical':True,'finite_loss_gradient':True,'smoke_weight':beta})
   del m,xt,yt,logits,q,loss;torch.cuda.empty_cache()
 save(OUT/'smoke.json',{'passed':True,'updated':time.time(),'checks':checks,'all_historical_prediction_splits_verified':210,'no_test_performance_used':True,'probability_and_no_direct_self_label_check':True,'NW_gradient_check':True})
 print('SMOKE_OK',json.dumps({'historical_median_seconds':cfg['historical_median_seconds_per_krr_fold'],'new_fits':TOTAL,'checks':checks}),flush=True)

def run():
 cfg=protocol();assert json.loads((OUT/'smoke.json').read_text())['passed']
 # Interleave cohorts for early timing measurements; order never depends on scores.
 tasks=[]
 for i in range(15):
  for kind in KINDS:
   if i>=len(SUBJECTS[kind]):continue
   s=SUBJECTS[kind][i]
   for f in range(5):
    for arm in ARMS:tasks.append((kind,s,f,arm))
 # First each cohort's first fold/arm, then the same complete fixed queue.
 first=[('BCI2020',0,0,ARMS[0]),('Nguyen2017',1,0,ARMS[0])]
 tasks=first+[t for t in tasks if t not in first]
 status={'state':'running','pid':os.getpid(),'started':time.time(),'total_new_folds':TOTAL}
 with (OUT/'run.lock').open('w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  try:
   for kind,s,f,arm in tasks:
    status.update(dataset=kind,subject=s,fold=f,arm=arm,updated=time.time(),completed_new_folds=len(list((OUT/'results').glob('*/*/*.npz'))));save(OUT/'status.json',status)
    x,y=dataset(kind,s);tr,te=folds(kind,x,y)[f];train_fold(kind,arm,s,f,x,y,tr,te)
    # Summaries only after completed subjects or cohort, no score-based decisions.
    if f==4 and arm==ARMS[-1]:summarize()
   n=summarize();assert n==TOTAL;status.update(state='complete',completed_new_folds=n)
  except BaseException as e:status.update(state='failed',error=repr(e));raise
  finally:status['updated']=time.time();save(OUT/'status.json',status)

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');ap.add_argument('--report',action='store_true');a=ap.parse_args();torch.set_num_threads(4)
 if a.smoke:smoke()
 elif a.report:summarize()
 else:run()
