from pathlib import Path
import json,time,numpy as np
R=Path(__file__).resolve().parent
p=R/'status.json';s=json.loads(p.read_text()) if p.exists() else {'state':'starting'}
rows=[json.loads(p.read_text()) for p in (R/'results/fast_self').glob('*.json')]
seconds=[r['seconds'] for r in rows]
print(json.dumps(dict(state=s.get('state'),completed_folds=len(rows),total_folds=30,percent=round(100*len(rows)/30,1),subject=s.get('subject'),fold=s.get('fold'),estimated_remaining_seconds=None if not seconds else (30-len(rows))*float(np.mean(seconds)),measured_seconds_per_fold=None if not seconds else float(np.mean(seconds))),indent=2))
if (R/'paired_analysis.json').exists():
 result=json.loads((R/'paired_analysis.json').read_text());result.pop('subjects',None);print(json.dumps(result,indent=2))
