def experiment(geometry):
    import torch
    from torch import nn
    from torch.nn import functional as F
    from transformers import PretrainedConfig
    from sklearn.model_selection import StratifiedKFold
    from sklearn.metrics import accuracy_score,f1_score,cohen_kappa_score
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.linear_model import LogisticRegression
    import inner_models as im
    import run_inner_study as r
    from scipy.signal import welch
    def bandpower(x):
        f,p=welch(x,fs=256.,nperseg=256,noverlap=128,axis=-1)
        return np.concatenate([np.log(np.maximum(p[...,(f>=a)&(f<b)].sum(-1),1e-12)) for a,b in [(8,13),(13,30),(30,70)]],axis=1)
    torch.set_num_threads(4)
    def loo(q,y):
        k=im.kernel(q,q);a=k+.1*torch.eye(len(q),device=q.device,dtype=k.dtype);b=torch.cholesky_inverse(torch.linalg.cholesky(a))
        target=F.one_hot(y,3).to(k.dtype);return (k@(b@target)).float()
    im.loo=loo
    def build(arch):
        if arch=='fast':
            return im.FAST(PretrainedConfig(electrodes=geometry['channels'],zone_dict=geometry['zone_dict'],dim_cnn=32,dim_token=32,seq_len=1024,window_len=256,slide_step=128,head='Conv4Layers',n_classes=3,num_layers=4,num_heads=8,dropout=.1))
        m=im.EEGNet();m.spatial=nn.Conv2d(8,16,(60,1),groups=8,bias=False);m.classifier=nn.Linear(16*32,3);return m
    def metrics(y,p):
        pred=p.argmax(1);return dict(accuracy=float(accuracy_score(y,pred)),macro_f1=float(f1_score(y,pred,average='macro')),kappa=float(cohen_kappa_score(y,pred)))
    def summary():
        rows=[json.loads(p.read_text()) for p in (OUT/'results').glob('*/*.json')];groups=[]
        for job in ['fast_ce','fast_self']:
            a=[x for x in rows if x['job']==job];subjects=[]
            for s in range(1,7):
                q=[x for x in a if x['subject']==s]
                if len(q)==5:subjects.append(dict(subject=s,**{k:float(np.mean([x['evaluation'][k] for x in q])) for k in ['accuracy','macro_f1','kappa']}))
            groups.append(dict(job=job,n_fits=len(a),subjects=subjects,mean_accuracy=float(np.mean([x['accuracy'] for x in subjects])) if subjects else None))
        atomic(OUT/'summary.json',dict(groups=groups,complete=all(g['n_fits']==30 for g in groups),note='One frozen seed; mean folds within subject then mean subjects; not original paper protocol'))
    # Actual shape/gradient smoke and arbitrary-three-class analytical LOO check.
    im.seed_all(9);q=F.normalize(torch.randn(9,12,device='cuda'),dim=1).requires_grad_();y=torch.arange(9,device='cuda')%3
    actual=loo(q,y)
    k=im.kernel(q,q);a=k+.1*torch.eye(len(q),device=q.device,dtype=k.dtype)
    expected=(k@torch.linalg.solve(a,F.one_hot(y,3).double())).float()
    assert torch.allclose(actual,expected,atol=1e-5)
    g=torch.autograd.grad(F.cross_entropy(4*actual,y),q)[0]
    assert torch.isfinite(g).all() and g.norm()>0
    for arch in ['fast','eegnet']:
        m=build(arch).cuda();x=torch.randn(9,60,1024,device='cuda')
        logits,z=r.representation(m,x);assert logits.shape==(9,3)
        loss=F.cross_entropy(logits,y)+im.auxiliary(z,y,'loo');loss.backward()
        assert all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters());del m;torch.cuda.empty_cache()
    atomic(OUT/'smoke.json',dict(passed=True,checks=['Three-class self-support scores equal direct solve','60 channels and 1024 time samples','Both backbones finite gradients']))
    if SMOKE_ONLY:
        print('EXTERNAL_CONTROL_SMOKE_PASS',flush=True)
        return
    started=time.time()
    for subject in range(1,7):
        with np.load(OUT/f'sub-{subject:02d}.npz') as f:x=f['X'];y=f['y'];trial=f['original_trial']
        folds=list(StratifiedKFold(5,shuffle=True,random_state=42).split(x,y))
        atomic(OUT/f'splits_sub{subject:02d}.json',dict(folds=[dict(train=tr.tolist(),test=ev.tolist()) for tr,ev in folds],one_trial_per_sample=True))
        feat=bandpower(x)
        for fold,(tr,ev) in enumerate(folds):
            assert not set(trial[tr])&set(trial[ev]);norm=r.normalization(x[tr]);xx=((x-norm[0])/norm[1]).astype(np.float32)
            for job in ['fast_ce','fast_self']:
                dest=OUT/'results'/job;dest.mkdir(parents=True,exist_ok=True);name=f'sub{subject:02d}_fold{fold}'
                if (dest/(name+'.json')).exists():continue
                atomic(OUT/'status.json',dict(state='running',phase='training',pid=os.getpid(),subject=subject,fold=fold+1,job=job,started=started,updated=time.time()))
                if job=='spectral_logistic':
                    t=time.time();m=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=2000));m.fit(feat[tr],y[tr]);p=m.predict_proba(feat[ev]);timing=dict(seconds=time.time()-t)
                else:
                    arch,method=job.split('_');method='loo' if method=='self' else method;im.seed_all(42+subject*101+fold*17);m=build(arch);initial=r.state_hash(m)
                    if method=='loo':assert initial==json.loads((OUT/'results/fast_ce'/(name+'.json')).read_text())['initial_state_sha256']
                    m,timing=r.train(m,xx[tr],y[tr],method,200,.0005);p=r.predict(m,xx[ev])
                    torch.save(dict(state_dict=m.cpu().state_dict(),normalization=norm,train=tr,test=ev,architecture=arch,method='self_support'),dest/(name+'.pt'))
                    del m;torch.cuda.empty_cache();timing['initial_state_sha256']=initial;timing['supervision']='self-support K alpha, not leave-one-out'
                np.savez_compressed(dest/(name+'.npz'),prob=p,y=y[ev],train=tr,test=ev,original_trial=trial[ev])
                atomic(dest/(name+'.json'),dict(subject=subject,fold=fold,job=job,evaluation=metrics(y[ev],p),**timing))
                summary();print('NGUYEN_FOLD_DONE',job,subject,fold,metrics(y[ev],p),flush=True)
