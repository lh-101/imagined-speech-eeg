"""Single-seed external self-support control; historical CE and LOO are reused."""
from pathlib import Path
import sys,os,json,time,inspect,importlib.util,hashlib,fcntl,argparse
ROOT=Path(__file__).resolve().parent
STAGE=Path('/root/FAST/experiments/nature_stage_20261002')
ORIGINAL=STAGE/'nguyen_external_20261003'
sys.path[:0]=[str(STAGE),'/root/FAST']
spec=importlib.util.spec_from_file_location('nguyen_original',STAGE/'run_nguyen_external.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
import numpy as np
m.OUT=ROOT
SMOKE_ONLY='--smoke' in sys.argv
m.SMOKE_ONLY=SMOKE_ONLY
source=inspect.getsource(m.experiment)
source=source.replace("['fast_ce','fast_loo','eegnet_ce','spectral_logistic']","['fast_ce','fast_self']")
old="target=F.one_hot(y,3).to(k.dtype);return (target-(b@target)/b.diag()[:,None]).float()"
new="target=F.one_hot(y,3).to(k.dtype);return (k@(b@target)).float()"
assert old in source;source=source.replace(old,new)
begin=source.index('    actual=loo(q,y)')
end=source.index("    for arch in ['fast','eegnet']:",begin)
source=source[:begin]+'''    actual=loo(q,y)
    k=im.kernel(q,q);a=k+.1*torch.eye(len(q),device=q.device,dtype=k.dtype)
    expected=(k@torch.linalg.solve(a,F.one_hot(y,3).double())).float()
    assert torch.allclose(actual,expected,atol=1e-5)
    g=torch.autograd.grad(F.cross_entropy(4*actual,y),q)[0]
    assert torch.isfinite(g).all() and g.norm()>0
'''+source[end:]
source=source.replace("checks=['Three-class analytic LOO equals refits','60 channels and 1024 time samples','Both backbones finite gradients']","checks=['Three-class self-support scores equal direct solve','60 channels and 1024 time samples','Both backbones finite gradients']")
source=source.replace('    started=time.time()',"    if SMOKE_ONLY:\n        print('EXTERNAL_CONTROL_SMOKE_PASS',flush=True)\n        return\n    started=time.time()")
old="arch,method=job.split('_');im.seed_all(42+subject*101+fold*17);m=build(arch);initial=r.state_hash(m)"
new="arch,method=job.split('_');method='loo' if method=='self' else method;im.seed_all(42+subject*101+fold*17);m=build(arch);initial=r.state_hash(m)"
assert old in source;source=source.replace(old,new)
# Reused train uses method='loo' to dispatch the overridden scoring function;
# metadata explicitly records the actual control definition.
source=source.replace("timing['initial_state_sha256']=initial","timing['initial_state_sha256']=initial;timing['supervision']='self-support K alpha, not leave-one-out'")
source=source.replace("architecture=arch,method=method)","architecture=arch,method='self_support')")
exec(compile(source,str(ROOT/'frozen_experiment.py'),'exec'),m.__dict__)

def prepare():
 ROOT.mkdir(exist_ok=True)
 (ROOT/'results').mkdir(exist_ok=True)
 for subject in range(1,7):
  p=ORIGINAL/f'sub-{subject:02d}.npz';assert p.exists()
  dest=ROOT/p.name
  if not dest.exists():dest.symlink_to(p)
 ce=ROOT/'results/fast_ce'
 if not ce.exists():ce.symlink_to(ORIGINAL/'results/fast_ce',target_is_directory=True)
 for subject in range(1,7):
  for fold in range(5):
   name=f'sub{subject:02d}_fold{fold}'
   for method in ('fast_ce','fast_loo'):
    assert (ORIGINAL/'results'/method/(name+'.npz')).exists()
    assert (ORIGINAL/'results'/method/(name+'.json')).exists()
 geometry=json.loads((ORIGINAL/'geometry.json').read_text())
 return geometry

def analyze():
 rows=[]
 for subject in range(1,7):
  values={k:[] for k in ('ce','loo','self')}; f1={k:[] for k in values}
  for fold in range(5):
   name=f'sub{subject:02d}_fold{fold}'
   paths={'ce':ORIGINAL/'results/fast_ce','loo':ORIGINAL/'results/fast_loo','self':ROOT/'results/fast_self'}
   data={k:np.load(p/(name+'.npz')) for k,p in paths.items()}
   for k in values:
    for field in ('y','train','test','original_trial'):assert np.array_equal(data[k][field],data['ce'][field])
    info=json.loads((paths[k]/(name+'.json')).read_text());values[k].append(info['evaluation']['accuracy']);f1[k].append(info['evaluation']['macro_f1'])
   info=json.loads((paths['self']/(name+'.json')).read_text());ref=json.loads((paths['ce']/(name+'.json')).read_text())
   assert info['initial_state_sha256']==ref['initial_state_sha256']
  rows.append(dict(subject=subject,**{k:float(np.mean(v)) for k,v in values.items()},macro_f1={k:float(np.mean(v)) for k,v in f1.items()}))
 comparisons={}
 for a,b in [('loo','ce'),('loo','self'),('self','ce')]:
  d=100*np.array([r[a]-r[b] for r in rows]);rng=np.random.default_rng(20261004)
  boot=d[rng.integers(0,6,(10000,6))].mean(1)
  signs=2*((np.arange(64)[:,None]>>np.arange(6))&1)-1
  comparisons[f'{a}_minus_{b}']=dict(delta_pp=float(d.mean()),subject_bootstrap_95ci_pp=np.quantile(boot,[.025,.975]).tolist(),exact_two_sided_sign_flip_p=float((np.abs((signs*d).mean(1))>=abs(d.mean())-1e-12).mean()),positive_subjects=int((d>0).sum()),negative_subjects=int((d<0).sum()))
 result=dict(complete=True,subjects=rows,n_subjects=6,seed=42,means_percent={k:100*float(np.mean([r[k] for r in rows])) for k in ('ce','loo','self')},comparisons=comparisons,primary='loo_minus_self',note='Single frozen seed, same historical splits, previously examined external dataset; exploratory evidence, not zero-shot transfer or cross-subject deployment; secondary comparisons are descriptive.')
 m.atomic(ROOT/'paired_analysis.json',result)
 print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':
 geometry=prepare()
 if SMOKE_ONLY:m.experiment(geometry)
 else:
  assert json.loads((ROOT/'smoke.json').read_text())['passed']
  with (ROOT/'run.lock').open('w') as lock:
   fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
   protocol=dict(dataset='Nguyen2017 ShortWords',subjects=6,folds=5,seed=42,new_fits=30,epochs=200,primary='Historical LOO versus newly trained self-support kernel supervision',historical_CE_and_LOO_reused=True,representation='Unchanged regional/global concatenation',ridge=.1,gamma=2.,aux_weight=.3,score_scale=4.,lr=.0005,source_hashes={str(p):m.digest(p) for p in [Path(__file__),STAGE/'run_nguyen_external.py',STAGE/'inner_models.py',STAGE/'run_inner_study.py']},original_protocol_sha256=m.digest(ORIGINAL/'protocol.json'),limitations=['Previously examined dataset','Single initialization seed','Six independent subjects','Weak raw FAST baseline','No new architecture or zero-shot/cross-subject transfer claim'])
   p=ROOT/'protocol.json'
   if p.exists():assert json.loads(p.read_text())==protocol
   else:m.atomic(p,protocol)
   (ROOT/'frozen_experiment.py').write_text(source)
   try:
    m.experiment(geometry);analyze();m.atomic(ROOT/'status.json',dict(state='complete',updated=time.time(),new_fits=30))
   except Exception as e:
    m.atomic(ROOT/'status.json',dict(state='failed',error=repr(e),updated=time.time()));raise
