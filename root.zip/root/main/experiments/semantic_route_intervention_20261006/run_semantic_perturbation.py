"""Exploratory label-preserving/label-changing interventions on saved models.

No training. No new network. Caching routes is a diagnostic intervention only.
"""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
import argparse
import copy
import fcntl
import hashlib
import json
import math
from pathlib import Path
import signal
import sys
import time
import traceback

BASE=Path('/root/FAST/experiments/adaptive_route_diagnostic_20261006')
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
import run_route_diagnostic as r
import numpy as np
import torch
from torch.nn import functional as F

DRAWS=8
BATCH=128
TOTAL=15
RNG_SEED=20261006+4200
STOP=False
DATA=r.make_data('content_selection')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def oracle(x):
    match=(x[:,1:,:4]*x[:,:1,:4]).sum(-1)
    return (match.unsqueeze(-1)*x[:,1:,4:6]).sum(1)


def selected_mask(x):
    return (x[:,1:,:4]*x[:,:1,:4]).sum(-1).bool()


def probe_indices():
    query=DATA['test'][0][:,0,:4].argmax(-1)
    return torch.cat([torch.where(query==q)[0][:4] for q in range(4)]).tolist()


def altered_data():
    x,y=DATA['test']
    assert torch.equal(y,oracle(x))
    selected=selected_mask(x)
    assert (selected.sum(-1)==1).all()
    g=torch.Generator().manual_seed(RNG_SEED)
    replacements=torch.rand(DRAWS,len(x),4,2,generator=g)*2-1
    irrelevant=x.unsqueeze(0).repeat(DRAWS,1,1,1)
    relevant=irrelevant.clone()
    mask=selected.unsqueeze(0).unsqueeze(-1)
    irrelevant[:,:,1:,4:6]=torch.where(mask,x[None,:,1:,4:6],replacements)
    relevant[:,:,1:,4:6]=torch.where(mask,replacements,x[None,:,1:,4:6])
    yi=oracle(irrelevant.flatten(0,1)).reshape(DRAWS,len(x),2)
    yr=oracle(relevant.flatten(0,1)).reshape(DRAWS,len(x),2)
    assert torch.equal(yi,y.unsqueeze(0).expand_as(yi))
    assert torch.equal(irrelevant[:,:,:,:4],x[None,:,:,:4].expand_as(irrelevant[:,:,:,:4]))
    assert torch.equal(relevant[:,:,:,:4],x[None,:,:,:4].expand_as(relevant[:,:,:,:4]))
    assert torch.equal(irrelevant[:,:,0],x[None,:,0].expand_as(irrelevant[:,:,0]))
    assert torch.equal(relevant[:,:,0],x[None,:,0].expand_as(relevant[:,:,0]))
    assert torch.equal(relevant[:,:,:,6],x[None,:,:,6].expand_as(relevant[:,:,:,6]))
    assert (replacements>=-1).all() and (replacements<=1).all()
    return {'irrelevant':(irrelevant,yi),'relevant':(relevant,yr)}


PERTURBED=altered_data()


def name(depth,arm):
    return r.key('small_transformer','content_selection',depth,arm)


def protocol():
    manifest=[]
    for depth in r.DEPTHS:
        for arm in r.ARMS:
            case=name(depth,arm)
            manifest.append({'case':case,'checkpoint_sha256':digest(BASE/'results'/(case+'.pt')),
                'original_result_sha256':digest(BASE/'results'/(case+'.json'))})
    cfg={'created':time.time(),'device':'cpu','threads':2,'model_count':TOTAL,
        'draws':DRAWS,'batch':BATCH,'rng_seed':RNG_SEED,'test_samples':len(DATA['test'][0]),
        'jacobian_test_indices':probe_indices(),'data_sha256':DATA['hashes'],
        'manifest':manifest,'source_script_sha256':digest(BASE/'run_route_diagnostic.py'),
        'analysis_script_sha256':digest(__file__),'protocol_sha256':digest(ROOT/'定向扰动协议.md'),
        'intervention_sha256':{k:hashlib.sha256(x.numpy().tobytes()+y.numpy().tobytes()).hexdigest() for k,(x,y) in PERTURBED.items()},
        'limits':'Post-hoc exploratory analysis of previously evaluated single-seed simplified models. No training, no novelty certification; caching is diagnostic only.'}
    path=ROOT/'protocol.json'
    if path.exists():
        old=json.loads(path.read_text())
        for key in cfg:
            if key!='created':assert old[key]==cfg[key],('Existing different protocol',key)
        return old
    r.atomic_json(path,cfg)
    return cfg


def load_model(depth,arm):
    case=name(depth,arm)
    info=json.loads((BASE/'results'/(case+'.json')).read_text())
    saved=torch.load(BASE/'results'/(case+'.pt'),map_location='cpu')
    assert saved['configuration']=={'arch':'small_transformer','arm':arm,'depth':depth}
    assert info['data_sha256']==DATA['hashes']
    model=r.build('small_transformer',arm,depth).eval()
    model.load_state_dict(saved['model'])
    assert r.state_hash(model)==info['final_state_sha256']
    for p in model.parameters():p.requires_grad_(False)
    return model,info


def baseline(model,x):
    predictions,angles=[],[]
    with torch.no_grad():
        for start in range(0,len(x),BATCH):
            prediction,_,theta,_=model(x[start:start+BATCH])
            predictions.append(prediction)
            angles.append(torch.stack(theta,dim=-1))
    return torch.cat(predictions),torch.cat(angles)


def intervene(model,x,original_angles,mode):
    prediction,angles=[],[]
    with torch.no_grad():
        for start in range(0,len(x),BATCH):
            if STOP:raise InterruptedError('Stop requested; completed analyses retained')
            frozen=[original_angles[start:start+BATCH,:,layer] for layer in range(len(model.blocks))] if mode=='cached' else None
            y,_,theta,_=model(x[start:start+BATCH],frozen=frozen)
            prediction.append(y);angles.append(torch.stack(theta,dim=-1))
    return torch.cat(prediction),torch.cat(angles)


def stats(values):
    arr=np.asarray(values,dtype=np.float64)
    assert np.isfinite(arr).all()
    return {'mean':float(arr.mean()),'median':float(np.median(arr)),
        'q10':float(np.quantile(arr,.1)),'q90':float(np.quantile(arr,.9)),
        'max':float(arr.max()),'min':float(arr.min())}


def angle_delta_per_role(delta,x):
    # delta shape [batch,tokens,layers]. Distinguish direct token routing
    # from later query/selected-token effects instead of pooling all roles.
    square=delta.square().mean(-1)
    selected=selected_mask(x).float()
    return torch.stack((square[:,0],(square[:,1:]*selected).sum(-1),
        (square[:,1:]*(1-selected)).sum(-1)/3),dim=-1)


def jacobian_diagnostics(model):
    m=copy.deepcopy(model).double().eval()
    value_indices=DATA['indices']
    records=[]
    for sample in probe_indices():
        base=DATA['test'][0][sample:sample+1].double()
        selected=int(selected_mask(base)[0].long().argmax())
        chosen=torch.tensor([2*selected,2*selected+1])
        unchosen=torch.tensor([j for j in range(8) if j not in chosen.tolist()])
        with torch.no_grad():
            _,_,cache,_=m(base)
        cache=[a.detach() for a in cache]
        def fn(z,mode):
            delta=torch.zeros(35,dtype=torch.float64).scatter(0,value_indices,z)
            return m(base+delta.reshape(1,5,7),frozen=cache if mode=='cached' else None)[0].flatten()
        zero=torch.zeros(8,dtype=torch.float64)
        jac={mode:torch.autograd.functional.jacobian(lambda z:fn(z,mode),zero,vectorize=True) for mode in ['full','cached']}
        target=torch.zeros(2,8,dtype=torch.float64)
        target[:,chosen]=torch.eye(2,dtype=torch.float64)
        oracle_j=torch.autograd.functional.jacobian(lambda z:oracle(base+torch.zeros(35,dtype=torch.float64).scatter(0,value_indices,z).reshape(1,5,7)).flatten(),zero,vectorize=True)
        assert torch.equal(target,oracle_j)
        record={'sample':sample,'query_key':int(base[0,0,:4].argmax()),'selected_slot':selected}
        for mode,j in jac.items():
            assert torch.isfinite(j).all()
            selected_j,nuisance_j=j[:,chosen],j[:,unchosen]
            record[mode]={'selected_norm':r.norm2(selected_j),'irrelevant_norm':r.norm2(nuisance_j),
                'selected_derivative_error_frobenius':float((selected_j-torch.eye(2,dtype=torch.float64)).norm()),
                'irrelevant_frobenius':float(nuisance_j.norm())}
        difference=jac['full']-jac['cached']
        record['route_feedback_difference']={'selected_norm':r.norm2(difference[:,chosen]),'irrelevant_norm':r.norm2(difference[:,unchosen])}
        direction=torch.linspace(-1,1,8,dtype=torch.float64);direction/=direction.norm()
        errors={}
        for mode,j in jac.items():
            eps=1e-5
            with torch.no_grad():fd=(fn(zero+eps*direction,mode)-fn(zero-eps*direction,mode))/(2*eps)
            error=float((fd-j@direction).norm()/(fd.norm()+1e-12))
            assert error<3e-4,('Jacobian mismatch',model.arm,sample,mode,error)
            errors[mode]=error
        record['finite_difference_error']=errors
        record['jacobian_values']={mode:j.tolist() for mode,j in jac.items()}
        records.append(record)
    return records


def summarize_jacobians(records):
    out={}
    for mode in ['full','cached','route_feedback_difference']:
        fields=records[0][mode]
        out[mode]={field:stats([v[mode][field] for v in records]) for field in fields}
    return out


def analyze(depth,arm):
    start=time.time();case=name(depth,arm)
    path=ROOT/'results'/(case+'.json')
    if path.exists():return json.loads(path.read_text())
    model,original=load_model(depth,arm)
    initial_hash=r.state_hash(model)
    x,y=DATA['test']
    base_prediction,base_angles=baseline(model,x)
    base_mse=float(F.mse_loss(base_prediction,y))
    assert abs(base_mse-original['test_mse'])<3e-7,('Original score mismatch',case,base_mse,original['test_mse'])
    result={'case':case,'depth':depth,'arm':arm,'baseline_test_mse':base_mse,
        'baseline_score_reproduced':True,'saved_final_state_sha256':initial_hash,
        'test_samples':len(x),'draws_per_sample':DRAWS,'perturbations':{},
        'checkpoint_sha256':digest(BASE/'results'/(case+'.pt'))}
    arrays={'baseline_prediction':base_prediction.numpy(),'original_target':y.numpy()}
    for kind,(altered,targets) in PERTURBED.items():
        kind_result={}
        predictions={mode:[] for mode in ['full','cached']}
        role_angles=[]
        for draw in range(DRAWS):
            for mode in ['full','cached']:
                prediction,angles=intervene(model,altered[draw],base_angles,mode)
                assert torch.isfinite(prediction).all() and torch.isfinite(angles).all()
                predictions[mode].append(prediction)
                if mode=='full':role_angles.append(angle_delta_per_role(angles-base_angles,x))
                else:assert torch.equal(angles,base_angles)
        targets_delta=targets-y.unsqueeze(0)
        arrays[kind+'_targets']=targets.numpy()
        for mode,parts in predictions.items():
            prediction=torch.stack(parts)
            delta=prediction-base_prediction.unsqueeze(0)
            measures={'perturbed_mse':(prediction-targets).square().mean(-1),
                'prediction_change_mse':delta.square().mean(-1),
                'required_response_error':(delta-targets_delta).square().mean(-1)}
            arrays[kind+'_'+mode+'_predictions']=prediction.numpy()
            for metric,values in measures.items():
                arrays[kind+'_'+mode+'_'+metric]=values.numpy()
            kind_result[mode]={metric:stats(values.mean(0).numpy()) for metric,values in measures.items()}
            if arm=='static':
                if mode=='cached':
                    assert torch.allclose(prediction,torch.stack(predictions['full']),atol=1e-7,rtol=1e-7),('Static routes changed with caching',kind)
        theta=torch.stack(role_angles)
        arrays[kind+'_route_delta_square_by_role']=theta.numpy()
        kind_result['route_angle_delta_rms']={role:math.sqrt(float(theta[:,:,i].mean())) for i,role in enumerate(['query','selected','irrelevant'])}
        kind_result['teacher_change_mse']=stats(targets_delta.square().mean(-1).mean(0).numpy())
        kind_result['zero_prediction_change_response_error']=kind_result['teacher_change_mse']['mean']
        full=kind_result['full'];cached=kind_result['cached']
        kind_result['cached_minus_full']={field:cached[field]['mean']-full[field]['mean'] for field in full}
        result['perturbations'][kind]=kind_result
        print('INTERVENTION_DONE',case,kind,json.dumps({'full_response_error':full['required_response_error']['mean'],'cached_response_error':cached['required_response_error']['mean']}),flush=True)
    probes=jacobian_diagnostics(model)
    result['jacobian_diagnostics']=probes
    result['jacobian_summary']=summarize_jacobians(probes)
    result['weights_unchanged']=initial_hash==r.state_hash(model)
    assert result['weights_unchanged']
    result['seconds']=time.time()-start
    result['finite_difference_max_error']=max(value for p in probes for value in p['finite_difference_error'].values())
    result['limits']='Exploratory diagnostics; route caching can alter necessary adaptation. No model training, no independent training replicates, no novelty or mechanism acceptance.'
    path.parent.mkdir(exist_ok=True)
    raw=path.with_suffix('.npz');tmp=raw.with_suffix('.npz.tmp')
    with tmp.open('wb') as f:np.savez_compressed(f,**arrays)
    tmp.replace(raw)
    r.atomic_json(path,result)
    print('MODEL_DONE',case,json.dumps({'seconds':result['seconds'],'baseline_test_mse':base_mse}),flush=True)
    return result


def summarize():
    rows=[json.loads(p.read_text()) for p in sorted((ROOT/'results').glob('*.json'))]
    table=[]
    for row in rows:
        item={key:row[key] for key in ['case','depth','arm','baseline_test_mse','seconds']}
        for kind in ['irrelevant','relevant']:
            for mode in ['full','cached']:
                p=row['perturbations'][kind][mode]
                for field in ['perturbed_mse','prediction_change_mse','required_response_error']:
                    item[kind+'_'+mode+'_'+field]=p[field]['mean']
        for mode in ['full','cached']:
            for field in ['selected_derivative_error_frobenius','irrelevant_norm']:
                item['jacobian_'+mode+'_'+field]=row['jacobian_summary'][mode][field]['mean']
        table.append(item)
    summary={'complete':len(rows)==TOTAL,'completed_models':len(rows),'total_models':TOTAL,'table':table,
        'all_baseline_scores_reproduced':all(v['baseline_score_reproduced'] for v in rows),
        'all_weights_unchanged':all(v['weights_unchanged'] for v in rows),
        'max_finite_difference_error':max((v['finite_difference_max_error'] for v in rows),default=None),
        'interpretation':'Descriptive evidence only. Do not treat high sensitivity or low change alone as a failure/success. Caching is diagnostic, not a new inference model.'}
    r.atomic_json(ROOT/'summary.json',summary)
    if summary['complete']:
        lines=['# 定向信息扰动：15个保存模型已完成分析','',
            '没有重新训练，五条件三深度全部保留。均方误差越小越好；本报告为探索性测量，不自动认定故障或创新成立。',
            '无关变化响应：答案不变时预测改变量MSE；有关变化响应误差：预测改变量与正确答案改变量之差的MSE。',
            '缓存列是原输入路线的诊断干预，不是部署模型，不代表网络效果提升。','',
            '|深度|条件|原测试MSE|无关变化响应|缓存后无关响应|有关变化响应误差|缓存后有关误差|',
            '|---:|---|---:|---:|---:|---:|---:|']
        for row in table:
            lines.append(f"|{row['depth']}|{row['arm']}|{row['baseline_test_mse']:.6f}|{row['irrelevant_full_prediction_change_mse']:.6f}|{row['irrelevant_cached_prediction_change_mse']:.6f}|{row['relevant_full_required_response_error']:.6f}|{row['relevant_cached_required_response_error']:.6f}|")
        lines+=['','需要同时看无关响应、必要响应和原预测误差；若普通控制已兼顾三者，没有新算子必要性的支持。静态路由完整/缓存结果应相同。',
            '所有测量只有一个原训练种子；输入/重抽取不能作为独立训练次数。不同方向导数分别计算，原始样本分布及完整数值在JSON/NPZ中。',
            '', '流程来源：Kassis et al. (2026), Scientific Agent Skills, https://doi.org/10.48550/arXiv.2609.00065 。']
        (ROOT/'semantic_report.md').write_text('\n'.join(lines),encoding='utf8')
    return summary


def smoke():
    cfg=protocol();checks=[]
    for arm in ['dynamic','static','all_linear_spectral']:
        model,info=load_model(4,arm)
        before=r.state_hash(model)
        x,y=DATA['test']
        pred,theta=baseline(model,x)
        assert abs(float(F.mse_loss(pred,y))-info['test_mse'])<3e-7
        for kind,(altered,target) in PERTURBED.items():
            full,_=intervene(model,altered[0,:16],theta[:16],'full')
            cached,_=intervene(model,altered[0,:16],theta[:16],'cached')
            assert torch.isfinite(full).all() and torch.isfinite(cached).all()
            if arm=='static':assert torch.allclose(full,cached,atol=1e-7,rtol=1e-7)
        assert r.state_hash(model)==before
        checks.append({'arm':arm,'baseline_reproduced':True,'finite':True,'weights_unchanged':True})
    start=time.time()
    deep,_=load_model(16,'dynamic')
    deep_base,deep_theta=baseline(deep,DATA['test'][0])
    for mode in ['full','cached']:
        intervene(deep,PERTURBED['irrelevant'][0][0],deep_theta,mode)
    inference_seconds=time.time()-start
    # Exact oracle derivative and finite differences on all 16 prespecified probes.
    start=time.time();probes=jacobian_diagnostics(deep);jacobian_seconds=time.time()-start
    estimate=TOTAL*(inference_seconds*(2*DRAWS)+jacobian_seconds)/60
    r.atomic_json(ROOT/'smoke.json',{'passed':True,'checks':checks,
        'oracle_label_preservation':True,'oracle_derivative_verified':True,
        'static_cache_identity':True,'finite_difference_max_error':max(v for p in probes for v in p['finite_difference_error'].values()),
        'deep_inference_sample_seconds':inference_seconds,'deep_jacobian_seconds':jacobian_seconds,
        'conservative_runtime_minutes':estimate,'device':'cpu','GPU_used':False})
    print('SMOKE_OK',json.dumps({'passed':True,'conservative_minutes':estimate}),flush=True)


def status():
    path=ROOT/'status.json'
    if not path.exists():return {'state':'not_started'}
    obj=json.loads(path.read_text())
    rows=[json.loads(p.read_text()) for p in (ROOT/'results').glob('*.json')]
    obj['completed_models']=len(rows);obj['total_models']=TOTAL;obj['percent']=round(len(rows)*100/TOTAL,1)
    obj['process_present']=Path('/proc',str(obj.get('pid'))).exists()
    obj['elapsed_minutes']=(time.time()-obj['started'])/60
    if rows:seconds=sum(v['seconds'] for v in rows)/len(rows)
    else:seconds=json.loads((ROOT/'smoke.json').read_text())['conservative_runtime_minutes']*60/TOTAL
    remaining=(TOTAL-len(rows))*seconds/60
    obj['estimated_remaining_minutes']=remaining if obj['state']=='running' else (0 if obj['state']=='complete' else None)
    obj['ETA_limits']='Approximate timing; first deepest model is conservative for shallower cases.'
    return obj


def run():
    protocol();assert json.loads((ROOT/'smoke.json').read_text())['passed']
    tasks=[(d,a) for d in r.DEPTHS for a in r.ARMS]
    first=(16,'dynamic');tasks=[first]+[t for t in tasks if t!=first]
    obj={'state':'running','pid':os.getpid(),'started':time.time(),'total_models':TOTAL,'device':'cpu','training':False}
    with (ROOT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            for depth,arm in tasks:
                obj.update(current={'depth':depth,'arm':arm},updated=time.time(),completed_models=len(list((ROOT/'results').glob('*.json'))))
                r.atomic_json(ROOT/'status.json',obj)
                analyze(depth,arm);summarize()
            final=summarize();assert final['complete']
            # Verify all source inputs, including unchanged checkpoints.
            protocol()
            obj.update(state='complete',completed_models=TOTAL)
        except InterruptedError as error:
            obj.update(state='stopped',error=str(error));print('STOPPED',str(error),flush=True)
        except BaseException as error:
            obj.update(state='failed',error=repr(error));traceback.print_exc();raise
        finally:
            obj.update(updated=time.time(),completed_models=len(list((ROOT/'results').glob('*.json'))))
            r.atomic_json(ROOT/'status.json',obj)


def stop_handler(signum,frame):
    global STOP
    STOP=True


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');ap.add_argument('--status',action='store_true');ap.add_argument('--watch',action='store_true');args=ap.parse_args()
    torch.set_num_threads(2);torch.set_num_interop_threads(1)
    signal.signal(signal.SIGTERM,stop_handler)
    if args.smoke:smoke()
    elif args.status or args.watch:
        while True:
            print(json.dumps(status(),indent=2),flush=True)
            if not args.watch:break
            time.sleep(5)
    else:run()
