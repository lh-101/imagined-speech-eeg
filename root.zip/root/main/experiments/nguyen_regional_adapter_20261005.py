"""Fixed six-subject external extension of the established plain regional adapter."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='4'
import sys,time,json,fcntl
from pathlib import Path
sys.path[:0]=['/root/FAST/experiments','/root/FAST','/root/FAST/experiments/residual_20260925']
import numpy as np,torch
from torch.nn import functional as F
from transformers import PretrainedConfig
from sklearn.metrics import f1_score,balanced_accuracy_score
from sklearn.model_selection import StratifiedKFold
import context_adapter_20261004 as common
ROOT=Path('/root/FAST/experiments/nature_stage_20261002/nguyen_external_20261003')
SOURCE=ROOT/'results/fast_loo'
OUT=Path('/root/FAST/experiments/nguyen_regional_adapter_20261005')
STEPS=200;SUBJECTS=list(range(1,7))

def build(geometry):
    return common.v4.FAST(PretrainedConfig(electrodes=geometry['channels'],zone_dict=geometry['zone_dict'],
        dim_cnn=32,dim_token=32,seq_len=1024,window_len=256,slide_step=128,head='Conv4Layers',
        n_classes=3,num_layers=4,num_heads=8,dropout=.1)).cuda().eval()

def ridge(q,y):
    k=torch.exp(-2*(1-q.double()@q.double().T))
    a=k+.1*torch.eye(len(q),device=q.device,dtype=k.dtype)
    b=torch.cholesky_inverse(torch.linalg.cholesky(a))
    target=F.one_hot(y,3).to(k.dtype)
    return (target-(b@target)/b.diag()[:,None]).float()

def representation(base,adapter,full):
    # Adapter remains float32; frozen source token/Transformer preserve original BF16 evaluation.
    delta,gate=adapter(full,torch.zeros_like(full))
    with torch.autocast('cuda',dtype=torch.bfloat16):
        tokens=base.input_layer(full.flatten(2))+delta
        tokens=torch.cat([base.cls_token.expand(len(full),-1,-1),tokens],1)
        hidden=base.transformer(tokens+base.pos_embedding[:,:base.n_tokens+1])[:,0]
        logits=base.last_layer(hidden)
    q=torch.cat([F.normalize(torch.asinh(full.float()).flatten(1),dim=-1),F.normalize(hidden.float(),dim=-1)],-1)/2**.5
    return logits.float(),q,gate,delta

@torch.no_grad()
def cache(base,x):
    parts=[]
    for i in range(0,len(x),64):
        with torch.autocast('cuda',dtype=torch.bfloat16):
            parts.append(base.forward_head(torch.from_numpy(x[i:i+64]).cuda()))
    return torch.cat(parts)

def metrics(y,pred):
    return {'accuracy':float((pred==y).mean()),'balanced_accuracy':float(balanced_accuracy_score(y,pred)),
            'macro_f1':float(f1_score(y,pred,labels=[0,1,2],average='macro',zero_division=0))}

def report():
    subjects=[]
    for s in SUBJECTS:
        paths=[OUT/f'sub{s:02d}_fold{fi}.npz' for fi in range(5)]
        if not all(p.exists() for p in paths):continue
        yy=[];new=[];old=[];ce=[]
        for fi,p in enumerate(paths):
            with np.load(p) as z:
                yy.extend(z['y']);new.extend(z['pred']);old.extend(z['source_pred']);ce.extend(z['ce_pred'])
        y=np.array(yy);row={'subject':s,'adapter':metrics(y,np.array(new)),'source_loo':metrics(y,np.array(old)),'source_ce':metrics(y,np.array(ce))}
        row['delta_loo_accuracy_pp']=100*(row['adapter']['accuracy']-row['source_loo']['accuracy'])
        row['delta_loo_macro_f1_pp']=100*(row['adapter']['macro_f1']-row['source_loo']['macro_f1'])
        subjects.append(row)
    means={arm:{m:float(np.mean([r[arm][m] for r in subjects])) for m in ['accuracy','balanced_accuracy','macro_f1']} for arm in ['adapter','source_loo','source_ce']} if subjects else {}
    result={'complete':len(subjects)==6,'n_subjects':len(subjects),'subjects':subjects,'means':means,
        'delta_loo_accuracy_pp':100*(means['adapter']['accuracy']-means['source_loo']['accuracy']) if subjects else None,
        'delta_loo_macro_f1_pp':100*(means['adapter']['macro_f1']-means['source_loo']['macro_f1']) if subjects else None,
        'positive_subjects':sum(r['delta_loo_accuracy_pp']>1e-9 for r in subjects),
        'negative_subjects':sum(r['delta_loo_accuracy_pp']<-1e-9 for r in subjects),
        'limits':'Single seed, previously inspected independent dataset; weak source decoding near chance. Not independent model selection, not cross-subject or zero-shot transfer. No adaptation using test labels; no causal or biological claims.'}
    common.save(OUT/'summary.json',result)

def load_fold(s,fi,tr,te,x,y,geometry):
    name=f'sub{s:02d}_fold{fi}'
    ck=torch.load(SOURCE/f'{name}.pt',map_location='cpu')
    assert ck['architecture']=='fast' and ck['method']=='loo'
    assert np.array_equal(ck['train'],tr) and np.array_equal(ck['test'],te)
    assert not set(tr)&set(te)
    mu,sd=ck['normalization']
    # Independently verify checkpoint normalization used training trials only.
    expected_mu=x[tr].mean(axis=(0,2),keepdims=True,dtype=np.float64).astype(np.float32)
    expected_sd=np.maximum(x[tr].std(axis=(0,2),keepdims=True,dtype=np.float64).astype(np.float32),1e-6)
    assert np.array_equal(mu,expected_mu) and np.array_equal(sd,expected_sd)
    xx=((x-mu)/sd).astype(np.float32)
    base=build(geometry);base.load_state_dict(ck['state_dict']);base.requires_grad_(False)
    train_features=cache(base,xx[tr]);test_features=cache(base,xx[te])
    with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):old_logits=base.forward_transformer(test_features)
    old_probability=old_logits.float().softmax(-1).cpu().numpy();old_pred=old_probability.argmax(-1)
    with np.load(SOURCE/f'{name}.npz') as z:
        assert np.array_equal(z['train'],tr) and np.array_equal(z['test'],te) and np.array_equal(z['y'],y[te])
        assert np.array_equal(old_pred,z['prob'].argmax(-1)),'Saved source prediction mismatch; do not silently alter comparator'
        max_prob_difference=float(np.max(np.abs(old_probability-z['prob'])))
        assert max_prob_difference<1e-6,'Source probability mismatch'
    with np.load(ROOT/'results/fast_ce'/f'{name}.npz') as z:
        assert np.array_equal(z['train'],tr) and np.array_equal(z['test'],te) and np.array_equal(z['y'],y[te])
        ce_pred=z['prob'].argmax(-1)
    return base,train_features,test_features,old_logits.detach().float(),old_pred,ce_pred,max_prob_difference

def main():
    OUT.mkdir(exist_ok=True);torch.set_num_threads(4)
    with (OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);started=time.time()
        protocol={'dataset':'Nguyen2017 ShortWords, already prepared 6 subjects, 300 whole trials per subject, 60 channels, 3 classes',
            'architecture':'Established ordinary regional gate adapter, 9377 trainable parameters, same nonlinear bounded residual injected before frozen Transformer. Eight regions retained; class count and window count follow dataset. No new complement or conditional gate.',
            'source':str(SOURCE),'subjects':SUBJECTS,'folds':5,'new_fits':30,'steps':STEPS,
            'optimizer':'AdamW lr .001 cosine to .0001, weight_decay .01; CE+.3CE(4*LOO)+.01 mean squared token correction; same settings as main dataset adapter',
            'precision':'Source cached CNN features and frozen Transformer BF16 as historical evaluation; new adapter float32. Exact historical probability and zero-initialized source logits checked.',
            'primary':'Mean subject accuracy difference adapter minus saved FAST+LOO; macro F1, balanced accuracy and individual changes also reported.',
            'split':'Reuse each saved stratified5fold seed42 and stored training-only normalization; one trial per sample, no test-label selection.',
            'stop':'Finish fixed30 adapter fits then stop regardless of outcome. No automatic extra dataset, hyperparameter sweep or baseline retraining.',
            'limits':['Previously inspected dataset, single seed; random trial folds do not rule out recording drift','Source decoding weak, chance33.33%; improved score alone insufficient to establish strong external applicability','No subject-independent, zero-shot transfer or biological claims','Additional200adapter steps are part of method; cannot attribute all gain uniquely to gating','No claim of architectural originality established by this experiment'],
            'source_hashes':{str(Path(__file__)):common.sha(__file__),str(Path(common.__file__)):common.sha(common.__file__)}}
        if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==protocol
        else:common.save(OUT/'protocol.json',protocol)
        geometry=json.loads((ROOT/'geometry.json').read_text())
        assert len(geometry['channels'])==60 and len(geometry['zone_dict'])==8
        try:
            for s in SUBJECTS:
                with np.load(ROOT/f'sub-{s:02d}.npz') as z:x=z['X'];y=z['y'].astype(np.int64)
                assert x.shape==(300,60,1024) and np.array_equal(np.unique(y),np.arange(3))
                for fi,(tr,te) in enumerate(StratifiedKFold(5,shuffle=True,random_state=42).split(x,y)):
                    name=f'sub{s:02d}_fold{fi}';dest=OUT/f'{name}.npz'
                    if dest.exists():continue
                    common.v4.seed_all(42+s*101+fi*17)
                    base,full,test,old,old_pred,ce_pred,prob_diff=load_fold(s,fi,tr,te,x,y,geometry)
                    before=common.tensorhash(base)
                    common.v4.seed_all(42+s*101+fi*17)
                    adapter=common.Adapter(full,torch.zeros_like(full),'plain_adapter').cuda()
                    assert sum(p.numel() for p in adapter.parameters())==9377
                    with torch.no_grad():initial=representation(base,adapter,test)[0]
                    assert torch.equal(initial,old),'Zero adapter differs from source'
                    if not (OUT/'smoke.json').exists():common.save(OUT/'smoke.json',{'passed':True,'parameters':9377,'source_prob_max_error':prob_diff,'zero_initial_logits_exact':True,'normalization_training_only':True,'classes':3,'windows':base.n_tokens,'regions':len(geometry['zone_dict'])})
                    opt=torch.optim.AdamW(adapter.parameters(),lr=.001,weight_decay=.01)
                    yt=torch.from_numpy(y[tr]).cuda();trace=[];t=time.time()
                    for step in range(STEPS):
                        opt.zero_grad(set_to_none=True)
                        for g in opt.param_groups:g['lr']=.001*(.1+.9*.5*(1+np.cos(np.pi*step/(STEPS-1))))
                        logits,q,gate,delta=representation(base,adapter,full)
                        mainloss=F.cross_entropy(logits,yt);aux=.3*F.cross_entropy(4*ridge(q,yt),yt)
                        loss=mainloss+aux+.01*delta.square().mean()
                        assert torch.isfinite(loss);loss.backward()
                        assert all(p.grad is None or torch.isfinite(p.grad).all() for p in adapter.parameters())
                        opt.step()
                        if step in [0,49,99,199]:trace.append({'step':step+1,'main_loss':float(mainloss.detach()),'aux_loss':float(aux.detach()),'delta_rms':float(delta.detach().square().mean().sqrt())})
                    assert common.tensorhash(base)==before,'Frozen source altered'
                    with torch.no_grad():prob=representation(base,adapter,test)[0].softmax(-1).cpu().numpy()
                    pred=prob.argmax(-1)
                    common.save(OUT/f'{name}.json',{'subject':s,'fold':fi,'seconds':time.time()-t,'metrics':metrics(y[te],pred),'source_loo':metrics(y[te],old_pred),
                        'trace':trace,'source_sha256':common.sha(SOURCE/f'{name}.pt'),'source_unchanged':True,'zero_init_exact':True,'source_prob_max_error':prob_diff})
                    torch.save({'state_dict':adapter.cpu().state_dict(),'train_idx':tr,'test_idx':te,'source':str(SOURCE/f'{name}.pt')},OUT/f'{name}.pt')
                    with dest.with_suffix('.npz.tmp').open('wb') as f:np.savez_compressed(f,pred=pred,prob=prob,y=y[te],source_pred=old_pred,ce_pred=ce_pred,train_idx=tr,test_idx=te)
                    dest.with_suffix('.npz.tmp').replace(dest)
                    n=len(list(OUT.glob('sub*_fold*.npz')));elapsed=time.time()-started
                    common.save(OUT/'status.json',{'state':'running','pid':os.getpid(),'completed_folds':n,'total_folds':30,'subject':s,'fold':fi+1,'elapsed_seconds':elapsed,'estimated_remaining_seconds':elapsed*(30-n)/n})
                    print('EXTERNAL_ADAPTER_DONE',s,fi,metrics(y[te],pred),flush=True);report()
                    del base,full,test,adapter,opt,loss,logits,q;torch.cuda.empty_cache()
            report();common.save(OUT/'status.json',{'state':'complete','completed_folds':30,'total_folds':30,'elapsed_seconds':time.time()-started})
        except Exception as e:common.save(OUT/'status.json',{'state':'failed','error':repr(e),'pid':os.getpid()});raise

if __name__=='__main__':main()
