from pathlib import Path
import subprocess,sys,os,json,time
R=Path(__file__).resolve().parent
if '--worker' in sys.argv:
    import fcntl
    with (R/'followup.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        for name in ['offset_audit.py','physiology.py']:
            (R/'followup_status.json').write_text(json.dumps({'state':'running','job':name,'pid':os.getpid(),'updated':time.time()}))
            rc=subprocess.call([sys.executable,str(R/name)],env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1'))
            if rc:
                (R/'followup_status.json').write_text(json.dumps({'state':'failed','job':name,'exit_code':rc,'updated':time.time()}));sys.exit(rc)
        (R/'followup_status.json').write_text(json.dumps({'state':'complete','updated':time.time()}))
else:
    with (R/'followup.log').open('ab') as f:p=subprocess.Popen([sys.executable,str(Path(__file__)),'--worker'],stdout=f,stderr=subprocess.STDOUT,start_new_session=True,stdin=subprocess.DEVNULL,cwd=R)
    (R/'followup.pid').write_text(str(p.pid));print(json.dumps({'started':True,'pid':p.pid,'log':str(R/'followup.log')}))
