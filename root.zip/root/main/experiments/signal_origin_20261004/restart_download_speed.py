from pathlib import Path
import os,signal,time,json,subprocess,sys
R=Path(__file__).resolve().parent;out=R/'raw_cohort';pid=int((R/'raw_cohort.pid').read_text());proc=Path(f'/proc/{pid}/cmdline')
if proc.exists():
    assert str(R/'raw_cohort.py').encode() in proc.read_bytes().split(b'\0')
    os.kill(pid,signal.SIGTERM)
    for _ in range(30):
        if not proc.exists():break
        time.sleep(.1)
stamp=int(time.time());p=out/'protocol.json'
if p.exists():p.replace(out/f'protocol_before_download_change_{stamp}.json')
(out/'download_config.json').write_text(json.dumps({'workers':48,'time':time.time(),'reason':'Measured low per-connection throughput; compare48workers with12, preserve8MiB chunks and all scientific endpoints.'}))
(out/f'download_amendment_{stamp}.json').write_text(json.dumps({'previous_pid':pid,'change':'Only download concurrency12->48, all completed chunks retained; no outcomes inspected or analysis endpoints changed. Protocol copy retained because source hash changes.','time':time.time()}))
subprocess.run([sys.executable,str(R/'launch_raw_cohort.py')],check=True)
