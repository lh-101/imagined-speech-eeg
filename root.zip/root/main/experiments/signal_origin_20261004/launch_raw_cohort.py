from pathlib import Path
import subprocess,sys,json,os
R=Path(__file__).resolve().parent
with (R/'raw_cohort.log').open('ab') as f:p=subprocess.Popen([sys.executable,str(R/'raw_cohort.py')],stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True,cwd=R,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'))
(R/'raw_cohort.pid').write_text(str(p.pid));print(json.dumps({'pid':p.pid,'log':str(R/'raw_cohort.log')}))
