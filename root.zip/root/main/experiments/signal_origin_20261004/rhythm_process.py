"""Bounded exploratory spectral decomposition; no neural classifier or outcome tuning."""
import os
os.environ['OMP_NUM_THREADS']='1'
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,time,pickle,hashlib,itertools,warnings
import numpy as np,mne
from scipy.signal import welch,butter,sosfilt,sosfilt_zi
with warnings.catch_warnings():
    warnings.simplefilter('ignore')
    from fooof import FOOOF
from study import R,SRC,save
OUT=R/'rhythm_process';OUT.mkdir(exist_ok=True)
REGIONS=['Pre-frontal','Frontal','Pre-central','Central','Post-central','Temporal','Parietal','Occipital']
WINDOWS={'action_early':(.5,1.5),'action_late':(2.,3.),'relax':(3.,4.)}
BANDS={'alpha':(8,13),'beta':(13,30)}

def spectral(x,fs,names):
    g=json.loads((R.parent/'nature_stage_20261002/inner_prepared/geometry.json').read_text())
    ix=[[names.index(n) for n in g['zone_dict'][r]] for r in REGIONS]
    f,p=welch(x,fs=fs,nperseg=int(fs),noverlap=0,nfft=int(fs),axis=-1,detrend='constant')
    return f,np.stack([p[:,i].mean(1) for i in ix],axis=1)

def fit_rows(subject,session,source,psds,f,condition,direction,clean):
    rows=[];keep=(f>=3)&(f<=40);ff=f[keep]
    for clean_only in [False,True]:
        for window,p in psds.items():
            for ci in [1,2]:
                selected=(condition==ci)&(clean if clean_only else True)
                pools=[p[selected&(direction==d)].mean(0) for d in range(4) if np.any(selected&(direction==d))]
                if len(pools)!=4:continue
                spectrum=np.mean(pools,axis=0)
                for ri,region in enumerate(REGIONS):
                    fm=FOOOF(peak_width_limits=[2,12],max_n_peaks=4,min_peak_height=.1,peak_threshold=2,aperiodic_mode='fixed',verbose=False)
                    yy=np.maximum(spectrum[ri,keep],1e-24);fm.fit(ff,yy,[3,40])
                    metrics={'aperiodic_exponent':float(fm.aperiodic_params_[1]),'aperiodic_offset':float(fm.aperiodic_params_[0])}
                    ap=fm._ap_fit;peaks=fm._peak_fit
                    for band,(a,b) in BANDS.items():
                        kk=(ff>=a)&(ff<b)
                        metrics[band+'_raw_logpower']=float(np.log10(yy[kk].sum()))
                        metrics[band+'_above_background']=float((np.log10(yy)-ap)[kk].mean())
                        metrics[band+'_fitted_peak']=float(peaks[kk].mean())
                    rows.append({'subject':subject,'session':session,'source':source,'window':window,'condition':ci,'region':region,'clean_only':clean_only,'r_squared':float(fm.r_squared_),'fit_error':float(fm.error_),'fit_usable':bool(fm.r_squared_>=.8 and fm.error_<=.15),'peak_parameters':fm.peak_params_.tolist(),'metrics':metrics,'frequencies':ff.tolist(),'log10_spectrum':np.log10(yy).tolist(),'aperiodic_fit':ap.tolist(),'periodic_fit':peaks.tolist()})
    return rows

def derivative(s,ses):
    label=f'sub-{s:02d}_ses-{ses:02d}';folder=SRC/f'sub-{s:02d}'/f'ses-{ses:02d}'
    with (folder/(label+'_events.dat')).open('rb') as h:ev=np.asarray(pickle.load(h,encoding='latin1'))
    with (folder/(label+'_report.pkl')).open('rb') as h:report=pickle.load(h,encoding='latin1')
    ep=mne.read_epochs(folder/(label+'_eeg-epo.fif'),preload=True,verbose='ERROR');assert np.array_equal(ep.events[:,0],ev[:,0])
    x=ep.get_data(copy=True)*1e6;fs=ep.info['sfreq'];psds={}
    for window,(a,b) in WINDOWS.items():
        ind=(ep.times>=a)&(ep.times<b);assert ind.sum()==int(fs)
        f,psds[window]=spectral(x[:,:,ind],fs,ep.ch_names)
    flags=np.asarray(report.get('EMG_trials',[]),dtype=int).ravel();clean=~np.isin(np.arange(len(ev)),flags)
    # Full time-course, one-second moving spectra: centres0..3.5s, overlapping and descriptive.
    centres=np.arange(0,3.5001,.125);course=[]
    for c in centres:
        ind=(ep.times>=c-.5)&(ep.times<c+.5);ff,pp=spectral(x[:,:,ind],fs,ep.ch_names)
        course.append(np.stack([np.log10(np.maximum(pp[:,:,(ff>=a)&(ff<b)].sum(-1),1e-24)) for a,b in BANDS.values()],axis=-1))
    dest=OUT/'records'/f'sub{s:02d}_ses{ses:02d}.npz'
    np.savez_compressed(dest,**psds,frequencies=f,condition=ev[:,2],direction=ev[:,1],clean=clean,centres=centres,band_timecourse=np.stack(course,axis=1))
    rows=fit_rows(s,ses,'author_derivative',psds,f,ev[:,2],ev[:,1],clean)
    save(dest.with_suffix('.json'),{'rows':rows,'source_file':str(folder/(label+'_eeg-epo.fif')),'features_sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})

def raw_pilot():
    s=1;ses=3;path=R/'raw_pilot/sub-01_ses-03.bdf';audit=json.loads((R/'raw_pilot/audit.json').read_text())
    folder=SRC/'sub-01'/'ses-03';prefix='sub-01_ses-03'
    with (folder/(prefix+'_events.dat')).open('rb') as h:ev=np.asarray(pickle.load(h,encoding='latin1'))
    ep=mne.read_epochs(folder/(prefix+'_eeg-epo.fif'),preload=False,verbose='ERROR');raw=mne.io.read_raw_bdf(path,preload=False,verbose='ERROR');fs=raw.info['sfreq']
    events=mne.find_events(raw,stim_channel='Status',shortest_event=1,mask=65535,mask_type='and',initial_event=True,verbose='ERROR')
    lookup={int(e[0]):int(e[2]) for e in events if e[2] in [31,32,33,34]};assert all(lookup.get(int(r[0]))==int(r[1])+31 for r in ev)
    picks=[raw.ch_names.index(n) for n in ep.ch_names]+[raw.ch_names.index('EXG1'),raw.ch_names.index('EXG2')]
    sos=butter(4,[.5,45],fs=fs,btype='bandpass',output='sos');zi=sosfilt_zi(sos);cols={k:[] for k in WINDOWS}
    for row in ev:
        sample=int(row[0]);following=events[(events[:,0]>sample)&(events[:,0]<sample+5*fs)]
        a=following[following[:,2]==44];b=following[following[:,2]==45];assert len(a)==len(b)==1
        a=int(a[0,0]);b=int(b[0,0]);start=int(sample-10*fs);end=min(raw.n_times,b+int(fs));assert start>=0
        x=raw.get_data(picks=picks,start=start,stop=end)*1e6;x=x[:128]-x[128:130].mean(0)
        z=sosfilt(sos,x,axis=-1,zi=zi[:,None,:]*x[:,0][None,:,None])[0]
        actual={'action_early':(a,a+int(fs)),'action_late':(b-int(fs),b),'relax':(b,b+int(fs))}
        for w,(u,v) in actual.items():
            assert v<=end
            f,p=spectral(z[None,:,u-start:v-start],fs,ep.ch_names);cols[w].append(p[0])
    psds={k:np.array(v) for k,v in cols.items()};rows=fit_rows(1,3,'raw_forward_no_ICA',psds,f,ev[:,2],ev[:,1],np.ones(len(ev),bool))
    save(OUT/'raw_pilot_result.json',{'rows':rows,'raw_sha256':audit['raw_sha256'],'scope':'One-record processing sensitivity only, not biological validation. Actual action and relax triggers;10s forward-filter warmup.'})

def summary():
    rows=[r for p in (OUT/'records').glob('*.json') for r in json.loads(p.read_text())['rows']]
    contrasts=[];metrics=list(rows[0]['metrics']) if rows else []
    for region in REGIONS:
        for metric in metrics:
            for contrast in ['action_late-minus-early','action_late-minus-relax']:
                first='action_late';second='action_early' if contrast.endswith('early') else 'relax';subjects=[]
                for s in range(1,11):
                    values=[]
                    for ses in range(1,4):
                        q={(r['window'],r['condition']):r for r in rows if r['subject']==s and r['session']==ses and r['region']==region and not r['clean_only']}
                        keys=[(first,1),(first,2),(second,1),(second,2)]
                        if not all(k in q and q[k]['fit_usable'] for k in keys):continue
                        values.append(q[first,1]['metrics'][metric]-q[first,2]['metrics'][metric]-q[second,1]['metrics'][metric]+q[second,2]['metrics'][metric])
                    if len(values)==3:subjects.append({'subject':s,'value':float(np.mean(values)),'sessions':values})
                v=np.array([z['value'] for z in subjects]);n=len(v)
                if n>=6:
                    signs=np.array(list(itertools.product([-1,1],repeat=n)));p=float((np.abs((signs*v).mean(1))>=abs(v.mean())-1e-12).mean())
                    rng=np.random.default_rng(20261004);bs=v[rng.integers(0,n,(5000,n))].mean(1)
                    contrasts.append({'region':region,'metric':metric,'contrast':contrast,'n_subjects':n,'subjects':subjects,'mean':float(v.mean()),'subject_bootstrap95':np.quantile(bs,[.025,.975]).tolist(),'p_two_sided_signflip':p})
    ranked=sorted(contrasts,key=lambda r:r['p_two_sided_signflip']);q=1.
    for i in range(len(ranked)-1,-1,-1):q=min(q,ranked[i]['p_two_sided_signflip']*len(ranked)/(i+1));ranked[i]['bh_q_all_exploratory']=q
    save(OUT/'summary.json',{'complete_records':len(list((OUT/'records').glob('*.json'))),'total_records':30,'fit_count':len(rows),'fit_usable_fraction':float(np.mean([r['fit_usable'] for r in rows])) if rows else None,'contrasts':contrasts,'interpretation':'Exploratory task-by-stage associations, all8regions and8metrics reported with BH across all tested interactions. Not neural cause, independent replication, semantic decoding, or proof of novelty. Fixed condition/run order remains confounded.'})

def main():
    started=time.time();(OUT/'records').mkdir(exist_ok=True)
    protocol={'started':started,'analysis':'Exploratory decomposition of internally spoken versus visualized directions and task-stage interaction; not cross-subject prediction. Existing outcomes known.','windows':WINDOWS,'spectra':'Matched1second Hann Welch;1Hz resolution; scalp-channel PSD averaged in8fixed label-independent regions; equal average across4directions then condition pooled spectrum. Absolute power, no spatial normalization.','fit':'FOOOF1.1.1 fixed aperiodic3-40Hz; peak widths2-12Hz,max4,minheight.1,threshold2. Fit-quality R2>=.8,error<=.15; poor fits retained and flagged; no peak is0, not missing. One-second resolution limits narrow peak and low-frequency interpretation.','metrics':'Exponent,offset;alpha8-13,beta13-30 raw integrated log10power, above-background residual mean and fitted peak mean. Background slope is not direct excitation/inhibition measurement.','contrasts':'Task interaction late-minus-early and late-minus-relax for all8regions×8metrics=128 planned exploratory endpoints. Three-session participant means, >=6complete participants, symmetric signflip, bootstrap5000,BH alltested. Session and clean fit tables preserved.','temporal':'1second moving PSD centres0..3.5 step.125, descriptive smoothing, no precise onset claim. Cue/window overlap explicitly retained.','sensitivity':'Raw subject1session3 already downloaded, forward buffered0.5-45Hz,noICA,actual task tags. One record cannot establish preprocessing robustness.','limits':['Derivative noncausal filter and ICA may alter timing','Relax screen differs from action; stage effects not unique to inner speech','Task condition runs fixed order, residual context/drift confounding','No reading task, no precise inner syllable onset, no measured speech envelope','No causal cortical source inference; no outcome-dependent band/subject selection','Existing-data exploration; novelty unresolved; negative findings retained'],'stop':'Finish30alreadyavailablederivative records plus1existingraw processing check. No extra dataset, neural training, or adaptive endpoint search.','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    if not (OUT/'protocol.json').exists():save(OUT/'protocol.json',protocol)
    try:
        for s in range(1,11):
            for ses in range(1,4):
                if not (OUT/'records'/f'sub{s:02d}_ses{ses:02d}.json').exists():derivative(s,ses)
                summary();n=len(list((OUT/'records').glob('*.json')))
                save(OUT/'status.json',{'state':'running','phase':'derivative_analysis','completed_records':n,'total_records':30,'elapsed_seconds':time.time()-started,'pid':os.getpid(),'estimated_remaining_seconds':(time.time()-started)*(30-n)/n,'updated':time.time()});print('RHYTHM_RECORD_DONE',s,ses,flush=True)
        if not (OUT/'raw_pilot_result.json').exists():raw_pilot()
        summary();save(OUT/'status.json',{'state':'complete','completed_records':30,'raw_sensitivity_records':1,'elapsed_seconds':time.time()-started,'updated':time.time()});print('RHYTHM_COMPLETE',flush=True)
    except Exception as e:save(OUT/'status.json',{'state':'failed','error':repr(e),'updated':time.time()});raise
if __name__=='__main__':main()
