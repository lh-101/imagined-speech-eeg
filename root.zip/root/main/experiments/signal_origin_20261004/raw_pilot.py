"""Technical raw-recording feasibility pilot; no model outcomes or subject selection."""
from pathlib import Path
import requests,os,json,time,hashlib,pickle
from concurrent.futures import ThreadPoolExecutor,as_completed
import numpy as np,mne
from study import R,SRC,save
OUT=R/'raw_pilot';OUT.mkdir(exist_ok=True)
def main():
    import fcntl
    with (OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);started=time.time()
        inv=json.loads((R/'raw_metadata/raw_inventory.json').read_text())['files'];key='ds003626/sub-01/ses-03/eeg/sub-01_ses-03_task-innerspeech_eeg.bdf';obj=next(x for x in inv if x['key']==key)
        save(OUT/'protocol.json',{'scope':'Technical feasibility only; no prediction endpoints, no performance-based pilot selection','selection':'First subject, short third session; outcome-independent technical choice. Complete all10 subjects if expanding study, not a one-subject biological claim.','source':obj,'steps':['Download pinned raw BDF using bounded parallel Range, size and MD5 if plain ETag','Check physical channel units and sample rate','Extract genuine Status events; verify released trial labels and timestamps against raw triggers','Retain actual condition markers and report identifiers; no invented blocks'],'raw_data_budget_bytes':obj['size']*2+1024**3,'auto_train':False,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
        try:
            import shutil
            assert shutil.disk_usage(OUT).free>obj['size']*2+1024**3
            parts=OUT/'parts';parts.mkdir(exist_ok=True);step=8*1024**2;spec=[(i,a,min(a+step,obj['size'])-1) for i,a in enumerate(range(0,obj['size'],step))]
            def get(item):
                i,a,b=item;p=parts/f'{i:04d}.part'
                if p.exists() and p.stat().st_size==b-a+1:return p
                for attempt in range(3):
                    try:
                        r=requests.get('https://s3.amazonaws.com/openneuro.org/'+key,headers={'Range':f'bytes={a}-{b}','If-Match':'"'+obj['etag']+'"'},stream=True,timeout=(10,45));r.raise_for_status();assert r.status_code==206 and r.headers.get('Content-Range','').startswith(f'bytes {a}-{b}/')
                        tmp=p.with_suffix('.tmp')
                        with tmp.open('wb') as f:
                            for block in r.iter_content(1024**2):f.write(block)
                        assert tmp.stat().st_size==b-a+1;tmp.replace(p);return p
                    except Exception:
                        if attempt==2:raise
            with ThreadPoolExecutor(max_workers=12) as pool:
                futures={pool.submit(get,x):x for x in spec};done=0
                for f in as_completed(futures):
                    f.result();done+=1;downloaded=sum(p.stat().st_size for p in parts.glob('*.part'));elapsed=time.time()-started
                    save(OUT/'status.json',{'state':'running','phase':'download','pid':os.getpid(),'completed_parts':done,'total_parts':len(spec),'downloaded_bytes':downloaded,'total_bytes':obj['size'],'started':started,'updated':time.time(),'mean_MB_per_second':downloaded/max(elapsed,1)/1e6,'rough_remaining_seconds':(obj['size']-downloaded)/max(downloaded/max(elapsed,1),1)})
                    print('RAW_PART_DONE',done,len(spec),downloaded,flush=True)
            p=OUT/'sub-01_ses-03.bdf'
            if not p.exists() or p.stat().st_size!=obj['size']:
                with p.with_suffix('.tmp').open('wb') as f:
                    for i,_,_ in spec:
                        with (parts/f'{i:04d}.part').open('rb') as g:
                            while True:
                                b=g.read(4*1024**2)
                                if not b:break
                                f.write(b)
                p.with_suffix('.tmp').replace(p)
            md5=hashlib.md5();sha=hashlib.sha256()
            with p.open('rb') as f:
                for b in iter(lambda:f.read(4*1024**2),b''):md5.update(b);sha.update(b)
            if '-' not in obj['etag']:assert md5.hexdigest()==obj['etag']
            save(OUT/'status.json',{'state':'running','phase':'raw_events','pid':os.getpid(),'updated':time.time()})
            raw=mne.io.read_raw_bdf(p,preload=False,verbose='ERROR');events=mne.find_events(raw,stim_channel='Status',shortest_event=1,mask=65535,mask_type='and',initial_event=True,verbose='ERROR')
            np.save(OUT/'raw_events.npy',events)
            pre='sub-01_ses-03';folder=SRC/'sub-01'/'ses-03'
            with (folder/(pre+'_events.dat')).open('rb') as f:derived=np.asarray(pickle.load(f,encoding='latin1'))
            trial=events[np.isin(events[:,2],[31,32,33,34])];matches={}
            for factor in [1,4]:matches[str(factor)]=bool(len(trial)==len(derived) and np.array_equal(trial[:,0],derived[:,0]*factor) and np.array_equal(trial[:,2],derived[:,1]+31))
            factor=next((int(k) for k,v in matches.items() if v),None)
            runs=[];begin=0
            for i in range(1,len(derived)+1):
                if i==len(derived) or derived[i,2]!=derived[begin,2]:
                    runs.append({'first_trial':begin,'last_trial':i-1,'condition_code':int(derived[begin,2]),'n_trials':i-begin,'recorded_first_sample':int(derived[begin,0]),'recorded_last_sample':int(derived[i-1,0]),'interpretation':'Maximal recorded condition segment, not automatically a complete acquisition run'});begin=i
            audit={'complete':True,'subject':1,'session':3,'raw_sha256':sha.hexdigest(),'raw_md5':md5.hexdigest(),'source':obj,'sampling_rate':raw.info['sfreq'],'duration_seconds':raw.n_times/raw.info['sfreq'],'channel_names':raw.ch_names,'raw_trigger_counts':{str(int(c)):int(n) for c,n in zip(*np.unique(events[:,2],return_counts=True))},'n_raw_direction_trials':len(trial),'n_released_trials':len(derived),'timestamp_factors_checked':matches,'verified_timestamp_factor':factor,'recorded_condition_segments':runs,'first_events':events[:40].tolist(),'technical_alignment_passed':factor is not None,'limitations':['One technical recording only; not a biological result','Acquisition task runs and task conditions may be confounded','No new causal preprocessing or prediction performed yet','Parts retained, no automatic deletion of project data']}
            save(OUT/'audit.json',audit);save(OUT/'status.json',{'state':'complete','technical_alignment_passed':factor is not None,'elapsed_seconds':time.time()-started,'updated':time.time()});print('RAW_AUDIT_COMPLETE',factor,len(trial),len(derived),flush=True)
        except Exception as e:save(OUT/'status.json',{'state':'failed','error':repr(e),'updated':time.time()});raise
if __name__=='__main__':main()
