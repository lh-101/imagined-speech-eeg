"""Exploratory task-state/content distinction, with same cues and real sessions."""
from pathlib import Path
import os,time,json,pickle,hashlib,itertools
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
import numpy as np,mne
from scipy.signal import welch
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression,Ridge
from sklearn.metrics import balanced_accuracy_score
from study import SRC,save,R
OUT=R/'physiology';OUT.mkdir(exist_ok=True)
BANDS=[(1,4),(4,8),(8,13),(13,30),(30,45)]
def power(x):
    f,p=welch(x,fs=256,nperseg=128,noverlap=64,nfft=128,detrend='constant',axis=-1)
    return np.stack([np.log(np.maximum(p[:,:,(f>=a)&(f<b)].sum(-1)*2,1e-18)) for a,b in BANDS],axis=1)
def relative(x):return (x-x.mean(-1,keepdims=True)).reshape(len(x),-1)
def features(s):
    path=OUT/f'sub{s:02d}_features.npz'
    if path.exists():
        with np.load(path) as f:return {k:f[k] for k in f.files}
    parts=[]
    for ses in range(1,4):
        pre=f'sub-{s:02d}_ses-{ses:02d}';folder=SRC/f'sub-{s:02d}'/f'ses-{ses:02d}'
        with (folder/(pre+'_events.dat')).open('rb') as f:ev=np.asarray(pickle.load(f,encoding='latin1'))
        with (folder/(pre+'_report.pkl')).open('rb') as f:report=pickle.load(f,encoding='latin1')
        flag=np.asarray(report.get('EMG_trials',[]),dtype=int).ravel();assert not len(flag) or (flag.min()>=0 and flag.max()<len(ev))
        d={'direction':ev[:,1],'condition':ev[:,2],'session':ev[:,3],'trial':np.arange(len(ev)),'sample':ev[:,0],'clean':~np.isin(np.arange(len(ev)),flag)}
        assert set(ev[:,2])=={0,1,2} and np.all(ev[:,3]==ses)
        for kind,suffix in [('eeg','_eeg-epo.fif'),('exg','_exg-epo.fif')]:
            ep=mne.read_epochs(folder/(pre+suffix),preload=True,verbose='ERROR');assert np.array_equal(ep.events[:,0],ev[:,0]);x=ep.get_data(copy=True)*1e6
            if kind=='exg':x=x[:,2:,:] # exclude ear references, retain four EOG and two mouth EMG channels
            for name,(a,b) in {'pre':(-.5,0),'cue':(0,.5),'action':(1.,3.)}.items():
                z=power(x[:,:,(ep.times>=a)&(ep.times<b)]);d[kind+'_'+name]=relative(z)
            d[kind+'_delta']=d[kind+'_action']-d[kind+'_pre']
        parts.append(d)
    d={k:np.concatenate([p[k] for p in parts]) for k in parts[0]};np.savez_compressed(path,**d);return d
def fit_score(x,z,y,target):
    m=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=2000,class_weight='balanced',random_state=42));m.fit(x,y);pred=m.predict(z)
    return {'balanced_accuracy':float(balanced_accuracy_score(target,pred)), 'prediction':pred.tolist(),'target':target.tolist(),'train_balanced_accuracy':float(balanced_accuracy_score(y,m.predict(x)))}
def summary():
    rows=[json.loads(p.read_text()) for p in (OUT/'fits').glob('*.json')];groups=[]
    for task,feature in sorted({(r['task'],r['feature']) for r in rows}):
        subjects=[]
        for s in range(1,11):
            rs=[r for r in rows if r['subject']==s and r['task']==task and r['feature']==feature]
            if len(rs)==3:
                subjects.append({'subject':s,'balanced_accuracy':float(balanced_accuracy_score(np.concatenate([r['target'] for r in rs]),np.concatenate([r['prediction'] for r in rs])))})
        groups.append({'task':task,'feature':feature,'subjects':subjects,'mean_balanced_accuracy':float(np.mean([r['balanced_accuracy'] for r in subjects])) if subjects else None})
    save(OUT/'summary.json',{'complete':len(rows)==480,'completed':len(rows),'total':480,'groups':groups,'unit':'fraction','limitations':'Task-condition runs and mental state differ; remaining block effects, eye/muscle activity and cue memory are not eliminated. No causal or language-specific mechanism established.'})
def main():
    import fcntl
    with (OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);started=time.time()
        protocol={'analysis':'Exploratory on previously observed cohort; modalities not previously evaluated in this contrast by this script','subjects':10,'sessions':3,'condition_mapping':{'0':'pronounced','1':'inner','2':'visualized'},'time_windows_relative_to_direction_cue':{'pre':[-.5,0],'cue':[0,.5],'action':[1,3]},'features':'Log Welch power in fixed five bands, mean across channels removed within each trial/band; action-minus-pre difference. All EXG ear reference channels excluded.','spectral':'Welch Hann 128points,64overlap,128FFT,256Hz. Identical estimator across windows. Different averaging lengths remain a limitation.','split':'Leave true same-day session out; all target trials untouched during fitting. No target calibration. Direction balanced accuracy per condition; task balanced accuracy inner-v-visual.','primary':'Inner-versus-visual classification using relative power change, after train-only Ridge alpha10 adjustment for six EXG power-change features. Compare with pre-cue, cue, EXG-only and EMG-flag-clean controls.','secondary':['inner/visual direction decoding and cross-condition direction transfer, action relative power','pronounced-versus-inner action EEG/EXG positive procedural comparator'],'clean':'Exclude official EMG flagged trial indices from both train and test. Do not exclude according to classifier outcomes.','normalization':'All scalers and nuisance regressions fitted only on training subjects session partitions. Features themselves per trial without labels.','model':'LogisticRegression C1,max_iter2000,class_weight balanced,seed42; no HPO','total_fits':480,'rivals':['Task state is identifiable but word/direction content is not','Differences occur already before cue due condition-specific runs, preparation or drift','Eye/mouth signal predicts task state','Late scalp signal changes remain after measured peripheral association adjustment; still not proof of neural source'],'stopping':'No automatic modules or datasets. If controls match action or cross-session weak, no claimed biological discovery; record all outcomes. Strong controlled association requires independent replication and literature comparison before claim.','sources':['https://www.nature.com/articles/s41597-022-01147-2','https://sinc.unl.edu.ar/sinc-publications/2021/NPRKS21/sinc_NPRKS21.pdf'],'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'limitations':['Same-day sessions, not independent cohort','Condition-specific runs confound task and recording context','Spatial visual and linguistic direction contents share cues; language specificity not identifiable','Released noncausal filtering and session-wide ICA may spread temporal activity','EXG regression does not eliminate all artifacts and could remove genuine associations','Modality differences were already described in original dataset paper; simple rediscovery not new contribution']}
        p=OUT/'protocol.json'
        if p.exists():assert json.loads(p.read_text())==protocol
        else:save(p,protocol)
        (OUT/'fits').mkdir(exist_ok=True)
        try:
            for s in range(1,11):
                save(OUT/'status.json',{'state':'running','phase':'features','subject':s,'started':started,'updated':time.time(),'pid':os.getpid()});d=features(s)
                for ses in range(1,4):
                    source=d['session']!=ses;target=~source;cond=d['condition'];direction=d['direction']
                    for clean in [False,True]:
                        allowed=(cond==1)|(cond==2)
                        if clean:allowed=allowed&d['clean']
                        tr=np.flatnonzero(source&allowed);te=np.flatnonzero(target&allowed);y=(cond[tr]==1).astype(int);yy=(cond[te]==1).astype(int)
                        assert set(y)==set(yy)=={0,1}
                        sx=StandardScaler().fit(d['eeg_delta'][tr]);se=StandardScaler().fit(d['exg_delta'][tr]);xx=sx.transform(d['eeg_delta'][tr]);zz=sx.transform(d['eeg_delta'][te]);ee=se.transform(d['exg_delta'][tr]);ez=se.transform(d['exg_delta'][te]);reg=Ridge(alpha=10).fit(ee,xx);res=(xx-reg.predict(ee),zz-reg.predict(ez))
                        names=['eeg_delta','eeg_delta_residual'] if clean else ['eeg_pre','eeg_cue','eeg_action','eeg_delta','eeg_delta_residual','exg_pre','exg_action','exg_delta']
                        for name in names:
                            p=OUT/'fits'/f'sub{s:02d}_ses{ses}_state_{int(clean)}_{name}.json'
                            if p.exists():continue
                            x,z=res if name.endswith('residual') else (d[name][tr],d[name][te]);r=fit_score(x,z,y,yy)
                            save(p,{'subject':s,'session':ses,'task':'inner_vs_visual_clean' if clean else 'inner_vs_visual','feature':name,'train_idx':tr.tolist(),'test_idx':te.tolist(),**r})
                    for traincond,testcond in [(1,1),(2,2),(1,2),(2,1)]:
                        tr=np.flatnonzero(source&(cond==traincond));te=np.flatnonzero(target&(cond==testcond));name=f'direction_{traincond}_to_{testcond}';p=OUT/'fits'/f'sub{s:02d}_ses{ses}_{name}.json'
                        if not p.exists():save(p,{'subject':s,'session':ses,'task':name,'feature':'eeg_action','train_idx':tr.tolist(),'test_idx':te.tolist(),**fit_score(d['eeg_action'][tr],d['eeg_action'][te],direction[tr],direction[te])})
                    for name in ['eeg_action','exg_action']:
                        tr=np.flatnonzero(source&(cond!=2));te=np.flatnonzero(target&(cond!=2));p=OUT/'fits'/f'sub{s:02d}_ses{ses}_pronounced_vs_inner_{name}.json'
                        if not p.exists():save(p,{'subject':s,'session':ses,'task':'pronounced_vs_inner','feature':name,'train_idx':tr.tolist(),'test_idx':te.tolist(),**fit_score(d[name][tr],d[name][te],cond[tr],cond[te])})
                    n=len(list((OUT/'fits').glob('*.json')));save(OUT/'status.json',{'state':'running','phase':'fits','subject':s,'session':ses,'completed':n,'total':480,'started':started,'updated':time.time(),'pid':os.getpid(),'elapsed_seconds':time.time()-started,'estimated_remaining_seconds':(time.time()-started)*(480-n)/n});print('PHYSIO_SESSION_DONE',s,ses,n,flush=True)
                summary()
            summary();save(OUT/'status.json',{'state':'complete','completed':480,'total':480,'elapsed_seconds':time.time()-started,'updated':time.time()})
        except Exception as e:save(OUT/'status.json',{'state':'failed','error':repr(e),'updated':time.time()});raise
if __name__=='__main__':main()
