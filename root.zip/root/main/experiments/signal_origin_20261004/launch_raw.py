from pathlib import Path
import subprocess,sys,json
R=Path(__file__).resolve().parent
with (R/'raw_pilot.log').open('ab') as f:p=subprocess.Popen([sys.executable,str(R/'raw_pilot.py')],stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True,cwd=R)
(R/'raw_pilot.pid').write_text(str(p.pid));print(json.dumps({'pid':p.pid,'log':str(R/'raw_pilot.log')}))
