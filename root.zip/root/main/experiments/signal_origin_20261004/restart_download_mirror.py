from pathlib import Path
import os,signal,time,json,subprocess,sys
R=Path(__file__).resolve().parent;out=R/'raw_cohort';route=json.loads((out/'mirror_route.json').read_text());assert route['source_header_verified'] and route['require_original_size_MD5']
pid=int((R/'raw_cohort.pid').read_text());proc=Path(f'/proc/{pid}/cmdline')
if proc.exists():
    assert str(R/'raw_cohort.py').encode() in proc.read_bytes().split(b'\0');os.kill(pid,signal.SIGTERM)
    for _ in range(30):
        if not proc.exists():break
        time.sleep(.1)
stamp=int(time.time());p=out/'protocol.json'
if p.exists():p.replace(out/f'protocol_before_mirror_{stamp}.json')
(out/'download_config.json').write_text(json.dumps({'workers':12,'time':time.time(),'reason':'Pinned mirror raw headers match official; try12 persistent worker sessions with final originalMD5 verification, official fallback. Scientific endpoints unchanged.'}))
(out/f'download_amendment_{stamp}.json').write_text(json.dumps({'previous_pid':pid,'time':time.time(),'change':'Download route only, pinned mirror revision and persistent sessions; retain all completed official chunks, require final original size/MD5 before extraction. Scientific analysis unchanged.','route':route}))
subprocess.run([sys.executable,str(R/'launch_raw_cohort.py')],check=True)
