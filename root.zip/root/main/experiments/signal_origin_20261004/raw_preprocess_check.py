"""Technical preprocessing comparison, no one-subject discovery claim."""
from pathlib import Path
import os,json,pickle,time,hashlib
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import numpy as np,mne
from scipy.signal import butter,sosfilt,sosfilt_zi,sosfiltfilt,welch
from study import R,SRC,save
OUT=R/'raw_preprocess_check';OUT.mkdir(exist_ok=True)
BANDS=[(4,8),(8,13),(13,30)]
def power(x,fs):
    n=int(fs*.5);f,p=welch(x,fs=fs,nperseg=n,noverlap=n//2,nfft=n,detrend='constant',axis=-1)
    return np.stack([np.log(np.maximum(p[:,:,(f>=a)&(f<b)].sum(-1)*(fs/n),1e-18)) for a,b in BANDS],axis=1)
def main():
    started=time.time();audit=json.loads((R/'raw_pilot/audit.json').read_text());assert audit['technical_alignment_passed']
    protocol={'purpose':'Technical processing feasibility only, not a biological result','subject':1,'session':3,'trial_n':100,'filters':'Both fourth-order Butterworth0.5-45Hz; forward-only versus forward-backward. Ear-average scalp reference. No ICA.','buffer':'10 seconds before and after each direction event. Forward-filter state initialized at buffer start with first sample; no future samples used for earlier output. Not an exact whole-session causal pipeline.','windows':'Observed direction->action, action->relax, and preceding0.5s from real raw tags. Additionallate action excludes first1s after action trigger.','periphery':'Bipolar horizontalEOG EXG3-EXG4, verticalEOG EXG5-EXG6, mouthEXG7-EXG8','bands':BANDS,'features':'Log bandpower theta/alpha/beta, within-trial band-wise spatial mean subtraction for EEG; action-minus-pre-cue. No classifier tuning or fitting.','comparison':'Author released waveform only for matched late-action feature reference; differs in ICA/filter settings, not an isolated causal-effect estimate.','stop':'No one-subject hypothesis selection; technical pass requires aligned triggers/windows and finite features. Then freeze full-cohort scientific analysis separately.','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    save(OUT/'protocol.json',protocol)
    try:
        raw=mne.io.read_raw_bdf(R/'raw_pilot/sub-01_ses-03.bdf',preload=False,verbose='ERROR');fs=raw.info['sfreq'];assert fs==1024
        events=np.load(R/'raw_pilot/raw_events.npy');triggers=events[np.isin(events[:,2],[31,32,33,34])]
        folder=SRC/'sub-01'/'ses-03';pre='sub-01_ses-03'
        with (folder/(pre+'_events.dat')).open('rb') as f:meta=np.asarray(pickle.load(f,encoding='latin1'))
        ep=mne.read_epochs(folder/(pre+'_eeg-epo.fif'),preload=True,verbose='ERROR');der=ep.get_data(copy=True)*1e6
        assert np.array_equal(ep.events[:,0],meta[:,0]) and np.array_equal(triggers[:,0],meta[:,0])
        names=raw.ch_names;scalp=[names.index(n) for n in ep.ch_names];extra=[names.index('EXG'+str(i)) for i in range(1,9)];picks=scalp+extra
        sos=butter(4,[.5,45],fs=fs,btype='bandpass',output='sos');zi=sosfilt_zi(sos);data={'condition':meta[:,2],'direction':meta[:,1],'trial':np.arange(len(meta))};col={};timing=[]
        for j,(sample,_,label) in enumerate(triggers):
            following=events[(events[:,0]>sample)&(events[:,0]<sample+5*fs)]
            action=following[following[:,2]==44];relax=following[following[:,2]==45]
            assert len(action)==len(relax)==1 and action[0,0]<relax[0,0]
            a=int(action[0,0]);b=int(relax[0,0]);start=int(sample-10*fs);end=int(min(raw.n_times,sample+10*fs));assert start>=0
            x=raw.get_data(picks=picks,start=start,stop=end)*1e6;x[:128]-=x[128:130].mean(0)
            x=np.concatenate([x[:128],(x[130]-x[131])[None],(x[132]-x[133])[None],(x[134]-x[135])[None]])
            causal=sosfilt(sos,x,axis=-1,zi=zi[:,None,:]*x[:,0][None,:,None])[0];zero=sosfiltfilt(sos,x,axis=-1)
            windows={'pre':(int(sample-.5*fs),sample),'cue':(sample,a),'action':(a,b),'late_action':(a+int(fs),b)}
            assert all(v>u for u,v in windows.values())
            for method,z in [('forward',causal),('zero_phase',zero)]:
                for window,(u,v) in windows.items():
                    q=z[:,u-start:v-start];feat=power(q[None],fs)[0]
                    eeg=feat[:,:128];eeg=eeg-eeg.mean(1,keepdims=True)
                    col.setdefault(method+'/eeg/'+window,[]).append(eeg.reshape(-1));col.setdefault(method+'/bipolar_exg/'+window,[]).append(feat[:,128:].reshape(-1))
            late=(ep.times>=(a-sample)/fs+1)&(ep.times<(b-sample)/fs);assert late.sum()>=128
            feat=power(der[j:j+1,:,late],ep.info['sfreq'])[0];feat=feat-feat.mean(1,keepdims=True);col.setdefault('author/eeg/late_action',[]).append(feat.reshape(-1))
            timing.append({'trial':j,'direction_sample':int(sample),'action_sample':a,'relax_sample':b,'cue_seconds':(a-sample)/fs,'action_seconds':(b-a)/fs})
            save(OUT/'status.json',{'state':'running','completed_trials':j+1,'total_trials':100,'elapsed_seconds':time.time()-started,'updated':time.time()})
        data.update({k:np.array(v) for k,v in col.items()});assert all(np.isfinite(v).all() for v in data.values())
        for method in ['forward','zero_phase']:
            for kind in ['eeg','bipolar_exg']:data[f'{method}/{kind}/delta']=data[f'{method}/{kind}/late_action']-data[f'{method}/{kind}/pre']
        np.savez_compressed(OUT/'features.npz',**data)
        save(OUT/'audit.json',{'complete':True,'technical_passed':True,'n_trials':100,'scalp_names':ep.ch_names,'raw_source_sha256':audit['raw_sha256'],'timing':timing,'cue_duration_range': [min(r['cue_seconds'] for r in timing),max(r['cue_seconds'] for r in timing)],'action_duration_range':[min(r['action_seconds'] for r in timing),max(r['action_seconds'] for r in timing)],'finite_feature_arrays':True,'inference':'Timing and preprocessing pipeline usable in this recording. No biological effect, cross-subject reproducibility or novelty tested.'})
        save(OUT/'status.json',{'state':'complete','technical_passed':True,'elapsed_seconds':time.time()-started,'updated':time.time()});print('RAW_PREPROCESS_TECHNICAL_PASS',flush=True)
    except Exception as e:save(OUT/'status.json',{'state':'failed','error':repr(e),'updated':time.time()});raise
if __name__=='__main__':main()
