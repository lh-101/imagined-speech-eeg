"""Reuse saved direction predictions; only add missing matched direction controls."""
import os
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,time,hashlib,itertools,fcntl
import numpy as np
from sklearn.metrics import balanced_accuracy_score,confusion_matrix
from physiology import OUT as OLD,features,fit_score
from study import R,save
OUT=R/'content_audit';OUT.mkdir(exist_ok=True)
CONTROL=['eeg_cue','exg_action','eeg_delta']

def aggregate():
    rows=[];origins=[]
    for p in sorted((OLD/'fits').glob('*.json')):
        r=json.loads(p.read_text())
        if r['task'].startswith('direction_'):
            r['setting']=r['task'];rows.append(r);origins.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'reused':True})
    for p in sorted((OUT/'fits').glob('*.json')):
        rows.append(json.loads(p.read_text()));origins.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'reused':False})
    groups={};subject_rows=[]
    for setting in sorted({r['setting'] for r in rows}):
        groups[setting]={}
        for s in range(1,11):
            q=sorted([r for r in rows if r['subject']==s and r['setting']==setting],key=lambda r:r['session'])
            if len(q)!=3:continue
            y=np.concatenate([r['target'] for r in q]);p=np.concatenate([r['prediction'] for r in q]);ba=float(balanced_accuracy_score(y,p));groups[setting][s]=ba
            subject_rows.append({'setting':setting,'subject':s,'balanced_accuracy':ba,'n_test_trials':len(y),'session_balanced_accuracy':[r['balanced_accuracy'] for r in q],'confusion_counts_labels0123':confusion_matrix(y,p,labels=[0,1,2,3]).tolist()})
    definitions=[]
    for c in [1,2]:
        action=f'direction_{c}_to_{c}'
        for setting in [action]+[f'direction_{c}_{f}' for f in CONTROL]:definitions.append((setting+'-chance',setting,None))
        for f in CONTROL:definitions.append((action+'-minus-'+f,action,f'direction_{c}_{f}'))
        other=2 if c==1 else 1;definitions.append((f'within_task_{c}-minus-other_task_trained',action,f'direction_{other}_to_{c}'))
    stats=[]
    for label,a,b in definitions:
        keys=sorted(set(groups.get(a,{}))&(set(groups.get(b,{})) if b else set(range(1,11))))
        if len(keys)!=10:continue
        v=np.array([groups[a][s]-(groups[b][s] if b else .25) for s in keys]);signs=np.array(list(itertools.product([-1,1],repeat=10)))
        p=float((np.abs((signs*v).mean(1))>=abs(v.mean())-1e-12).mean());rng=np.random.default_rng(20261004);bs=v[rng.integers(0,10,(10000,10))].mean(1)
        stats.append({'comparison':label,'mean_difference_pp':float(v.mean()*100),'subject_bootstrap95_pp':(np.quantile(bs,[.025,.975])*100).tolist(),'p_exact_signflip_two_sided':p,'subjects':[{'subject':s,'difference_pp':float(x*100)} for s,x in zip(keys,v)]})
    ranked=sorted(stats,key=lambda r:r['p_exact_signflip_two_sided']);run=0.
    for i,r in enumerate(ranked):run=max(run,min(1,(len(ranked)-i)*r['p_exact_signflip_two_sided']));r['holm_all16']=run
    save(OUT/'summary.json',{'complete':len(rows)==300,'reused_fits':sum(x['reused'] for x in origins),'new_control_fits':sum(not x['reused'] for x in origins),'groups':[{'setting':k,'mean_balanced_accuracy_percent':float(np.mean(list(v.values()))*100),'n_subjects':len(v)} for k,v in groups.items() if v],'subjects':subject_rows,'comparisons':stats,'provenance':origins,'limits':['Existing cohort and direction results already inspected; descriptive/exploratory, not independent confirmation','Word and direction have one-to-one mapping; language specificity cannot be identified from these labels','Tasks in separate fixed-order runs; context can influence patterns','One-person training/testing; held-out real sessions avoid same-session fitting; no cross-person model','Action and cue windows unequal duration; weak performance cannot rank their biological strength','Five band features and linear decoder only; null result does not exclude all waveform/content information','Exact sign-flip assumes symmetric participant differences, not a full retraining label-permutation null','Derivative noncausal filtering and ICA; six peripheral channels contain scalp/brain mixtures too','Peripheral prediction or lack thereof is not proof of cortical source','Cross-task transfer near chance cannot establish shared representation']})

def main():
    with (OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);started=time.time();(OUT/'fits').mkdir(exist_ok=True)
        assert len(list((OLD/'fits').glob('*direction_*.json')))==120
        protocol={'claim':'Exploratory direction-content evidence audit, not new biological discovery','reuse':'All120previouslycompleted within-task and cross-task direction fits; no retraining','add':'180missing matched direction fits:10subjects×3heldreal sessions×2taskconditions×3features(eeg_cue,exg_action,eeg_delta). Cached waveform-derived fixed features reused.','feature_definition':'Identical existing5band spatiallyrelative logpower; eeg_delta=action1-3s minus precue-.5-0s; eeg_cue0-.5s; EXGaction1-3s excluding ear references. Delta not artifact removal.','model':'Same train-only StandardScaler+LogisticRegression C1,class_weightbalanced,max_iter2000,seed42; no optimization. Four numeric direction classes0123, no new linguistic labels.','split':'Within each participant, train2sessions,testremaining1; same labelled target trials as reused predictions. Never cross-person model.','statistics':'16fixed paired comparisons including abovechance25%,action-vs-cue/peripheral/delta and within-vs-other-task training. Participant pooledOOF balancedaccuracy, equalparticipantmean, bootstrap10000,exacttwo-sided signflip symmetricdifferences assumption,Holmall16. No interim significance decisions.','stopping':'Run180newfits once; retainallresults. No band/window/task tuning afterresults. If evidence fails, content-specific claim unsupported by this representation.','novelty':'Notestablished; audit of alreadyobserveddata. Samecue word/direction confound prevents standalone language-mechanism claim.','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'started':started}
        if not (OUT/'protocol.json').exists():save(OUT/'protocol.json',protocol)
        try:
            for s in range(1,11):
                d=features(s);c=d['condition'];y=d['direction']
                for ses in range(1,4):
                    for condition in [1,2]:
                        tr=np.flatnonzero((d['session']!=ses)&(c==condition));te=np.flatnonzero((d['session']==ses)&(c==condition))
                        assert set(y[tr])==set(y[te])=={0,1,2,3} and not set(tr)&set(te)
                        old=json.loads((OLD/'fits'/f'sub{s:02d}_ses{ses}_direction_{condition}_to_{condition}.json').read_text());assert old['test_idx']==te.tolist() and old['target']==y[te].tolist()
                        for feature in CONTROL:
                            setting=f'direction_{condition}_{feature}';p=OUT/'fits'/f'sub{s:02d}_ses{ses}_{setting}.json'
                            if not p.exists():save(p,{'subject':s,'session':ses,'setting':setting,'feature':feature,'train_idx':tr.tolist(),'test_idx':te.tolist(),**fit_score(d[feature][tr],d[feature][te],y[tr],y[te])})
                    n=len(list((OUT/'fits').glob('*.json')));save(OUT/'status.json',{'state':'running','completed_new_fits':n,'total_new_fits':180,'elapsed_seconds':time.time()-started,'estimated_remaining_seconds':(time.time()-started)*(180-n)/n,'pid':os.getpid(),'updated':time.time()})
                aggregate();print('CONTENT_SUBJECT_DONE',s,n,flush=True)
            aggregate();save(OUT/'status.json',{'state':'complete','completed_new_fits':180,'reused_fits':120,'elapsed_seconds':time.time()-started,'updated':time.time()});print('CONTENT_AUDIT_COMPLETE',flush=True)
        except Exception as e:save(OUT/'status.json',{'state':'failed','error':repr(e),'updated':time.time()});raise
if __name__=='__main__':main()
