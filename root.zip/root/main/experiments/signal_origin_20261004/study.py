"""Bounded retrospective signal-origin diagnostic. No neural training."""
from pathlib import Path
import os,json,time,pickle,hashlib,sys
os.environ['OMP_NUM_THREADS']='1'
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['MKL_NUM_THREADS']='1'
import numpy as np
from scipy.io import loadmat,whosmat
import mne
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import balanced_accuracy_score,accuracy_score
R=Path('/root/FAST/experiments/signal_origin_20261004');R.mkdir(exist_ok=True)
SRC=Path('/root/FAST/experiments/nature_stage_20261002/inner_data/ds003626/derivatives')
WINDOWS={'pre_direction_cue':[-.5,0.],'direction_cue':[0.,.5], 'early_action':[.5,1.], 'late_action':[2.5,3.], 'full_action':[.5,3.], 'relax':[3.,4.]}
def save(p,d):
    t=p.with_suffix('.tmp');t.write_text(json.dumps(d,indent=2));t.replace(p)
def audit():
    main=[]
    for s in range(1,16):
        for split,key in [('Training set','epo_train'),('Validation set','epo_validation')]:
            p=Path('/root/FAST/BCIC2020Track3')/split/f'Data_Sample{s:02d}.mat'
            d=loadmat(p,simplify_cells=True);e=d[key]
            row={'subject':s,'split':split,'top_keys':[k for k in d if not k.startswith('__')], 'epoch_fields':list(e)}
            for k,v in e.items():
                a=np.asarray(v);row[k]={'shape':list(a.shape),'dtype':str(a.dtype)}
                if a.size<=140:row[k]['values']=a.tolist()
                if k in ['t','time','times'] and a.size:row[k]['range']=[float(a.min()),float(a.max())]
            main.append(row)
    inner=[]
    for s in range(1,11):
        for ses in range(1,4):
            pre=f'sub-{s:02d}_ses-{ses:02d}';p=SRC/f'sub-{s:02d}'/f'ses-{ses:02d}'
            with (p/(pre+'_events.dat')).open('rb') as f:ev=np.asarray(pickle.load(f,encoding='latin1'))
            e=mne.read_epochs(p/(pre+'_eeg-epo.fif'),preload=False,verbose='ERROR');z=mne.read_epochs(p/(pre+'_exg-epo.fif'),preload=False,verbose='ERROR')
            assert ev.shape==(len(e),4) and np.all(ev[:,3]==ses)
            assert np.array_equal(e.events[:,0],ev[:,0]) and np.array_equal(e.events[:,2],ev[:,1]+31)
            assert np.array_equal(e.events,z.events) and np.array_equal(e.times,z.times)
            keep=ev[:,2]==1
            assert set(ev[keep,1])=={0,1,2,3}
            inner.append({'subject':s,'session':ses,'time_range':[e.tmin,e.tmax],'sfreq':e.info['sfreq'],'inner_counts':np.bincount(ev[keep,1],minlength=4).tolist(),'exg_names':z.ch_names,'windows_samples':{k:int(((e.times>=a)&(e.times<b)).sum()) for k,(a,b) in WINDOWS.items()},'alignment_verified':True})
    save(R/'metadata_audit.json',{'main_dataset':main,'inner_dataset':inner,'note':'Training/validation partition is not asserted to be an acquisition session. Inner dataset session identifiers are supplied by released event metadata. No fabricated blocks.'})
    print('AUDIT_DONE',len(main),len(inner),flush=True)
def features(s):
    dest=R/f'features_sub{s:02d}.npz'
    if dest.exists():
        with np.load(dest) as f:return {k:f[k] for k in f.files}
    parts=[]
    for ses in range(1,4):
        pre=f'sub-{s:02d}_ses-{ses:02d}';p=SRC/f'sub-{s:02d}'/f'ses-{ses:02d}'
        with (p/(pre+'_events.dat')).open('rb') as f:ev=np.asarray(pickle.load(f,encoding='latin1'))
        keep=np.flatnonzero(ev[:,2]==1);d={'y':ev[keep,1],'session':np.full(len(keep),ses),'sample':ev[keep,0],'trial':keep}
        for kind,suffix in [('eeg','_eeg-epo.fif'),('exg','_exg-epo.fif')]:
            ep=mne.read_epochs(p/(pre+suffix),preload=False,verbose='ERROR')[keep].load_data();x=ep.get_data(copy=True)*1e6
            for name,(a,b) in WINDOWS.items():
                ix=(ep.times>=a)&(ep.times<b);assert ix.any()
                d[f'{kind}/{name}']=x[:,:,ix].mean(-1).astype(np.float64)
            d[f'{kind}/baseline_corrected_action']=d[f'{kind}/full_action']-d[f'{kind}/pre_direction_cue']
        parts.append(d)
    d={k:np.concatenate([p[k] for p in parts]) for k in parts[0]};assert all(np.isfinite(v).all() for v in d.values())
    np.savez_compressed(dest,**d);return d
def summarize():
    rows=[json.loads(p.read_text()) for p in (R/'fits').glob('*.json')];groups=[]
    for mode in ['trial_cv','session_holdout']:
        for feature in sorted({r['feature'] for r in rows}):
            subjects=[]
            for s in range(1,11):
                a=[r for r in rows if r['subject']==s and r['mode']==mode and r['feature']==feature]
                if len(a)==(5 if mode=='trial_cv' else 3):
                    with np.load(R/f'features_sub{s:02d}.npz') as f:y=f['y']
                    pred=np.full(len(y),-1,dtype=int)
                    for r in a:pred[np.array(r['test_idx'])]=r['pred']
                    assert np.all(pred>=0)
                    subjects.append({'subject':s,'balanced_accuracy':float(balanced_accuracy_score(y,pred)),'accuracy':float(accuracy_score(y,pred))})
            groups.append({'mode':mode,'feature':feature,'subjects':subjects,'mean_balanced_accuracy':float(np.mean([s['balanced_accuracy'] for s in subjects])) if subjects else None})
    save(R/'summary.json',{'complete':len(rows)==1120,'completed_fits':len(rows),'total_fits':1120,'groups':groups,'unit':'fraction, not percent','aggregation':'Full out-of-fold predictions per subject then equal subject mean; each trial tested once per feature/protocol.'})
def run():
    import fcntl
    with (R/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        started=time.time();protocol={'subjects':10,'sessions':3,'windows_event_relative_seconds':WINDOWS,'event_zero':'Direction-cue onset; source acquisition action begins +0.5s and ends +3.0s on released epoch axis','features':'Per-channel time mean EEG128 and EXG8, each window; full action minus pre-direction-cue mean additionally','models':'Training-only StandardScaler + LogisticRegression(C=1,max_iter=2000,random_state=42). No tuning.','split':'Pooled within-subject stratified fivefold shuffle seed42 compared with three leave-real-session-out folds; shared splits across all features. Whole trial unit.','total_fits':1120,'primary_comparisons':['pre_direction_cue versus full_action EEG means','trial_cv versus real_session_holdout full_action EEG means'],'secondary':'Cue, early/late action, relaxation, baseline correction and EXG are descriptive rival-explanation controls. No best-window selection.','limitations':['Retrospective exploration on already observed subjects; no independent confirmation','Same-day sessions, not cross-day','Released derivatives use noncausal filtering and session-wide ICA; pre-cue activity may include temporal smearing','Visual direction cue confounds semantic class; action signal alone is not speech specificity','No signal-origin causal attribution from classification','Full action 2.5s versus pre-cue0.5s differs in averaging duration','Main dataset may lack real block identifiers; never infer these from row ordering'],'source':'https://www.nature.com/articles/s41597-022-01147-2','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
        p=R/'protocol.json'
        if p.exists():assert json.loads(p.read_text())==protocol
        else:save(p,protocol)
        (R/'fits').mkdir(exist_ok=True)
        try:
            for s in range(1,11):
                save(R/'status.json',{'state':'running','phase':'features','subject':s,'started':started,'updated':time.time(),'pid':os.getpid()})
                d=features(s);y=d['y'];idx=np.arange(len(y));names=sorted(k for k in d if '/' in k);assert len(names)==14
                splits={'trial_cv':list(StratifiedKFold(5,shuffle=True,random_state=42).split(idx,y)), 'session_holdout':[(idx[d['session']!=ses],idx[d['session']==ses]) for ses in range(1,4)]}
                for mode,folds in splits.items():
                    for fi,(tr,te) in enumerate(folds):
                        assert not set(tr)&set(te) and set(y[tr])==set(y[te])=={0,1,2,3}
                        for name in names:
                            p=R/'fits'/f'sub{s:02d}_{mode}_fold{fi}_{name.replace("/","_")}.json'
                            if p.exists():continue
                            x=d[name];m=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=2000,random_state=42));m.fit(x[tr],y[tr]);pred=m.predict(x[te])
                            save(p,{'subject':s,'mode':mode,'fold':fi,'feature':name,'train_idx':tr.tolist(),'test_idx':te.tolist(),'pred':pred.tolist(),'balanced_accuracy':float(balanced_accuracy_score(y[te],pred)),'training_balanced_accuracy':float(balanced_accuracy_score(y[tr],m.predict(x[tr])))})
                        n=len(list((R/'fits').glob('*.json')));save(R/'status.json',{'state':'running','phase':'fits','subject':s,'completed':n,'total':1120,'started':started,'updated':time.time(),'pid':os.getpid(),'elapsed_seconds':time.time()-started,'estimated_remaining_seconds':(time.time()-started)*(1120-n)/n if n else None})
                        print('FOLD_DONE',s,mode,fi,n,flush=True)
                summarize()
            summarize();save(R/'status.json',{'state':'complete','completed':1120,'total':1120,'started':started,'updated':time.time(),'elapsed_seconds':time.time()-started})
        except Exception as e:
            save(R/'status.json',{'state':'failed','error':repr(e),'updated':time.time()});raise
if __name__=='__main__':
    if '--audit' in sys.argv:audit()
    else:run()
