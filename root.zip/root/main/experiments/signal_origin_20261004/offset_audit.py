from pathlib import Path
import os,time,json,hashlib
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import numpy as np
from scipy.io import loadmat
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge,LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import balanced_accuracy_score
from study import R,save
OUT=R/'offset_audit';OUT.mkdir(exist_ok=True)
def main():
    started=time.time();save(OUT/'protocol.json',{'subjects':15,'features':['visible_mean_spatially_centered','visible_mean_channel_common','post_mean_pre_mean_residual','pre_mean_post_mean_residual'],'purpose':'Distinguish channel-common reference level, spatial pattern, and trial-stable component; not source localization','splits':'Trial fivefold seed42 and official train->validation; no invented block labels','models':'StandardScaler+LogisticRegression C1 max_iter2000; residual Ridge alpha10 fitted in training only','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'limits':'No causal attribution, no independence of unknown repeat groups, retrospective exploration; numerical units are released MAT units and not newly asserted physiological units.'})
    rows=[];stats=[]
    for s in range(1,16):
        parts=[]
        for split,key in [('Training set','epo_train'),('Validation set','epo_validation')]:
            e=loadmat(Path('/root/FAST/BCIC2020Track3')/split/f'Data_Sample{s:02d}.mat',simplify_cells=True)[key];x=e['x'].transpose(2,1,0);t=e['t']/1000
            pre=x[:,:,(t>=-.5)&(t<0)].mean(-1);post=x[:,:,(t>=0)&(t<2.4)].mean(-1);mean=x[:,:,:750].mean(-1)
            parts.append({'y':e['y'].argmax(0),'pre':pre,'post':post,'mean':mean,'dynamic_std':x[:,:,:750].std(-1)})
        n=len(parts[0]['y']);d={k:np.concatenate([p[k] for p in parts]) for k in parts[0]};y=d['y'];m=d['mean'];pre=d['pre'];post=d['post'];idx=np.arange(len(y))
        corr=[]
        for c in range(64):
            if pre[:,c].std()>0 and post[:,c].std()>0:corr.append(float(np.corrcoef(pre[:,c],post[:,c])[0,1]))
        stats.append({'subject':s,'median_channel_pre_post_correlation':float(np.median(corr)),'median_abs_mean':float(np.median(np.abs(m))),'median_dynamic_std':float(np.median(d['dynamic_std'])),'median_abs_mean_to_dynamic_std':float(np.median(np.abs(m)/np.maximum(d['dynamic_std'],1e-12))),'spatial_common_fraction_squared_mean':float(np.sum(m.mean(1)**2)*64/np.maximum(np.sum(m*m),1e-12))})
        for mode,folds in {'trial_cv':list(StratifiedKFold(5,shuffle=True,random_state=42).split(idx,y)),'official_partition':[(idx[:n],idx[n:])]}.items():
            predictions={k:[] for k in ['visible_mean_spatially_centered','visible_mean_channel_common','post_mean_pre_mean_residual','pre_mean_post_mean_residual']};targets=[]
            for tr,te in folds:
                targets.extend(y[te]);fs={'visible_mean_spatially_centered':(m[tr]-m[tr].mean(1,keepdims=True),m[te]-m[te].mean(1,keepdims=True)),'visible_mean_channel_common':(m[tr].mean(1,keepdims=True),m[te].mean(1,keepdims=True))}
                for name,a,b in [('post_mean_pre_mean_residual',post,pre),('pre_mean_post_mean_residual',pre,post)]:
                    sa=StandardScaler().fit(a[tr]);sb=StandardScaler().fit(b[tr]);aa=sa.transform(a[tr]);az=sa.transform(a[te]);bb=sb.transform(b[tr]);bz=sb.transform(b[te]);reg=Ridge(alpha=10).fit(bb,aa);fs[name]=(aa-reg.predict(bb),az-reg.predict(bz))
                for name,(xx,zz) in fs.items():
                    model=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=2000,random_state=42));model.fit(xx,y[tr]);predictions[name].extend(model.predict(zz).tolist())
            for name,pred in predictions.items():rows.append({'subject':s,'mode':mode,'feature':name,'balanced_accuracy':float(balanced_accuracy_score(targets,pred))})
        save(OUT/'results.json',{'complete':s==15,'completed_subjects':s,'total_subjects':15,'rows':rows,'numerical_stats':stats});save(OUT/'status.json',{'state':'complete' if s==15 else 'running','subject':s,'elapsed_seconds':time.time()-started,'updated':time.time()});print('OFFSET_SUBJECT_DONE',s,flush=True)
if __name__=='__main__':main()
