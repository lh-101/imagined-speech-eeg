"""Audit raw availability and event identifiability without downloading recordings."""
from pathlib import Path
import requests,json,time,hashlib,xml.etree.ElementTree as ET,csv,io
from concurrent.futures import ThreadPoolExecutor,as_completed
R=Path('/root/FAST/experiments/signal_origin_20261004/raw_metadata');R.mkdir(exist_ok=True)
BASE='https://s3.amazonaws.com/openneuro.org/';NS={'s':'http://s3.amazonaws.com/doc/2006-03-01/'}
def save(name,obj):
    p=R/name;t=p.with_suffix('.tmp');t.write_text(json.dumps(obj,indent=2));t.replace(p)
def listing(prefix):
    files=[];token=None
    while True:
        pars={'list-type':'2','prefix':prefix}
        if token:pars['continuation-token']=token
        r=requests.get(BASE,params=pars,timeout=(10,30));r.raise_for_status();tree=ET.fromstring(r.content)
        for x in tree.findall('s:Contents',NS):files.append({'key':x.findtext('s:Key',namespaces=NS),'size':int(x.findtext('s:Size',namespaces=NS)),'etag':x.findtext('s:ETag',namespaces=NS).strip('"')})
        token=tree.findtext('s:NextContinuationToken',namespaces=NS)
        if not token:break
    return files
def fetch(obj):
    key=obj['key'];dest=R/key;dest.parent.mkdir(parents=True,exist_ok=True)
    if key.endswith('.bdf'):
        # Read header only. Do not download full BDF if Range is ignored.
        res=requests.get(BASE+key,headers={'Range':'bytes=0-65535','If-Match':'"'+obj['etag']+'"'},stream=True,timeout=(10,30))
        assert res.status_code==206 and res.headers.get('Content-Range','').startswith('bytes 0-'), 'Range not honored'
        body=res.raw.read(65536);res.close();dest=dest.with_suffix('.header');dest.write_bytes(body)
        assert len(body)>=256
        n=int(body[252:256]);size=int(body[184:192]);assert 256+256*n==size and size<=len(body)
        pos=256;fields={}
        for name,width in [('label',16),('transducer',80),('unit',8),('physical_min',8),('physical_max',8),('digital_min',8),('digital_max',8),('prefilter',80),('samples_per_record',8),('reserved',32)]:
            fields[name]=[body[pos+i*width:pos+(i+1)*width].decode('latin1').strip() for i in range(n)];pos+=n*width
        return {'key':key,'bytes_read':len(body),'raw_bytes':obj['size'],'header':{'channels':n,'record_duration':body[244:252].decode('latin1').strip(),'records':body[236:244].decode('latin1').strip(),'fields':fields},'sha256_header_read':hashlib.sha256(body).hexdigest()}
    assert obj['size']<=2*1024*1024,'Metadata only'
    res=requests.get(BASE+key,headers={'If-Match':'"'+obj['etag']+'"'},timeout=(10,30));res.raise_for_status();assert len(res.content)==obj['size'];dest.write_bytes(res.content)
    row={'key':key,'bytes_read':len(res.content),'sha256':hashlib.sha256(res.content).hexdigest()}
    if key.endswith('_events.tsv'):
        rows=list(csv.DictReader(io.StringIO(res.text),delimiter='\t'));row.update({'columns':list(rows[0]) if rows else [],'n_events':len(rows),'first_events':rows[:12],'unique_fields':{k:sorted({r[k] for r in rows})[:100] for k in rows[0] if k not in ['onset','duration','sample']} if rows else {}})
    elif key.endswith('.json'):row['json']=res.json()
    return row
def main():
    started=time.time();save('status.json',{'state':'running','phase':'listing','started':started})
    try:
        allfiles=listing('ds003626/sub-');save('raw_inventory.json',{'files':allfiles,'raw_total_bytes':sum(x['size'] for x in allfiles if x['key'].endswith('.bdf')),'note':'Mutable official S3 snapshot pinned at retrieval by ETag; no assumed OpenNeuro release identifier.'})
        selected=[x for x in allfiles if x['key'].endswith(('.bdf','.tsv','.json')) and (x['key'].endswith('.bdf') or x['size']<=2*1024*1024)]
        headers=[x for x in selected if x['key'].endswith('.bdf')];assert len(headers)==30,'Expected 10 subjects x3 real sessions'
        done=[];errors=[]
        with ThreadPoolExecutor(max_workers=4) as pool:
            futures={pool.submit(fetch,x):x for x in selected}
            for f in as_completed(futures):
                try:done.append(f.result())
                except Exception as e:errors.append({'key':futures[f]['key'],'error':repr(e)})
                save('audit.json',{'complete':False,'results':done,'errors':errors});save('status.json',{'state':'running','phase':'fetch','completed':len(done)+len(errors),'total':len(selected),'started':started,'updated':time.time()});print('METADATA_DONE',len(done),len(errors),len(selected),flush=True)
        save('audit.json',{'complete':True,'results':done,'errors':errors,'elapsed_seconds':time.time()-started,'downloaded_bytes':sum(x['bytes_read'] for x in done),'all_raw_bytes_if_downloaded':sum(x['size'] for x in headers),'raw_recordings_downloaded':False})
        save('status.json',{'state':'complete','completed':len(done),'failed_files':len(errors),'elapsed_seconds':time.time()-started,'updated':time.time()})
    except Exception as e:save('status.json',{'state':'failed','error':repr(e),'updated':time.time()});raise
if __name__=='__main__':main()
