from pathlib import Path
import requests,time,json
R=Path('/root/FAST/experiments/signal_origin_20261004/raw_cohort')
repo='raei/Nieto-2022-ThinkingOutLoudOpenAccessEEGBasedBCIDatasetInnerSpeech'
rows=[]
for base in ['https://hf-mirror.com','https://huggingface.co']:
    start=time.time()
    try:
        res=requests.get(base+'/api/datasets/'+repo,timeout=(5,12));res.raise_for_status();j=res.json();files=[x['rfilename'] for x in j.get('siblings',[])];row={'base':base,'passed':True,'revision':j.get('sha'),'n_files':len(files),'raw_files':[f for f in files if f.endswith('.bdf')],'metadata_files':[f for f in files if f.endswith(('.md','.tsv','.json'))][:20],'seconds':time.time()-start}
    except Exception as e:row={'base':base,'passed':False,'error':repr(e),'seconds':time.time()-start}
    rows.append(row);print(json.dumps(row),flush=True)
(R/'mirror_probe.json').write_text(json.dumps(rows,indent=2))
