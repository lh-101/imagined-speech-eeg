from pathlib import Path
import subprocess,sys,os,json,time
R=Path(__file__).resolve().parent
if '--worker' in sys.argv:
    with (R/'queue.lock').open('w') as lock:
        import fcntl
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        for name in ['main_probe.py','study.py']:
            (R/'queue_status.json').write_text(json.dumps({'state':'running','job':name,'pid':os.getpid(),'updated':time.time()}))
            rc=subprocess.call([sys.executable,str(R/name)],env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1'))
            if rc:
                (R/'queue_status.json').write_text(json.dumps({'state':'failed','job':name,'exit_code':rc,'updated':time.time()}));sys.exit(rc)
        (R/'queue_status.json').write_text(json.dumps({'state':'complete','updated':time.time()}))
else:
    with (R/'run.log').open('ab') as f:
        p=subprocess.Popen([sys.executable,str(Path(__file__)),'--worker'],stdout=f,stderr=subprocess.STDOUT,start_new_session=True,stdin=subprocess.DEVNULL,cwd=R,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1'))
    (R/'queue.pid').write_text(str(p.pid));print(json.dumps({'started':True,'pid':p.pid,'log':str(R/'run.log')}))
