"""Frozen raw cohort analysis, rolling bounded cache, no neural model search."""
from pathlib import Path
import os,json,time,pickle,hashlib,shutil,itertools,fcntl,threading
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
import requests,numpy as np,mne
from scipy.signal import butter,sosfilt,sosfilt_zi,sosfiltfilt,welch
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from concurrent.futures import ThreadPoolExecutor,as_completed
from study import R,SRC,save
OUT=R/'raw_cohort';OUT.mkdir(exist_ok=True);CACHE=OUT/'download_cache';CACHE.mkdir(exist_ok=True)
BANDS=[(4,8),(8,13),(13,30)]
def download(obj):
    key=obj['key'];label=key.split('/')[1]+'_'+key.split('/')[2];folder=CACHE/label;folder.mkdir(exist_ok=True);p=folder/'record.bdf'
    assert folder.resolve().parent==CACHE.resolve()
    spec=[(i,a,min(a+8*1024**2,obj['size'])-1) for i,a in enumerate(range(0,obj['size'],8*1024**2))]
    mirror=json.loads((OUT/'mirror_route.json').read_text()) if (OUT/'mirror_route.json').exists() else None
    threadstate=threading.local()
    def part(item):
        i,a,b=item;q=folder/f'{i:04d}.part'
        if q.exists() and q.stat().st_size==b-a+1:return
        for attempt in range(4):
            try:
                if not hasattr(threadstate,'session'):threadstate.session=requests.Session()
                url=mirror['base']+key.removeprefix(mirror['strip_prefix']) if mirror and attempt<3 else 'https://s3.amazonaws.com/openneuro.org/'+key
                headers={'Range':f'bytes={a}-{b}'}
                if not (mirror and attempt<3):headers['If-Match']='"'+obj['etag']+'"'
                resp=threadstate.session.get(url,headers=headers,stream=True,timeout=(10,60));resp.raise_for_status();assert resp.status_code==206 and resp.headers.get('Content-Range','').startswith(f'bytes {a}-{b}/')
                with q.with_suffix('.tmp').open('wb') as f:
                    for block in resp.iter_content(1024**2):f.write(block)
                resp.close();assert q.with_suffix('.tmp').stat().st_size==b-a+1;q.with_suffix('.tmp').replace(q);return
            except Exception:
                if attempt==3:raise
    if not p.exists() or p.stat().st_size!=obj['size']:
        assert shutil.disk_usage(OUT).free>obj['size']*2+1024**3
        before=sum(q.stat().st_size for q in folder.glob('*.part'));start=time.time()
        config=json.loads((OUT/'download_config.json').read_text()) if (OUT/'download_config.json').exists() else {}
        with ThreadPoolExecutor(max_workers=int(config.get('workers',12))) as pool:
            futures=[pool.submit(part,x) for x in spec]
            for f in as_completed(futures):
                f.result();n=sum(q.stat().st_size for q in folder.glob('*.part'));elapsed=time.time()-start;speed=(n-before)/max(elapsed,1)
                save(OUT/'download_status.json',{'state':'downloading','record':label,'bytes':n,'total_bytes':obj['size'],'new_bytes_per_second':speed,'route':'pinned_verified_mirror_with_official_fallback' if mirror else 'official_S3','estimated_record_remaining_seconds':(obj['size']-n)/speed if speed>0 else None,'updated':time.time()})
        with p.with_suffix('.tmp').open('wb') as f:
            for i,_,_ in spec:
                with (folder/f'{i:04d}.part').open('rb') as g:shutil.copyfileobj(g,f,4*1024**2)
        p.with_suffix('.tmp').replace(p)
    md5=hashlib.md5();sha=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(4*1024**2),b''):md5.update(b);sha.update(b)
    assert p.stat().st_size==obj['size']
    if '-' not in obj['etag']:assert md5.hexdigest()==obj['etag']
    return p,sha.hexdigest(),folder
def power(x,fs):
    n=int(fs*.5);f,p=welch(x,fs=fs,nperseg=n,noverlap=n//2,nfft=n,detrend='constant',axis=-1)
    return np.stack([np.log(np.maximum(p[:,:,(f>=a)&(f<b)].sum(-1)*(fs/n),1e-18)) for a,b in BANDS],axis=1)
def extract(subject,session,path,dest,sha):
    raw=mne.io.read_raw_bdf(path,preload=False,verbose='ERROR');fs=raw.info['sfreq'];assert fs==1024
    events=mne.find_events(raw,stim_channel='Status',shortest_event=1,mask=65535,mask_type='and',initial_event=True,verbose='ERROR')
    pre=f'sub-{subject:02d}_ses-{session:02d}';folder=SRC/f'sub-{subject:02d}'/f'ses-{session:02d}'
    with (folder/(pre+'_events.dat')).open('rb') as f:meta=np.asarray(pickle.load(f,encoding='latin1'))
    with (folder/(pre+'_report.pkl')).open('rb') as f:report=pickle.load(f,encoding='latin1')
    ep=mne.read_epochs(folder/(pre+'_eeg-epo.fif'),preload=True,verbose='ERROR');der=ep.get_data(copy=True)*1e6
    assert np.array_equal(ep.events[:,0],meta[:,0]);assert np.array_equal(ep.events[:,2],meta[:,1]+31)
    lookup={int(e[0]):int(e[2]) for e in events if e[2] in [31,32,33,34]};assert all(lookup.get(int(r[0]))==int(r[1])+31 for r in meta),'Raw label/timing differs; stop, do not infer'
    flags=np.asarray(report.get('EMG_trials',[]),dtype=int).ravel();assert not len(flags) or (flags.min()>=0 and flags.max()<len(meta))
    scalp=[raw.ch_names.index(n) for n in ep.ch_names];extra=[raw.ch_names.index('EXG'+str(i)) for i in range(1,9)];sos=butter(4,[.5,45],fs=fs,btype='bandpass',output='sos');zi=sosfilt_zi(sos)
    data={'condition':meta[:,2],'direction':meta[:,1],'trial':np.arange(len(meta)),'clean':~np.isin(np.arange(len(meta)),flags)};cols={};timing=[]
    for j,r in enumerate(meta):
        sample=int(r[0]);following=events[(events[:,0]>sample)&(events[:,0]<sample+5*fs)];act=following[following[:,2]==44];rel=following[following[:,2]==45];assert len(act)==len(rel)==1
        a=int(act[0,0]);b=int(rel[0,0]);start=int(sample-10*fs);end=int(min(raw.n_times,sample+10*fs));assert start>=0 and b>a+fs
        x=raw.get_data(picks=scalp+extra,start=start,stop=end)*1e6;x[:128]-=x[128:130].mean(0)
        x=np.concatenate([x[:128],(x[130]-x[131])[None],(x[132]-x[133])[None],(x[134]-x[135])[None]])
        zf=sosfilt(sos,x,axis=-1,zi=zi[:,None,:]*x[:,0][None,:,None])[0];zz=sosfiltfilt(sos,x,axis=-1)
        for method,z in [('forward',zf),('zero_phase',zz)]:
            for name,(u,v) in {'pre':(int(sample-.5*fs),sample),'cue':(sample,a),'late':(a+int(fs),b)}.items():
                feat=power(z[None,:,u-start:v-start],fs)[0];eeg=feat[:,:128];eeg=eeg-eeg.mean(1,keepdims=True)
                cols.setdefault(method+'/eeg/'+name,[]).append(eeg.reshape(-1));cols.setdefault(method+'/exg/'+name,[]).append(feat[:,128:].reshape(-1))
        late=(ep.times>=(a-sample)/fs+1)&(ep.times<(b-sample)/fs);assert late.sum()>=128
        feat=power(der[j:j+1,:,late],ep.info['sfreq'])[0];cols.setdefault('author/eeg/late',[]).append((feat-feat.mean(1,keepdims=True)).reshape(-1))
        timing.append({'trial':j,'direction_sample':sample,'action_sample':a,'relax_sample':b,'condition':int(r[2]),'direction':int(r[1])})
    data.update({k:np.array(v) for k,v in cols.items()});assert all(np.isfinite(x).all() for x in data.values())
    for method in ['forward','zero_phase']:
        for kind in ['eeg','exg']:data[method+'/'+kind+'/delta']=data[method+'/'+kind+'/late']-data[method+'/'+kind+'/pre']
    with dest.with_suffix('.tmp').open('wb') as f:np.savez_compressed(f,**data)
    dest.with_suffix('.tmp').replace(dest)
    save(dest.with_suffix('.json'),{'subject':subject,'session':session,'raw_sha256':sha,'features_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'n_trials':len(meta),'raw_alignment_passed':True,'scalp_names':ep.ch_names,'timing':timing,'note':'Features are scalp associations, not cortical source estimates.'})
def contrast(d,x):
    vals=[]
    for direction in range(4):
        a=x[(d['condition']==1)&(d['direction']==direction)];b=x[(d['condition']==2)&(d['direction']==direction)]
        assert len(a)>0 and len(b)>0;vals.append(float(a.mean()-b.mean()))
    return float(np.mean(vals))
def analyze():
    paths=sorted((OUT/'features').glob('*.npz'));geometry=json.loads((R.parent/'nature_stage_20261002/inner_prepared/geometry.json').read_text());names=geometry['channels'];groups=geometry['zone_dict']
    definitions=[('central_beta',2,[names.index(n) for n in groups['Central']]),('occipital_alpha',1,[names.index(n) for n in groups['Occipital']])]
    data={};rows=[]
    for p in paths:
        s=int(p.stem.split('_')[0][3:]);ses=int(p.stem.split('_')[1][3:])
        with np.load(p) as f:d={k:f[k] for k in f.files}
        data[s,ses]=d
        for method in ['forward','zero_phase']:
            for name,band,channels in definitions:
                for window in ['pre','cue','late','delta']:
                    x=d[f'{method}/eeg/{window}'].reshape(len(d['condition']),3,128)[:,band,channels].mean(1)
                    for clean in [False,True]:
                        select=d['clean'] if clean else np.ones(len(x),dtype=bool);dd={k:v[select] for k,v in d.items()};value=contrast(dd,x[select]);rows.append({'subject':s,'session':ses,'method':method,'region_band':name,'window':window,'clean':clean,'inner_minus_visual':value})
    # Final peripheral controls use other participants only to fit associations.
    if len(data)==30:
        for method in ['forward','zero_phase']:
            for name,band,channels in definitions:
                for clean in [False,True]:
                    for held in range(1,11):
                        xx=[];yy=[]
                        for (s,ses),d in data.items():
                            if s==held:continue
                            sel=np.isin(d['condition'],[1,2]) & (d['clean'] if clean else True)
                            y=d[f'{method}/eeg/delta'].reshape(len(sel),3,128)[:,band,channels].mean(1)
                            xx.append(d[f'{method}/exg/delta'][sel]);yy.append(y[sel])
                        model=make_pipeline(StandardScaler(),Ridge(alpha=10));model.fit(np.concatenate(xx),np.concatenate(yy))
                        for ses in range(1,4):
                            d=data[held,ses];sel=d['clean'] if clean else np.ones(len(d['condition']),dtype=bool);dd={k:v[sel] for k,v in d.items()}
                            y=d[f'{method}/eeg/delta'].reshape(len(sel),3,128)[:,band,channels].mean(1);res=y-model.predict(d[f'{method}/exg/delta'])
                            rows.append({'subject':held,'session':ses,'method':method,'region_band':name,'window':'delta_peripheral_adjusted','clean':clean,'inner_minus_visual':contrast(dd,res[sel])})
        for (s,ses),d in data.items():
            for method in ['forward','zero_phase']:
                for band in range(3):
                    for channel,label in enumerate(['horizontal_eog','vertical_eog','mouth_emg']):
                        x=d[f'{method}/exg/delta'].reshape(len(d['condition']),3,3)[:,band,channel]
                        rows.append({'subject':s,'session':ses,'method':method,'region_band':f'peripheral_band{band}_{label}','window':'delta','clean':False,'inner_minus_visual':contrast(d,x)})
    summaries=[];rng=np.random.default_rng(20261004)
    for method,name,window,clean in sorted({(r['method'],r['region_band'],r['window'],r['clean']) for r in rows}):
        subjects=[]
        for s in range(1,11):
            rs=[r for r in rows if (r['method'],r['region_band'],r['window'],r['clean'],r['subject'])==(method,name,window,clean,s)]
            if len(rs)==3:subjects.append({'subject':s,'value':float(np.mean([r['inner_minus_visual'] for r in rs])),'session_values':[r['inner_minus_visual'] for r in sorted(rs,key=lambda r:r['session'])]})
        if len(subjects)==10:
            v=np.array([r['value'] for r in subjects]);signs=np.array(list(itertools.product([-1,1],repeat=10)));bs=v[rng.integers(0,10,(10000,10))].mean(1);p=float((np.abs((signs*v).mean(1))>=abs(v.mean())-1e-12).mean())
            summaries.append({'method':method,'region_band':name,'window':window,'clean':clean,'subjects':subjects,'mean':float(v.mean()),'subject_bootstrap95':np.quantile(bs,[.025,.975]).tolist(),'unadjusted_exact_sign_flip_two_sided':p})
    primary=[r for r in summaries if r['method']=='forward' and r['window']=='delta' and not r['clean'] and r['region_band'] in ['central_beta','occipital_alpha']]
    if len(primary)==2:
        ranked=sorted(primary,key=lambda r:r['unadjusted_exact_sign_flip_two_sided']);running=0
        for i,r in enumerate(ranked):running=max(running,min(1,(2-i)*r['unadjusted_exact_sign_flip_two_sided']));r['holm_two_primary']=running
    save(OUT/'analysis.json',{'complete':len(paths)==30,'completed_records':len(paths),'rows':rows,'summaries':summaries,'primary':primary,'unit':'difference in spatially centered natural-log bandpower change; not accuracy','interpretation':'Exploratory task association. Sign flip symmetry assumption, run-order confounding, peripheral activity and filter-state effects remain. No established biological discovery.'})
def clean_cache(folder):
    assert folder.resolve().parent==CACHE.resolve()
    for p in folder.iterdir():
        assert p.is_file() and (p.name=='record.bdf' or p.suffix in ['.part','.tmp']) and p.resolve().parent==folder.resolve()
    for p in folder.iterdir():p.unlink()
    folder.rmdir()
def main():
    with (OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);started=time.time();(OUT/'features').mkdir(exist_ok=True)
        inventory=json.loads((R/'raw_metadata/raw_inventory.json').read_text())['files'];objs={(int(x['key'].split('/')[1][4:]),int(x['key'].split('/')[2][4:])):x for x in inventory if x['key'].endswith('.bdf')};assert len(objs)==30
        protocol={'subjects':10,'sessions':3,'order':'All10 session1, then all10 session2, then all10 session3','claim':'Exploratory within-trial task-associated scalp spectral modulation; not neural causal mechanism','primary':'Inner-minus-visual difference in late-action-minus-pre-cue spatially relative logpower: Central beta13-30Hz and Occipital alpha8-13Hz. Regions fixed existing label-independent geometry; Holm correction for two forward-filter primary endpoints.','aggregation':'Equal average across four directions within session, then three sessions within subject, then10subjects; subject-level bootstrap and exact two-sided sign-flip, symmetric differences assumed.','controls':['Forward vs zero-phase identical IIR0.5-45Hz, no ICA;10s warmup buffer is not exact continuous filtering','Actual raw direction/action/relax triggers; late starts1s after true action onset','Pre and cue task contrasts, same direction labels','Bipolar EOG/EMG features and leave-subject-out peripheral association adjustment in final controls','Official EMG-flag-clean sensitivity, all participants retained','Session-specific effect consistency, all endpoints retained'],'limits':['Prior cohort outcomes already observed, retrospective not independent confirmation','Tasks occur in condition-specific runs; task and recording context may remain confounded','Differential scalp alpha/beta patterns described in original paper; rediscovery not automatically novel','Reject control explanations before interpreting task-specific effects','No choosing frequency, region or participants by results','Peripheral adjustment may remove genuine shared activity and cannot remove every artifact'],'stop':'Finish frozen30records; no extra datasets/module tuning. If primary lacks reproducibility or controls do not distinguish explanations, report negative and stop this route.','storage':'Rolling cache <=one raw recording+parts; retain features, trigger timestamps, sourceETag, hashes and analysis. Delete only this run temporary cache after validated extraction. Original files and pilot untouched.','source_objects':list(objs.values()),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
        p=OUT/'protocol.json'
        if p.exists():assert json.loads(p.read_text())==protocol
        else:save(p,protocol)
        try:
            for ses in range(1,4):
                for s in range(1,11):
                    dest=OUT/'features'/f'sub{s:02d}_ses{ses:02d}.npz'
                    if dest.exists() and dest.with_suffix('.json').exists():continue
                    save(OUT/'status.json',{'state':'running','phase':'download','subject':s,'session':ses,'completed_records':len(list((OUT/'features').glob('*.npz'))),'total_records':30,'started':started,'updated':time.time(),'pid':os.getpid()})
                    folder=None
                    if (s,ses)==(1,3):path=R/'raw_pilot/sub-01_ses-03.bdf';sha=json.loads((R/'raw_pilot/audit.json').read_text())['raw_sha256']
                    else:path,sha,folder=download(objs[s,ses])
                    save(OUT/'status.json',{'state':'running','phase':'extract','subject':s,'session':ses,'completed_records':len(list((OUT/'features').glob('*.npz'))),'total_records':30,'started':started,'updated':time.time(),'pid':os.getpid()})
                    extract(s,ses,path,dest,sha)
                    if folder:clean_cache(folder)
                    analyze();print('COHORT_RECORD_DONE',s,ses,flush=True)
            analyze();save(OUT/'status.json',{'state':'complete','completed_records':30,'total_records':30,'elapsed_seconds':time.time()-started,'updated':time.time()})
        except Exception as e:save(OUT/'status.json',{'state':'failed','error':repr(e),'updated':time.time()});raise
if __name__=='__main__':main()
