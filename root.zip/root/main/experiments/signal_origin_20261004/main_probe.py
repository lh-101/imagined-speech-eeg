"""Use true MATLAB epoch time coordinates; do not invent block identities."""
from pathlib import Path
import os,json,time,hashlib
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
import numpy as np
from scipy.io import loadmat
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import balanced_accuracy_score
from study import R,save
def main():
    out=R/'main';out.mkdir(exist_ok=True);(out/'fits').mkdir(exist_ok=True);started=time.time()
    protocol={'subjects':15,'split':'Fivefold stratified pooled training+validation seed42; additionally official training->validation. The latter is a partition holdout, NOT verified cross-session/block.','features':['pre_epoch_zero_mean[-0.5,0)','early_post_zero_mean[0,0.5)','late_post_zero_mean[1.5,2)','post_zero_mean[0,2.4)','visible_first750_mean','post_zero_minus_pre_zero_mean'],'models':'StandardScaler fitted only on train, LogisticRegression C1 max_iter2000 seed42; no tuning','timing':'MATLAB t in milliseconds, converted /1000. Epoch zero physical event not conclusively verified; pre-zero cannot be called pre-direction-cue or pre-imagery.','total_fits':540,'limitations':['Already explored dataset, retrospective diagnostic','No real block identifiers in supplied epochs','Trial order is not acquisition block metadata','Any inherited acausal filtering could spread later activity into earlier samples','Official partition may contain related acquisitions, not independent replication'],'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    save(out/'protocol.json',protocol)
    try:
        for s in range(1,16):
            parts=[]
            for split,key in [('Training set','epo_train'),('Validation set','epo_validation')]:
                e=loadmat(Path('/root/FAST/BCIC2020Track3')/split/f'Data_Sample{s:02d}.mat',simplify_cells=True)[key]
                x=e['x'].transpose(2,1,0);t=np.asarray(e['t'])/1000;y=e['y'].argmax(0)
                assert x.shape[1:]==(64,795) and float(e['fs'])==256
                d={'y':y}
                for name,a,b in [('pre_zero',-.5,0),('early_post_zero',0,.5),('late_post_zero',1.5,2),('post_zero',0,2.4)]:d[name]=x[:,:,(t>=a)&(t<b)].mean(-1)
                d['visible_first750']=x[:,:,:750].mean(-1);d['baseline_corrected_post_zero']=d['post_zero']-d['pre_zero'];parts.append(d)
            d={k:np.concatenate([p[k] for p in parts]) for k in parts[0]};y=d.pop('y');n=len(parts[0]['y']);idx=np.arange(len(y))
            folds={'trial_cv':list(StratifiedKFold(5,shuffle=True,random_state=42).split(idx,y)),'official_partition':[(idx[:n],idx[n:])]}
            for mode,ss in folds.items():
                for fi,(tr,te) in enumerate(ss):
                    for feature,x in d.items():
                        p=out/'fits'/f'sub{s:02d}_{mode}_{fi}_{feature}.json'
                        if p.exists():continue
                        m=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=2000,random_state=42));m.fit(x[tr],y[tr]);pred=m.predict(x[te])
                        save(p,{'subject':s,'mode':mode,'fold':fi,'feature':feature,'test_idx':te.tolist(),'pred':pred.tolist(),'y':y[te].tolist(),'balanced_accuracy':float(balanced_accuracy_score(y[te],pred))})
                    completed=len(list((out/'fits').glob('*.json')));save(out/'status.json',{'state':'running','subject':s,'completed':completed,'total':540,'started':started,'elapsed_seconds':time.time()-started,'estimated_remaining_seconds':(time.time()-started)*(540-completed)/completed,'updated':time.time()})
                print('MAIN_SUBJECT_DONE',s,completed,flush=True)
            rows=[json.loads(p.read_text()) for p in (out/'fits').glob('*.json')];groups=[]
            for mode in folds:
                for feature in d:
                    subjects=[]
                    for sub in range(1,16):
                        a=[r for r in rows if r['subject']==sub and r['mode']==mode and r['feature']==feature]
                        if len(a)==(5 if mode=='trial_cv' else 1):subjects.append({'subject':sub,'balanced_accuracy':float(balanced_accuracy_score(np.concatenate([r['y'] for r in a]),np.concatenate([r['pred'] for r in a])))})
                    groups.append({'mode':mode,'feature':feature,'subjects':subjects,'mean_balanced_accuracy':float(np.mean([r['balanced_accuracy'] for r in subjects])) if subjects else None})
            save(out/'summary.json',{'complete':len(rows)==540,'groups':groups,'completed':len(rows),'total':540,'unit':'fraction'})
        save(out/'status.json',{'state':'complete','completed':540,'total':540,'elapsed_seconds':time.time()-started,'updated':time.time()})
    except Exception as e:save(out/'status.json',{'state':'failed','error':repr(e),'updated':time.time()});raise
if __name__=='__main__':main()
