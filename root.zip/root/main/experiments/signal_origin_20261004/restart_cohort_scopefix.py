from pathlib import Path
import os,signal,subprocess,time,sys,json
R=Path(__file__).resolve().parent;out=R/'raw_cohort'
assert not list((out/'features').glob('*.npz')),'Scope correction must precede any cohort outcomes'
pid=int((R/'raw_cohort.pid').read_text());p=Path(f'/proc/{pid}/cmdline')
if p.exists():
    assert str(R/'raw_cohort.py').encode() in p.read_bytes().split(b'\0')
    os.kill(pid,signal.SIGTERM)
    for _ in range(30):
        if not p.exists():break
        time.sleep(.1)
protocol=out/'protocol.json'
if protocol.exists():protocol.replace(out/'protocol_before_selector_fix.json')
(out/'amendment.json').write_text(json.dumps({'time':time.time(),'reason':'Ensure planned Holm family includes only Central-beta and Occipital-alpha, excludes descriptive peripheral controls. No feature outcomes yet, no hypothesis changed. Retain all downloaded chunks.','previous_pid':pid}))
subprocess.run([sys.executable,str(R/'launch_raw_cohort.py')],check=True)
