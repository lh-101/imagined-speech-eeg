from pathlib import Path
import requests,time,json,hashlib
R=Path('/root/FAST/experiments/signal_origin_20261004/raw_cohort');repo='raei/Nieto-2022-ThinkingOutLoudOpenAccessEEGBasedBCIDatasetInnerSpeech'
info=json.loads((R/'mirror_probe.json').read_text());rev=next(x['revision'] for x in info if x['base']=='https://hf-mirror.com' and x['passed']);obj=next(x for x in json.loads((R/'protocol.json').read_text())['source_objects'] if '/sub-01/ses-01/' in x['key']);path=obj['key'].split('/',1)[1];url=f'https://hf-mirror.com/datasets/{repo}/resolve/{rev}/{path}'
start=time.time();res=requests.get(url,headers={'Range':'bytes=0-1048575'},stream=True,timeout=(8,15));row={'status':res.status_code,'header_seconds':time.time()-start,'content_range':res.headers.get('Content-Range'),'revision':rev}
try:
    assert res.status_code==206 and res.headers.get('Content-Range','').startswith('bytes 0-1048575/'), 'Mirror Range not honored'
    body=b''.join(res.iter_content(65536));res.close();assert len(body)==1048576
    source=Path('/root/FAST/experiments/signal_origin_20261004/raw_metadata')/obj['key'];header=source.with_suffix('.header').read_bytes();assert body[:len(header)]==header,'Mirror header differs from source'
    row.update(passed=True,seconds=time.time()-start,MB_per_second=len(body)/(time.time()-start)/1e6,header_matches=True)
    (R/'mirror_route.json').write_text(json.dumps({'base':f'https://hf-mirror.com/datasets/{repo}/resolve/{rev}/','strip_prefix':'ds003626/','revision':rev,'source_header_verified':True,'require_original_size_MD5':True},indent=2))
except Exception as e:row.update(passed=False,error=repr(e))
(R/'mirror_speed_probe.json').write_text(json.dumps(row,indent=2));print(json.dumps(row))
