from pathlib import Path
import requests,json,hashlib
R=Path('/root/FAST/experiments/signal_origin_20261004/sources');R.mkdir(exist_ok=True)
repo='raei/Jeong-2022-InternationalBCICompetition2020Review-track3'
expected='029604c2d4a929a849044d5e860359154461b07945370d56e6ab754f0f38d3dd'
for url in ['https://osf.io/download/ymvjz/?version=1','https://hf-mirror.com/datasets/'+repo+'/resolve/main/Data_description%28Track3%29.pdf']:
    try:
        r=requests.get(url,timeout=(8,20));r.raise_for_status()
        assert r.content.startswith(b'%PDF') and hashlib.sha256(r.content).hexdigest()==expected
        p=R/'Data_description_Track3.pdf';p.write_bytes(r.content)
        from pypdf import PdfReader
        text='\n'.join(page.extract_text() for page in PdfReader(p).pages);(R/'Data_description_Track3.txt').write_text(text)
        print('VERIFIED_MANUAL',url,len(r.content),expected,'\n',text,flush=True)
        raise SystemExit(0)
    except Exception as e:print('ROUTE_FAILED',url,repr(e),flush=True)
j=requests.get('https://huggingface.co/api/datasets/'+repo,timeout=30);j.raise_for_status();data=j.json();(R/'mirror_listing.json').write_text(json.dumps(data,indent=2))
sha=data['sha'];files=[x['rfilename'] for x in data['siblings']];print('LISTING',sha,files,flush=True)
for name in files:
    if name.lower().endswith(('.pdf','.md','.xlsx','.txt')):
        r=requests.get(f'https://huggingface.co/datasets/{repo}/resolve/{sha}/{name}',timeout=45);r.raise_for_status()
        assert len(r.content)<10*1024*1024,'Only small metadata documents requested'
        p=R/Path(name).name;p.write_bytes(r.content);print('DOC',name,len(r.content),hashlib.sha256(r.content).hexdigest(),flush=True)
        if name.lower().endswith('.pdf'):
            import subprocess
            subprocess.run(['pdftotext','-layout',str(p),str(p.with_suffix('.txt'))],check=False)
