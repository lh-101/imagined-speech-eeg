from pathlib import Path
import os,signal,time,subprocess,sys,json
R=Path(__file__).resolve().parent
pid=int((R/'raw_pilot.pid').read_text())
p=Path(f'/proc/{pid}/cmdline')
if p.exists():
    args=p.read_bytes().split(b'\0');assert str(R/'raw_pilot.py').encode() in args,'Do not stop unrelated jobs'
    os.kill(pid,signal.SIGTERM)
    for _ in range(30):
        if not p.exists():break
        time.sleep(.1)
(R/'raw_download_amendment.json').write_text(json.dumps({'time':time.time(),'reason':'Observed download mean0.56MB/s; increase4->12 parallel Range workers, retain completed chunks. Before any raw prediction outcomes.','previous_pid':pid}))
subprocess.run([sys.executable,str(R/'launch_raw.py')],check=True)
