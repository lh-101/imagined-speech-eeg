from pathlib import Path
import requests,time,json,os,socket
from concurrent.futures import ThreadPoolExecutor,as_completed
R=Path('/root/FAST/experiments/signal_origin_20261004/raw_cohort')
obj=json.loads((R/'protocol.json').read_text())['source_objects'][0]
key=obj['key'];urls=['https://s3.amazonaws.com/openneuro.org/','https://s3.us-east-1.amazonaws.com/openneuro.org/','https://s3.us-east-2.amazonaws.com/openneuro.org/','https://openneuro.org.s3.amazonaws.com/']
def probe(base):
    started=time.monotonic();row={'base':base,'range_bytes':1024**2}
    try:
        r=requests.get(base+key,headers={'Range':'bytes=100663296-101711871','If-Match':'"'+obj['etag']+'"'},timeout=(6,12),stream=True)
        row.update(status=r.status_code,final_url=r.url,header_seconds=time.monotonic()-started,etag=r.headers.get('ETag'),content_range=r.headers.get('Content-Range'))
        assert r.status_code==206 and r.headers.get('Content-Range','').startswith('bytes 100663296-101711871/')
        n=0
        for block in r.iter_content(65536):
            n+=len(block)
            if time.monotonic()-started>20:raise TimeoutError('Bounded route probe exceeded20s')
        r.close();row.update(bytes=n,seconds=time.monotonic()-started,MB_per_second=n/max(time.monotonic()-started,.001)/1e6,passed=n==1024**2)
    except Exception as e:row.update(passed=False,error=repr(e),seconds=time.monotonic()-started)
    print(json.dumps(row),flush=True);return row
rows=[]
with ThreadPoolExecutor(max_workers=4) as pool:
    for f in as_completed([pool.submit(probe,u) for u in urls]):rows.append(f.result())
(R/'route_probe.json').write_text(json.dumps({'rows':rows,'time':time.time(),'proxy_env_present':{k:bool(os.environ.get(k)) for k in ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY']},'key':key},indent=2))
