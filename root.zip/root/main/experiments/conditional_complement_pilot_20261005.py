"""Bounded paired development test of contextual token adapters; no novelty guarantee."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='4'
from pathlib import Path
import sys,time,json,hashlib,fcntl
sys.path[:0]=['/root/FAST','/root/FAST/experiments/residual_20260925']
import numpy as np,h5py,torch
from torch import nn
from torch.nn import functional as F
from sklearn.model_selection import KFold
import run_metric_v4 as v4
OUT=Path('/root/FAST/experiments/conditional_complement_pilot_20261005');OUT.mkdir(exist_ok=True)
SOURCE=Path('/root/FAST/experiments/mechanism_20260927/results/full_additive_seed42')
SUBJECTS=[0,7,10];ARMS=['conditional_complement'];STEPS=200

def save(p,d):
    t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(d,indent=2));t.replace(p)

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
    return h.hexdigest()

def tensorhash(m):
    h=hashlib.sha256()
    for k,t in m.state_dict().items():h.update(k.encode());h.update(t.cpu().numpy().tobytes())
    return h.hexdigest()

class Adapter(nn.Module):
    def __init__(self,full,mean,mode,weight,bias):
        super().__init__();self.mode=mode
        self.register_buffer('token_weight',weight.detach().clone())
        self.register_buffer('token_bias',bias.detach().clone())
        with torch.no_grad():
            context=self.token_context(full)
            context=torch.asinh(context.float())
            self.register_buffer('context_center',context.mean((0,1),keepdim=True))
            self.register_buffer('context_scale',context.std((0,1),unbiased=False,keepdim=True).clamp_min(.1))
        with torch.no_grad():
            _,sv,vh=torch.linalg.svd(weight.detach().double(),full_matrices=False)
            rank=int((sv>sv.max()*1e-10).sum())
            self.register_buffer('basis',vh[:rank].T.float())
            full=self.complement(full)
        # Training-only regional/feature scales; window dimension pooled.
        for label,z in [('full',full),('mean',mean),('increment',full-mean)]:
            z=torch.asinh(z.float());self.register_buffer(label+'_center',z.mean((0,1),keepdim=True));self.register_buffer(label+'_scale',z.std((0,1),unbiased=False,keepdim=True).clamp_min(.1))
        self.gate=nn.Sequential(nn.LayerNorm(64),nn.Linear(64,16),nn.GELU(),nn.Linear(16,1))
        self.out=nn.Linear(256,32,bias=False);nn.init.zeros_(self.out.weight)

    def token_context(self,full):
        return F.gelu(F.linear(full.flatten(2),self.token_weight,self.token_bias)).unsqueeze(2)

    def complement(self,full):
        z=full.flatten(2)
        return (z-(z@self.basis)@self.basis.T).reshape_as(full)

    def norm(self,z,label):return ((torch.asinh(z.float())-getattr(self,label+'_center'))/getattr(self,label+'_scale')).clamp(-6,6)

    def forward(self,full,mean):
        if self.mode=='context_adapter':
            first=self.norm(mean,'mean');second=self.norm(full-mean,'increment')
        else:
            second=self.norm(self.complement(full),'full')
            first=((torch.asinh(self.token_context(full).float())-self.context_center)/self.context_scale).clamp(-6,6).expand_as(second)
        gate=torch.sigmoid(self.gate(torch.cat([first,second],-1)))
        return .5*torch.tanh(self.out((gate*second).flatten(2))/.5),gate

def representation(base,adapter,full,mean):
    delta,gate=adapter(full,mean);tokens=base.input_layer(full.flatten(2))+delta
    tokens=torch.cat([base.cls_token.expand(len(full),-1,-1),tokens],1)
    hidden=base.transformer(tokens+base.pos_embedding[:,:base.n_tokens+1])[:,0]
    logits=base.last_layer(hidden)
    with torch.autocast('cuda',enabled=False):q=torch.cat([F.normalize(torch.asinh(full.float()).flatten(1),dim=-1),F.normalize(hidden.float(),dim=-1)],-1)/(2**.5)
    return logits,q,gate,delta

def load_fold(s,fi,tr,te,x,y):
    ck=torch.load(SOURCE/f'{s}-fold{fi}.pt',map_location='cpu');assert np.array_equal(ck['train_idx'],tr) and np.array_equal(ck['test_idx'],te)
    base=v4.FAST(v4.config()).cuda().eval();base.load_state_dict(ck['state_dict']);base.requires_grad_(False)
    with torch.no_grad():
        tx=torch.from_numpy(x).cuda();full=base.forward_head(tx)
        visible=(base.n_tokens-1)*base.config.slide_step+base.config.window_len;assert visible==750
        mu=tx[:,:,:visible].mean(-1,keepdim=True);mean=base.forward_head(mu.expand_as(tx).contiguous())
        old=base.forward_transformer(full[te]);pred=old.argmax(-1).cpu().numpy()
    with np.load(SOURCE/f'{s}-fold{fi}.npz') as z:
        assert np.array_equal(z['y'],y[te]) and np.array_equal(z['test_idx'],te)
        assert np.array_equal(pred,z['primary_pred']),'Original checkpoint prediction mismatch'
    return base,full.detach(),mean.detach(),old.detach(),pred

def report():
    groups=[]
    for arm in ARMS:
        subjects=[]
        for s in SUBJECTS:
            ps=[OUT/arm/f'{s}-fold{fi}.npz' for fi in range(5)]
            if not all(p.exists() for p in ps):continue
            truth=[];pred=[];source=[]
            for p in ps:
                with np.load(p) as z:truth.extend(z['y']);pred.extend(z['pred']);source.extend(z['source_pred'])
            yy=np.array(truth);subjects.append({'subject':s,'accuracy':float((np.array(pred)==yy).mean()),'source':float((np.array(source)==yy).mean()),'rescued':int(((np.array(source)!=yy)&(np.array(pred)==yy)).sum()),'harmed':int(((np.array(source)==yy)&(np.array(pred)!=yy)).sum())})
        groups.append({'arm':arm,'subjects':subjects,'n_subjects':len(subjects),'mean_accuracy':float(np.mean([z['accuracy'] for z in subjects])) if subjects else None,'mean_source':float(np.mean([z['source'] for z in subjects])) if subjects else None})
    for group in groups:
        for row in group['subjects']:
            truth=[];plain=[]
            for fi in range(5):
                path=Path('/root/FAST/experiments/regional_adapter_full_20261004/plain_adapter')/f"{row['subject']}-fold{fi}.npz"
                with np.load(path) as z:truth.extend(z['y']);plain.extend(z['pred'])
            row['plain_adapter']=float((np.array(plain)==np.array(truth)).mean())
            row['delta_plain_pp']=100*(row['accuracy']-row['plain_adapter'])
            null_truth=[];null_pred=[]
            for fi in range(5):
                path=Path('/root/FAST/experiments/null_adapter_pilot_20261005/null_adapter')/f"{row['subject']}-fold{fi}.npz"
                with np.load(path) as z:null_truth.extend(z['y']);null_pred.extend(z['pred'])
            row['complement_only']=float((np.array(null_pred)==np.array(null_truth)).mean())
            row['delta_complement_pp']=100*(row['accuracy']-row['complement_only'])
        group['mean_plain_adapter']=float(np.mean([z['plain_adapter'] for z in group['subjects']])) if group['subjects'] else None
        group['delta_plain_pp']=100*(group['mean_accuracy']-group['mean_plain_adapter']) if group['subjects'] else None
        group['mean_complement_only']=float(np.mean([z['complement_only'] for z in group['subjects']])) if group['subjects'] else None
        group['delta_complement_pp']=100*(group['mean_accuracy']-group['mean_complement_only']) if group['subjects'] else None
    save(OUT/'summary.json',{'complete':all(z['n_subjects']==3 for z in groups),'groups':groups,'interpretation':'Three previouslyselecteddevelopment participants, not fullcohort or independentconfirmation. Trainable capacity matched to saved plain adapter; selected from development probe; no biological claim. Initial identity not final performance guarantee.'})

def main():
    torch.set_num_threads(4)
    with (OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);started=time.time()
        protocol={'design':'Preserve learnedfull-inputFAST+LOO checkpoint, freezeallsourceweights; newadapter injectsbounded32dim residual into5tokensbeforeTransformer. Initializeoutzero, exactoriginalpredictor atstart.','candidate':'Residual values read only projection-complement features. Shared 64-input gate reads normalized original 32dim post-GELU token and normalized 32dim regional complement; token broadcast across8regions. Frozen original projection weight and bias are buffers; zero output initialization preserves original logits. Context and complement normalization trained on training fold only. Input orthogonality precedes normalization/gating; no claim of orthogonal final output.','comparison':'Use saved same-fold plain and complement-only adapter results. Identical 9377 trainable parameters, optimizer, seed and200steps; gate input changes from complement/complement to preserved-token/complement. No baseline retraining. Different normalization contexts, so comparison tests joint design not a pure mechanism attribution.','subjects':SUBJECTS,'folds':5,'arms':ARMS,'new_fits':15,'steps':STEPS,'optimizer':'AdamW lr.001 cosine to.0001, weight_decay.01; CE+.3CE(4×LOO) unchangedparameters; additional.01mean(delta_token^2) inbotharms. Fixedfinalstep, no testtuning.','limits':['Previously selected0/7/10, allfoldsseen repeatedly, development only','Fitsonlyadapter on memorizedsource; possibleweakgradientand overfitting','RNG seed42+s*5+fireset for samefulladapter init','Finish fixed15 pilot fits. Predeclared operational expansion rule: mean gain versus saved plain adapter >=0.5pp and at least2of3 subjects strictly improve. It is development screening, not significance. If expanded, reuse15finished folds and record selection. No hyperparameter tuning.','No retrainingoldbaseline; loadandverify savedpredictions','Null-space methods and adapters have existing work; exact originality not established','Linear null directions may be task irrelevant or dominated by acquisition artifacts; dimension loss alone is not a defect','Probe result was used to select candidate; folds repeatedly observed development data, not confirmation','Earlierfrozenlinearlogitreadoutfailed; this is preTransformer nonlinear conditional featureadapter, not claim guaranteedsolution'],'sources':{str(Path(__file__)):sha(__file__),str(SOURCE):'perfoldhashstoredwithoutput'}}
        if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==protocol
        else:save(OUT/'protocol.json',protocol)
        try:
            for s in SUBJECTS:
                with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5') as h:x=h[f'{s+1:02d}/X'][:];y=h[f'{s+1:02d}/Y'][:].astype(np.int64)
                for fi,(tr,te) in enumerate(KFold(5,shuffle=False).split(x)):
                    if all((OUT/a/f'{s}-fold{fi}.npz').exists() for a in ARMS):continue
                    v4.seed_all(42+s*5+fi);base,full,mean,old,oldpred=load_fold(s,fi,tr,te,x,y);before=tensorhash(base);yt=torch.from_numpy(y[tr]).cuda()
                    for arm in ARMS:
                        dest=OUT/arm;dest.mkdir(exist_ok=True);p=dest/f'{s}-fold{fi}.npz'
                        if p.exists():continue
                        v4.seed_all(42+s*5+fi);adapter=Adapter(full[tr],mean[tr],arm,base.input_layer[0].weight,base.input_layer[0].bias).cuda()
                        with torch.no_grad():initial=representation(base,adapter,full[te],mean[te])[0]
                        assert torch.equal(initial,old),'Zero adapter not identical'
                        opt=torch.optim.AdamW(adapter.parameters(),lr=.001,weight_decay=.01);trace=[];t=time.time()
                        for step in range(STEPS):
                            opt.zero_grad(set_to_none=True)
                            for group in opt.param_groups:group['lr']=.001*(.1+.9*.5*(1+np.cos(np.pi*step/(STEPS-1))))
                            logits,q,gate,delta=representation(base,adapter,full[tr],mean[tr]);mainloss=F.cross_entropy(logits,yt);aux=.3*F.cross_entropy(4*v4.ridge_fit(q,yt)[1],yt);loss=mainloss+aux+.01*delta.square().mean()
                            assert torch.isfinite(loss);loss.backward();assert all(z.grad is None or torch.isfinite(z.grad).all() for z in adapter.parameters());opt.step()
                            if step in [0,49,99,199]:trace.append({'step':step+1,'main_loss':float(mainloss.detach()),'aux_loss':float(aux.detach()),'delta_rms':float(delta.detach().square().mean().sqrt())})
                        assert tensorhash(base)==before,'Frozen source changed'
                        with torch.no_grad():logits,q,gate,delta=representation(base,adapter,full[te],mean[te]);pred=logits.argmax(-1).cpu().numpy()
                        save(dest/f'{s}-fold{fi}.json',{'subject':s,'fold':fi,'arm':arm,'accuracy':float((pred==y[te]).mean()),'source_accuracy':float((oldpred==y[te]).mean()),'source_sha256':sha(SOURCE/f'{s}-fold{fi}.pt'),'source_unchanged':True,'zero_init_exact':True,'trace':trace,'seconds':time.time()-t,'parameters':sum(z.numel() for z in adapter.parameters())})
                        torch.save({'state_dict':adapter.cpu().state_dict(),'arm':arm,'train_idx':tr,'test_idx':te,'source':str(SOURCE/f'{s}-fold{fi}.pt')},dest/f'{s}-fold{fi}.pt')
                        with p.with_suffix('.npz.tmp').open('wb') as f:np.savez_compressed(f,pred=pred,source_pred=oldpred,y=y[te],train_idx=tr,test_idx=te,prob=logits.softmax(-1).cpu().numpy())
                        p.with_suffix('.npz.tmp').replace(p);n=sum(len(list((OUT/a).glob('*-fold*.npz'))) for a in ARMS);save(OUT/'status.json',{'state':'running','pid':os.getpid(),'completed_folds':n,'total_folds':15,'elapsed_seconds':time.time()-started,'estimated_remaining_seconds':(time.time()-started)*(15-n)/n,'updated':time.time()});print('ADAPTER_FOLD_DONE',arm,s,fi,float((pred==y[te]).mean()),flush=True);report()
                    del base,full,mean,old,adapter,opt,logits,q,loss;torch.cuda.empty_cache()
            report();save(OUT/'status.json',{'state':'complete','completed_folds':15,'total_folds':15,'elapsed_seconds':time.time()-started,'updated':time.time()})
        except Exception as e:save(OUT/'status.json',{'state':'failed','error':repr(e),'updated':time.time()});raise
if __name__=='__main__':main()
