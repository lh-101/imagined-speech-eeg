"""Summarize fixed arms, including negative results; pilot is preliminary."""
import json, argparse
from pathlib import Path
import numpy as np

def summarize(root):
    groups = {}
    rows = []
    for phase in ('pilot_main', 'pilot_external', 'full_main', 'full_external'):
        folder = root/phase
        protocol = folder/'protocol.json'
        if not protocol.exists():
            continue
        for path in folder.glob('*/*/complete.json'):
            rows.extend(dict(phase=phase, **r) for r in json.loads(path.read_text())['rows'])
    for phase in sorted({r['phase'] for r in rows}):
        phase_rows = [r for r in rows if r['phase'] == phase]
        for budget in (.25, .5, 1.):
            subset = [r for r in phase_rows if r['budget'] == budget]
            if not subset:
                continue
            people = sorted({r['subject'] for r in subset})
            subjects = []
            for person in people:
                r = [z for z in subset if z['subject'] == person]
                entry = {'subject': person, 'completed_folds': len({z['fold'] for z in r})}
                for obj in ('ce', 'loo'):
                    for arm in ('pointwise_control', 'multiscale'):
                        cells = [z for z in r if z['objective'] == obj and z['arm'] == arm]
                        entry[obj+'_'+arm] = {m:float(np.mean([z[m] for z in cells])) for m in ('accuracy','macro_f1')}
                    entry[obj+'_structure_gain_pp'] = 100*(entry[obj+'_multiscale']['accuracy']-entry[obj+'_pointwise_control']['accuracy'])
                entry['supervision_structure_interaction_pp'] = entry['loo_structure_gain_pp']-entry['ce_structure_gain_pp']
                subjects.append(entry)
            groups[phase+'_budget'+str(int(budget*100))] = dict(subjects=subjects,
                mean_structure_gain_pp={o:float(np.mean([s[o+'_structure_gain_pp'] for s in subjects])) for o in ('ce','loo')},
                mean_interaction_pp=float(np.mean([s['supervision_structure_interaction_pp'] for s in subjects])))
    result = dict(groups=groups, finished_rows=len(rows),
        limitations='Pilot: two fixed participants and one fold per dataset, not full-cohort evidence. Full: report subject-level paired results only after five folds complete. Previously explored data; no originality or necessary-use claim follows automatically.')
    target = root/'summary.json'
    temp = target.with_suffix('.tmp')
    temp.write_text(json.dumps(result,ensure_ascii=False,indent=2))
    temp.replace(target)
    return result

if __name__ == '__main__':
    ap=argparse.ArgumentParser();ap.add_argument('root');args=ap.parse_args()
    print(json.dumps(summarize(Path(args.root)),ensure_ascii=False))
