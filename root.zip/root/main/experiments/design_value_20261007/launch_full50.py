from pathlib import Path
import json, subprocess, os

root=Path(__file__).resolve().parent
module='/root/FAST/experiments/parallel_principles_20261007/temporal'
for phase in ('pilot_main','pilot_external'):
    assert json.loads((root/phase/'status.json').read_text())['state']=='complete'
print(subprocess.run(['nvidia-smi','--query-gpu=memory.used,utilization.gpu','--format=csv,noheader'],capture_output=True,text=True).stdout.strip())
for shard in (0,1):
    phase=f'full50_worker{shard}'
    record=root/(phase+'_launch.json')
    if record.exists():
        print(record.read_text())
        continue
    with (root/(phase+'.log')).open('ab') as log:
        p=subprocess.Popen(['/root/venv_fast/bin/python','-u',str(root/'run_full50.py'),
            '--temporal-module-dir',module,'--out',str(root/phase),'--mode','full',
            '--dataset','both','--shard',str(shard),'--reuse-root',str(root)],
            stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,cwd=root,
            start_new_session=True,env={**os.environ,'OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2'})
    record.write_text(json.dumps(dict(pid=p.pid,phase=phase)))
    print(record.read_text())
