"""Prepared paired experiment. GPU smoke and source audit required before launch."""
import os
for key in ('OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS'):
    os.environ[key] = '2'
import argparse, json, time, hashlib, sys
from pathlib import Path
import numpy as np

def subsets(train, labels, seed):
    rng = np.random.default_rng(seed)
    pools = [rng.permutation(train[labels[train] == c]) for c in np.unique(labels)]
    assert all(len(pool) >= 4 for pool in pools)
    return {p: np.sort(np.concatenate([v[:max(2, int(len(v)*p))] for v in pools]))
            for p in (.25, .5, 1.)}

def atomic(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf8')
    tmp.replace(path)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--temporal-module-dir', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--mode', choices=('smoke', 'pilot', 'full'), default='smoke')
    ap.add_argument('--dataset', choices=('main', 'external', 'both'), default='both')
    args = ap.parse_args()
    sys.path.insert(0, args.temporal_module_dir)
    import torch
    from torch.nn import functional as F
    import run_temporal as t
    ref = t.ref
    torch.set_num_threads(2)
    assert torch.cuda.is_available()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    epochs = 3 if args.mode == 'smoke' else 200
    protocol = dict(mode=args.mode, steps_per_stage=epochs,
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        module_sha256=hashlib.sha256(Path(t.__file__).read_bytes()).hexdigest(),
        controls_sha256=hashlib.sha256(Path(ref.__file__).read_bytes()).hexdigest(),
        objectives=['ce', 'loo'], architectures=['pointwise_control', 'multiscale'],
        budgets=[.25, .5, 1.], backbone='trained from scratch on budget subset',
        previously_explored=True, dataset=args.dataset)
    if (out/'protocol.json').exists():
        assert json.loads((out/'protocol.json').read_text(encoding='utf8')) == protocol
    else:
        atomic(out/'protocol.json', protocol)
    cases = []
    for kind in ('main', 'external'):
        if args.dataset not in ('both', kind):
            continue
        people = ref.subjects(kind) if args.mode == 'full' else ([0, 7] if kind == 'main' else [1, 4])
        if args.mode == 'smoke':
            people = people[:1]
        for subject in people:
            for fold in (range(5) if args.mode == 'full' else [0]):
                for budget in ([.25] if args.mode == 'smoke' else [.25, .5, 1.]):
                    cases.append((kind, subject, fold, budget))
    start = time.time()
    done = 0
    for kind, subject, fold, budget in cases:
        dest = out/kind/f'sub{subject}_fold{fold}_budget{int(budget*100)}'
        if (dest/'complete.json').exists():
            done += 1
            continue
        dest.mkdir(parents=True, exist_ok=True)
        x, y = ref.dataset(kind, subject)
        outer_train, test = list(ref.splits(kind, x, y))[fold]
        train = subsets(outer_train, y, ref.seed(kind, subject, fold)+7000)[budget]
        assert not np.intersect1d(train, test).size
        classes = len(np.unique(y))
        assert np.array_equal(np.unique(y[train]), np.arange(classes))
        if kind == 'external':
            mu = x[train].mean((0, 2), keepdims=True, dtype=np.float64).astype(np.float32)
            sd = np.maximum(x[train].std((0, 2), keepdims=True, dtype=np.float64).astype(np.float32), 1e-6)
            x = ((x-mu)/sd).astype(np.float32)
            np.savez_compressed(dest/'normalization.npz', mean=mu, scale=sd, train_idx=train)
        xt = torch.from_numpy(x[train]).cuda()
        target = torch.from_numpy(y[train]).cuda()
        xe = torch.from_numpy(x[test]).cuda()
        case_rows = []
        def auxiliary(q):
            k = torch.exp(-2*(1-q.double()@q.double().T))
            inv = torch.cholesky_inverse(torch.linalg.cholesky(k+.1*torch.eye(len(q), device=q.device, dtype=k.dtype)))
            yy = F.one_hot(target, classes).to(k.dtype)
            loo = (yy-(inv@yy)/inv.diag()[:,None]).float()
            return .3*F.cross_entropy(4*loo, target)
        def evaluate(base, adapter, feat):
            with torch.no_grad():
                if adapter is None:
                    with torch.autocast('cuda', dtype=torch.bfloat16):
                        logits, _ = ref.main_ref.v4.representation(base, xe)
                else:
                    logits = ref.rep(kind, base, adapter, feat, torch.zeros_like(feat))[0]
                return logits.float().softmax(-1).cpu().numpy()
        for objective in ('ce', 'loo'):
            ref.main_ref.v4.seed_all(ref.seed(kind, subject, fold))
            if kind == 'main':
                base = ref.main_ref.v4.FAST(ref.main_ref.v4.config()).cuda()
            else:
                geometry = json.loads((ref.external_ref.ROOT/'geometry.json').read_text())
                base = ref.external_ref.build(geometry)
            base.train().requires_grad_(True)
            opt = torch.optim.AdamW(base.parameters(), lr=.0005)
            schedule = ref.main_ref.v4.cosine_scheduler(1, .1, epochs, 1, warmup_epochs=min(10, epochs//5))
            for step in range(epochs):
                opt.zero_grad(set_to_none=True)
                for group in opt.param_groups:
                    group['lr'] = .0005*float(schedule[step-1])
                with torch.autocast('cuda', dtype=torch.bfloat16):
                    logits, q = ref.main_ref.v4.representation(base, xt)
                    loss = F.cross_entropy(logits, target)
                if objective == 'loo':
                    loss = loss+auxiliary(q)
                assert torch.isfinite(loss)
                loss.backward()
                assert all(p.grad is None or torch.isfinite(p.grad).all() for p in base.parameters())
                opt.step()
            del opt, logits, q, loss
            base.eval().requires_grad_(False)
            for p in base.parameters():
                p.grad = None
            with torch.no_grad():
                if kind == 'external':
                    ft = ref.external_ref.cache(base, x[train])
                    fe = ref.external_ref.cache(base, x[test])
                else:
                    ft = base.forward_head(xt).detach()
                    fe = base.forward_head(xe).detach()
            source_hash = ref.main_ref.tensorhash(base)
            prob = evaluate(base, None, fe)
            np.savez_compressed(dest/f'{objective}_backbone.npz', prob=prob, y=y[test], train_idx=train, test_idx=test)
            reference = ref.initialize(kind, ft, torch.zeros_like(ft))
            ref.main_ref.v4.seed_all(ref.seed(kind, subject, fold)+10000)
            generic = ref.GenericAdapter(reference).cuda()
            del reference
            def fit(adapter, correction=False):
                params = [p for p in adapter.parameters() if p.requires_grad]
                optimizer = torch.optim.AdamW(params, lr=.001, weight_decay=.01)
                for step in range(epochs):
                    for g in optimizer.param_groups:
                        g['lr'] = .001*(.1+.9*.5*(1+np.cos(np.pi*step/max(epochs-1,1))))
                    optimizer.zero_grad(set_to_none=True)
                    logits, q, _, delta = ref.rep(kind, base, adapter, ft, torch.zeros_like(ft))
                    if correction:
                        with torch.no_grad():
                            old_delta = generic(ft, torch.zeros_like(ft))[0]
                        delta = delta-old_delta
                    loss = F.cross_entropy(logits, target)+.01*delta.square().mean()
                    if objective == 'loo':
                        loss = loss+auxiliary(q)
                    assert torch.isfinite(loss)
                    loss.backward()
                    assert all(p.grad is None or torch.isfinite(p.grad).all() for p in params)
                    optimizer.step()
            fit(generic)
            prob = evaluate(base, generic, fe)
            np.savez_compressed(dest/f'{objective}_generic.npz', prob=prob, y=y[test], train_idx=train, test_idx=test)
            generic.eval().requires_grad_(False)
            for p in generic.parameters():
                p.grad = None
            generic_hash = ref.main_ref.tensorhash(generic)
            for arm in ('pointwise_control', 'multiscale'):
                ref.main_ref.v4.seed_all(ref.seed(kind, subject, fold)+20000)
                adapter = t.Temporal(generic, arm).cuda()
                assert sum(p.numel() for p in adapter.parameters() if p.requires_grad) == 6440
                with torch.no_grad():
                    initial = ref.rep(kind, base, adapter, fe, torch.zeros_like(fe))[0]
                    original = ref.rep(kind, base, generic, fe, torch.zeros_like(fe))[0]
                    assert torch.equal(initial, original)
                fit(adapter, correction=True)
                prob = evaluate(base, adapter, fe)
                np.savez_compressed(dest/f'{objective}_{arm}.npz', prob=prob, y=y[test], train_idx=train, test_idx=test)
                row = dict(dataset=kind, subject=subject, fold=fold, budget=budget,
                    objective=objective, arm=arm, n_train=len(train), n_test=len(test),
                    **ref.metrics(y[test], prob.argmax(-1)))
                atomic(dest/f'{objective}_{arm}.json', row)
                case_rows.append(row)
                del adapter
            assert ref.main_ref.tensorhash(base) == source_hash
            assert ref.main_ref.tensorhash(generic) == generic_hash
            torch.save(dict(base_state=base.cpu().state_dict(), adapter_state=generic.cpu().state_dict(),
                train_idx=train, test_idx=test, objective=objective), dest/f'{objective}_intermediate.pt')
            del base, generic, ft, fe
            torch.cuda.empty_cache()
        atomic(dest/'complete.json', dict(rows=case_rows, training_labels_budget_restricted=True))
        del xt, xe, target
        done += 1
        elapsed = time.time()-start
        atomic(out/'status.json', dict(state='running', completed_cases=done, total_cases=len(cases),
            elapsed_seconds=elapsed, estimated_remaining_seconds=elapsed*(len(cases)-done)/done))
        print('CASE_DONE', kind, subject, fold, budget, flush=True)
    atomic(out/'status.json', dict(state='complete', completed_cases=done, total_cases=len(cases), elapsed_seconds=time.time()-start))

if __name__ == '__main__':
    main()
