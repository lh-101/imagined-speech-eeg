import json
from pathlib import Path
import numpy as np
from sklearn.metrics import f1_score

def summarize(root):
    datasets={}
    for kind,people in [('main',range(15)),('external',range(1,7))]:
        subjects=[]
        for subject in people:
            folders=[]
            for fold in range(5):
                found=[root/f'full50_worker{w}'/kind/f'sub{subject}_fold{fold}_budget50' for w in (0,1)]
                found=[p for p in found if (p/'complete.json').exists()]
                assert len(found)<=1,'Duplicate fold execution'
                if found:folders.append(found[0])
            if len(folders)!=5:continue
            row=dict(subject=subject)
            truth=None
            for objective in ('ce','loo'):
                for arm in ('pointwise_control','multiscale'):
                    ys=[];ps=[];test_indices=[]
                    for folder in folders:
                        with np.load(folder/f'{objective}_{arm}.npz') as z:
                            assert not np.intersect1d(z['train_idx'],z['test_idx']).size
                            ys.extend(z['y']);ps.extend(z['prob'].argmax(-1));test_indices.extend(z['test_idx'])
                    yy=np.asarray(ys);pp=np.asarray(ps)
                    assert len(test_indices)==len(set(test_indices))
                    if truth is None:truth=yy
                    else:assert np.array_equal(yy,truth)
                    row[objective+'_'+arm]=dict(accuracy=float(np.mean(yy==pp)),
                        macro_f1=float(f1_score(yy,pp,average='macro',zero_division=0)))
                row[objective+'_structure_gain_pp']=100*(row[objective+'_multiscale']['accuracy']-row[objective+'_pointwise_control']['accuracy'])
            subjects.append(row)
        group=dict(completed_subjects=len(subjects),total_subjects=len(people),subjects=subjects)
        if subjects:
            group['means']={a:{m:float(np.mean([s[a][m] for s in subjects])) for m in ('accuracy','macro_f1')}
                for a in ('ce_pointwise_control','ce_multiscale','loo_pointwise_control','loo_multiscale')}
            for objective in ('ce','loo'):
                difference=np.array([s[objective+'_structure_gain_pp'] for s in subjects])
                rng=np.random.default_rng(20261007)
                boots=difference[rng.integers(0,len(difference),(10000,len(difference)))].mean(1)
                group[objective+'_structure_contrast']=dict(mean_pp=float(difference.mean()),
                    positive_subjects=int(np.sum(difference>1e-8)),negative_subjects=int(np.sum(difference<-1e-8)),
                    exploratory_subject_bootstrap_95_interval_pp=np.quantile(boots,[.025,.975]).tolist())
        datasets[kind]=group
    status=[]
    for w in (0,1):
        folder=root/f'full50_worker{w}'
        p=folder/'status.json'
        if p.exists():status.append(json.loads(p.read_text()))
    result=dict(complete=all(g['completed_subjects']==g['total_subjects'] for g in datasets.values()),
        datasets=datasets,workers=status,completed_cases=sum(s.get('completed_cases',0) for s in status),
        total_cases=105,
        limitations='50% budget selected after pilot inspection; repeated development datasets and one seed. Subject bootstrap is descriptive and does not remove model-selection bias. Not independent confirmation, biological mechanism, necessity, or firstness.')
    target=root/'full50_summary.json';tmp=target.with_suffix('.tmp')
    tmp.write_text(json.dumps(result,ensure_ascii=False,indent=2));tmp.replace(target)
    return result

if __name__=='__main__':
    print(json.dumps(summarize(Path(__file__).resolve().parent),ensure_ascii=False))
