"""Exploratory causal state operator. Ingredients are known; novelty unverified."""
import numpy as np
LAM=.001
BLOCK=32
COS=.5
GAMMA=.95

def forget(C,D,gamma):
    a=C@D
    out=C-gamma*a@np.linalg.pinv(D.T@a,rcond=1e-10,hermitian=True)@a.T
    return (out+out.T)/2

class Memory:
    def __init__(self,d,m,method,gamma=0.):
        self.d,self.m,self.method,self.gamma=d,m,method,gamma
        self.N=d*m;self.eye=np.eye(self.N)
        self.theta=np.zeros(self.N);self.C=np.zeros((self.N,self.N));self.ready=False
        self.t=0;self.events=[];self.buffer=[]
        self.histC=[np.zeros((d,d)),np.zeros((d,d))]
        self.histW=[np.zeros((m,d)),np.zeros((m,d))]
        self.addresses=[];self.means=[]

    def h(self,k):return np.kron(np.eye(self.m),k[None,:])

    def ridge_update(self,k,v):
        H=self.h(k);e=v-H@self.theta
        self.C+=H.T@H
        self.C=(self.C+self.C.T)/2
        self.theta+=np.linalg.solve(self.C+LAM*self.eye,H.T@e)

    def start_block(self):
        self.startC=self.C.copy();self.startTheta=self.theta.copy()
        self.references=[w.copy() for w in self.histW]
        self.hist_ready=all(np.linalg.eigvalsh(c).min()>1e-8 for c in self.histC)
        self.grad=[np.zeros(self.N),np.zeros(self.N)];self.count=[0,0]
        self.buffer=[]

    def end_block(self):
        if not self.hist_ready:return
        Q=self.startC+LAM*self.eye;L=np.linalg.cholesky(Q)
        z=[np.linalg.solve(L,g/max(n,1)) for g,n in zip(self.grad,self.count)]
        norms=[np.linalg.norm(a) for a in z]
        cosine=float(z[0]@z[1]/(norms[0]*norms[1])) if min(norms)>1e-12 else -1.
        direction=z[0]/max(norms[0],1e-30)+z[1]/max(norms[1],1e-30)
        coherent=cosine>COS
        should_replay=coherent if self.method!='single_block' else np.linalg.norm(direction)>1e-12
        if not should_replay:return
        self.C=self.startC.copy();self.theta=self.startTheta.copy()
        if self.method=='paired_global':self.C*=1-GAMMA
        elif self.method=='paired_key':
            H=np.concatenate([self.h(k) for k,v in self.buffer],0)
            D=np.linalg.solve(Q,H.T)
            self.C=forget(self.C,D,GAMMA)
        else:
            if self.method=='single_block':
                g=sum(self.h(k).T@(v-self.h(k)@self.startTheta) for k,v in self.buffer)/len(self.buffer)
                D=np.linalg.solve(Q,g[:,None])
            else:
                direction/=np.linalg.norm(direction)
                D=np.linalg.solve(L.T,direction[:,None])
            self.C=forget(self.C,D,GAMMA)
        for k,v in self.buffer:self.ridge_update(k,v)
        self.events.append({'t':self.t,'cosine':cosine,'method':self.method})

    def step(self,k,v):
        self.t+=1
        if self.method.startswith('dict'):
            distances=[np.linalg.norm(k-a) for a in self.addresses]
            if not distances or min(distances)>1e-10:
                self.addresses.append(k.copy());self.means.append(v.copy())
            else:
                j=int(np.argmin(distances));self.means[j]=(1-self.gamma)*self.means[j]+self.gamma*v
            return
        if self.method=='sliding':
            self.buffer.append((k.copy(),v.copy()));self.buffer=self.buffer[-int(self.gamma):]
            K=np.stack([p[0] for p in self.buffer]);V=np.stack([p[1] for p in self.buffer])
            self.theta=np.linalg.solve(K.T@K+LAM*np.eye(self.d),K.T@V).T.reshape(-1)
            return
        if self.method=='delta':
            self.theta+=self.gamma*self.h(k).T@(v-self.h(k)@self.theta)
            return
        block=self.method in ['paired_tensor','single_block','paired_global','paired_key']
        if block:
            if (self.t-1)%BLOCK==0:self.start_block()
            group=(self.t-1)%2
            H=self.h(k)
            self.grad[group]+=H.T@(v-self.references[group]@k);self.count[group]+=1
            self.buffer.append((k.copy(),v.copy()))
            self.histC[group]+=np.outer(k,k)
            hc=self.histC[group]
            hw=self.histW[group]
            hw+=np.outer(v-hw@k,np.linalg.solve(hc+LAM*np.eye(self.d),k))
        elif not self.ready:self.ready=np.linalg.eigvalsh(self.C).min()>1e-8
        if self.ready:
            if self.method=='global':self.C*=1-self.gamma
            elif self.method=='key':
                D=np.linalg.solve(self.C+LAM*self.eye,self.h(k).T)
                self.C=forget(self.C,D,self.gamma)
            elif self.method=='old_tensor':
                e=v-self.h(k)@self.theta
                if np.linalg.norm(e)>1e-12:
                    D=np.linalg.solve(self.C+LAM*self.eye,(self.h(k).T@(e/np.linalg.norm(e)))[:,None])
                    self.C=forget(self.C,D,self.gamma)
        self.ridge_update(k,v)
        if block and self.t%BLOCK==0:self.end_block()
        assert np.isfinite(self.theta).all()

    def predict(self,queries):
        if self.method.startswith('dict'):
            if not self.addresses:return np.zeros((len(queries),self.m))
            A=np.stack(self.addresses);V=np.stack(self.means)
            ix=np.argmin(((queries[:,None,:]-A[None,:,:])**2).sum(-1),1)
            return V[ix]
        return queries@self.theta.reshape(self.m,self.d).T

    def capacity(self):
        if self.method.startswith('dict'):return len(self.addresses)*(self.d+self.m)
        if self.method=='sliding':return self.N+int(self.gamma)*(self.d+self.m)+self.d**2
        if self.method=='delta':return self.N
        if self.method in ['paired_tensor','single_block','paired_global','paired_key']:
            return 2*self.N**2+8*self.N+2*self.d**2+BLOCK*(self.d+self.m)
        return self.N+self.N**2

def validate():
    rng=np.random.default_rng(27190);d=3;m=2
    a=Memory(d,m,'rls');K=rng.normal(size=(40,d));V=rng.normal(size=(40,m))
    for t,(k,v) in enumerate(zip(K,V),1):
        a.step(k,v)
        direct=np.linalg.solve(K[:t].T@K[:t]+LAM*np.eye(d),K[:t].T@V[:t]).T
        assert np.max(np.abs(a.theta.reshape(m,d)-direct))<1e-8
    X=rng.normal(size=(12,12));C=X@X.T+.1*np.eye(12);D=rng.normal(size=(12,2))
    cc=forget(C,D,GAMMA)
    assert np.linalg.eigvalsh(cc).min()>0
    z1=rng.normal(size=12);z2=rng.normal(size=12)
    S=(np.outer(z1,z2)+np.outer(z2,z1))/2
    u=z1/np.linalg.norm(z1)+z2/np.linalg.norm(z2);u/=np.linalg.norm(u)
    ev=np.linalg.eigh(S)
    assert abs(abs(u@ev[1][:,-1])-1)<1e-10
    # Replaying a block with zero forgetting must equal provisional RLS, not double count.
    a=Memory(d,m,'rls');before=Memory(d,m,'rls')
    for k,v in zip(K[:8],V[:8]):a.step(k,v);before.step(k,v)
    c=before.C.copy();theta=before.theta.copy()
    for k,v in zip(K[8:24],V[8:24]):a.step(k,v)
    before.C=c;before.theta=theta
    for k,v in zip(K[8:24],V[8:24]):before.step(k,v)
    assert np.array_equal(a.C,before.C) and np.array_equal(a.theta,before.theta)
    # Prefix equality: suffix observations cannot modify earlier saved outputs.
    b=Memory(d,m,'paired_tensor');c=Memory(d,m,'paired_tensor')
    for k,v in zip(K[:20],V[:20]):b.step(k,v);c.step(k,v)
    saved=b.predict(K[:2]).copy()
    assert np.array_equal(saved,c.predict(K[:2]))
    for k,v in zip(K[20:],V[20:]+10):c.step(k,v)
    assert np.array_equal(saved,b.predict(K[:2]))
    return {'rls_direct':True,'positive_precision':True,'cross_direction_eigenvector':True,'no_double_count':True,'causal_prefix':True}
