import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import argparse,hashlib,json,time,traceback
from pathlib import Path
import numpy as np
from paired_replay import Memory,validate

ROOT=Path(__file__).resolve().parent
METHODS=[('paired_tensor',.95),('rls',0),('delta',.2),('delta',1),('old_tensor',.5),
         *[('global',g) for g in [.01,.03,.1,.3]],
         *[('key',g) for g in [.03,.1,.3,.5,.95]],
         ('single_block',.95),('paired_global',.95),('paired_key',.95),
         ('sliding',32),('sliding',64),*[('dict',g) for g in [.05,.1,.3]]]

def save(path,z):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(z,indent=2),encoding='utf8');tmp.replace(path)

def generate(family,rho,kind,noise,seed):
    rng=np.random.default_rng(8473100+seed+int(rho*1000)+int(noise*10000)+{'static':0,'partial':100000,'whole':200000}[kind]+(1000000 if family=='continuous' else 0))
    d=8;m=4;common=rng.normal(size=d);common/=np.linalg.norm(common)
    def keys(n):
        z=np.sqrt(1-rho)*rng.normal(size=(n,d))/np.sqrt(d)+np.sqrt(rho)*common
        return z/np.linalg.norm(z,axis=1,keepdims=True)
    rotation=np.linalg.qr(rng.normal(size=(m,m)))[0]
    if family=='repeated':
        queries=keys(d);v0=rng.normal(size=(d,m));v1=v0.copy();mask=np.zeros((d,m),bool)
        if kind=='partial':mask[:2,0]=True
        elif kind=='whole':mask[:2,:]=True
        v1[mask]=rng.normal(size=mask.sum())
        index=np.array([j for _ in range(30) for j in rng.permutation(d)])
        index[120:]=rng.choice(2,size=120,p=[.8,.2])
        K=queries[index];targets=np.stack([v0[j] if t<120 else v1[j] for t,j in enumerate(index)])
        querymask=mask
    else:
        queries=keys(32);W0=rng.normal(size=(m,d));W1=W0.copy()
        if kind=='partial':W1[0,:2]+=rng.normal(size=2)
        elif kind=='whole':W1+=rng.normal(size=(m,d))
        v0=queries@W0.T;v1=queries@W1.T
        K=keys(240);basis=keys(2)
        K[120:]=rng.normal(size=(120,2))@basis+.02*rng.normal(size=(120,d))
        K[120:]/=np.linalg.norm(K[120:],axis=1,keepdims=True)
        targets=np.concatenate([K[:120]@W0.T,K[120:]@W1.T])
        querymask=np.abs(v1-v0)>1e-10
    V=(targets+rng.normal(scale=noise,size=targets.shape))@rotation
    return {'K':K,'V':V,'queries':queries,'v0':v0,'v1':v1,'rotation':rotation,'querymask':querymask}

def trial(data,method,gamma):
    memory=Memory(8,4,method,gamma);start=time.time();curve=[]
    for t,(k,v) in enumerate(zip(data['K'],data['V']),1):
        memory.step(k,v)
        if t%12==0:
            pred=memory.predict(data['queries'])@data['rotation'].T
            target=data['v0'] if t<=120 else data['v1']
            e=(pred-target)**2;mask=data['querymask']
            curve.append({'t':t,'mse':float(e.mean()),'changed_mse':float(e[mask].mean()) if mask.any() else None,
                          'unchanged_mse':float(e[~mask].mean()) if (~mask).any() else None})
            if method not in ['delta','dict','sliding']:assert np.linalg.eigvalsh(memory.C).min()>-1e-6
    return {'method':method,'gamma':gamma,'seconds':time.time()-start,'post_mse':float(np.mean([a['mse'] for a in curve if a['t']>120])),
            'final_mse':curve[-1]['mse'],'trajectory':curve,'events':memory.events,'state_scalars':memory.capacity()}

def summarize(rows):
    result={}
    for family in ['repeated','continuous']:
        rr=[r for r in rows if r['family']==family]
        if not rr:continue
        bymethod={}
        for method,g in METHODS:
            chosen=[r for r in rr if r['method']==method and r['gamma']==g]
            bymethod[method+'_'+str(g)]={'mean_post_mse':float(np.mean([r['post_mse'] for r in chosen])),
                'static_post_mse':float(np.mean([r['post_mse'] for r in chosen if r['kind']=='static'])) if any(r['kind']=='static' for r in chosen) else None,
                'partial_post_mse':float(np.mean([r['post_mse'] for r in chosen if r['kind']=='partial'])) if any(r['kind']=='partial' for r in chosen) else None,
                'seconds':float(sum(r['seconds'] for r in chosen)),'mean_state_scalars':float(np.mean([r['state_scalars'] for r in chosen]))}
        control=min((k for k in bymethod if not k.startswith('paired_tensor')),key=lambda k:bymethod[k]['mean_post_mse'])
        candidate=bymethod['paired_tensor_0.95'];best=bymethod[control]
        result[family]={'methods':bymethod,'best_single_control':control,
                        'relative_mse_reduction':1-candidate['mean_post_mse']/max(best['mean_post_mse'],1e-12)}
    ready=len(rows)==72*len(METHODS)
    met=ready and all(result[f]['relative_mse_reduction']>=.05 and
                     result[f]['methods']['paired_tensor_0.95']['static_post_mse']<=1.05*result[f]['methods'][result[f]['best_single_control']]['static_post_mse']+1e-10 and
                     all(result[f]['methods']['paired_tensor_0.95']['partial_post_mse']<=.95*result[f]['methods'][c]['partial_post_mse'] for c in ['paired_global_0.95','paired_key_0.95']) for f in ['repeated','continuous'])
    return {'families':result,'complete':ready,'triage_met':met,'method_runs':len(rows)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['smoke','pilot'],required=True);a=ap.parse_args()
    out=ROOT/a.phase;out.mkdir(exist_ok=True);start=time.time();rows=[]
    checks=validate();save(out/'validation.json',checks)
    configs=[(fam,rho,kind,noise,seed) for fam in ['repeated','continuous'] for rho in [0.,.8] for kind in ['static','partial','whole'] for noise in [0.,.05,.15] for seed in range(2)]
    if a.phase=='smoke':configs=[('repeated',.8,'static',.15,101),('repeated',.8,'partial',.15,102),('continuous',.8,'static',.15,101),('continuous',.8,'partial',.15,102)]
    completed=0
    try:
        for i,(family,rho,kind,noise,seed) in enumerate(configs):
            data=generate(family,rho,kind,noise,seed)
            np.savez_compressed(out/f'seq{i:03d}.npz',**data)
            for method,gamma in METHODS:
                row=trial(data,method,gamma)
                row.update({'family':family,'rho':rho,'kind':kind,'noise':noise,'seed':seed,'sequence':i})
                rows.append(row)
            completed+=1;elapsed=time.time()-start
            save(out/'raw.json',rows)
            save(out/'summary.json',summarize(rows))
            save(out/'status.json',{'state':'running','sequences_done':completed,'total':len(configs),'elapsed_seconds':elapsed,
                 'estimated_remaining_seconds':(len(configs)-completed)*elapsed/completed})
            print('DONE',family,rho,kind,noise,seed,elapsed,flush=True)
        save(out/'status.json',{'state':'complete','sequences_done':completed,'total':len(configs),'elapsed_seconds':time.time()-start,'method_runs':len(rows),
             'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'operator_sha256':hashlib.sha256((ROOT/'paired_replay.py').read_bytes()).hexdigest()})
    except Exception:
        save(out/'status.json',{'state':'failed','sequences_done':completed,'error':traceback.format_exc()})
        raise
if __name__=='__main__':main()
