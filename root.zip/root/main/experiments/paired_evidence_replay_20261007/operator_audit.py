"""Independent behavioral checks exercise actual rollback and equivariance."""
from pathlib import Path
import json,numpy as np
import paired_replay as op

def run():
    rng=np.random.default_rng(75901);d=3;m=2
    K=rng.normal(size=(96,d));K/=np.linalg.norm(K,axis=1,keepdims=True)
    V=rng.normal(size=(96,m))
    # Exercise the actual end_block branch at zero discount; direct ridge must match.
    discount=op.GAMMA
    try:
        op.GAMMA=0
        a=op.Memory(d,m,'single_block');errors=[]
        for t,(k,v) in enumerate(zip(K,V),1):
            a.step(k,v)
            direct=np.linalg.solve(K[:t].T@K[:t]+op.LAM*np.eye(d),K[:t].T@V[:t]).T
            errors.append(float(np.max(np.abs(a.theta.reshape(m,d)-direct))))
            assert np.allclose(a.C,np.kron(np.eye(m),K[:t].T@K[:t]),atol=1e-10)
        assert a.events,'Did not exercise rollback'
        assert max(errors)<1e-8
    finally:op.GAMMA=discount
    # Unit is covariant under orthogonal input/output coordinate rotations.
    Rk=np.linalg.qr(rng.normal(size=(d,d)))[0];Rv=np.linalg.qr(rng.normal(size=(m,m)))[0]
    W=rng.normal(size=(m,d));Wnew=W.copy();Wnew[0,0]+=3
    VV=np.concatenate([K[:48]@W.T,K[48:]@Wnew.T])
    b=op.Memory(d,m,'paired_tensor');c=op.Memory(d,m,'paired_tensor');rotation_errors=[]
    for k,v in zip(K,VV):
        b.step(k,v);c.step(k@Rk,v@Rv)
        expected=b.predict(K[:8])@Rv
        actual=c.predict(K[:8]@Rk)
        rotation_errors.append(float(np.max(np.abs(expected-actual))))
    assert b.events and len(b.events)==len(c.events)
    assert max(rotation_errors)<1e-7
    assert np.linalg.eigvalsh(b.C).min()>0
    report={'actual_rollback_direct_ridge_max_error':max(errors),'rollback_events_tested':len(a.events),
            'input_output_rotation_max_error':max(rotation_errors),'rotated_event_count':len(b.events),
            'limitations':'Numerical invariance/no-double-count checks, not training convergence, scientific validation, or novelty proof'}
    Path(__file__).with_name('operator_audit.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report))
    return report
if __name__=='__main__':run()
