"""Read-only model/data audit and CPU inference benchmark; outputs isolated."""
from pathlib import Path
import json,sys,time,hashlib
import numpy as np
import torch,h5py
from scipy.io import loadmat
from transformers import PretrainedConfig
P=Path('/root/FAST');sys.path.insert(0,str(P))
from FAST import FAST
from BCIC2020Track3_preprocess import Electrodes,Zones
R=Path(__file__).resolve().parent

def forward(model,x):
    f=model.forward_head(x)
    tokens=model.input_layer(f.flatten(2))
    tokens=torch.cat([model.cls_token.expand(len(x),-1,-1),tokens],1)
    h=model.transformer(tokens+model.pos_embedding[:,:model.n_tokens+1])[:,0]
    return model.last_layer(model.dropout(h)),f,h

def audit():
    records=[];ref=None
    for s in range(15):
        for folder,key in [('Training set','epo_train'),('Validation set','epo_validation')]:
            d=loadmat(P/'BCIC2020Track3'/folder/f'Data_Sample{s+1:02d}.mat',simplify_cells=True)
            e=d[key];m=d['mnt'];clab=list(map(str,e['clab']));mc=list(map(str,m['clab']))
            assert clab==Electrodes==mc
            assert float(e['fs'])==256
            assert list(map(str,e['className']))==['Hello','Helpme','Stop','Thankyou','Yes']
            xy=np.stack([m['x'],m['y']],1);xyz=np.asarray(m['pos_3d']).T
            if ref is None: ref=xy.copy()
            records.append(dict(subject=s+1,set=folder,channels_match=True,fs=256,coordinates_match_reference=bool(np.allclose(ref,xy))))
            if s==0 and folder=='Training set':
                metadata=dict(electrodes=clab,zones=Zones,class_names=list(map(str,e['className'])),fs=256,
                              xy=xy.tolist(),xyz=xyz.tolist(),times_ms=np.asarray(e['t']).tolist(),
                              coordinate_note='Dataset-provided montage coordinates; not individually digitized MRI-space source locations.')
            del d
    metadata['audit']=records
    metadata['checkpoints']={f'{m}_seed{seed}':len(list((P/f'experiments/mechanism_20260927/results/full_{m}_seed{seed}').glob('*-fold*.pt'))) for seed in (42,142,242) for m in ('ce','protected','additive')}
    assert all(v==75 for v in metadata['checkpoints'].values())
    (R/'metadata.json').write_text(json.dumps(metadata,indent=2))
    ck=torch.load(P/'experiments/mechanism_20260927/results/full_ce_seed42/0-fold0.pt',map_location='cpu',weights_only=False)
    model=FAST(PretrainedConfig(**ck['config'])).eval();model.load_state_dict(ck['state_dict'],strict=True)
    with h5py.File(P/'Processed/BCIC2020Track3.h5') as f: x=f['01/X'][:][ck['test_idx']];y=f['01/Y'][:][ck['test_idx']]
    saved=np.load(P/'experiments/mechanism_20260927/results/full_ce_seed42/0-fold0.npz')
    rows=[]
    for threads in (1,4,8):
        torch.set_num_threads(threads)
        for precision in ('fp32','bf16'):
            try:
                with torch.inference_mode(),torch.autocast('cpu',dtype=torch.bfloat16,enabled=precision=='bf16'):
                    logits,features,h=forward(model,torch.from_numpy(x));start=time.time()
                    for _ in range(3):logits,features,h=forward(model,torch.from_numpy(x))
                    seconds=(time.time()-start)/3
                pred=logits.float().argmax(1).numpy()
                rows.append(dict(threads=threads,precision=precision,seconds_per_70=seconds,accuracy=float((pred==y).mean()),saved_accuracy=float((saved['primary_pred']==y).mean()),prediction_mismatches=int((pred!=saved['primary_pred']).sum()),max_probability_difference=float(np.abs(logits.float().softmax(-1).numpy()-saved['primary_prob']).max())))
            except Exception as e: rows.append(dict(threads=threads,precision=precision,error=str(e)))
    report=dict(benchmark=rows,device='cpu',torch=torch.__version__,feature_shape=list(features.shape),hidden_shape=list(h.shape))
    (R/'cpu_benchmark.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)

if __name__=='__main__':audit()
