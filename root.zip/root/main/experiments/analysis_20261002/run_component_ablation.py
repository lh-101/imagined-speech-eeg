"""Controlled additive-objective ablations, isolated from historical results.

Inherited FAST architecture and original 200-epoch schedule are unchanged.
Variants change only the auxiliary representation or its kernel self-support.
This is a test of component necessity, not a new architecture or novelty claim.
"""
import argparse,importlib.util,json,sys,time,fcntl
from pathlib import Path
import numpy as np,torch
from torch.nn import functional as F
R=Path(__file__).resolve().parent
M=Path('/root/FAST/experiments/mechanism_20260927')
sys.path.insert(0,str(M))
import run_mechanism_study as study
v4=study.v4
original_representation=v4.representation
original_ridge=v4.ridge_fit
VARIANTS=['regional_loo','global_loo','joint_loo','joint_self_support']

def representation_for(name):
    def call(model,x):
        logits,q=original_representation(model,x)
        if name=='regional_loo':q=q[:,:-32]*(2.**.5)
        elif name=='global_loo':q=q[:,-32:]*(2.**.5)
        return logits,q
    return call

def self_supported(q,y):
    k=v4.kernel(q,q);chol=torch.linalg.cholesky(k+v4.CFG['ridge']*torch.eye(len(q),device=q.device,dtype=k.dtype))
    target=F.one_hot(y,5).to(k.dtype);alpha=torch.cholesky_solve(target,chol)
    return alpha,(k@alpha).float()

def sanity():
    # Identity is compared against literal refits at fixed representations.
    torch.manual_seed(7);q=F.normalize(torch.randn(8,12,dtype=torch.float64),dim=-1).requires_grad_();y=torch.arange(8)%5
    _,loo=original_ridge(q,y);explicit=[]
    for i in range(len(q)):
        ix=torch.arange(len(q))!=i;k=v4.kernel(q[ix],q[ix]);target=F.one_hot(y[ix],5).double()
        a=torch.linalg.solve(k+v4.CFG['ridge']*torch.eye(ix.sum(),dtype=k.dtype),target)
        explicit.append((v4.kernel(q[i:i+1],q[ix])@a).squeeze(0))
    error=float((loo.double()-torch.stack(explicit)).abs().max())
    assert error<1e-6
    loss=F.cross_entropy(4*loo,y);g=torch.autograd.grad(loss,q)[0];assert torch.isfinite(g).all()
    _,own=self_supported(q.detach(),y);assert not torch.allclose(own,loo)
    return dict(loo_max_refit_error=error,finite_loo_gradients=True,self_support_differs=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--launch',action='store_true')
    ap.add_argument('--seeds',type=int,nargs='+',default=[42,142,242]);ap.add_argument('--subjects',type=int,nargs='+',default=list(range(15)))
    ap.add_argument('--variants',nargs='+',choices=VARIANTS,default=VARIANTS);a=ap.parse_args()
    study.ROOT=R/'component_ablation';study.OUT=study.ROOT/'results';study.ROOT.mkdir(exist_ok=True);study.OUT.mkdir(exist_ok=True)
    study.JOBS=[dict(method=m,condition='full',seed=s) for s in a.seeds for m in a.variants]
    protocol=dict(variants=a.variants,seeds=a.seeds,subjects=a.subjects,epochs=200,optimizer='AdamW',
                  aux_weight=.3,ridge=.1,kernel_gamma=2.,score_scale=4.,update='direct gradient sum',
                  n_folds=len(study.JOBS)*len(a.subjects)*5,original_manifest=json.loads((M/'manifest.json').read_text()),
                  source_sha256=study.sha(Path(__file__)),sanity=sanity(),
                  note='No protected gradient or new input preprocessing. Joint LOO is a replay control. Historical CE is a reference; new training uses the same inherited schedule. Small-subject pilot cannot support population conclusions. No outer-test-based hyperparameter selection.')
    print(json.dumps({k:v for k,v in protocol.items() if k!='original_manifest'},indent=2),flush=True)
    if not a.launch:return
    if not torch.cuda.is_available():raise RuntimeError('No GPU: preparation/check passed; training was not started.')
    lock=(study.ROOT/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    path=study.ROOT/'protocol.json'
    if path.exists():assert json.loads(path.read_text())==protocol,'Protocol mismatch: use a distinct output directory.'
    else:study.atomic_json(path,protocol)
    for ji,job in enumerate(study.JOBS):
        v4.representation=representation_for(job['method'])
        v4.ridge_fit=self_supported if job['method']=='joint_self_support' else original_ridge
        dest=study.OUT/study.job_name(job);dest.mkdir(exist_ok=True)
        for s in a.subjects:
            status=dict(state='running',job=study.job_name(job),job_index=ji,jobs=len(study.JOBS),updated=time.time())
            study.subject(job,s,dest,status)
            for fi in range(5):
                hashes=[json.loads(p.read_text())['initial_state_sha256'] for p in study.OUT.glob(f'full_*_seed{job["seed"]}/{s}-fold{fi}.json')]
                assert len(set(hashes))==1,'Unequal initialization'
            study.report()
    study.atomic_json(study.ROOT/'status.json',dict(state='complete',updated=time.time()))

if __name__=='__main__':main()
