"""Frozen-checkpoint inference diagnostics, no training and no model selection.

CPU FP32 anchor is checked against saved CUDA BF16 predictions. Perturbation
deltas always use the same CPU anchor. Region masks do not imply source activity.
"""
import argparse,json,sys,time,os,fcntl
from pathlib import Path
import numpy as np
import h5py,torch
from transformers import PretrainedConfig
from audit_cpu import forward
P=Path('/root/FAST');sys.path.insert(0,str(P))
from FAST import FAST
R=Path(__file__).resolve().parent
OLD=P/'experiments/mechanism_20260927/results'
REGIONS=['Pre-frontal','Frontal','Pre-central','Central','Post-central','Temporal','Parietal','Occipital']
BANDS=[(1,4),(4,8),(8,13),(13,30),(30,80),(80,128.0001)]

def atomic(p,d):
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(d,indent=2));tmp.replace(p)

def qparts(f,h):
    r=torch.nn.functional.normalize(torch.asinh(f.float()).flatten(1),dim=-1)
    c=torch.nn.functional.normalize(h.float(),dim=-1)
    return dict(regional=r,global_cls=c,joint=torch.cat([r,c],1)/np.sqrt(2))

def geometry(parts,y):
    y=np.asarray(y);same=y[:,None]==y[None,:];valid=~np.eye(len(y),dtype=bool)
    out={}
    for name,z in parts.items():
        sim=(z@z.T).numpy();a=float(sim[same&valid].mean());b=float(sim[~same].mean())
        out[name]=dict(same_class_cosine=a,different_class_cosine=b,gap=a-b)
    return out

def predict(model,x):
    # Fixed chunking for anchor and interventions.
    out=[]
    for a in range(0,len(x),35):out.append(forward(model,torch.from_numpy(np.ascontiguousarray(x[a:a+35])))[0])
    return torch.cat(out).float()

def logits_from_features(model,f):
    tokens=model.input_layer(f.flatten(2))
    tokens=torch.cat([model.cls_token.expand(len(f),-1,-1),tokens],1)
    h=model.transformer(tokens+model.pos_embedding[:,:model.n_tokens+1])[:,0]
    return model.last_layer(model.dropout(h))

def spatial_predict(model,x,cached,region,indices):
    # CNN heads are independent; recompute only the intervened head, preserving
    # all unchanged features. This is numerically checked against full inference.
    region_index=list(model.config.zone_dict).index(region);out=[]
    for a in range(0,len(x),35):
        local=torch.from_numpy(np.ascontiguousarray(x[a:a+35,indices]))
        windows=local.unfold(-1,model.config.window_len,model.config.slide_step)
        b,c,n,t=windows.shape
        new=model.head.encoders[region](windows.permute(0,2,1,3).reshape(b*n,c,t)).reshape(b,n,-1)
        features=cached[a:a+35].clone();features[:,:,region_index,:]=new
        out.append(logits_from_features(model,features))
    return torch.cat(out).float()

def metrics(logits,y,anchor):
    p=logits.softmax(-1).numpy();pred=p.argmax(1)
    return dict(accuracy=float((pred==y).mean()),accuracy_drop_pp=float(((anchor==y).mean()-(pred==y).mean())*100),
                nll=float(-np.log(np.maximum(p[np.arange(len(y)),y],1e-12)).mean()))

def run_fold(method,seed,s,fi,mode):
    dest=R/'results'/f'{mode}_{method}_seed{seed}';dest.mkdir(parents=True,exist_ok=True)
    name=f'{s}-fold{fi}';out=dest/(name+'.json')
    if out.exists():return json.loads(out.read_text())
    start=time.time();src=OLD/f'full_{method}_seed{seed}'
    ck=torch.load(src/(name+'.pt'),map_location='cpu',weights_only=False)
    cfg=PretrainedConfig(**ck['config']);model=FAST(cfg).eval();model.load_state_dict(ck['state_dict'],strict=True)
    tr=np.asarray(ck['train_idx']);te=np.asarray(ck['test_idx']);assert len(np.intersect1d(tr,te))==0
    with h5py.File(P/'Processed/BCIC2020Track3.h5') as h:
        x=h[f'{s+1:02d}/X'][:][te];y=h[f'{s+1:02d}/Y'][:][te].astype(int)
    saved=np.load(src/(name+'.npz'));assert np.array_equal(saved['y'],y)
    with torch.inference_mode():
        chunks=[forward(model,torch.from_numpy(np.ascontiguousarray(x[a:a+35]))) for a in range(0,len(x),35)]
        logits,f,h=[torch.cat([c[k] for c in chunks]) for k in range(3)]
        anchor=logits.argmax(1).numpy();parts=qparts(f,h)
        result=dict(method=method,seed=seed,subject=s,fold=fi,precision='cpu_fp32',n_test=len(te),
                    saved_cuda_accuracy=float((saved['primary_pred']==y).mean()),cpu_accuracy=float((anchor==y).mean()),
                    saved_prediction_mismatches=int((anchor!=saved['primary_pred']).sum()),
                    max_probability_difference=float(np.abs(logits.softmax(-1).numpy()-saved['primary_prob']).max()),
                    geometry=geometry(parts,y),perturbations={})
        if mode=='spatial':
            for region in REGIONS:
                ix=[cfg.electrodes.index(e) for e in cfg.zone_dict[region]]
                for replacement in ('zero','trial_mean'):
                    z=x.copy()
                    z[:,ix,:]=0 if replacement=='zero' else x[:,ix,:].mean(-1,keepdims=True)
                    perturbed=spatial_predict(model,z,f,region,ix)
                    if s==0 and fi==0 and region==REGIONS[0] and replacement=='zero':
                        reference=predict(model,z)
                        assert torch.allclose(reference,perturbed,atol=1e-5,rtol=1e-5)
                        result['cached_head_max_error']=float((reference-perturbed).abs().max())
                    result['perturbations'][region+'__'+replacement]=dict(n_channels=len(ix),**metrics(perturbed,y,anchor))
        if mode=='temporal':
            for a in range(0,750,150):
                z=x.copy();z[:,:,a:a+150]=0
                result['perturbations'][f'{a}:{a+150}']=metrics(predict(model,z),y,anchor)
        if mode=='frequency':
            # Transform original 795 measured samples, then reproduce 5-sample edge padding.
            raw=x[:,:,:795].astype(np.float64);spectrum=np.fft.rfft(raw,axis=-1);freq=np.fft.rfftfreq(795,1/256.)
            for lo,hi in BANDS:
                spec=spectrum.copy();spec[:,:,(freq>=lo)&(freq<hi)]=0
                z=np.fft.irfft(spec,n=795,axis=-1).astype(np.float32);z=np.pad(z,((0,0),(0,0),(0,5)),mode='edge')
                result['perturbations'][f'{lo:g}-{min(hi,128):g}Hz']=metrics(predict(model,z),y,anchor)
        # Store unprojected held-out features; no cross-fold embedding pooling.
        np.savez_compressed(dest/(name+'.npz'),test_idx=te,y=y,pred=anchor,logits=logits.numpy(),
                            regional=parts['regional'].numpy(),global_cls=parts['global_cls'].numpy())
    result['seconds']=time.time()-start;atomic(out,result)
    print('FOLD_DONE',mode,method,seed,s,fi,round(result['seconds'],2),result['saved_prediction_mismatches'],flush=True)
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['features','spatial','temporal','frequency'],default='features')
    ap.add_argument('--methods',nargs='+',default=['ce','protected','additive']);ap.add_argument('--seeds',type=int,nargs='+',default=[42])
    ap.add_argument('--subjects',type=int,nargs='+',default=list(range(15)));ap.add_argument('--folds',type=int,nargs='+',default=list(range(5)))
    ap.add_argument('--threads',type=int,default=4);a=ap.parse_args();torch.set_num_threads(a.threads)
    lock=(R/(a.mode+'.lock')).open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    jobs=[(m,seed,s,f) for seed in a.seeds for s in a.subjects for m in a.methods for f in a.folds]
    atomic(R/(a.mode+'_protocol.json'),dict(arguments=vars(a),n_folds=len(jobs),training=False,
        note='Exploratory analysis of development-used outer folds. Perturbations at inference are distribution shifts, not source localization. Regions have unequal channel counts. CPU anchors may differ from historical CUDA BF16.',
        aggregation='Within-fold statistics; average folds, then seeds within subject. Subject is statistical unit.'))
    rows=[];start=time.time()
    for j,job in enumerate(jobs):
        atomic(R/(a.mode+'_status.json'),dict(state='running',done=j,total=len(jobs),current=job,pid=os.getpid(),elapsed_seconds=time.time()-start))
        rows.append(run_fold(*job,a.mode))
    atomic(R/(a.mode+'_summary.json'),dict(complete=True,rows=rows,seconds=time.time()-start))
    atomic(R/(a.mode+'_status.json'),dict(state='complete',done=len(jobs),total=len(jobs),seconds=time.time()-start))

if __name__=='__main__':main()
