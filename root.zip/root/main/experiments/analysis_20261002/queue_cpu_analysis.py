"""One-off local process queue, not a scheduled automation or active watcher."""
import json,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parent
def main():
    while True:
        p=R/'features_status.json'
        if p.exists():
            s=json.loads(p.read_text())
            if s['state']=='complete':break
            if not Path(f'/proc/{s["pid"]}').exists():raise RuntimeError('Feature extraction stopped before completion; no automatic training/retry.')
        time.sleep(15)
    with (R/'plot.log').open('a') as log:
        subprocess.check_call(['/root/venv_fast/bin/python',str(R/'plot_completed_analysis.py'),'features'],stdout=log,stderr=log,cwd=R)
    with (R/'spatial.log').open('a') as log:
        code=subprocess.call(['/root/venv_fast/bin/python','-u',str(R/'analyze_saved_models.py'),'--mode','spatial','--threads','1','--seeds','42'],stdout=log,stderr=log,cwd=R)
    (R/'queue_result.json').write_text(json.dumps(dict(spatial_exit_code=code,finished=time.time())))
    if code:raise RuntimeError('Spatial analysis failed; inspect spatial.log')
    with (R/'plot.log').open('a') as log:
        subprocess.check_call(['/root/venv_fast/bin/python',str(R/'plot_completed_analysis.py'),'spatial'],stdout=log,stderr=log,cwd=R)
if __name__=='__main__':main()
