"""Plot only complete subject/fold summaries; no placeholder outcome graphics."""
import argparse,json,csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from matplotlib.patches import Circle,Polygon
R=Path(__file__).resolve().parent
M=['ce','protected','additive'];N=['CE only','Auxiliary + protected','Auxiliary + additive'];C=['#7C9FB5','#338F7B','#97BFA7']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42})
def save(fig,name):
    for ext in ('svg','pdf','png'):fig.savefig(R/(name+'.'+ext),bbox_inches='tight',dpi=200)
    plt.close(fig)
def load(mode):
    d=json.loads((R/(mode+'_summary.json')).read_text());assert d['complete']
    rows=d['rows'];keys={(r['method'],r['seed'],r['subject'],r['fold']) for r in rows}
    for m in M:
        for s in range(15):assert all((m,42,s,f) in keys for f in range(5))
    return rows
def subjects(rows,m,value):
    return np.array([np.mean([value(r) for r in rows if r['method']==m and r['subject']==s]) for s in range(15)])
def features():
    rows=load('features');fig,axs=plt.subplots(1,3,figsize=(11.5,3.5),layout='constrained')
    report={}
    for ax,key,title in zip(axs,['regional','global_cls','joint'],['a  Regional representation','b  Global CLS representation','c  Balanced joint representation']):
        vals=[subjects(rows,m,lambda r:r['geometry'][key]['gap']) for m in M]
        for s in range(15):ax.plot(range(3),[v[s] for v in vals],color='#B8C7CD',lw=.7,alpha=.7)
        for j,v in enumerate(vals):ax.scatter(np.full(15,j),v,color=C[j],s=22);ax.plot([j-.16,j+.16],[v.mean()]*2,color=C[j],lw=3)
        ax.set(xticks=range(3),xticklabels=['CE','Protected','Additive'],ylabel='Same-class minus different-class cosine',title=title)
        report[key]={m:dict(subject_mean=float(v.mean()),subject_sd=float(v.std(ddof=1))) for m,v in zip(M,vals)}
    save(fig,'05_heldout_representation_geometry')
    report['anchor_audit']=dict(total_trials=sum(r['n_test'] for r in rows),prediction_mismatches=sum(r['saved_prediction_mismatches'] for r in rows),cpu_accuracy=float(np.mean([r['cpu_accuracy'] for r in rows])),note='Within-fold geometry; seed42; development-used folds; no cross-fold feature pooling. Each point is a subject, five folds averaged. This does not prove regional/global complementarity.')
    (R/'geometry_statistics.json').write_text(json.dumps(report,indent=2))
def head(ax,values,meta,norm):
    xy=np.asarray(meta['xy']);names=meta['electrodes'];groups=meta['zones']
    by_channel={e:values[k] for k,(_,names_z) in enumerate(groups.items()) for e in names_z}
    ax.add_patch(Circle((0,0),.92,facecolor='#F7FAFA',edgecolor='#849AA4',lw=1.1))
    ax.add_patch(Polygon([[-.07,.917],[0,1.01],[.07,.917]],closed=False,fill=False,edgecolor='#849AA4'))
    v=[by_channel[e] for e in names]
    sc=ax.scatter(xy[:,0],xy[:,1],c=v,cmap='RdBu_r',norm=norm,s=80,edgecolors='white',linewidths=.45,zorder=3)
    ax.set(xlim=(-1.04,1.04),ylim=(-1.01,1.08));ax.set_aspect('equal');ax.axis('off');return sc
def spatial():
    rows=load('spatial');meta=json.loads((R/'metadata.json').read_text());regions=list(meta['zones'])
    table=[];data={}
    for mode in ('zero','trial_mean'):
        for m in M:
            v=np.stack([subjects(rows,m,lambda r:r['perturbations'][g+'__'+mode]['accuracy_drop_pp']) for g in regions],1)
            data[mode,m]=v
            for s in range(15):
                for j,g in enumerate(regions):table.append(dict(method=m,subject=s+1,replacement=mode,region=g,n_channels=len(meta['zones'][g]),accuracy_drop_pp=v[s,j]))
    limit=max(1.,max(np.abs(v.mean(0)).max() for v in data.values()));norm=TwoSlopeNorm(vmin=-limit,vcenter=0,vmax=limit)
    fig,axs=plt.subplots(2,3,figsize=(10.8,7),layout='constrained')
    for i,mode in enumerate(('zero','trial_mean')):
        for j,m in enumerate(M):
            sc=head(axs[i,j],data[mode,m].mean(0),meta,norm);axs[i,j].set_title(N[j]+'\n'+('Zero replacement' if i==0 else 'Trial-mean replacement'),fontsize=10)
    fig.colorbar(sc,ax=axs,label='Accuracy drop relative to CPU anchor (pp)',shrink=.8)
    fig.suptitle('Regional inference sensitivity · seed42 · 15 subjects\nOne measured value per channel group; colours repeated within each group',fontsize=12)
    save(fig,'06_regional_sensitivity_maps')
    fig,axs=plt.subplots(1,2,figsize=(12,4),layout='constrained')
    rng=np.random.default_rng(42)
    for ax,mode in zip(axs,('zero','trial_mean')):
        for j,m in enumerate(M):
            diff=data[mode,m]-data[mode,'ce']
            if m=='ce':continue
            mean=diff.mean(0);boot=diff[rng.integers(0,15,size=(10000,15))].mean(1);lo,hi=np.quantile(boot,[.025,.975],axis=0)
            x=np.arange(8)+(j-1.5)*.16
            ax.errorbar(x,mean,yerr=np.maximum(0,np.stack([mean-lo,hi-mean])),fmt='o',color=C[j],capsize=3,label=N[j])
        ax.axhline(0,color='#849AA4',lw=1);ax.set(xticks=range(8),xticklabels=regions,ylabel='Sensitivity difference from CE (pp)',title=mode.replace('_',' '));ax.tick_params(axis='x',labelrotation=45);ax.legend(fontsize=8,frameon=False)
    save(fig,'07_regional_paired_differences')
    with (R/'regional_subject_values.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(table[0]));writer.writeheader();writer.writerows(table)
    audit=dict(total_predictions=sum(r['n_test'] for r in rows),anchor_mismatches=sum(r['saved_prediction_mismatches'] for r in rows),median_seconds_per_fold=float(np.median([r['seconds'] for r in rows])),
               note='Inference perturbation, unequal region sizes, subject bootstrap intervals descriptive and not multiplicity-corrected; seed42 only; not neural source attribution.')
    (R/'spatial_statistics.json').write_text(json.dumps(audit,indent=2))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['features','spatial']);a=ap.parse_args()
    features() if a.mode=='features' else spatial()
