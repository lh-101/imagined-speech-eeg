import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import sys
sys.path.insert(0,'/root/FAST/experiments/paired_evidence_replay_20261007')
import run_experiment as ref
from bilateral_memory import BilateralMemory,validate
import numpy as np,json,time,argparse,hashlib,traceback
from pathlib import Path

ROOT=Path(__file__).resolve().parent
NEW={'bilateral':'bilateral','data_full':'full_output','data_single':'single_output','data_random':'random_output','data_parameter':'parameter','data_global':'global'}
METHODS=[(k,.95) for k in NEW]+ref.METHODS

def save(p,z):
    q=p.with_suffix('.tmp');q.write_text(json.dumps(z,indent=2),encoding='utf8');q.replace(p)

def run(data,method,gamma):
    if method not in NEW:return ref.trial(data,method,gamma)
    mem=BilateralMemory(8,4,NEW[method]);curve=[];start=time.time()
    for t,(k,v) in enumerate(zip(data['K'],data['V']),1):
        mem.step(k,v)
        if t%12==0:
            prediction=mem.predict(data['queries'])@data['rotation'].T
            target=data['v0'] if t<=120 else data['v1'];err=(prediction-target)**2;mask=data['querymask']
            curve.append({'t':t,'mse':float(err.mean()),'changed_mse':float(err[mask].mean()) if mask.any() else None,
                          'unchanged_mse':float(err[~mask].mean()) if (~mask).any() else None})
            assert np.linalg.eigvalsh(mem.C).min()>-1e-6
    return {'method':method,'gamma':gamma,'post_mse':float(np.mean([r['mse'] for r in curve if r['t']>120])),
            'final_mse':curve[-1]['mse'],'trajectory':curve,'events':mem.events,'confirmations':mem.confirmations,
            'state_scalars':mem.capacity(),'seconds':time.time()-start}

def summary(rows,complete=False):
    reports={}
    for family in ['repeated','continuous']:
        rr=[r for r in rows if r['family']==family]
        if not rr:continue
        values={}
        for name,g in METHODS:
            rs=[r for r in rr if r['method']==name and r['gamma']==g]
            if not rs:continue
            values[name+'_'+str(g)]={'post_mse':float(np.mean([r['post_mse'] for r in rs])),
                'static_mse':float(np.mean([r['post_mse'] for r in rs if r['kind']=='static'])) if any(r['kind']=='static' for r in rs) else None,
                'partial_mse':float(np.mean([r['post_mse'] for r in rs if r['kind']=='partial'])) if any(r['kind']=='partial' for r in rs) else None,
                'time_seconds':float(sum(r['seconds'] for r in rs)),'state_scalars':float(np.mean([r['state_scalars'] for r in rs]))}
        control=min((k for k in values if k!='bilateral_0.95'),key=lambda k:values[k]['post_mse'])
        reports[family]={'methods':values,'best_control':control,
             'mse_reduction_vs_best_control':1-values['bilateral_0.95']['post_mse']/max(values[control]['post_mse'],1e-12)}
    met=complete and all(reports[f]['mse_reduction_vs_best_control']>=.05 and
         reports[f]['methods']['bilateral_0.95']['static_mse']<=1.05*reports[f]['methods'][reports[f]['best_control']]['static_mse']+1e-10 and
         all(reports[f]['methods']['bilateral_0.95']['partial_mse']<=.95*reports[f]['methods'][k]['partial_mse'] for k in ['data_full_0.95','data_single_0.95','data_random_0.95']) for f in ['repeated','continuous'])
    return {'complete':complete,'triage_met':met,'families':reports,'method_runs':len(rows),
            'claim':'Exploratory operator screening; mathematical ingredients known; no firstness or EEG improvement claim.'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['smoke','pilot'],required=True);a=ap.parse_args()
    out=ROOT/a.phase;out.mkdir(exist_ok=True);rows=[];start=time.time();done=0
    try:
        save(out/'validation.json',validate())
        configs=[(f,r,k,n,s) for f in ['repeated','continuous'] for r in [0.,.8] for k in ['static','partial','whole'] for n in [0.,.05,.15] for s in [100,101]]
        if a.phase=='smoke':configs=[('repeated',.8,'partial',.15,201),('continuous',.8,'partial',.15,201)]
        for i,(family,rho,kind,noise,seed) in enumerate(configs):
            data=ref.generate(family,rho,kind,noise,seed);np.savez_compressed(out/f'seq{i:03d}.npz',**data)
            confirmations=[]
            for method,gamma in METHODS:
                row=run(data,method,gamma)
                row.update({'family':family,'rho':rho,'kind':kind,'noise':noise,'seed':seed,'sequence':i})
                if method in NEW:confirmations.append(row['confirmations'])
                rows.append(row)
            assert all(c==confirmations[0] for c in confirmations),'New controllers differ'
            done+=1;elapsed=time.time()-start
            save(out/'raw.json',rows);save(out/'summary.json',summary(rows))
            save(out/'status.json',{'state':'running','sequences_done':done,'total':len(configs),'elapsed_seconds':elapsed,
                 'estimated_remaining_seconds':(len(configs)-done)*elapsed/done})
            print('DONE',family,rho,kind,noise,seed,elapsed,flush=True)
        save(out/'summary.json',summary(rows,a.phase=='pilot'))
        save(out/'status.json',{'state':'complete','sequences_done':done,'total':len(configs),'method_runs':len(rows),'elapsed_seconds':time.time()-start,
            'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'operator_sha256':hashlib.sha256((ROOT/'bilateral_memory.py').read_bytes()).hexdigest(),
            'previous_operator_sha256':hashlib.sha256(Path(ref.Memory.__module__ and '/root/FAST/experiments/paired_evidence_replay_20261007/paired_replay.py').read_bytes()).hexdigest()})
    except Exception:
        save(out/'status.json',{'state':'failed','sequences_done':done,'error':traceback.format_exc()});raise
if __name__=='__main__':main()
