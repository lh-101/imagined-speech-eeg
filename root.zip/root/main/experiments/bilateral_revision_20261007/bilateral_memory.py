import sys
sys.path.insert(0,'/root/FAST/experiments/paired_evidence_replay_20261007')
import paired_replay as old
import numpy as np

class BilateralMemory(old.Memory):
    def __init__(self,d,m,mode):
        super().__init__(d,m,'rls')
        self.mode=mode;self.dataC=np.zeros((d,d));self.generator=np.random.default_rng(73042)
        self.confirmations=[]

    def start_block(self):
        super().start_block()
        self.metric=self.dataC.copy()

    def end_block(self):
        if not self.hist_ready:return
        L=np.linalg.cholesky(self.metric+old.LAM*np.eye(self.d))
        A,B=[np.linalg.solve(L,(g/max(n,1)).reshape(self.m,self.d).T).T for g,n in zip(self.grad,self.count)]
        cosine=float(np.sum(A*B)/(np.linalg.norm(A)*np.linalg.norm(B))) if min(np.linalg.norm(A),np.linalg.norm(B))>1e-12 else -1.
        if cosine<=old.COS:return
        self.confirmations.append(self.t)
        S=(A@B.T+B@A.T)/2
        values,vectors=np.linalg.eigh(S)
        keep=[]
        for j in range(self.m):
            u=vectors[:,j];a=u@A;b=u@B
            cos=float(a@b/(np.linalg.norm(a)*np.linalg.norm(b))) if min(np.linalg.norm(a),np.linalg.norm(b))>1e-12 else -1.
            if values[j]>1e-12 and cos>old.COS:keep.append(j)
        U=vectors[:,keep];rank=U.shape[1]
        if self.mode in ['bilateral','single_output','random_output'] and rank==0:return
        if self.mode=='full_output':U=np.eye(self.m)
        elif self.mode=='single_output':U=np.linalg.eigh(A@A.T)[1][:,-rank:]
        elif self.mode=='random_output':U=np.linalg.qr(self.generator.normal(size=(self.m,self.m)))[0][:,:rank]
        Q=self.startC+old.LAM*self.eye
        self.C=self.startC.copy();self.theta=self.startTheta.copy()
        if self.mode=='global':self.C*=1-old.GAMMA;revision_rank=self.N
        elif self.mode=='parameter':
            LL=np.linalg.cholesky(Q)
            z=[np.linalg.solve(LL,g/max(n,1)) for g,n in zip(self.grad,self.count)]
            u=z[0]/max(np.linalg.norm(z[0]),1e-30)+z[1]/max(np.linalg.norm(z[1]),1e-30)
            assert np.linalg.norm(u)>1e-12, 'Degenerate parameter control direction'
            D=np.linalg.solve(LL.T,(u/np.linalg.norm(u))[:,None])
            self.C=old.forget(self.C,D,old.GAMMA);revision_rank=1
        else:
            K=np.stack([k for k,v in self.buffer])
            # Reduce to an orthonormal input span before constructing the product.
            _,singular,Vh=np.linalg.svd(K,full_matrices=False)
            inputrank=int((singular>1e-10*max(singular[0],1)).sum())
            V=Vh[:inputrank].T
            D=np.linalg.solve(Q,np.kron(U,V))
            self.C=old.forget(self.C,D,old.GAMMA);revision_rank=U.shape[1]*inputrank
        for k,v in self.buffer:self.ridge_update(k,v)
        self.events.append({'t':self.t,'cosine':cosine,'output_rank':rank,'revision_rank':revision_rank,'mode':self.mode})

    def step(self,k,v):
        self.t+=1
        if (self.t-1)%old.BLOCK==0:self.start_block()
        group=(self.t-1)%2
        self.grad[group]+=self.h(k).T@(v-self.references[group]@k)
        self.count[group]+=1;self.buffer.append((k.copy(),v.copy()))
        self.histC[group]+=np.outer(k,k)
        self.histW[group]+=np.outer(v-self.histW[group]@k,np.linalg.solve(self.histC[group]+old.LAM*np.eye(self.d),k))
        self.dataC+=np.outer(k,k)
        self.ridge_update(k,v)
        if self.t%old.BLOCK==0:self.end_block()
        assert np.isfinite(self.theta).all()

    def capacity(self):
        return 2*self.N**2+8*self.N+3*self.d**2+old.BLOCK*(self.d+self.m)+self.m**2

def validate():
    rng=np.random.default_rng(81734);d=3;m=2
    K=rng.normal(size=(96,d));K/=np.linalg.norm(K,axis=1,keepdims=True)
    W=rng.normal(size=(m,d));W2=W.copy();W2[0,0]+=3
    V=np.concatenate([K[:48]@W.T,K[48:]@W2.T])
    Rk=np.linalg.qr(rng.normal(size=(d,d)))[0];Rv=np.linalg.qr(rng.normal(size=(m,m)))[0]
    a=BilateralMemory(d,m,'bilateral');b=BilateralMemory(d,m,'bilateral');error=[]
    for k,v in zip(K,V):
        a.step(k,v);b.step(k@Rk,v@Rv)
        error.append(float(np.max(np.abs(a.predict(K[:5])@Rv-b.predict(K[:5]@Rk)))))
    assert a.events and len(a.events)==len(b.events)
    assert max(error)<1e-7
    assert np.linalg.eigvalsh(a.C).min()>0
    # Six event controllers must agree despite different revised memory states.
    models=[BilateralMemory(d,m,mode) for mode in ['bilateral','full_output','single_output','random_output','parameter','global']]
    for k,v in zip(K,V):
        for model in models:model.step(k,v)
    assert all(model.confirmations==models[0].confirmations for model in models)
    discount=old.GAMMA
    try:
        old.GAMMA=0;z=BilateralMemory(d,m,'full_output');maxdirect=0.
        for t,(k,v) in enumerate(zip(K,V),1):
            z.step(k,v)
            direct=np.linalg.solve(K[:t].T@K[:t]+old.LAM*np.eye(d),K[:t].T@V[:t]).T
            maxdirect=max(maxdirect,float(np.max(np.abs(direct-z.theta.reshape(m,d)))))
        assert z.events and maxdirect<1e-8
    finally:old.GAMMA=discount
    return {'rotation_max_error':max(error),'direct_replay_max_error':maxdirect,'shared_confirmation_events':models[0].confirmations,
            'positive_precision':True,'basis_invariance':True,'note':'Random-output control is randomized; no equivariance claim for its fixed random basis.'}
