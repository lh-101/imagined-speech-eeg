"""Final-error decomposition only; targets are used solely for evaluation."""
import sys,json,time
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/paired_evidence_replay_20261007')
from paired_replay import Memory
from bilateral_memory import BilateralMemory
import numpy as np

def run(out):
    start=time.time();out=Path(out)
    raw=json.loads((out/'raw.json').read_text())
    metadata={r['sequence']:r for r in raw if r['family']=='continuous'}
    rows=[]
    for index,meta in sorted(metadata.items()):
        with np.load(out/f'seq{index:03d}.npz') as z:data={k:z[k].copy() for k in z.files}
        queries=data['queries'];targetmap=np.linalg.lstsq(queries,data['v1'],rcond=None)[0]
        assert np.allclose(queries@targetmap,data['v1'],atol=1e-10)
        _,singular,Vh=np.linalg.svd(data['K'][120:],full_matrices=False)
        P=Vh[:2].T@Vh[:2]
        qs=queries@P;qr=queries@(np.eye(8)-P)
        models={'bilateral':BilateralMemory(8,4,'bilateral'),
                'data_full':BilateralMemory(8,4,'full_output'),
                'global_0.03':Memory(8,4,'global',.03),'delta_1':Memory(8,4,'delta',1)}
        for k,v in zip(data['K'],data['V']):
            for memory in models.values():memory.step(k,v)
        for method,memory in models.items():
            es=memory.predict(qs)@data['rotation'].T-qs@targetmap
            er=memory.predict(qr)@data['rotation'].T-qr@targetmap
            total=memory.predict(queries)@data['rotation'].T-data['v1']
            assert np.allclose(total,es+er,atol=1e-10)
            row={k:meta[k] for k in ['sequence','rho','kind','noise','seed']}
            row.update({'method':method,'final_mse':float((total**2).mean()),
                        'dominant_plane_mse':float((es**2).mean()),'remaining_plane_mse':float((er**2).mean()),
                        'cross_term':float(2*(es*er).mean()),'input_singular_values':singular.tolist()})
            expected=next(r['final_mse'] for r in raw if r['sequence']==index and
                          (r['method']==method if method in ['bilateral','data_full'] else r['method']==method.split('_')[0] and r['gamma']==float(method.split('_')[1])))
            assert abs(expected-row['final_mse'])<1e-10,'Audit changed main final predictions'
            rows.append(row)
    report={'rows':rows,'elapsed_seconds':time.time()-start,
            'scope':'Final-time linear prediction errors split using dominant two observed key directions. Components include a cross term; remaining directions have small nonzero observations. Diagnostic only, not a new success criterion.'}
    (out/'plane_audit.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    return {'plane_audit_complete':True,'plane_audit_rows':len(rows),'plane_audit_seconds':report['elapsed_seconds']}
