# 路由诊断已完成：描述性结果

全部60个预设条件保留。简化网络、单种子筛查，不能据此认定新原理成立或官方多流模型存在故障。
下表均方误差越低越好；比值为完整预测Jacobian范数/缓存路由预测Jacobian范数，三个验证样本平均。
反馈差异是导数测量，不能代替性能因果证据。固定路由实际自由度较小。

|骨干|任务|深度|条件|测试MSE|扰动后MSE|预测导数范数比|隐藏反馈相对值|
|---|---|---:|---|---:|---:|---:|---:|
|residual_mlp|smooth_teacher|16|all_linear_spectral|0.00130|0.00130|1.013|0.491|
|residual_mlp|smooth_teacher|16|dynamic|0.00713|0.00720|1.044|2.288|
|residual_mlp|smooth_teacher|16|router_spectral|0.00147|0.00147|1.011|0.481|
|residual_mlp|smooth_teacher|16|static|0.00125|0.00125|1.000|0.000|
|residual_mlp|smooth_teacher|16|weak|0.00133|0.00133|1.022|0.308|
|residual_mlp|smooth_teacher|4|all_linear_spectral|0.00222|0.00222|0.964|0.325|
|residual_mlp|smooth_teacher|4|dynamic|0.00315|0.00315|0.963|0.797|
|residual_mlp|smooth_teacher|4|router_spectral|0.00251|0.00252|0.958|0.339|
|residual_mlp|smooth_teacher|4|static|0.00208|0.00210|1.000|0.000|
|residual_mlp|smooth_teacher|4|weak|0.00235|0.00236|0.968|0.205|
|residual_mlp|smooth_teacher|8|all_linear_spectral|0.00114|0.00114|1.040|0.398|
|residual_mlp|smooth_teacher|8|dynamic|0.00256|0.00256|1.085|0.766|
|residual_mlp|smooth_teacher|8|router_spectral|0.00135|0.00135|1.056|0.399|
|residual_mlp|smooth_teacher|8|static|0.00117|0.00117|1.000|0.000|
|residual_mlp|smooth_teacher|8|weak|0.00124|0.00124|1.008|0.185|
|small_transformer|smooth_teacher|16|all_linear_spectral|0.00041|0.00041|1.135|1.148|
|small_transformer|smooth_teacher|16|dynamic|0.00059|0.00059|1.241|1.709|
|small_transformer|smooth_teacher|16|router_spectral|0.00053|0.00053|1.079|0.959|
|small_transformer|smooth_teacher|16|static|0.00053|0.00053|1.000|0.000|
|small_transformer|smooth_teacher|16|weak|0.00055|0.00056|1.024|0.495|
|small_transformer|smooth_teacher|4|all_linear_spectral|0.00050|0.00050|1.011|0.288|
|small_transformer|smooth_teacher|4|dynamic|0.00078|0.00078|1.047|0.659|
|small_transformer|smooth_teacher|4|router_spectral|0.00065|0.00065|0.971|0.348|
|small_transformer|smooth_teacher|4|static|0.00068|0.00069|1.000|0.000|
|small_transformer|smooth_teacher|4|weak|0.00063|0.00063|0.965|0.247|
|small_transformer|smooth_teacher|8|all_linear_spectral|0.00053|0.00053|1.036|0.401|
|small_transformer|smooth_teacher|8|dynamic|0.00079|0.00079|1.097|0.941|
|small_transformer|smooth_teacher|8|router_spectral|0.00070|0.00070|1.008|0.384|
|small_transformer|smooth_teacher|8|static|0.00065|0.00065|1.000|0.000|
|small_transformer|smooth_teacher|8|weak|0.00064|0.00064|0.984|0.212|

判读需同时检查学习曲线、普通约束对照和两类任务，不取单一最优条件下结论。当前报告只提供测量，不将相减导数归因为有害机制。

流程来源：Kassis et al. (2026), Scientific Agent Skills, https://doi.org/10.48550/arXiv.2609.00065 。