"""Fix the diagnosed teacher/architecture symmetry mismatch; preserve v1.

Only smooth task labels change to a permutation-invariant shared-token teacher.
This is an implementation/design correction, not a new operator or success claim.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
import time

BASE = Path('/root/FAST/experiments/adaptive_route_diagnostic_20261006')
sys.path.insert(0, str(BASE))
import run_route_diagnostic as r
import torch
from torch.nn import functional as F

ROOT=Path(__file__).resolve().parent
original_make_data=r.make_data
r.ROOT=ROOT
r.TASKS=['smooth_teacher']
r.TOTAL=30


def teacher(x):
    g=torch.Generator().manual_seed(r.SEED+100)
    w1=torch.randn(7,32,generator=g)/math.sqrt(7)
    w2=torch.randn(32,2,generator=g)/math.sqrt(32)
    return (x@w1).tanh().mean(dim=1)@w2


def make_data(task):
    data=original_make_data(task)
    if task!='smooth_teacher':return data
    for name in ['train','val','test','noisy']:
        x,_=data[name];data[name]=(x,teacher(x))
    data['hashes']={name:hashlib.sha256(x.numpy().tobytes()+y.numpy().tobytes()).hexdigest()
        for name,(x,y) in [('train',data['train']),('validation',data['val']),('test',data['test']),('noisy_test',data['noisy'])]}
    return data


r.make_data=make_data
original_protocol=r.protocol


def protocol():
    obj=original_protocol()
    additions={'correction_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'unchanged_base_script_sha256':hashlib.sha256((BASE/'run_route_diagnostic.py').read_bytes()).hexdigest(),
        'task_correction':'Same original inputs, splits, perturbations; new labels from shared per-token tanh teacher averaged across tokens. Both backbones can represent the target. Original results retained and no models or settings selected by test score.'}
    for name,value in additions.items():
        if name in obj:assert obj[name]==value,('Incompatible correction',name)
    obj.update(additions);r.atomic_json(ROOT/'protocol.json',obj)
    return obj


r.protocol=protocol


def smoke():
    protocol()
    data=make_data('smooth_teacher')
    x,y=data['train']
    assert torch.allclose(y,teacher(x[:,[1,0,2,3,4],:]),atol=1e-7)
    original=original_make_data('smooth_teacher')
    assert all(torch.equal(data[name][0],original[name][0]) for name in ['train','val','test','noisy'])
    checks=[]
    for arch in r.ARCHES:
        hashes=[]
        for arm in r.ARMS:
            m=r.build(arch,arm,4)
            hashes.append(r.state_hash(m))
            loss=F.mse_loss(m(x[:16])[0],y[:16]);loss.backward()
            assert torch.isfinite(loss) and all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters())
            checks.append({'arch':arch,'arm':arm,'finite_gradient':True})
        assert len(set(hashes))==1
    old=json.loads((BASE/'smoke.json').read_text())
    assert old['passed']
    r.atomic_json(ROOT/'smoke.json',{'passed':True,'checks':checks,
        'teacher_permutation_invariant_verified':True,'identical_original_input_arrays_verified':True,
        'jacobian_implementation_previously_verified':True,
        'conservative_runtime_estimate_minutes':old['conservative_runtime_estimate_minutes']/2,
        'device':'cpu','GPU_used':False})
    print('TASKCHECK_SMOKE_OK',json.dumps({'passed':True,'total_fits':30,'teacher_symmetry_verified':True}),flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');ap.add_argument('--status',action='store_true');args=ap.parse_args()
    torch.set_num_threads(2);torch.set_num_interop_threads(1)
    if args.smoke:smoke()
    elif args.status:print(json.dumps(r.get_status(),indent=2))
    else:
        import signal
        signal.signal(signal.SIGTERM,r.stop_handler)
        r.run()
