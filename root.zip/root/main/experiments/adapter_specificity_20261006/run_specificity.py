"""Fixed adapter controls on both complete cohorts; retain every completed result."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='4'
from pathlib import Path
import sys,json,time,hashlib,fcntl,argparse,itertools
sys.path[:0]=['/root/FAST/experiments','/root/FAST','/root/FAST/experiments/residual_20260925']
import numpy as np,h5py,torch
from torch import nn
from torch.nn import functional as F
from sklearn.model_selection import KFold,StratifiedKFold
from sklearn.metrics import f1_score
import regional_adapter_full_20261004 as main_ref
import nguyen_regional_adapter_20261005 as external_ref

OUT=Path('/root/FAST/experiments/adapter_specificity_20261006')
ARMS=['generic_adapter','no_gate','regional_ce_only']
STEPS=200

def save(p,x):
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(x,indent=2));tmp.replace(p)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

class NoGate(nn.Module):
    def __init__(self,reference):
        super().__init__()
        self.register_buffer('center',reference.full_center.clone())
        self.register_buffer('scale',reference.full_scale.clone())
        self.out=nn.Linear(256,32,bias=False);nn.init.zeros_(self.out.weight)
    def forward(self,full,mean):
        r=((torch.asinh(full.float())-self.center)/self.scale).clamp(-6,6)
        return .5*torch.tanh(self.out(r.flatten(2))/.5),torch.ones_like(r[...,:1])

class GenericAdapter(nn.Module):
    """Ordinary 256->32->32 nonlinear bottleneck, 9280 vs reference9377 params."""
    def __init__(self,reference):
        super().__init__()
        self.register_buffer('center',reference.full_center.clone())
        self.register_buffer('scale',reference.full_scale.clone())
        self.down=nn.Linear(256,32)
        self.out=nn.Linear(32,32)
        nn.init.zeros_(self.out.weight);nn.init.zeros_(self.out.bias)
    def forward(self,full,mean):
        r=((torch.asinh(full.float())-self.center)/self.scale).clamp(-6,6)
        return .5*torch.tanh(self.out(F.gelu(self.down(r.flatten(2))))/.5),torch.ones_like(r[...,:1])

def initialize(kind,train_features,mean_features):
    common=main_ref if kind=='main' else external_ref.common
    return common.Adapter(train_features,mean_features,'plain_adapter').cuda()

def build_arm(arm,reference):
    if arm=='no_gate':return NoGate(reference).cuda()
    if arm=='generic_adapter':return GenericAdapter(reference).cuda()
    return reference

def rep(kind,base,adapter,features,mean):
    if kind=='main':return main_ref.representation(base,adapter,features,mean)
    return external_ref.representation(base,adapter,features)

def ridge(kind,q,y):
    return main_ref.v4.ridge_fit(q,y)[1] if kind=='main' else external_ref.ridge(q,y)

def seed(kind,s,f):
    return 42+s*5+f if kind=='main' else 42+s*101+f*17

def name(kind,s,f):return f'{s}-fold{f}' if kind=='main' else f'sub{s:02d}_fold{f}'

def reference_dir(kind):
    return main_ref.OUT/'plain_adapter' if kind=='main' else external_ref.OUT

def subjects(kind):return list(range(15)) if kind=='main' else list(range(1,7))

def dataset(kind,s):
    if kind=='main':
        with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5') as h:
            return h[f'{s+1:02d}/X'][:],h[f'{s+1:02d}/Y'][:].astype(np.int64)
    with np.load(external_ref.ROOT/f'sub-{s:02d}.npz') as z:return z['X'],z['y'].astype(np.int64)

def splits(kind,x,y):
    return KFold(5,shuffle=False).split(x) if kind=='main' else StratifiedKFold(5,shuffle=True,random_state=42).split(x,y)

def load(kind,s,f,tr,te,x,y):
    main_ref.v4.seed_all(seed(kind,s,f))
    if kind=='main':
        base,full,mean,old,oldpred=main_ref.load_fold(s,f,tr,te,x,y)
        train_features,test_features=full[tr],full[te]
        train_mean,test_mean=mean[tr],mean[te]
    else:
        geometry=json.loads((external_ref.ROOT/'geometry.json').read_text())
        base,train_features,test_features,old,oldpred,ce,prob_error=external_ref.load_fold(s,f,tr,te,x,y,geometry)
        train_mean=torch.zeros_like(train_features);test_mean=torch.zeros_like(test_features)
    old=old.float()
    main_ref.v4.seed_all(seed(kind,s,f));adapter=initialize(kind,train_features,train_mean)
    with torch.no_grad():initial=rep(kind,base,adapter,test_features,test_mean)[0].float()
    assert torch.equal(initial,old),'Initial predictions differ from saved source'
    p=reference_dir(kind)/f'{name(kind,s,f)}.npz'
    ck=reference_dir(kind)/f'{name(kind,s,f)}.pt'
    with np.load(p) as z:
        assert np.array_equal(z['train_idx'],tr) and np.array_equal(z['test_idx'],te)
        assert np.array_equal(z['y'],y[te]) and np.array_equal(z['source_pred'],oldpred)
        reference_pred=z['pred'].copy();reference_prob=z['prob'].copy()
    adapter.load_state_dict(torch.load(ck,map_location='cpu')['state_dict'])
    with torch.no_grad():replay=rep(kind,base,adapter,test_features,test_mean)[0].float().softmax(-1).cpu().numpy()
    assert np.array_equal(replay.argmax(-1),reference_pred),'Current reference prediction mismatch'
    error=float(np.max(np.abs(replay-reference_prob)))
    assert error<1e-6,'Current reference probability mismatch'
    return base,train_features,test_features,train_mean,test_mean,old,oldpred,reference_pred,error

def metrics(y,p):
    return {'accuracy':float((p==y).mean()),'macro_f1':float(f1_score(y,p,labels=np.arange(5 if y.max()==4 else 3),average='macro',zero_division=0))}

def full_report():
    result={'complete':True,'datasets':{},'limits':'Previously inspected folds, one fixed seed; descriptive development evidence, not independent confirmation. Generic adapter is near parameter matched, not identical:9280 vs9377. No-gate8192. LOO removed only in stage2; source remains LOO trained.'}
    primary=[]
    for kind in ['main','external']:
        rows=[]
        for s in subjects(kind):
            paths=[OUT/kind/a/f'{name(kind,s,f)}.npz' for a in ARMS for f in range(5)]
            if not all(p.exists() for p in paths):continue
            yy=[];reference=[];source=[];new={a:[] for a in ARMS}
            for f in range(5):
                for ai,a in enumerate(ARMS):
                    with np.load(OUT/kind/a/f'{name(kind,s,f)}.npz') as z:
                        if ai==0:yy.extend(z['y']);reference.extend(z['reference_pred']);source.extend(z['source_pred'])
                        new[a].extend(z['pred'])
            y=np.array(yy)
            row={'subject':s,'reference':metrics(y,np.array(reference)),'source_loo':metrics(y,np.array(source))}
            row.update({a:metrics(y,np.array(p)) for a,p in new.items()});rows.append(row)
        complete=len(rows)==len(subjects(kind));result['complete']&=complete
        group={'complete':complete,'completed_subjects':len(rows),'total_subjects':len(subjects(kind)),'subjects':rows}
        if rows:
            methods=['reference','source_loo']+ARMS
            group['means']={a:{m:float(np.mean([r[a][m] for r in rows])) for m in ['accuracy','macro_f1']} for a in methods}
            group['reference_minus_control_pp']={a:100*(group['means']['reference']['accuracy']-group['means'][a]['accuracy']) for a in ARMS}
        if complete:
            group['paired_subject_statistics']={}
            for a in ARMS:
                d=100*np.array([r['reference']['accuracy']-r[a]['accuracy'] for r in rows])
                rng=np.random.default_rng(20261006);ci=np.quantile(d[rng.integers(0,len(d),(50000,len(d)))].mean(1),[.025,.975])
                signs=np.array(list(itertools.product([-1,1],repeat=len(d))))
                p=float(np.mean(abs((signs*d).mean(1))>=abs(d.mean())-1e-12))
                group['paired_subject_statistics'][a]={'mean_pp':float(d.mean()),'bootstrap95_pp':ci.tolist(),'exact_signflip_p':p,'positive_subjects':int((d>1e-10).sum()),'negative_subjects':int((d<-1e-10).sum())}
                if a!='no_gate':primary.append((kind,a,p))
        result['datasets'][kind]=group
    if len(primary)==4:
        ordered=sorted(primary,key=lambda t:t[2]);last=0.;adjusted={}
        for i,(kind,a,p) in enumerate(ordered):last=max(last,min(1.,(4-i)*p));adjusted[f'{kind}/{a}']=last
        result['primary_holm_adjusted_p']=adjusted
        result['statistics_scope']='Holm across four predeclared primary comparisons only; does not correct historical adaptive model selection. No-gate secondary. Subject, not fold, is sampling unit.'
    save(OUT/'summary.json',result)

def protocol():
    dependencies=[Path(__file__),Path(main_ref.__file__),Path(external_ref.__file__),Path(external_ref.common.__file__),Path(main_ref.v4.__file__),Path('/root/FAST/FAST.py')]
    return {'version':1,'created_utc':'2026-10-06','datasets':{'main':{'subjects':15,'folds':5},'external':{'subjects':6,'folds':5}},'arms':ARMS,'new_fits':315,'reused_reference_fits':105,
      'questions':['Does the selected regional gate outperform an ordinary nonlinear bottleneck adapter of near-equal parameter count?','Does stage2 LOO add benefit for exactly the same regional architecture?'],
      'secondary_question':'Does removing the gate retain the selected regional-path gain? Parameter count decreases to8192.',
      'parameters':{'reference':9377,'regional_ce_only':9377,'no_gate':8192,'generic_adapter':9280},
      'generic_details':'Ordinary biased256->32 linear,GELU,biased32->32 output; zero final output; same asinh/training-only regional normalization/clipping, .5tanh bound, insertion location and frozen source. 97fewer parameters,1.0344% difference; not exact matching.',
      'source':'Each fold original FAST+LOO checkpoint; no baseline retraining, no cross-dataset weight transfer.',
      'training':{'steps':200,'optimizer':'AdamW','lr':.001,'lr_final':.0001,'weight_decay':.01,'loss':'CE + .3 CE(4*LOO) + .01 mean(delta^2); regional_ce_only omits LOO only during stage2','source_frozen':True,'same_seed_as_reference':True},
      'endpoint':'All subjects equal weighted, merged fivefold accuracy; macroF1 secondary. Reference minus each control, descriptive effects; generic and stage2CE primary, noGate secondary.',
      'stop':'Finish315 fixedfolds regardless of outcomes, no tuning, subsetselection, extra datasets or performance-based early stopping. Preserve all completed results and failures. Do not suppress unfavorable core comparisons.',
      'limits':['Previously inspected folds, exploratory not independent confirmation','Single fixed base seed','LOO-off addresses stage2 only, stage1 source unchanged','Ordinary control is near matched in parameters, noGate less capacity','Frozen-base adapters test insertion-path design, not proof of biological mechanism'],
      'source_hashes':{str(p):sha(p) for p in dependencies}}

def completed():return sum(len(list((OUT/k/a).glob('*fold*.npz'))) for k in ['main','external'] for a in ARMS)

def status(started,state,**kwargs):
    n=completed();elapsed=time.time()-started
    save(OUT/'status.json',{'state':state,'pid':os.getpid(),'completed_folds':n,'total_folds':315,'elapsed_seconds':elapsed,'estimated_remaining_seconds':elapsed*(315-n)/n if n else None,'updated':time.time(),**kwargs})

def fit(kind,s,f,arm,base,train_features,test_features,train_mean,test_mean,old,y,tr,te,oldpred,refpred,replay_error):
    dest=OUT/kind/arm;dest.mkdir(parents=True,exist_ok=True);p=dest/f'{name(kind,s,f)}.npz'
    main_ref.v4.seed_all(seed(kind,s,f));reference=initialize(kind,train_features,train_mean)
    adapter=build_arm(arm,reference)
    nparams=sum(z.numel() for z in adapter.parameters())
    assert nparams=={'generic_adapter':9280,'no_gate':8192,'regional_ce_only':9377}[arm]
    with torch.no_grad():initial=rep(kind,base,adapter,test_features,test_mean)[0].float()
    assert torch.equal(initial,old),'Control zero initialization differs'
    opt=torch.optim.AdamW(adapter.parameters(),lr=.001,weight_decay=.01)
    yt=torch.from_numpy(y[tr]).cuda();trace=[];t=time.time()
    for step in range(STEPS):
        opt.zero_grad(set_to_none=True)
        for g in opt.param_groups:g['lr']=.001*(.1+.9*.5*(1+np.cos(np.pi*step/(STEPS-1))))
        logits,q,gate,delta=rep(kind,base,adapter,train_features,train_mean)
        ce=F.cross_entropy(logits,yt)
        aux=torch.zeros((),device='cuda') if arm=='regional_ce_only' else .3*F.cross_entropy(4*ridge(kind,q,yt),yt)
        loss=ce+aux+.01*delta.square().mean()
        assert torch.isfinite(loss);loss.backward()
        assert all(z.grad is None or torch.isfinite(z.grad).all() for z in adapter.parameters())
        opt.step()
        if step in [0,49,99,199]:trace.append({'step':step+1,'main_loss':float(ce.detach()),'aux_loss':float(aux.detach()),'delta_rms':float(delta.detach().square().mean().sqrt())})
    with torch.no_grad():prob=rep(kind,base,adapter,test_features,test_mean)[0].float().softmax(-1).cpu().numpy()
    pred=prob.argmax(-1);assert np.isfinite(prob).all()
    save(dest/f'{name(kind,s,f)}.json',{'dataset':kind,'subject':s,'fold':f,'arm':arm,'parameters':nparams,'seconds':time.time()-t,'metrics':metrics(y[te],pred),'reference_metrics':metrics(y[te],refpred),'trace':trace,'zero_init_exact':True,'reference_replay_error':replay_error})
    torch.save({'state_dict':adapter.cpu().state_dict(),'arm':arm,'train_idx':tr,'test_idx':te,'source':str((main_ref.SOURCE if kind=='main' else external_ref.SOURCE)/f'{name(kind,s,f)}.pt')},dest/f'{name(kind,s,f)}.pt')
    with p.with_suffix('.npz.tmp').open('wb') as handle:np.savez_compressed(handle,pred=pred,prob=prob,y=y[te],source_pred=oldpred,reference_pred=refpred,train_idx=tr,test_idx=te)
    p.with_suffix('.npz.tmp').replace(p)
    print('CONTROL_DONE',kind,s,f,arm,metrics(y[te],pred),flush=True)

def smoke():
    torch.set_num_threads(4);passed={}
    for kind,s in [('main',0),('external',1)]:
        x,y=dataset(kind,s);tr,te=next(splits(kind,x,y))
        base,train,test,mean,testmean,old,oldpred,refpred,error=load(kind,s,0,tr,te,x,y)
        source_hash=main_ref.tensorhash(base)
        for arm in ARMS:
            main_ref.v4.seed_all(seed(kind,s,0));reference=initialize(kind,train,mean);adapter=build_arm(arm,reference)
            with torch.no_grad():initial=rep(kind,base,adapter,test,testmean)[0].float()
            assert torch.equal(initial,old)
            before={k:v.detach().clone() for k,v in adapter.state_dict().items()}
            optimizer=torch.optim.AdamW(adapter.parameters(),lr=.001)
            logits,q,gate,delta=rep(kind,base,adapter,train,mean);yt=torch.from_numpy(y[tr]).cuda()
            aux=torch.zeros((),device='cuda') if arm=='regional_ce_only' else .3*F.cross_entropy(4*ridge(kind,q,yt),yt)
            loss=F.cross_entropy(logits,yt)+aux+.01*delta.square().mean();loss.backward()
            assert torch.isfinite(loss) and all(z.grad is None or torch.isfinite(z.grad).all() for z in adapter.parameters())
            optimizer.step();assert any(not torch.equal(v,before[k]) for k,v in adapter.state_dict().items())
            assert main_ref.tensorhash(base)==source_hash and all(p.grad is None for p in base.parameters())
            passed[f'{kind}/{arm}']={'finite_backward':True,'source_frozen':True,'zero_init_exact':True,'reference_replay_error':error,'parameters':sum(z.numel() for z in adapter.parameters())}
        del base,train,test,mean,testmean,adapter,reference,optimizer,loss,logits,q;torch.cuda.empty_cache()
    # Require the entire reference/checkpoint inventory before full launch.
    for kind in ['main','external']:
        for s in subjects(kind):
            for f in range(5):
                n=name(kind,s,f)
                assert all((reference_dir(kind)/(n+ext)).exists() for ext in ['.pt','.npz'])
                assert ((main_ref.SOURCE if kind=='main' else external_ref.SOURCE)/(n+'.pt')).exists()
    save(OUT/'smoke.json',{'passed':True,'checks':passed,'reference_fits_available':105})
    print('SMOKE_PASS',json.dumps(passed),flush=True)

def main():
    torch.set_num_threads(4);OUT.mkdir(parents=True,exist_ok=True)
    with (OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);p=protocol()
        if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==p
        else:save(OUT/'protocol.json',p)
        started=time.time();status(started,'running')
        try:
            for kind in ['main','external']:
                for s in subjects(kind):
                    x,y=dataset(kind,s)
                    for f,(tr,te) in enumerate(splits(kind,x,y)):
                        if all((OUT/kind/a/f'{name(kind,s,f)}.npz').exists() for a in ARMS):continue
                        base,train,test,mean,testmean,old,oldpred,refpred,error=load(kind,s,f,tr,te,x,y)
                        before=main_ref.tensorhash(base)
                        for arm in ARMS:
                            if (OUT/kind/arm/f'{name(kind,s,f)}.npz').exists():continue
                            status(started,'running',dataset=kind,subject=s,fold=f+1,arm=arm)
                            fit(kind,s,f,arm,base,train,test,mean,testmean,old,y,tr,te,oldpred,refpred,error)
                            assert main_ref.tensorhash(base)==before and all(p.grad is None for p in base.parameters())
                            status(started,'running',dataset=kind,subject=s,fold=f+1,arm=arm)
                        full_report();del base,train,test,mean,testmean,old;torch.cuda.empty_cache()
            full_report();assert completed()==315;status(started,'complete')
        except Exception as e:
            full_report();status(started,'failed',error=repr(e));raise

if __name__=='__main__':
    OUT.mkdir(parents=True,exist_ok=True)
    parser=argparse.ArgumentParser();parser.add_argument('--smoke',action='store_true');args=parser.parse_args()
    if args.smoke:smoke()
    else:main()
