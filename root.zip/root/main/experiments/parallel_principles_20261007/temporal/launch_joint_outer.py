"""Evaluate fixed joint rules on verified outer checkpoint holdouts."""
import time,traceback
from pathlib import Path
import run_joint_repair as j
ROOT=Path(__file__).resolve().parent
out=ROOT/'results'/'joint_outer_batch'
def main():
 out.mkdir(parents=True,exist_ok=True)
 if (out/'status.json').exists():raise RuntimeError('Preserve prior batch')
 j.save(out/'protocol.json',{'correction':'Remove inner validation gate; use original outer holdout of each saved backbone. Checkpoint train/test index equality and original replay checked by loader. New compression, normalization and pair centroids fit outer training only. No test labels used by forward computation.','arms':j.ARMS,'subjects':'15 BCI2020 and6 Nguyen,5 folds each','fits':315,'steps':200,'workers':2,'selection':'All three arms run all105 folds, no test score early stopping or choice of steps. Existing source/adapter artifacts preserved.','boundary':'Outer folds previously inspected repeatedly during development. This fixes direct inner sample overlap, but is exploratory development evaluation, NOT independent confirmation. Backbone remains frozen; compression and repair jointly train.'})
 start=time.time();j.save(out/'status.json',{'state':'running','stage':'joint_full','elapsed_seconds':0})
 try:
  result=j.run('full')
  j.save(out/'summary.json',result)
  j.save(out/'status.json',{'state':'complete','elapsed_seconds':time.time()-start,'folds':105,'fits':315})
 except BaseException:
  j.save(out/'status.json',{'state':'failed','error':traceback.format_exc()});raise
if __name__=='__main__':main()
