"""Nested training-only linear probes; exploratory, no architecture fitting."""
import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
import json,time,traceback
from pathlib import Path
import numpy as np,torch
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import RidgeClassifier
import run_temporal as t
torch.set_num_threads(2)
OUT=Path(__file__).resolve().parent/'results'/'label_information_audit'
def save(name,z):
 p=OUT/name;q=p.with_suffix('.tmp');q.write_text(json.dumps(z,indent=2));q.replace(p)
def main():
 OUT.mkdir(parents=True,exist_ok=True)
 if (OUT/'status.json').exists():raise RuntimeError('Existing audit')
 rows=[];start=time.time();configs=[(k,s,f) for k in ['main','external'] for s in t.ref.subjects(k) for f in range(5)]
 save('protocol.json',{'data':'outer training trials only; all 105 folds','probe':'fixed RidgeClassifier alpha=1; scaler fitted inner training; 3 inner stratified splits','representations':['full256','saved_rowspace32','complement224','random32'],'boundary':'Saved adapter learned on all outer training trials, including inner validation labels. Therefore rowspace vs complement comparisons are post-fit descriptive probes, not unbiased generalization estimates. Outer test accuracy never used. No firstness or causal claim.'})
 save('status.json',{'state':'running','progress':0,'total':105})
 try:
  for kind,s,f in configs:
   data=t.load(kind,s,f);base,best,train=data[:3];y=data[8][data[6]]
   with torch.no_grad():
    x=((torch.asinh(train.float())-best.center)/best.scale).clamp(-6,6).flatten(2).mean(1).cpu().numpy().astype(np.float64)
    _,_,vh=torch.linalg.svd(best.down.weight.float(),full_matrices=True);v=vh.cpu().numpy().astype(np.float64)
   random=np.random.default_rng(991).normal(size=(256,32));random=np.linalg.qr(random)[0]
   features={'full256':x,'saved_rowspace32':x@v[:32].T,'complement224':x@v[32:].T,'random32':x@random}
   scores={a:[] for a in features}
   for tr,va in StratifiedKFold(3,shuffle=True,random_state=73).split(x,y):
    for a,z in features.items():
     scaler=StandardScaler().fit(z[tr]);clf=RidgeClassifier(alpha=1).fit(scaler.transform(z[tr]),y[tr]);scores[a].append(float(clf.score(scaler.transform(z[va]),y[va])))
   rows.append({'dataset':kind,'subject':s,'fold':f,**{a:float(np.mean(z)) for a,z in scores.items()}})
   save('rows.json',rows);summary={}
   for k in ['main','external']:
    rr=[r for r in rows if r['dataset']==k]
    if rr:summary[k]={'folds':len(rr),**{a:float(np.mean([r[a] for r in rr])) for a in features}}
   save('summary.json',summary);elapsed=time.time()-start
   save('status.json',{'state':'running','progress':len(rows),'total':105,'elapsed_seconds':elapsed,'estimated_remaining_seconds':elapsed*(105-len(rows))/len(rows)})
   del data,base,best,train;torch.cuda.empty_cache()
  save('status.json',{'state':'complete','progress':105,'total':105,'elapsed_seconds':time.time()-start})
 except BaseException:
  save('status.json',{'state':'failed','progress':len(rows),'error':traceback.format_exc()});raise
if __name__=='__main__':main()
