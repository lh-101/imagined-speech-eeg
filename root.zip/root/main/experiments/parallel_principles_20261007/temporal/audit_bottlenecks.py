"""Training-only computation audit. No fitting, no evaluation-set selection."""
import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
import sys,json,time,traceback
from pathlib import Path
import torch
import run_temporal as t
torch.set_num_threads(2)
OUT=Path(__file__).resolve().parent/'results'/'bottleneck_audit'
def save(name,z):
 p=OUT/name;q=p.with_suffix('.tmp');q.write_text(json.dumps(z,indent=2));q.replace(p)
def main():
 OUT.mkdir(parents=True,exist_ok=True)
 if (OUT/'status.json').exists():raise RuntimeError('Preserve existing audit')
 start=time.time();rows=[]
 configs=[(kind,s,f) for kind in ['main','external'] for s in t.ref.subjects(kind) for f in range(5)]
 save('protocol.json',{'scope':'all 105 saved folds, training features only, no optimization','hypotheses':['hard clipping removes substantial input coordinates','bounded output suppresses derivatives','256-to-32 bottleneck removes high-variance directions','temporal windows are redundant'],'boundary':'Measurements do not prove label-relevant information loss, causal defects, or novelty. No test accuracy used for design selection.'})
 save('status.json',{'state':'running','progress':0,'total':len(configs)})
 try:
  for kind,s,f in configs:
   data=t.load(kind,s,f);base,best,train=data[:3]
   with torch.no_grad():
    raw=((torch.asinh(train.float())-best.center)/best.scale).flatten(2)
    x=raw.clamp(-6,6);flat=x.reshape(-1,256);center=flat-flat.mean(0)
    sv=torch.linalg.svdvals(center);ev=sv.square();effective=float(ev.sum().square()/ev.square().sum().clamp_min(1e-12))
    w=best.down[0].weight if isinstance(best.down,torch.nn.Sequential) else best.down.weight
    _,_,vh=torch.linalg.svd(w.float(),full_matrices=False)
    projected=center@vh.T
    retained=float(projected.square().sum()/center.square().sum().clamp_min(1e-12))
    hidden=best.down(flat);pre=best.out(hidden)/.5
    derivative=1-torch.tanh(pre).square()
    temporal=x-x.mean(1,keepdim=True)
    temporal_fraction=float(temporal.square().sum()/x.square().sum().clamp_min(1e-12))
    adjacent=torch.nn.functional.cosine_similarity(x[:,1:],x[:,:-1],dim=-1)
   row={'dataset':kind,'subject':s,'fold':f,'clipped_fraction':float((raw.abs()>6).float().mean()),'effective_input_rank':effective,'down_rowspace_variance_retained':retained,'tanh_derivative_below_01_fraction':float((derivative<.1).float().mean()),'mean_tanh_derivative':float(derivative.mean()),'temporal_centered_energy_fraction':temporal_fraction,'adjacent_window_cosine_mean':float(adjacent.mean())}
   rows.append(row);save('rows.json',rows)
   summary={}
   for group in ['main','external']:
    rr=[r for r in rows if r['dataset']==group]
    if rr:summary[group]={'folds':len(rr),**{k:sum(r[k] for r in rr)/len(rr) for k in row if k not in ['dataset','subject','fold']}}
   save('summary.json',summary)
   elapsed=time.time()-start;save('status.json',{'state':'running','progress':len(rows),'total':len(configs),'elapsed_seconds':elapsed,'estimated_remaining_seconds':elapsed*(len(configs)-len(rows))/len(rows)})
   del data,base,best,train;torch.cuda.empty_cache()
  save('status.json',{'state':'complete','progress':len(rows),'total':len(configs),'elapsed_seconds':time.time()-start})
 except BaseException:
  save('status.json',{'state':'failed','error':traceback.format_exc(),'progress':len(rows)});raise
if __name__=='__main__':main()
