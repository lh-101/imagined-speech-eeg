"""Joint trainable compression and pair repair, finite pilot then gated cohorts."""
import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
import copy,json,time,traceback,multiprocessing
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np,torch
from torch import nn
from torch.nn import functional as F
from sklearn.model_selection import StratifiedShuffleSplit
import run_temporal as t
ROOT=Path(__file__).resolve().parent
ARMS=['order_difference','order_symmetric','parallel_control']
STEPS=200
def save(p,z):
 q=p.with_suffix('.tmp');q.write_text(json.dumps(z,indent=2));q.replace(p)
class Joint(nn.Module):
 def __init__(self,reference,features,labels,arm):
  super().__init__();self.core=t.ref.GenericAdapter(reference);self.arm=arm
  self.a=nn.Sequential(nn.Linear(256,8),nn.GELU(),nn.Linear(8,256))
  self.b=nn.Sequential(nn.Linear(256,8),nn.GELU(),nn.Linear(8,256))
  self.scale=nn.Parameter(torch.tensor(.1))
 def interaction(self,x):
  ax=self.a(x);bx=self.b(x)
  if self.arm=='parallel_control':return (ax+bx)/2
  ab=self.a(bx);ba=self.b(ax)
  return (ab-ba)/2 if self.arm=='order_difference' else (ab+ba)/2
 def forward(self,full,mean):
  x=((torch.asinh(full.float())-self.core.center)/self.core.scale).clamp(-6,6).flatten(2)
  mixed=x+torch.tanh(self.scale)*torch.tanh(self.interaction(x))
  pre=self.core.out(F.gelu(self.core.down(mixed)))
  return .5*torch.tanh(pre/.5),torch.ones_like(x[...,:1])

def worker(config):
 kind,s,f,phase,out=config;torch.set_num_threads(2);out=Path(out);start=time.time()
 data=t.load(kind,s,f);base,best,train,test,mean,testmean,tr,te,y,oldpred,*_=data
 before=t.ref.main_ref.tensorhash(base)
 target=torch.from_numpy(y[tr]).cuda()
 if phase=='pilot':
  ii,jj=next(StratifiedShuffleSplit(1,test_size=.2,random_state=731).split(np.zeros(len(tr)),y[tr]))
  fit=train[ii];fitmean=mean[ii];yy=target[ii];val=train[jj];valmean=mean[jj];truth=y[tr][jj];savedpred=None
 else:fit,fitmean,yy,val,valmean,truth,savedpred=train,mean,target,test,testmean,y[te],oldpred
 reference=t.ref.initialize(kind,fit,fitmean);rows=[]
 for arm in ARMS:
  t.ref.main_ref.v4.seed_all(t.ref.seed(kind,s,f))
  model=Joint(reference,fit,yy,arm).cuda();count=sum(p.numel() for p in model.parameters())
  assert count==18001
  opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.01)
  for step in range(5 if phase=='smoke' else STEPS):
   for g in opt.param_groups:g['lr']=.001*(.1+.9*.5*(1+np.cos(np.pi*step/(STEPS-1))))
   opt.zero_grad(set_to_none=True);logits,q,_,delta=t.ref.rep(kind,base,model,fit,fitmean)
   loss=F.cross_entropy(logits,yy)+.3*F.cross_entropy(4*t.ref.ridge(kind,q,yy),yy)+.01*delta.square().mean()
   assert torch.isfinite(loss);loss.backward()
   assert all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters())
   opt.step()
  with torch.no_grad():prob=t.ref.rep(kind,base,model,val,valmean)[0].float().softmax(-1).cpu().numpy()
  pred=prob.argmax(-1);dest=out/kind/arm;dest.mkdir(parents=True,exist_ok=True);name=t.ref.name(kind,s,f)
  np.savez_compressed(dest/(name+'.npz'),pred=pred,prob=prob,y=truth)
  if phase=='full':torch.save({'state_dict':model.cpu().state_dict(),'arm':arm,'train_idx':tr,'test_idx':te},dest/(name+'.pt'))
  rows.append({'dataset':kind,'subject':s,'fold':f,'arm':arm,'accuracy':float((pred==truth).mean()),'parameters':count,'saved_accuracy':float((savedpred==truth).mean()) if savedpred is not None else None})
 assert t.ref.main_ref.tensorhash(base)==before
 assert all(p.grad is None for p in base.parameters())
 print('FOLD_DONE',phase,kind,s,f,'seconds',time.time()-start,flush=True)
 return rows
def run(phase):
 out=ROOT/'results'/('order_'+phase);out.mkdir(parents=True,exist_ok=True)
 if (out/'status.json').exists():raise RuntimeError('Preserve previous job')
 if phase=='smoke':configs=[('main',0,0,phase,str(out)),('external',1,0,phase,str(out))]
 elif phase=='pilot':configs=[(k,s,0,phase,str(out)) for k,ss in [('main',[0,5,10]),('external',[1,3,5])] for s in ss]
 else:configs=[(k,s,f,phase,str(out)) for k in ['main','external'] for s in t.ref.subjects(k) for f in range(5)]
 rows=[];start=time.time()
 save(out/'status.json',{'state':'running','progress':0,'total':len(configs)})
 with ProcessPoolExecutor(2,mp_context=multiprocessing.get_context('spawn')) as pool:
  for future in as_completed([pool.submit(worker,z) for z in configs]):
   rows.extend(future.result());save(out/'rows.json',rows);done=len(rows)//3;elapsed=time.time()-start
   save(out/'status.json',{'state':'running','progress':done,'total':len(configs),'elapsed_seconds':elapsed,'estimated_remaining_seconds':elapsed*(len(configs)-done)/done})
 summary={}
 for kind in ['main','external']:
  summary[kind]={}
  for arm in ARMS:
   # Subject-weighted pooled trial accuracy; preserve subject identities.
   subjects=sorted({r['subject'] for r in rows if r['dataset']==kind});acc=[]
   for s in subjects:
    pp=[];yy=[]
    for r in rows:
     if r['dataset']==kind and r['subject']==s and r['arm']==arm:
      with np.load(out/kind/arm/(t.ref.name(kind,s,r['fold'])+'.npz')) as z:pp.extend(z['pred']);yy.extend(z['y'])
    acc.append(float((np.asarray(pp)==np.asarray(yy)).mean()))
   summary[kind][arm]=float(np.mean(acc))
 save(out/'summary.json',summary);save(out/'status.json',{'state':'complete','progress':len(configs),'total':len(configs),'elapsed_seconds':time.time()-start})
 return summary
def main():
 out=ROOT/'results'/'order_batch';out.mkdir(parents=True,exist_ok=True)
 if (out/'status.json').exists():raise RuntimeError('Preserve prior batch')
 save(out/'protocol.json',{'arms':ARMS,'steps':200,'parameters_each':18001,'rule':'x+tanh(scale)*tanh((A(B(x))-B(A(x)))/2); two nonlinear256->8->256 operators; compression jointly trained','controls':'symmetric composition and independent parallel sum; equal parameter count, same training targets, optimizer and fixed200steps. Parallel control has fewer FLOPs; report timing.','novelty':'Composition difference is NOT a differential Lie bracket, NOT claimed to satisfy Jacobi identity or Lie equivariance. Related Lie Neurons (ICML2024), https://proceedings.mlr.press/v235/lin24aa.html. General noncommutativity not novel; exact candidate novelty unresolved.','evaluation':'same verified outer backbone holdouts, all105 folds and315fits, repeated development splits; exploratory only. Smoke numerical only, no score gate. No primary source artifacts overwritten.'})
 try:
  # Algebraic property check on ordinary real vectors; nonlinear composition.
  torch.manual_seed(918)
  a=nn.Sequential(nn.Linear(256,8),nn.GELU(),nn.Linear(8,256));b=nn.Sequential(nn.Linear(256,8),nn.GELU(),nn.Linear(8,256));x=torch.randn(7,256)
  ab=a(b(x));ba=b(a(x));difference=(ab-ba)/2
  assert torch.isfinite(difference).all() and torch.allclose(difference,-(ba-ab)/2)
  assert torch.equal(a(a(x))-a(a(x)),torch.zeros_like(x))
  save(out/'algebra_checks.json',{'swap_sign':True,'same_operator_zero':True,'finite':True,'differential_Lie_bracket':False})
  save(out/'status.json',{'state':'running','stage':'smoke'});run('smoke')
  save(out/'status.json',{'state':'running','stage':'full'});result=run('full')
  save(out/'summary.json',result);save(out/'status.json',{'state':'complete','folds':105,'fits':315})
 except BaseException:save(out/'status.json',{'state':'failed','error':traceback.format_exc()});raise
if __name__=='__main__':main()
