"""Finite GPU smoke then fixed full EEG run; exits after completion or failure."""
import subprocess,sys,json,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results'/'temporal_batch';OUT.mkdir(parents=True,exist_ok=True);start=time.time()
def status(stage,state='running',**kw):
 p=OUT/'status.json';q=p.with_suffix('.tmp');q.write_text(json.dumps(dict(state=state,stage=stage,elapsed_seconds=time.time()-start,**kw)));q.replace(p)
try:
 for job in ['temporal_smoke','temporal_screen']:
  status(job)
  subprocess.run([sys.executable,'-u',str(ROOT/'run_temporal.py'),'--job',job,'--workers','2'],check=True)
  assert json.loads((ROOT/'results'/job/'validation.json').read_text())['passed']
 status('all_fixed_cohorts_complete','complete')
except BaseException:
 status('exception','failed',error=traceback.format_exc());raise
