import json,subprocess,time,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
out=ROOT/'results'/'repair_batch';out.mkdir(parents=True,exist_ok=True)
def save(z):
 p=out/'status.json';q=p.with_suffix('.tmp');q.write_text(json.dumps(z));q.replace(p)
if (out/'status.json').exists():raise RuntimeError('Preserve existing run')
start=time.time()
for job in ['repair_smoke','repair_screen']:
 save({'state':'running','stage':job,'elapsed_seconds':time.time()-start})
 rc=subprocess.call([sys.executable,'-u',str(ROOT/'run_repair.py'),'--job',job,'--workers','2'])
 if rc:
  save({'state':'failed','stage':job,'exit_code':rc});raise SystemExit(rc)
 z=json.loads((ROOT/'results'/job/'validation.json').read_text())
 if not z['passed']:raise RuntimeError('Validation failed')
save({'state':'complete','elapsed_seconds':time.time()-start})
