"""Controlled temporal variation attenuation, paired arms; retain negatives."""
import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
import json,time,traceback,multiprocessing
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np,torch
import run_temporal as t
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results'/'temporal_mechanism'
ARMS=['multiscale','pointwise_control']
def attenuate(x,a):return x.mean(1,keepdim=True)+(1-a)*(x-x.mean(1,keepdim=True))
def worker(config):
 kind,s,f=config;torch.set_num_threads(2);data=t.load(kind,s,f);base,best=data[:2]
 hb=t.ref.main_ref.tensorhash(base);ha=t.ref.main_ref.tensorhash(best);rows=[];checks=[]
 for a in [.5,1.]:
  d=list(data);original_train=d[2];original_test=d[3]
  d[2]=attenuate(original_train,a);d[3]=attenuate(original_test,a)
  assert torch.allclose(d[2].mean(1),original_train.mean(1),rtol=1e-4,atol=1e-4)
  with torch.no_grad():d[9]=t.ref.rep(kind,base,best,d[3],d[5])[0].argmax(-1).cpu().numpy()
  before=(original_train-original_train.mean(1,keepdim=True)).float().square().sum()
  after=(d[2]-d[2].mean(1,keepdim=True)).float().square().sum()
  ratio=float(after/before.clamp_min(1e-12));assert abs(ratio-(1-a)**2)<1e-4
  checks.append({'attenuation':a,'train_temporal_energy_ratio':ratio,'train_mean_preserved':True})
  for arm in ARMS:
   row=t.train_arm(kind,s,f,arm,tuple(d),OUT/('level_'+str(a)),200)
   row['attenuation']=a;rows.append(row)
 assert t.ref.main_ref.tensorhash(base)==hb and t.ref.main_ref.tensorhash(best)==ha
 t.save(OUT/(kind+'_'+t.ref.name(kind,s,f)+'_audit.json'),{'source_frozen':True,'checks':checks})
 print('FOLD_DONE',kind,s,f,flush=True);return rows
def summary():
 result={};rng=np.random.default_rng(735)
 for kind in ['main','external']:
  subjects=[]
  for s in t.ref.subjects(kind):
   levels={}
   for a in [0.,.5,1.]:
    root=ROOT/'results'/'temporal_screen' if a==0 else OUT/('level_'+str(a))
    values={};truth_ref=None
    for arm in ARMS:
     yy=[];pp=[]
     for f in range(5):
      with np.load(root/kind/arm/(t.ref.name(kind,s,f)+'.npz')) as z:
       yy.extend(z['y']);pp.extend(z['pred'])
     truth=np.asarray(yy)
     if truth_ref is None:truth_ref=truth
     else:assert np.array_equal(truth_ref,truth)
     values[arm]=float((truth==np.asarray(pp)).mean())
    levels[str(a)]={**values,'gain_vs_control_pp':100*(values['multiscale']-values['pointwise_control'])}
   subjects.append({'subject':s,'levels':levels})
  contrasts=np.array([r['levels']['0.0']['gain_vs_control_pp']-r['levels']['1.0']['gain_vs_control_pp'] for r in subjects])
  boots=contrasts[rng.integers(0,len(contrasts),(10000,len(contrasts)))].mean(1)
  result[kind]={'subjects':subjects,'means':{str(a):{m:float(np.mean([r['levels'][str(a)][m] for r in subjects])) for m in ['multiscale','pointwise_control','gain_vs_control_pp']} for a in [0.,.5,1.]},'original_minus_collapsed_gain_pp':float(contrasts.mean()),'descriptive_subject_bootstrap_95_interval_pp':np.quantile(boots,[.025,.975]).tolist()}
 t.save(OUT/'summary.json',{'complete':True,'datasets':result,'boundary':'Controlled latent-feature intervention changes distribution and may erase label evidence. Gain interaction tests proposed dependence, not a unique mechanism or biological causality. Previously reused development cohorts; no firstness.'})
def main():
 OUT.mkdir(parents=True,exist_ok=True)
 if (OUT/'status.json').exists():raise RuntimeError('Preserve previous run')
 configs=[(k,s,f) for k in ['main','external'] for s in t.ref.subjects(k) for f in range(5)]
 t.save(OUT/'protocol.json',{'arms':ARMS,'attenuation':[0,.5,1],'zero_level':'Reuse previous complete200step multiscale and matched control; no rerun','new_fits':420,'folds':105,'rule':'x_mean+(1-a)*(x-x_mean), applied to latent windows in training and evaluation; preserves mean, reduces temporal energy exactly','prediction':'If temporal variation explains extra multiscale value, gain vs same-parameter control decreases upon removal. No gain or reverse interaction challenges account. Differences between datasets alone insufficient.','controls':'same train/test IDs, model sources, seeds,200steps,CE/LOO objectives,6440newparams','limits':'Not raw signal intervention; temporal attenuation changes joint distribution, possible removal of useful label evidence. Source backbone trained original outer train only. Repeated development splits, exploratory. No adaptive module claimed.'})
 rows=[];start=time.time();t.save(OUT/'status.json',{'state':'running','progress':0,'total':105})
 try:
  with ProcessPoolExecutor(2,mp_context=multiprocessing.get_context('spawn')) as pool:
   for future in as_completed([pool.submit(worker,z) for z in configs]):
    rows.extend(future.result());t.save(OUT/'rows.json',rows);done=len(rows)//4;elapsed=time.time()-start
    t.save(OUT/'status.json',{'state':'running','progress':done,'total':105,'elapsed_seconds':elapsed,'estimated_remaining_seconds':elapsed*(105-done)/done})
  summary();t.save(OUT/'status.json',{'state':'complete','progress':105,'total':105,'new_fits':420,'elapsed_seconds':time.time()-start})
 except BaseException:t.save(OUT/'status.json',{'state':'failed','error':traceback.format_exc()});raise
if __name__=='__main__':main()
