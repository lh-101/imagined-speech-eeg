"""Joint trainable compression and pair repair, finite pilot then gated cohorts."""
import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
import copy,json,time,traceback,multiprocessing
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np,torch
from torch import nn
from torch.nn import functional as F
from sklearn.model_selection import StratifiedShuffleSplit
import run_temporal as t
ROOT=Path(__file__).resolve().parent
ARMS=['plain_compression','capacity_control','joint_pair_repair']
STEPS=200
def save(p,z):
 q=p.with_suffix('.tmp');q.write_text(json.dumps(z,indent=2));q.replace(p)
class Joint(nn.Module):
 def __init__(self,reference,features,labels,arm):
  super().__init__();self.core=t.ref.GenericAdapter(reference);self.arm=arm
  x=((torch.asinh(features.float())-self.core.center)/self.core.scale).clamp(-6,6).flatten(2).mean(1)
  centers=torch.stack([x[labels==v].mean(0) for v in torch.unique(labels)])
  pairs=[];mid=[]
  for i in range(len(centers)):
   for j in range(i):pairs.append(centers[i]-centers[j]);mid.append((centers[i]+centers[j])/2)
  self.register_buffer('pairs',torch.stack(pairs).detach());self.register_buffer('mid',torch.stack(mid).detach())
  if arm!='plain_compression':
   self.down=nn.Linear(768,8);self.out=nn.Linear(8,32);nn.init.zeros_(self.out.weight);nn.init.zeros_(self.out.bias)
 def forward(self,full,mean):
  x=((torch.asinh(full.float())-self.core.center)/self.core.scale).clamp(-6,6).flatten(2)
  h=F.gelu(self.core.down(x));pre=self.core.out(h)
  if self.arm!='plain_compression':
   if self.arm=='capacity_control':features=torch.cat([x,x.square()/6,torch.tanh(x)],-1)
   else:
    # Regularized rowspace operator differentiates through the CURRENT W.
    w=self.core.down.weight.float();gram=w@w.T+.001*torch.eye(32,device=w.device)
    retained=(self.pairs@w.T)@torch.linalg.solve(gram,w)
    residual=F.normalize(self.pairs-retained,dim=-1)
    margin=((x.unsqueeze(-2)-self.mid)*retained).sum(-1)/retained.norm(dim=-1).clamp_min(1e-6)
    weights=torch.softmax(-margin.abs(),-1)
    repair=(torch.tanh(x@residual.T)*weights)@residual
    response=torch.tanh(x@F.normalize(retained,dim=-1).T)@F.normalize(retained,dim=-1)/len(self.pairs)
    features=torch.cat([x,repair,response],-1)
   pre=pre+self.out(F.gelu(self.down(features)))
  return .5*torch.tanh(pre/.5),torch.ones_like(x[...,:1])
def worker(config):
 kind,s,f,phase,out=config;torch.set_num_threads(2);out=Path(out);start=time.time()
 data=t.load(kind,s,f);base,best,train,test,mean,testmean,tr,te,y,oldpred,*_=data
 before=t.ref.main_ref.tensorhash(base)
 target=torch.from_numpy(y[tr]).cuda()
 if phase=='pilot':
  ii,jj=next(StratifiedShuffleSplit(1,test_size=.2,random_state=731).split(np.zeros(len(tr)),y[tr]))
  fit=train[ii];fitmean=mean[ii];yy=target[ii];val=train[jj];valmean=mean[jj];truth=y[tr][jj];savedpred=None
 else:fit,fitmean,yy,val,valmean,truth,savedpred=train,mean,target,test,testmean,y[te],oldpred
 reference=t.ref.initialize(kind,fit,fitmean);rows=[]
 for arm in ARMS:
  t.ref.main_ref.v4.seed_all(t.ref.seed(kind,s,f))
  model=Joint(reference,fit,yy,arm).cuda();count=sum(p.numel() for p in model.parameters())
  assert count==(9280 if arm=='plain_compression' else 15720)
  opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.01)
  for step in range(STEPS):
   for g in opt.param_groups:g['lr']=.001*(.1+.9*.5*(1+np.cos(np.pi*step/(STEPS-1))))
   opt.zero_grad(set_to_none=True);logits,q,_,delta=t.ref.rep(kind,base,model,fit,fitmean)
   loss=F.cross_entropy(logits,yy)+.3*F.cross_entropy(4*t.ref.ridge(kind,q,yy),yy)+.01*delta.square().mean()
   assert torch.isfinite(loss);loss.backward()
   assert all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters())
   opt.step()
  with torch.no_grad():prob=t.ref.rep(kind,base,model,val,valmean)[0].float().softmax(-1).cpu().numpy()
  pred=prob.argmax(-1);dest=out/kind/arm;dest.mkdir(parents=True,exist_ok=True);name=t.ref.name(kind,s,f)
  np.savez_compressed(dest/(name+'.npz'),pred=pred,prob=prob,y=truth)
  if phase=='full':torch.save({'state_dict':model.cpu().state_dict(),'arm':arm,'train_idx':tr,'test_idx':te},dest/(name+'.pt'))
  rows.append({'dataset':kind,'subject':s,'fold':f,'arm':arm,'accuracy':float((pred==truth).mean()),'parameters':count,'saved_accuracy':float((savedpred==truth).mean()) if savedpred is not None else None})
 assert t.ref.main_ref.tensorhash(base)==before
 assert all(p.grad is None for p in base.parameters())
 print('FOLD_DONE',phase,kind,s,f,'seconds',time.time()-start,flush=True)
 return rows
def run(phase):
 out=ROOT/'results'/('joint_'+phase);out.mkdir(parents=True,exist_ok=True)
 if (out/'status.json').exists():raise RuntimeError('Preserve previous job')
 if phase=='pilot':configs=[(k,s,0,phase,str(out)) for k,ss in [('main',[0,5,10]),('external',[1,3,5])] for s in ss]
 else:configs=[(k,s,f,phase,str(out)) for k in ['main','external'] for s in t.ref.subjects(k) for f in range(5)]
 rows=[];start=time.time()
 save(out/'status.json',{'state':'running','progress':0,'total':len(configs)})
 with ProcessPoolExecutor(2,mp_context=multiprocessing.get_context('spawn')) as pool:
  for future in as_completed([pool.submit(worker,z) for z in configs]):
   rows.extend(future.result());save(out/'rows.json',rows);done=len(rows)//3;elapsed=time.time()-start
   save(out/'status.json',{'state':'running','progress':done,'total':len(configs),'elapsed_seconds':elapsed,'estimated_remaining_seconds':elapsed*(len(configs)-done)/done})
 summary={}
 for kind in ['main','external']:
  summary[kind]={}
  for arm in ARMS:
   # Subject-weighted pooled trial accuracy; preserve subject identities.
   subjects=sorted({r['subject'] for r in rows if r['dataset']==kind});acc=[]
   for s in subjects:
    pp=[];yy=[]
    for r in rows:
     if r['dataset']==kind and r['subject']==s and r['arm']==arm:
      with np.load(out/kind/arm/(t.ref.name(kind,s,r['fold'])+'.npz')) as z:pp.extend(z['pred']);yy.extend(z['y'])
    acc.append(float((np.asarray(pp)==np.asarray(yy)).mean()))
   summary[kind][arm]=float(np.mean(acc))
 save(out/'summary.json',summary);save(out/'status.json',{'state':'complete','progress':len(configs),'total':len(configs),'elapsed_seconds':time.time()-start})
 return summary
def main():
 out=ROOT/'results'/'joint_batch';out.mkdir(parents=True,exist_ok=True)
 if (out/'status.json').exists():raise RuntimeError('Preserve prior batch')
 save(out/'protocol.json',{'arms':ARMS,'steps':STEPS,'pilot':'six predefined subjects, fold0,20% inner validation','gate':'strictly positive mean accuracy vs capacity_control on BOTH pilot datasets; no 2pp threshold','source':'backbone frozen, compression trained from fresh zero-output initialization; pair projection recomputed differentiably','limitation':'Backbone was previously trained on outer training labels, including inner validation. Pilot is conditional exploratory comparison, NOT unbiased nested validation. Normalization and centroids fitted on inner fit only. Full outer tests untouched by pilot gate. Development splits repeatedly reused; no independent confirmation or firstness claim.','full':'15+6 subjects,5 folds,3 arms; existing results preserved'})
 try:
  save(out/'status.json',{'state':'running','stage':'pilot'})
  result=run('pilot');gate=all(result[k]['joint_pair_repair']>result[k]['capacity_control'] for k in result)
  save(out/'gate.json',{'passed':gate,'pilot':result,'criterion':'positive gain vs matched capacity on both pilot cohorts'})
  if gate:
   save(out/'status.json',{'state':'running','stage':'full'});run('full')
  save(out/'status.json',{'state':'complete','gate_passed':gate,'full_launched':gate})
 except BaseException:save(out/'status.json',{'state':'failed','error':traceback.format_exc()});raise
if __name__=='__main__':main()
