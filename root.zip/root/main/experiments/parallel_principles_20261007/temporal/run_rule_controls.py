"""Fixed scale masks, full reference reused, all negative outcomes retained."""
import sys,json,time,traceback
from pathlib import Path
import numpy as np,torch
import run_temporal as t
HERE=Path(__file__).resolve().parent
FULL=HERE/'results'/'temporal_screen'
t.ROOT=HERE/'rule_controls'
t.ARMS=['direct_smoothing','slow_information_only','permuted_neighborhood']
original_pack=t.pack
def pack(x,arm):
 if arm not in t.ARMS:return original_pack(x,arm)
 if arm=='direct_smoothing':return torch.cat([x,t.smooth(x,3),t.smooth(x,5)],-1)
 if arm=='slow_information_only':
  slow=t.smooth(x,5)
  return torch.cat([slow,slow.square()/6,torch.tanh(slow)],-1)
 # Same timepoint features and operations, fixed nonlocal permutation.
 indices=torch.tensor(list(range(0,x.shape[1],2))+list(range(1,x.shape[1],2)),device=x.device)
 inverse=torch.argsort(indices)
 return original_pack(x[:,indices],'multiscale')[:,inverse]

t.pack=pack
def summarize(rows,out,full=False):
 datasets={}
 for kind in ['main','external']:
  subjects=[]
  for s in t.ref.subjects(kind):
   paths=[out/kind/a/(t.ref.name(kind,s,f)+'.npz') for a in t.ARMS for f in range(5)]
   if not all(p.exists() for p in paths):continue
   results={};truth_ref=None
   for arm in ['full_multiscale']+t.ARMS:
    yy=[];pred=[]
    for f in range(5):
     path=(FULL/kind/'multiscale' if arm=='full_multiscale' else out/kind/arm)/(t.ref.name(kind,s,f)+'.npz')
     with np.load(path) as z:
      yy.extend(z['y']);pred.extend(z['pred'])
      with np.load(FULL/kind/'multiscale'/(t.ref.name(kind,s,f)+'.npz')) as ref:
       assert np.array_equal(z['train_idx'],ref['train_idx']) and np.array_equal(z['test_idx'],ref['test_idx'])
    yy=np.asarray(yy)
    if truth_ref is None:truth_ref=yy
    else:assert np.array_equal(yy,truth_ref)
    results[arm]=t.ref.metrics(yy,np.asarray(pred))
   subjects.append({'subject':s,**results})
  report={'completed_subjects':len(subjects),'total_subjects':len(t.ref.subjects(kind)),'subjects':subjects}
  if subjects:
   report['accuracy_means']={arm:float(np.mean([r[arm]['accuracy'] for r in subjects])) for arm in ['full_multiscale']+t.ARMS}
   report['full_minus_control_pp']={arm:100*(report['accuracy_means']['full_multiscale']-report['accuracy_means'][arm]) for arm in t.ARMS}
  datasets[kind]=report
 t.save(out/'summary.json',{'complete':full,'datasets':datasets,'boundary':'All controls6440parameters with active inputs. Direct_smoothing has exactly same first-linear function class as telescoping multiscale decomposition: any gain reflects parameterization/optimization bias, NOT new expressive capacity. Slow-only nonlinear views preserve parameter count but restrict input information. Permutation alters neighborhood definition, not real signal acquisition. Reused development folds, one seed, exploratory.'})
t.summarize=summarize
def main():
 out=HERE/'results'/'rule_control_batch';out.mkdir(parents=True,exist_ok=True)
 if (out/'status.json').exists():raise RuntimeError('Preserve existing batch')
 t.save(out/'protocol.json',{'arms':t.ARMS,'reference':'Previously completed multiscale105folds reused and train/test IDs checked','new_fits':315,'steps':200,'new_params':6440,'backbone':'Source CNN,bestadapter,Transformer frozen; same fixed seed and CE/LOO objectives for all','contrasts':{'direct_smoothing':'raw,3mean,5mean vs difference components. Exact function-class equivalent before GELU; test parameterization efficiency only.','slow_information_only':'5mean and its square/tanh. All input weight columns active, same nominal trainable count; tests whether slow information alone suffices.','permuted_neighborhood':'Fixed even-odd temporal permutation, decompose then restore window alignment. Tests local neighborhood choice.'},'prediction':'Full should exceed slow-only and nonlocal-neighborhood if joint local structure matters; direct smoothing controls equivalent linear parametrization. Ties or losses constrain contributions. No universal2pp requirement or test-score early stopping.','limits':'All development folds repeatedly viewed; one seed; no independent confirmation, biological causality or firstness; no retrain completed baselines.'})
 start=time.time()
 try:
  x=torch.randn(2,5,256);s3=t.smooth(x,3);s5=t.smooth(x,5)
  w=torch.randn(768,8);a,b,c=w.split(256,0)
  lhs=original_pack(x,'multiscale')@w
  rhs=x@a+s3@(b-a)+s5@(c-b)
  assert torch.allclose(lhs,rhs,atol=5e-5,rtol=1e-4)
  for arm in t.ARMS:assert pack(x,arm).shape==(2,5,768) and torch.isfinite(pack(x,arm)).all()
  for job in ['temporal_smoke','temporal_screen']:
   t.save(out/'status.json',{'state':'running','stage':job,'elapsed_seconds':time.time()-start})
   sys.argv=[__file__,'--job',job,'--workers','2'];t.main()
  t.save(out/'status.json',{'state':'complete','elapsed_seconds':time.time()-start})
 except BaseException:t.save(out/'status.json',{'state':'failed','error':traceback.format_exc()});raise
if __name__=='__main__':main()
