"""Four matched corrections on frozen best saved EEG adapters; no baseline retrain."""
import os
for key in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[key]='2'
import sys,json,time,hashlib,argparse,traceback,multiprocessing
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
sys.path.insert(0,'/root/FAST/experiments/adapter_specificity_20261006')
import run_specificity as ref
import numpy as np,torch
from torch import nn
from torch.nn import functional as F
ROOT=Path(__file__).resolve().parent
ARMS=['adaptive_variation','fixed_mix','reverse_variation']
STEPS=200
def save(p,z):
 q=p.with_suffix('.tmp');q.write_text(json.dumps(z,ensure_ascii=False,indent=2));q.replace(p)
def smooth(x,k):
 # Replicated boundaries; same fixed windows/trials as saved model.
 return F.avg_pool1d(F.pad(x.transpose(1,2),(k//2,k//2),mode='replicate'),k,stride=1).transpose(1,2)
def pack(x,arm):
 if arm=='difference':
  d1=torch.zeros_like(x);d1[:,1:]=x[:,1:]-x[:,:-1]
  d2=torch.zeros_like(x);d2[:,2:]=(x[:,2:]-x[:,:-2])/2
  return torch.cat([x,d1,d2],-1)
 if arm=='multiscale':
  s3=smooth(x,3);s5=smooth(x,5)
  return torch.cat([x-s3,s3-s5,s5],-1)
 if arm=='local_global':
  mean=x.mean(1,keepdim=True).expand_as(x)
  d=torch.zeros_like(x);d[:,1:]=x[:,1:]-x[:,:-1]
  return torch.cat([x-mean,mean,d],-1)
 if arm=='pointwise_control':return torch.cat([x,x.square()/6,torch.tanh(x)],-1)
 raise ValueError(arm)
class Temporal(nn.Module):
 def __init__(self,saved,arm):
  super().__init__();self.saved=saved;self.saved.eval().requires_grad_(False);self.arm=arm
  self.register_buffer('reference_variation',saved._variation_median)
  self.down=nn.Linear(768,8);self.out=nn.Linear(8,32)
  nn.init.zeros_(self.out.weight);nn.init.zeros_(self.out.bias)
 def forward(self,full,mean):
  old,gate=self.saved(full,mean)
  x=((torch.asinh(full.float())-self.saved.center)/self.saved.scale).clamp(-6,6).flatten(2)
  centered=x-x.mean(1,keepdim=True)
  variation=centered.square().mean((1,2))/x.square().mean((1,2)).clamp_min(1e-8)
  weight=(variation/(variation+self.reference_variation.clamp_min(1e-8))).view(-1,1,1)
  if self.arm=='fixed_mix':weight=torch.ones_like(weight)*.5
  elif self.arm=='reverse_variation':weight=1-weight
  features=weight*pack(x,'multiscale')+(1-weight)*pack(x,'pointwise_control')
  correction=.5*torch.tanh(self.out(F.gelu(self.down(features)))/.5)
  return old+correction,gate

def load(kind,s,f):
 x,y=ref.dataset(kind,s);tr,te=list(ref.splits(kind,x,y))[f]
 # Existing exact source and adapter replay check, never fit these weights.
 base,train,test,mean,testmean,old,oldpred,reference,error=ref.load(kind,s,f,tr,te,x,y)
 common=ref.initialize(kind,train,mean);best=ref.GenericAdapter(common).cuda()
 folder=ref.OUT/kind/'generic_adapter';name=ref.name(kind,s,f)
 ck=torch.load(folder/(name+'.pt'),map_location='cpu');best.load_state_dict(ck['state_dict']);best.eval().requires_grad_(False)
 with np.load(folder/(name+'.npz')) as z:
  assert np.array_equal(z['train_idx'],tr) and np.array_equal(z['test_idx'],te)
  assert np.array_equal(z['y'],y[te]);prob=z['prob'].copy();pred=z['pred'].copy()
 with torch.no_grad():replay=ref.rep(kind,base,best,test,testmean)[0].float().softmax(-1).cpu().numpy()
 assert np.array_equal(replay.argmax(-1),pred)
 assert np.max(np.abs(replay-prob))<1e-6
 with torch.no_grad():
  normalized=((torch.asinh(train.float())-best.center)/best.scale).clamp(-6,6).flatten(2)
  centered=normalized-normalized.mean(1,keepdim=True)
  variation=centered.square().mean((1,2))/normalized.square().mean((1,2)).clamp_min(1e-8)
  best._variation_median=variation.median().detach()
 return base,best,train,test,mean,testmean,tr,te,y,pred,float(np.max(np.abs(replay-prob))),folder/(name+'.pt')
def train_arm(kind,s,f,arm,data,out,steps):
 base,best,train,test,mean,testmean,tr,te,y,oldpred,replayerr,source=data
 seed=ref.seed(kind,s,f);ref.main_ref.v4.seed_all(seed)
 adapter=Temporal(best,arm).cuda()
 trainable=[p for p in adapter.parameters() if p.requires_grad];assert sum(p.numel() for p in trainable)==6440
 with torch.no_grad():
  initial=ref.rep(kind,base,adapter,test,testmean)[0]
  exact=ref.rep(kind,base,best,test,testmean)[0];assert torch.equal(initial,exact)
 opt=torch.optim.AdamW(trainable,lr=.001,weight_decay=.01);target=torch.from_numpy(y[tr]).cuda();start=time.time();trace=[]
 for step in range(steps):
  for group in opt.param_groups:group['lr']=.001*(.1+.9*.5*(1+np.cos(np.pi*step/max(steps-1,1))))
  opt.zero_grad(set_to_none=True)
  logits,q,gate,total=ref.rep(kind,base,adapter,train,mean)
  with torch.no_grad():old_delta=best(train,mean)[0]
  correction=total-old_delta
  ce=F.cross_entropy(logits,target);aux=.3*F.cross_entropy(4*ref.ridge(kind,q,target),target)
  loss=ce+aux+.01*correction.square().mean()
  assert torch.isfinite(loss);loss.backward()
  assert all(p.grad is None or torch.isfinite(p.grad).all() for p in trainable)
  opt.step()
  if step in [0,49,99,steps-1]:trace.append({'step':step+1,'ce':float(ce.detach()),'aux':float(aux.detach()),'correction_rms':float(correction.detach().square().mean().sqrt())})
 with torch.no_grad():prob=ref.rep(kind,base,adapter,test,testmean)[0].float().softmax(-1).cpu().numpy()
 assert np.isfinite(prob).all();pred=prob.argmax(-1)
 dest=out/kind/arm;dest.mkdir(parents=True,exist_ok=True);name=ref.name(kind,s,f)
 np.savez_compressed(dest/(name+'.npz'),pred=pred,prob=prob,y=y[te],baseline_pred=oldpred,train_idx=tr,test_idx=te)
 row={'dataset':kind,'subject':s,'fold':f,'arm':arm,'accuracy':float((pred==y[te]).mean()),'baseline_accuracy':float((oldpred==y[te]).mean()),'parameters_new':6440,'steps':steps,'seconds':time.time()-start,'trace':trace,'baseline_replay_error':replayerr,'zero_init_exact':True,'baseline_adapter_source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
 save(dest/(name+'.json'),row)
 torch.save({'correction_state_dict':{k:v.cpu() for k,v in adapter.state_dict().items() if not k.startswith('saved.')},'arm':arm,'source':str(source),'train_idx':tr,'test_idx':te},dest/(name+'.pt'))
 return row
def worker(config):
 kind,s,f,out,steps=config;torch.set_num_threads(2);out=Path(out);start=time.time()
 data=load(kind,s,f);base,best=data[:2];before=ref.main_ref.tensorhash(base);bestbefore=ref.main_ref.tensorhash(best)
 rows=[]
 for arm in ARMS:rows.append(train_arm(kind,s,f,arm,data,out,steps))
 assert ref.main_ref.tensorhash(base)==before and ref.main_ref.tensorhash(best)==bestbefore
 assert all(p.grad is None for m in [base,best] for p in m.parameters())
 save(out/(kind+'_'+ref.name(kind,s,f)+'_audit.json'),{'frozen_unchanged':True,'steps':steps,'total_seconds':time.time()-start,'source_replay_passed':True})
 print('FOLD_DONE',kind,s,f,'seconds',time.time()-start,flush=True)
 return rows
def summarize(rows,out,full=False):
 result={}
 for kind in ['main','external']:
  subjects=ref.subjects(kind);finished=[]
  for s in subjects:
   paths=[out/kind/a/(ref.name(kind,s,f)+'.npz') for a in ARMS for f in range(5)]
   if not all(p.exists() for p in paths):continue
   preds={a:[] for a in ARMS};truth=[];baseline=[]
   for f in range(5):
    for j,a in enumerate(ARMS):
     with np.load(out/kind/a/(ref.name(kind,s,f)+'.npz')) as z:
      if j==0:truth.extend(z['y']);baseline.extend(z['baseline_pred'])
      preds[a].extend(z['pred'])
   y=np.asarray(truth);finished.append({'subject':s,'baseline':ref.metrics(y,np.asarray(baseline)),**{a:ref.metrics(y,np.asarray(p)) for a,p in preds.items()}})
  z={'completed_subjects':len(finished),'total_subjects':len(subjects),'subjects':finished}
  if finished:
   z['means']={a:{m:float(np.mean([r[a][m] for r in finished])) for m in ['accuracy','macro_f1']} for a in ['baseline']+ARMS}
   z['gain_vs_baseline_pp']={a:100*(z['means'][a]['accuracy']-z['means']['baseline']['accuracy']) for a in ARMS}
   z['gain_vs_fixed_mix_pp']={a:100*(z['means'][a]['accuracy']-z['means']['fixed_mix']['accuracy']) for a in ARMS[:-1]}
  result[kind]=z
 save(out/'summary.json',{'complete':full,'datasets':result,'fold_rows':rows,'success_criterion':'Report gains vs source and controls without mandatory2pp threshold. Single fixed seed, repeated development splits: exploratory only. Does not prove biological mechanism, causal necessity, or firstness.','published_comparison':'Old paper comparison retained separately; no published scores mixed with current paired architecture comparison.'})
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--job',choices=['adaptive_smoke','adaptive_screen'],required=True);ap.add_argument('--workers',type=int,default=2);a=ap.parse_args()
 out=ROOT/'results'/a.job;out.mkdir(parents=True,exist_ok=True)
 if (out/'status.json').exists():raise RuntimeError('Existing output; no overwrite')
 configs=[(kind,s,f,str(out),STEPS) for kind in ['main','external'] for s in ref.subjects(kind) for f in range(5)]
 if a.job=='adaptive_smoke':configs=[('main',0,0,str(out),5),('external',1,0,str(out),5)]
 save(out/'protocol.json',{'arms':ARMS,'workers':a.workers,'steps':200,'new_parameters_per_arm':6440,'mode':'training-median-normalized per-trial variation controls mixture of multiscale and pointwise representations before same6440parameter correction; fixed and reverse routing controls','source':'verified saved generic_adapter weights; no old baseline retraining','source_hash':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'literature':'Adaptive multi-scale fusion is an established family; this variation-based fixed routing rule is exploratory, exact novelty unresolved. No firstness.'})
 rows=[];done=0;start=time.time();total=len(configs)
 save(out/'status.json',{'state':'running','progress':0,'total':total,'elapsed_seconds':0,'workers':a.workers})
 try:
  with ProcessPoolExecutor(max_workers=a.workers,mp_context=multiprocessing.get_context('spawn')) as pool:
   for fut in as_completed([pool.submit(worker,c) for c in configs]):
    rows.extend(fut.result());done+=1;elapsed=time.time()-start
    save(out/'raw.json',rows);summarize(rows,out,False)
    save(out/'status.json',{'state':'running','progress':done,'total':total,'method_runs':len(rows),'elapsed_seconds':elapsed,'estimated_remaining_seconds':(total-done)*elapsed/done,'workers':a.workers})
  summarize(rows,out,a.job=='adaptive_screen')
  save(out/'validation.json',{'passed':True,'zero_init_and_source_replay':True,'frozen_both_source_modules':True,'finite_backward':True,'all_fixed_folds':done==total,'baseline_retrained':False})
  save(out/'status.json',{'state':'complete','progress':done,'total':total,'method_runs':len(rows),'elapsed_seconds':time.time()-start})
 except BaseException:
  save(out/'status.json',{'state':'failed','progress':done,'total':total,'elapsed_seconds':time.time()-start,'error':traceback.format_exc()});raise
if __name__=='__main__':main()
