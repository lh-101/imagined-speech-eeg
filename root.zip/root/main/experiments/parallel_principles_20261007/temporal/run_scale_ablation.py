"""Fixed scale masks, full reference reused, all negative outcomes retained."""
import sys,json,time,traceback
from pathlib import Path
import numpy as np,torch
import run_temporal as t
HERE=Path(__file__).resolve().parent
FULL=HERE/'results'/'temporal_screen'
t.ROOT=HERE/'scale_ablation'
t.ARMS=['without_local','without_middle','without_slow']
original_pack=t.pack
def pack(x,arm):
 if arm not in t.ARMS:return original_pack(x,arm)
 full=original_pack(x,'multiscale');parts=list(full.split(256,-1))
 parts[t.ARMS.index(arm)]=torch.zeros_like(parts[0])
 return torch.cat(parts,-1)
t.pack=pack
def summarize(rows,out,full=False):
 datasets={}
 for kind in ['main','external']:
  subjects=[]
  for s in t.ref.subjects(kind):
   paths=[out/kind/a/(t.ref.name(kind,s,f)+'.npz') for a in t.ARMS for f in range(5)]
   if not all(p.exists() for p in paths):continue
   results={};truth_ref=None
   for arm in ['full_multiscale']+t.ARMS:
    yy=[];pred=[]
    for f in range(5):
     path=(FULL/kind/'multiscale' if arm=='full_multiscale' else out/kind/arm)/(t.ref.name(kind,s,f)+'.npz')
     with np.load(path) as z:
      yy.extend(z['y']);pred.extend(z['pred'])
      with np.load(FULL/kind/'multiscale'/(t.ref.name(kind,s,f)+'.npz')) as ref:
       assert np.array_equal(z['train_idx'],ref['train_idx']) and np.array_equal(z['test_idx'],ref['test_idx'])
    yy=np.asarray(yy)
    if truth_ref is None:truth_ref=yy
    else:assert np.array_equal(yy,truth_ref)
    results[arm]=t.ref.metrics(yy,np.asarray(pred))
   subjects.append({'subject':s,**results})
  report={'completed_subjects':len(subjects),'total_subjects':len(t.ref.subjects(kind)),'subjects':subjects}
  if subjects:
   report['accuracy_means']={arm:float(np.mean([r[arm]['accuracy'] for r in subjects])) for arm in ['full_multiscale']+t.ARMS}
   report['full_minus_removed_pp']={arm:100*(report['accuracy_means']['full_multiscale']-report['accuracy_means'][arm]) for arm in t.ARMS}
  datasets[kind]=report
 t.save(out/'summary.json',{'complete':full,'datasets':datasets,'boundary':'Fixed slot-zeroing with retraining; identical nominal6440parameter architecture and budget, but masked input weights have no useful gradients, so effective capacity differs. Shows ablation sensitivity, not unique biological mechanism or firstness. Reused development folds.'})
t.summarize=summarize
def main():
 out=HERE/'results'/'scale_batch';out.mkdir(parents=True,exist_ok=True)
 if (out/'status.json').exists():raise RuntimeError('Preserve existing batch')
 t.save(out/'protocol.json',{'arms':t.ARMS,'components':['x-smooth3(x)','smooth3(x)-smooth5(x)','smooth5(x)'],'operation':'Zero one fixed256-dimensional slot, keep other slots unchanged, refit only same correction from same seed','reference':'Existing complete full_multiscale results reused, no rerun','new_fits':315,'steps':200,'subjects':'15BCI2020+6Nguyen,5original outer folds','capacity':'Same nominal6440params, same768->8->32 architecture; masked columns inactive, not identical effective capacity','controls':'Prior full and ordinarypointwise results available; inspect all components, no score-based early stopping','limits':'Singleseed,repeated development splits; descriptive exploratory analysis. Not evidence of biological frequency bands. CNN/backbone and bestsource frozen.'})
 start=time.time()
 try:
  x=torch.randn(2,5,256);p=original_pack(x,'multiscale').split(256,-1)
  assert torch.allclose(sum(p),x,atol=1e-6)
  for i,a in enumerate(t.ARMS):assert torch.count_nonzero(pack(x,a).split(256,-1)[i])==0
  for job in ['temporal_smoke','temporal_screen']:
   t.save(out/'status.json',{'state':'running','stage':job,'elapsed_seconds':time.time()-start})
   sys.argv=[__file__,'--job',job,'--workers','2'];t.main()
  t.save(out/'status.json',{'state':'complete','elapsed_seconds':time.time()-start})
 except BaseException:t.save(out/'status.json',{'state':'failed','error':traceback.format_exc()});raise
if __name__=='__main__':main()
