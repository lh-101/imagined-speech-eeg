"""Read-only progress display; Ctrl+C stops display, not experiments."""
import argparse,json,time,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--watch',action='store_true');a=ap.parse_args()
def duration(x):
 x=max(0,int(x));return f'{x//3600:02d}:{x//60%60:02d}:{x%60:02d}'
while True:
 if a.watch:print('\033[2J\033[H',end='')
 print('Network computation study | server time',datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
 print('Ctrl+C stops this display only. Rows are computational trials, not EEG subjects.')
 for p in sorted(ROOT.glob('*/results/*/status.json')):
  try:s=json.loads(p.read_text())
  except (ValueError,OSError):continue
  state=s.get('state');n=s.get('progress');total=s.get('total');elapsed=s.get('elapsed_seconds',s.get('elapsed',0))
  if state=='running':elapsed+=max(0,time.time()-p.stat().st_mtime)
  remain=s.get('estimated_remaining_seconds')
  if state=='running' and n and total:remain=max(0,total-n)*elapsed/n
  fraction=f'{n}/{total} ({100*n/total:.1f}%)' if isinstance(n,(int,float)) and total else s.get('stage','')
  print(f"{p.parent.name:24} | {str(state):9} | {fraction:24} | elapsed {duration(elapsed)} | ETA {duration(remain) if remain is not None and state=='running' else '--'}")
  if s.get('error'):print('  error:',str(s['error'])[-250:])
 print('ETA is a rough extrapolation; workloads and gated follow-ups differ.')
 if not a.watch:break
 try:time.sleep(5)
 except KeyboardInterrupt:break
