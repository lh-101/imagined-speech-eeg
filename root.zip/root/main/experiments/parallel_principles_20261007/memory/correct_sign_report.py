"""Preserve frozen output; correct tied sign-test accounting in a derived file."""
import json,math,time
from pathlib import Path
P=Path(__file__).resolve().parent/'results'/'digits_stream'
start=time.time()
while True:
 if time.time()-start>600:raise RuntimeError('Digits completion wait exceeded 10min')
 if (P/'status.json').exists():
  state=json.loads((P/'status.json').read_text())['state']
  if state=='failed':raise RuntimeError('Digits run failed')
  if state=='complete':break
 time.sleep(2)
summary=json.loads((P/'summary.json').read_text())
derived={}
for group,z in summary['groups'].items():
 rows=[]
 for item in z['all_contrasts']:
  if item is None:continue
  differences=list(item['seed_differences'].values());nonzero=[x for x in differences if abs(x)>1e-12]
  n=len(nonzero);wins=sum(x<0 for x in nonzero)
  p=min(1.,2*sum(math.comb(n,j) for j in range(min(wins,n-wins)+1))/2**n) if n else 1.
  rows.append({'control':item['control'],'gamma':item['gamma'],'kind':item['kind'],
    'effective_non_tied_seed_count':n,'ties_excluded':len(differences)-n,'corrected_two_sided_sign_p':p})
 derived[group]=rows
obj={'groups':derived,'note':'Numerical ties abs(diff)<=1e-12 excluded; all ties p=1. Derived correction only. Frozen summary preserved; gate did not use sign p. No multiplicity correction or confirmatory significance claim.'}
(P/'corrected_sign_tests.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2))
print('Corrected sign-test report written; original results and gate unchanged.')
