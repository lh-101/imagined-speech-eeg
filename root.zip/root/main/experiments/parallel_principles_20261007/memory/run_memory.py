"""Frozen replication and dimension transport; no hyperparameter search."""
import os
for _name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_name]='1'
import sys, json, time, hashlib, argparse, traceback, math
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
ROOT=Path(__file__).resolve().parent
for _p in [ROOT, ROOT.parent.parent/'双侧修订子空间20261007',
           ROOT.parent.parent/'证据一致性状态更新20261007',
           Path('/root/FAST/experiments/bilateral_memory_20261007'),
           Path('/root/FAST/experiments/bilateral_revision_20261007'),
           Path('/root/FAST/experiments/paired_evidence_replay_20261007')]:
    if _p.exists(): sys.path.append(str(_p))
import numpy as np
import paired_replay as old
import run_experiment as ref
from bilateral_memory import BilateralMemory, validate
NEW={'bilateral':'bilateral','data_full':'full_output','data_single':'single_output',
     'data_random':'random_output','data_parameter':'parameter','data_global':'global'}
METHODS=[(k,.95) for k in NEW]+ref.METHODS
SEEDS=list(range(200,208))

def save(p,z):
    q=p.with_suffix('.tmp'); q.write_text(json.dumps(z,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf8'); q.replace(p)

def generate(family,rho,kind,noise,seed,d=8):
    if d==8: return ref.generate(family,rho,kind,noise,seed)
    # Dimension transport only. Duration, old operator, and all thresholds stay fixed.
    rng=np.random.default_rng(8473100+seed+int(rho*1000)+int(noise*10000)+
        {'static':0,'partial':100000,'whole':200000}[kind]+(1000000 if family=='continuous' else 0)+d*10000000)
    m=4; common=rng.normal(size=d); common/=np.linalg.norm(common)
    def keys(n):
        z=np.sqrt(1-rho)*rng.normal(size=(n,d))/np.sqrt(d)+np.sqrt(rho)*common
        return z/np.linalg.norm(z,axis=1,keepdims=True)
    rotation=np.linalg.qr(rng.normal(size=(m,m)))[0]
    if family=='repeated':
        queries=keys(d);v0=rng.normal(size=(d,m));v1=v0.copy();mask=np.zeros((d,m),bool)
        if kind=='partial':mask[:2,0]=True
        elif kind=='whole':mask[:2,:]=True
        v1[mask]=rng.normal(size=mask.sum())
        index=np.array([j for _ in range(240//d) for j in rng.permutation(d)])
        index[120:]=rng.choice(2,size=120,p=[.8,.2]); K=queries[index]
        targets=np.stack([v0[j] if t<120 else v1[j] for t,j in enumerate(index)])
        querymask=mask
    else:
        queries=keys(32);W0=rng.normal(size=(m,d));W1=W0.copy()
        if kind=='partial':W1[0,:2]+=rng.normal(size=2)
        elif kind=='whole':W1+=rng.normal(size=(m,d))
        v0=queries@W0.T;v1=queries@W1.T;K=keys(240);basis=keys(2)
        K[120:]=rng.normal(size=(120,2))@basis+.02*rng.normal(size=(120,d))
        K[120:]/=np.linalg.norm(K[120:],axis=1,keepdims=True)
        targets=np.concatenate([K[:120]@W0.T,K[120:]@W1.T]);querymask=np.abs(v1-v0)>1e-10
    V=(targets+rng.normal(scale=noise,size=targets.shape))@rotation
    return {'K':K,'V':V,'queries':queries,'v0':v0,'v1':v1,'rotation':rotation,'querymask':querymask}

def trial(data,method,gamma):
    d=data['K'].shape[1];m=data['V'].shape[1]
    mem=BilateralMemory(d,m,NEW[method]) if method in NEW else old.Memory(d,m,method,gamma)
    curve=[];start=time.time()
    for t,(k,v) in enumerate(zip(data['K'],data['V']),1):
        mem.step(k,v)
        if t%12==0:
            prediction=mem.predict(data['queries'])@data['rotation'].T
            target=data['v0'] if t<=120 else data['v1'];err=(prediction-target)**2;mask=data['querymask']
            curve.append({'t':t,'mse':float(err.mean()),'changed_mse':float(err[mask].mean()) if mask.any() else None,
                          'unchanged_mse':float(err[~mask].mean()) if (~mask).any() else None})
            if method not in ['delta','dict','sliding']:assert np.linalg.eigvalsh(mem.C).min()>-1e-6
    return {'method':method,'gamma':gamma,'post_mse':float(np.mean([r['mse'] for r in curve if r['t']>120])),
            'final_mse':curve[-1]['mse'],'trajectory':curve,'events':mem.events,
            'confirmations':getattr(mem,'confirmations',None),'state_scalars':mem.capacity(),'seconds':time.time()-start}

def worker(config):
    seq,d,family,rho,kind,noise,seed,out=config
    data=generate(family,rho,kind,noise,seed,d)
    np.savez_compressed(Path(out)/f'seq{seq:04d}.npz',**data)
    rows=[];confirmations=[]
    for method,gamma in METHODS:
        row=trial(data,method,gamma)
        row.update({'dimension':d,'family':family,'rho':rho,'kind':kind,'noise':noise,'seed':seed,'sequence':seq})
        rows.append(row)
        if method in NEW:confirmations.append(row['confirmations'])
    assert all(c==confirmations[0] for c in confirmations),'Confirmation events differ'
    save(Path(out)/f'rows{seq:04d}.json',rows)
    return rows

def paired_report(rr,control,gamma,kind=None):
    rr=[r for r in rr if kind is None or r['kind']==kind]
    def maprows(method,g):
        return {(r['seed'],r['rho'],r['kind'],r['noise']):r['post_mse'] for r in rr if r['method']==method and r['gamma']==g}
    a=maprows('bilateral',.95);b=maprows(control,gamma);keys=sorted(a.keys() & b.keys())
    if not keys:return None
    diffs=np.array([a[k]-b[k] for k in keys]);seeds=sorted({k[0] for k in keys})
    cluster=np.array([np.mean([a[k]-b[k] for k in keys if k[0]==s]) for s in seeds])
    rng=np.random.default_rng(98412);boot=cluster[rng.integers(len(cluster),size=(10000,len(cluster)))].mean(1)
    nonzero=cluster[np.abs(cluster)>1e-12];wins=int((nonzero<0).sum());n=len(nonzero)
    p=min(1.,2*sum(math.comb(n,j) for j in range(min(wins,n-wins)+1))/2**n) if n else 1.
    return {'control':control,'gamma':gamma,'kind':kind,'paired_sequences':len(keys),'candidate_wins':int((diffs<0).sum()),
            'candidate_ties':int((np.abs(diffs)<=1e-12).sum()),'mean_candidate_minus_control':float(diffs.mean()),
            'relative_mse_reduction':float(1-np.mean([a[k] for k in keys])/max(np.mean([b[k] for k in keys]),1e-12)),
            'seed_differences':dict(zip(map(str,seeds),map(float,cluster))),
            'seed_cluster_bootstrap_95_interval':np.quantile(boot,[.025,.975]).tolist(),
            'two_sided_seed_sign_test_p':p,'uncertainty_note':'Seed clusters, not condition rows; only 8 seeds; exploratory multiplicity not adjusted.'}

def summarize(rows,complete=False):
    result={}
    for d in sorted({r['dimension'] for r in rows}):
        for family in ['repeated','continuous']:
            rr=[r for r in rows if r['dimension']==d and r['family']==family]
            if not rr:continue
            values={}
            for name,g in METHODS:
                rs=[r for r in rr if r['method']==name and r['gamma']==g]
                if not rs:continue
                values[f'{name}_{g}']={'post_mse':float(np.mean([r['post_mse'] for r in rs])),
                    **{f'{kind}_mse':float(np.mean([r['post_mse'] for r in rs if r['kind']==kind])) if any(r['kind']==kind for r in rs) else None for kind in ['static','partial','whole']},
                    'seconds':float(sum(r['seconds'] for r in rs)),'state_scalars':float(np.mean([r['state_scalars'] for r in rs]))}
            controls=[(n,g) for n,g in METHODS if n!='bilateral']
            best=min(controls,key=lambda ng:values[f'{ng[0]}_{ng[1]}']['post_mse'])
            b=values[f'{best[0]}_{best[1]}'];a=values['bilateral_0.95']
            gate=complete and a['post_mse']<=.95*b['post_mse'] and a['static_mse']<=1.05*b['static_mse']+1e-10 and all(a['partial_mse']<=.95*values[f'{n}_0.95']['partial_mse'] for n in ['data_full','data_single','data_random'])
            result[f'd{d}_{family}']={'methods':values,'best_control_descriptive':f'{best[0]}_{best[1]}','original_gate_met':bool(gate),
                'paired_contrasts':[paired_report(rr,n,g,k) for n,g in controls for k in [None,'static','partial','whole']]}
    return {'complete':complete,'method_runs':len(rows),'groups':result,
       'original_8d_gate_met':complete and all(result.get(f'd8_{f}',{}).get('original_gate_met',False) for f in ['repeated','continuous']),
       'claim':'Frozen new-seed computational repetition; 12d transport separate; no EEG, causal-mechanism, firstness, or independent expert certification claim.'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--job',choices=['memory_confirm','memory_smoke'],required=True)
    ap.add_argument('--workers',type=int,default=4);ap.add_argument('--out-root',type=Path,default=ROOT/'results')
    a=ap.parse_args();out=a.out_root/a.job;out.mkdir(parents=True,exist_ok=True)
    if (out/'status.json').exists():raise RuntimeError('Output already exists: choose a new --out-root; no overwrite.')
    rows=[];start=time.time();done=0
    base=[(d,f,r,k,n,s) for d in [8,12] for f in ['repeated','continuous'] for r in [0.,.8] for k in ['static','partial','whole'] for n in [0.,.05,.15] for s in SEEDS]
    if a.job=='memory_smoke':base=[(d,f,.8,k,.15,999) for d in [8,12] for f in ['repeated','continuous'] for k in ['static','partial','whole']]
    configs=[(i,*c,str(out)) for i,c in enumerate(base)]
    save(out/'status.json',{'state':'running','progress':0,'total':len(configs),'elapsed_seconds':0,'workers':a.workers})
    try:
        checks={'old':old.validate(),'bilateral':validate(),'constants':{n:getattr(old,n) for n in ['LAM','BLOCK','COS','GAMMA']},
                'source_sha256':{str(Path(m.__file__)):hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for m in [old,ref,sys.modules[BilateralMemory.__module__]]},
                'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'shared_confirmation_per_sequence':True}
        assert checks['constants']=={'LAM':.001,'BLOCK':32,'COS':.5,'GAMMA':.95}
        save(out/'validation.json',checks)
        pool=ProcessPoolExecutor(max_workers=a.workers) if a.workers>1 else None
        try:
            completed=(f.result() for f in as_completed([pool.submit(worker,c) for c in configs])) if pool else (worker(c) for c in configs)
            for batch in completed:
                rows.extend(batch);done+=1;elapsed=time.time()-start
                rows.sort(key=lambda r:(r['sequence'],METHODS.index((r['method'],r['gamma']))))
                # Per-sequence files retain every finished result; big checkpoint every 32.
                if done%32==0 or done==len(configs):
                    save(out/'raw.json',rows);save(out/'summary.json',summarize(rows,False))
                save(out/'status.json',{'state':'running','progress':done,'total':len(configs),'method_runs':len(rows),
                     'elapsed_seconds':elapsed,'estimated_remaining_seconds':(len(configs)-done)*elapsed/done,'workers':a.workers})
                print(f'DONE {done}/{len(configs)} elapsed={elapsed:.1f}',flush=True)
        finally:
            if pool:pool.shutdown(wait=True,cancel_futures=True)
        save(out/'summary.json',summarize(rows,a.job=='memory_confirm'))
        save(out/'status.json',{'state':'complete','progress':done,'total':len(configs),'method_runs':len(rows),'elapsed_seconds':time.time()-start})
    except BaseException:
        save(out/'status.json',{'state':'failed','progress':done,'total':len(configs),'elapsed_seconds':time.time()-start,'error':traceback.format_exc()});raise
if __name__=='__main__':main()
