"""Output-rank boundary diagnostic. Old operator/constants/controls unchanged."""
import os
for _n in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[_n]='1'
import argparse,hashlib,time,traceback
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import run_memory as frozen
ROOT=Path(__file__).resolve().parent
KINDS=['static','partial_rank1','partial_rank2','partial_rank3','whole','old_partial_reference']
METHODS=frozen.METHODS.copy()

def generate(family,rho,kind,noise,seed):
    if kind=='old_partial_reference':
        data=frozen.ref.generate(family,rho,'partial',noise,seed)
        data['change_rank']=np.array(1);data['generator_id']=np.array('unchanged_old_run_experiment_generate_partial')
        return data
    d=8;m=4
    # Common geometry, old relation and noise across ranks; change draws isolated from key draws.
    base_seed=9473100+seed+int(rho*1000)+int(noise*10000)+(1000000 if family=='continuous' else 0)
    rng=np.random.default_rng(base_seed);common=rng.normal(size=d);common/=np.linalg.norm(common)
    def keys(n):
        z=np.sqrt(1-rho)*rng.normal(size=(n,d))/np.sqrt(d)+np.sqrt(rho)*common
        return z/np.linalg.norm(z,axis=1,keepdims=True)
    rotation=np.linalg.qr(rng.normal(size=(m,m)))[0]
    r=int(kind[-1]) if kind.startswith('partial_rank') else None
    change_rng=np.random.default_rng(base_seed+10000000)
    delta_block=change_rng.normal(size=(3,3));whole_delta=change_rng.normal(size=(m,d))
    if family=='repeated':
        queries=keys(d);v0=rng.normal(size=(d,m));v1=v0.copy()
        index=np.array([j for _ in range(30) for j in rng.permutation(d)])
        index[120:]=rng.choice(2,size=120,p=[.8,.2]);K=queries[index]
        difference=np.zeros((d,m))
        if r is not None:difference[:r,:r]=delta_block[:r,:r].T
        elif kind=='whole':difference[:2,:]=whole_delta[:,:2].T # Old repeated-whole footprint.
        v1+=difference;targets=np.stack([v0[j] if t<120 else v1[j] for t,j in enumerate(index)])
        true_rank=int(np.linalg.matrix_rank(difference));post_rank=int(np.linalg.matrix_rank(difference[index[120:]]))
    else:
        queries=keys(32);W0=rng.normal(size=(m,d));W1=W0.copy()
        K=keys(240);basis=keys(2)
        K[120:]=rng.normal(size=(120,2))@basis+.02*rng.normal(size=(120,d));K[120:]/=np.linalg.norm(K[120:],axis=1,keepdims=True)
        difference=np.zeros((m,d))
        if r is not None:difference[:r,:r]=delta_block[:r,:r]
        elif kind=='whole':difference=whole_delta
        W1+=difference;v0=queries@W0.T;v1=queries@W1.T
        targets=np.concatenate([K[:120]@W0.T,K[120:]@W1.T])
        true_rank=int(np.linalg.matrix_rank(difference));post_rank=int(np.linalg.matrix_rank(K[120:]@difference.T))
    V=(targets+rng.normal(scale=noise,size=targets.shape))@rotation
    Rk=np.linalg.qr(np.random.default_rng(base_seed+20000000).normal(size=(d,d)))[0]
    # Input rotation changes representation only; target/query semantics remain the same.
    return {'K':K@Rk,'V':V,'queries':queries@Rk,'v0':v0,'v1':v1,'rotation':rotation,
            'querymask':np.abs(v1-v0)>1e-10,'input_rotation':Rk,'change_rank':np.array(true_rank),
            'post_observed_target_change_rank':np.array(post_rank),'generator_id':np.array('common_geometry_rank_extension_v1')}

def worker(config):
    i,f,r,k,n,s,out=config;data=generate(f,r,k,n,s);np.savez_compressed(Path(out)/f'seq{i:03d}.npz',**data)
    rows=[];confirm=[]
    for method,g in METHODS:
        row=frozen.trial(data,method,g);row.update({'sequence':i,'family':f,'rho':r,'kind':k,'noise':n,'seed':s,'dimension':8,
            'change_rank':int(data['change_rank']),'post_observed_target_change_rank':int(data.get('post_observed_target_change_rank',np.array(1))),
            'generator_id':str(data['generator_id'])});rows.append(row)
        if method in frozen.NEW:confirm.append(row['confirmations'])
    assert all(c==confirm[0] for c in confirm)
    frozen.save(Path(out)/f'rows{i:03d}.json',rows);return rows

def summary(rows,complete=False):
    groups={}
    for family in ['repeated','continuous']:
        rr=[r for r in rows if r['family']==family]
        if not rr:continue
        kinds={}
        for kind in KINDS:
            rs=[r for r in rr if r['kind']==kind]
            if not rs:continue
            values={f'{n}_{g}':float(np.mean([r['post_mse'] for r in rs if r['method']==n and r['gamma']==g])) for n,g in METHODS}
            controls=[(n,g) for n,g in METHODS if n!='bilateral'];best=min(controls,key=lambda ng:values[f'{ng[0]}_{ng[1]}'])
            contrasts=[frozen.paired_report(rs,n,g) for n,g in controls]
            for c in contrasts:
                c['uncertainty_note']='Only two stream seeds clustered across rho/noise; descriptive uncertainty, no confirmation or seed selection.'
            kinds[kind]={'methods':values,'best_fixed_control_descriptive':f'{best[0]}_{best[1]}',
                'candidate_reduction_vs_best':1-values['bilateral_0.95']/max(values[f'{best[0]}_{best[1]}'],1e-12),
                'contrasts':contrasts,'events_output_rank_counts':{str(rank):sum(sum(e.get('output_rank')==rank for e in r['events']) for r in rs if r['method']=='bilateral') for rank in range(5)}}
        groups[family]=kinds
    return {'complete':complete,'method_runs':len(rows),'groups':groups,
        'scope':'Cheap rank boundary diagnostic, two fixed new seeds; full static/whole negatives and exact old-partial reference separate.',
        'original_failed_gate_unchanged':True,'data_single_definition':'Single evidence SAME output rank as candidate; not rank-one update.',
        'data_parameter_definition':'One parameter direction revision.',
        'advance_policy':'No promotion unless ranks2/3 beat same-rank single evidence and strongest old fixed control; two seeds alone cannot confirm. Delta/key superiority or equivalent single evidence falsifies claimed need under this boundary.'}

def validate():
    result={}
    for family in ['repeated','continuous']:
        data=[generate(family,.8,k,.15,499) for k in KINDS[:-1]]
        assert all(np.array_equal(d['K'],data[0]['K']) and np.array_equal(d['queries'],data[0]['queries']) for d in data)
        assert all(np.array_equal(d['V'][:120],data[0]['V'][:120]) for d in data)
        assert [int(d['change_rank']) for d in data[1:4]]==[1,2,3]
        old=generate(family,.8,'old_partial_reference',.15,499);direct=frozen.ref.generate(family,.8,'partial',.15,499)
        assert all(np.array_equal(old[k],direct[k]) for k in direct)
        result[family]={'common_geometry_prefix_and_queries':True,'rank1_2_3_exact':True,'old_partial_reference_bit_exact':True,
            'post_observed_target_change_ranks':[int(d['post_observed_target_change_rank']) for d in data]}
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--job',choices=['synthetic_rank','synthetic_rank_smoke'],required=True)
    ap.add_argument('--workers',type=int,default=4);ap.add_argument('--out-root',type=Path,default=ROOT/'results');a=ap.parse_args()
    out=a.out_root/a.job;out.mkdir(parents=True,exist_ok=True)
    if (out/'status.json').exists():raise RuntimeError('Existing output; use another --out-root')
    base=[(f,r,k,n,s) for f in ['repeated','continuous'] for r in [0.,.8] for k in KINDS for n in [0.,.05,.15] for s in [500,501]]
    if a.job.endswith('smoke'):base=[(f,.8,k,.15,498) for f in ['repeated','continuous'] for k in KINDS]
    rows=[];done=0;start=time.time();pool=None;frozen.save(out/'status.json',{'state':'running','progress':0,'total':len(base),'elapsed_seconds':0})
    try:
        frozen.save(out/'validation.json',{'rank_inputs':validate(),'old':frozen.old.validate(),'bilateral':frozen.validate(),
            'constants':{n:getattr(frozen.old,n) for n in ['LAM','BLOCK','COS','GAMMA']},
            'source_sha256':{str(Path(m.__file__)):hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for m in [frozen,frozen.old,frozen.ref,frozen.sys.modules[frozen.BilateralMemory.__module__]]},
            'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
        cfg=[(i,*c,str(out)) for i,c in enumerate(base)];pool=ProcessPoolExecutor(max_workers=a.workers) if a.workers>1 else None
        completed=(f.result() for f in as_completed([pool.submit(worker,c) for c in cfg])) if pool else (worker(c) for c in cfg)
        for batch in completed:
            rows.extend(batch);done+=1;rows.sort(key=lambda r:(r['sequence'],METHODS.index((r['method'],r['gamma']))));elapsed=time.time()-start
            if done%12==0 or done==len(cfg):frozen.save(out/'raw.json',rows);frozen.save(out/'summary.json',summary(rows,False))
            frozen.save(out/'status.json',{'state':'running','progress':done,'total':len(cfg),'method_runs':len(rows),'elapsed_seconds':elapsed,'estimated_remaining_seconds':(len(cfg)-done)*elapsed/done})
            print(f'DONE {done}/{len(cfg)} elapsed={elapsed:.1f}',flush=True)
        frozen.save(out/'summary.json',summary(rows,not a.job.endswith('smoke')))
        frozen.save(out/'status.json',{'state':'complete','progress':done,'total':len(cfg),'method_runs':len(rows),'elapsed_seconds':time.time()-start})
    except BaseException:
        frozen.save(out/'status.json',{'state':'failed','progress':done,'total':len(base),'elapsed_seconds':time.time()-start,'error':traceback.format_exc()});raise
    finally:
        if pool:pool.shutdown(wait=True,cancel_futures=True)
if __name__=='__main__':main()
