"""Frozen 28-rule transfer to public real digits features, with controlled label remaps.
No teacher, test scoring, parameter search, or natural-drift/EEG claim.
"""
import os
for _name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_name]='1'
import argparse, hashlib, json, math, pickle, time, traceback
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
import sklearn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import run_memory as frozen

ROOT=Path(__file__).resolve().parent
SPLIT_SEED=734011
SEEDS=list(range(400,408))
METHODS=frozen.METHODS.copy()
KINDS=['static','partial','whole']
ACCESS=['biased','unbiased']

def digest_arrays(*arrays):
    h=hashlib.sha256()
    for a in arrays:
        a=np.ascontiguousarray(a);h.update(str(a.dtype).encode());h.update(str(a.shape).encode());h.update(a.tobytes())
    return h.hexdigest()

def fit_preprocessing(X,train):
    scaler=StandardScaler().fit(X[train])
    pca=PCA(n_components=8,svd_solver='full').fit(scaler.transform(X[train]))
    return scaler,pca

def normalize(z):
    norm=np.linalg.norm(z,axis=1,keepdims=True)
    assert norm.min()>1e-12,'Zero PCA key; no data-dependent fallback allowed'
    return z/norm

def prepare(out):
    digits=load_digits();selected=np.flatnonzero(digits.target<4)
    X=digits.data[selected].astype(np.float64);y=digits.target[selected].astype(np.int64)
    ids=np.arange(len(y))
    trainval,test=train_test_split(ids,test_size=.2,random_state=SPLIT_SEED,stratify=y)
    train,val=train_test_split(trainval,test_size=.25,random_state=SPLIT_SEED+1,stratify=y[trainval])
    train=np.sort(train);val=np.sort(val);test=np.sort(test)
    assert not(set(train)&set(val) or set(train)&set(test) or set(val)&set(test))
    assert len(train)+len(val)+len(test)==len(y)
    scaler,pca=fit_preprocessing(X,train)
    train_keys=normalize(pca.transform(scaler.transform(X[train])))
    val_keys=normalize(pca.transform(scaler.transform(X[val])))
    # No test-feature transform or test-query/target generation. Only IDs are sealed.
    package=out/'digits_train_val.npz'
    np.savez_compressed(package,train_keys=train_keys,train_labels=y[train],train_ids=selected[train],
        val_keys=val_keys,val_labels=y[val],val_ids=selected[val],scaler_mean=scaler.mean_,scaler_scale=scaler.scale_,
        pca_mean=pca.mean_,pca_components=pca.components_,pca_explained_variance_ratio=pca.explained_variance_ratio_)
    frozen.save(out/'sealed_test_ids.json',{'dataset':'sklearn.load_digits','classes':[0,1,2,3],
        'sample_ids':selected[test].tolist(),'test_scored':False,'test_feature_transform':False,
        'note':'IDs selected once using stratification; no test predictions, metrics, teacher or threshold selection.'})
    manifest={'dataset':'sklearn.load_digits','sklearn_version':sklearn.__version__,'numpy_version':np.__version__,
        'classes':[0,1,2,3],'split_seed':SPLIT_SEED,'split_seed_second':SPLIT_SEED+1,
        'split_sizes':{'train':len(train),'val':len(val),'sealed_test':len(test)},
        'train_class_counts':np.bincount(y[train],minlength=4).tolist(),'val_class_counts':np.bincount(y[val],minlength=4).tolist(),
        'train_ids':selected[train].tolist(),'val_ids':selected[val].tolist(),
        'raw_selected_dataset_sha256':digest_arrays(X,y,selected),'preprocessing_train_ids_sha256':digest_arrays(selected[train]),
        'package_sha256':hashlib.sha256(package.read_bytes()).hexdigest(),'preprocessing_fit':'train only; unsupervised StandardScaler + PCA8(full SVD); L2-normalized keys',
        'scaler_n_samples_seen':int(scaler.n_samples_seen_),'pca_explained_variance_ratio':pca.explained_variance_ratio_.tolist(),
        'test_used_for_model_selection':False,'test_feature_transform':False,'test_scored':False,
        'teacher_trained':False,'head_bias_added':False,'noise_added':False}
    frozen.save(out/'data_manifest.json',manifest)
    # Procedural negative test: arbitrary holdout pixel corruption cannot affect train fit.
    Xchanged=X.copy();Xchanged[np.r_[val,test]]+=np.random.default_rng(76510).normal(size=(len(val)+len(test),64))*1000
    alt_scaler,alt_pca=fit_preprocessing(Xchanged,train)
    assert np.array_equal(scaler.mean_,alt_scaler.mean_) and np.array_equal(scaler.scale_,alt_scaler.scale_)
    assert np.array_equal(pca.components_,alt_pca.components_) and np.array_equal(pca.mean_,alt_pca.mean_)
    return package,{'split_disjoint':True,'train_fit_unchanged_under_holdout_pixel_corruption':True,
        'train_key_max_norm_error':float(np.max(np.abs(np.linalg.norm(train_keys,axis=1)-1))),
        'val_key_max_norm_error':float(np.max(np.abs(np.linalg.norm(val_keys,axis=1)-1))),
        'test_transform_or_score':False,'manifest':manifest}

def labelmap(kind):
    if kind=='static':return np.arange(4)
    if kind=='partial':return np.array([1,0,2,3])
    if kind=='whole':return np.array([1,2,3,0])
    raise ValueError(kind)

def generate(package,kind,access,seed):
    with np.load(package) as p:base={k:p[k] for k in ['train_keys','train_labels','train_ids','val_keys','val_labels','val_ids']}
    rng=np.random.default_rng(7019300+seed)
    pools=[rng.permutation(np.flatnonzero(base['train_labels']==c)) for c in range(4)]
    counts=np.array([54,54,6,6] if access=='biased' else [30,30,30,30])
    assert all(len(pool)>=30+count for pool,count in zip(pools,counts))
    pre=np.concatenate([pool[:30] for pool in pools]);pre=pre[np.random.default_rng(871300+seed).permutation(120)]
    post=np.concatenate([pool[30:30+n] for pool,n in zip(pools,counts)])
    post=post[np.random.default_rng(891300+seed).permutation(120)]
    ix=np.r_[pre,post];labels=base['train_labels'][ix];mapped=labels.copy();mapped[120:]=labelmap(kind)[labels[120:]]
    eye=np.eye(4);v0=eye[base['val_labels']];v1=eye[labelmap(kind)[base['val_labels']]]
    changed_class=np.any(v0!=v1,axis=1)
    result={'K':base['train_keys'][ix],'V':eye[mapped],'queries':base['val_keys'],
        'v0':v0,'v1':v1,'querymask':np.abs(v1-v0)>1e-10,'changed_querymask':changed_class,
        'query_original_labels':base['val_labels'],'stream_original_labels':labels,'stream_mapped_labels':mapped,
        'stream_ids':base['train_ids'][ix],'query_ids':base['val_ids'],'post_class_counts':counts}
    assert len(np.unique(result['stream_ids']))==240
    assert not set(result['stream_ids'])&set(result['query_ids'])
    assert np.all(result['V'].sum(1)==1) and np.all(np.isin(result['V'],[0,1]))
    assert np.array_equal(np.bincount(labels[:120],minlength=4),np.full(4,30))
    assert np.array_equal(np.bincount(labels[120:],minlength=4),counts)
    return result

def new_memory(method,gamma):
    return frozen.BilateralMemory(8,4,frozen.NEW[method]) if method in frozen.NEW else frozen.old.Memory(8,4,method,gamma)

def evaluate(pred,target,changed):
    error=(pred-target)**2;truth=np.argmax(target,axis=1);correct=np.argmax(pred,axis=1)==truth
    return {'mse':float(error.mean()),'accuracy':float(correct.mean()),
       'macro_accuracy':float(np.mean([correct[truth==c].mean() for c in range(4)])),
       'changed_class_mse':float(error[changed].mean()) if changed.any() else None,
       'unchanged_class_mse':float(error[~changed].mean()) if (~changed).any() else None,
       'changed_class_accuracy':float(correct[changed].mean()) if changed.any() else None,
       'unchanged_class_accuracy':float(correct[~changed].mean()) if (~changed).any() else None,
       'per_class_accuracy':[float(correct[truth==c].mean()) for c in range(4)]}

def trial(data,method,gamma):
    memory=new_memory(method,gamma);curve=[];prefix=[];start=time.time()
    for t,(k,v) in enumerate(zip(data['K'],data['V']),1):
        # True prequential stream score: current key is revealed, v not yet passed to memory.
        pre=memory.predict(k[None,:])[0]
        prefix.append({'t':t,'mse':float(np.mean((pre-v)**2)),'correct':bool(np.argmax(pre)==np.argmax(v))})
        memory.step(k,v)
        if t%12==0:
            prediction=memory.predict(data['queries']);target=data['v0'] if t<=120 else data['v1']
            metrics=evaluate(prediction,target,data['changed_querymask'] if t>120 else np.zeros(len(target),dtype=bool))
            curve.append({'t':t,**metrics})
            if method not in ['delta','dict','sliding']:assert np.linalg.eigvalsh(memory.C).min()>-1e-6
        assert np.isfinite(memory.predict(k[None,:])).all()
    post=[r for r in curve if r['t']>120];postprefix=prefix[120:]
    return {'method':method,'gamma':gamma,'post_mse':float(np.mean([r['mse'] for r in post])),
       'post_accuracy':float(np.mean([r['accuracy'] for r in post])),
       'post_macro_accuracy':float(np.mean([r['macro_accuracy'] for r in post])),
       'post_changed_class_mse':float(np.mean([r['changed_class_mse'] for r in post])) if data['changed_querymask'].any() else None,
       'post_unchanged_class_mse':float(np.mean([r['unchanged_class_mse'] for r in post])) if (~data['changed_querymask']).any() else None,
       'post_prequential_mse':float(np.mean([r['mse'] for r in postprefix])),
       'post_prequential_accuracy':float(np.mean([r['correct'] for r in postprefix])),
       'final_mse':curve[-1]['mse'],'final_accuracy':curve[-1]['accuracy'],'trajectory':curve,
       'prequential_trajectory':prefix,'events':memory.events,'confirmations':getattr(memory,'confirmations',None),
       'state_scalars':memory.capacity(),'seconds':time.time()-start}

def worker(config):
    i,kind,access,seed,package,out=config;data=generate(package,kind,access,seed)
    np.savez_compressed(Path(out)/f'seq{i:03d}.npz',**data);rows=[];confirm=[]
    for method,gamma in METHODS:
        row=trial(data,method,gamma);row.update({'sequence':i,'kind':kind,'access':access,'seed':seed,
            'family':'digits_controlled_remap','dimension':8,'rho':0.,'noise':0.,'post_class_counts':data['post_class_counts'].tolist()})
        rows.append(row)
        if method in frozen.NEW:confirm.append(row['confirmations'])
    assert all(c==confirm[0] for c in confirm)
    frozen.save(Path(out)/f'rows{i:03d}.json',rows);return rows

def pair_report(rows,control,gamma,kind=None,access=None):
    rr=[r for r in rows if (kind is None or r['kind']==kind) and (access is None or r['access']==access)]
    def keyed(method,g):return {(r['seed'],r['kind'],r['access']):r for r in rr if r['method']==method and r['gamma']==g}
    a=keyed('bilateral',.95);b=keyed(control,gamma);keys=sorted(a.keys()&b.keys())
    if not keys:return None
    seeds=sorted({k[0] for k in keys});diff=np.array([a[k]['post_mse']-b[k]['post_mse'] for k in keys])
    cluster=np.array([np.mean([a[k]['post_mse']-b[k]['post_mse'] for k in keys if k[0]==s]) for s in seeds])
    boot=cluster[np.random.default_rng(51174).integers(len(cluster),size=(10000,len(cluster)))].mean(1)
    n=len(cluster);wins=int((cluster<0).sum());sign=min(1.,2*sum(math.comb(n,j) for j in range(min(wins,n-wins)+1))/2**n)
    return {'control':control,'gamma':gamma,'kind':kind,'access':access,'pairs':len(keys),
       'mean_candidate_minus_control_mse':float(diff.mean()),
       'relative_mse_reduction':float(1-np.mean([a[k]['post_mse'] for k in keys])/max(np.mean([b[k]['post_mse'] for k in keys]),1e-12)),
       'mean_candidate_minus_control_accuracy':float(np.mean([a[k]['post_accuracy']-b[k]['post_accuracy'] for k in keys])),
       'seed_differences':dict(zip(map(str,seeds),map(float,cluster))),'seed_wins':wins,'sequence_wins':int((diff<0).sum()),
       'seed_cluster_bootstrap_95_interval':np.quantile(boot,[.025,.975]).tolist(),'two_sided_seed_sign_test_p':sign,
       'uncertainty_note':'Eight stream-resampling seeds on ONE fixed real-data split, not eight datasets, independent populations or EEG subjects; p unadjusted descriptive.'}

def summary(rows,complete=False):
    groups={}
    for access in ACCESS:
        rr=[r for r in rows if r['access']==access]
        if not rr:continue
        values={}
        for name,g in METHODS:
            picked=[r for r in rr if r['method']==name and r['gamma']==g]
            if not picked:continue
            values[f'{name}_{g}']={}
            for kind in [None,*KINDS]:
                r=[z for z in picked if kind is None or z['kind']==kind]
                values[f'{name}_{g}'][kind or 'all']={'mse':float(np.mean([z['post_mse'] for z in r])),
                    'accuracy':float(np.mean([z['post_accuracy'] for z in r])),
                    'macro_accuracy':float(np.mean([z['post_macro_accuracy'] for z in r])),
                    'prequential_mse':float(np.mean([z['post_prequential_mse'] for z in r])),
                    'mean_state_scalars':float(np.mean([z['state_scalars'] for z in r]))} if r else None
        oldcontrols=frozen.ref.METHODS
        bestpartial=min(oldcontrols,key=lambda ng:values[f'{ng[0]}_{ng[1]}']['partial']['mse']) if any(r['kind']=='partial' for r in rr) else None
        beststatic=min(oldcontrols,key=lambda ng:values[f'{ng[0]}_{ng[1]}']['static']['mse']) if any(r['kind']=='static' for r in rr) else None
        prereq=[pair_report(rows,n,g,'partial',access) for n,g in [('data_full',.95),('data_single',.95),*(oldcontrols if bestpartial else [])]]
        prereq=[c for c in prereq if c]
        # Comparing all 22 old fixed controls avoids selecting a weak one after inspection.
        robust=complete and len(prereq)==24 and all(c['relative_mse_reduction']>=.05 and c['seed_wins']>=6 and c['seed_cluster_bootstrap_95_interval'][1]<0 for c in prereq)
        static_ok=complete and beststatic is not None and values['bilateral_0.95']['static']['mse']<=1.05*values[f'{beststatic[0]}_{beststatic[1]}']['static']['mse']+1e-10
        groups[access]={'methods':values,'best_old_fixed_partial_control_descriptive':f'{bestpartial[0]}_{bestpartial[1]}' if bestpartial else None,
           'best_old_fixed_static_control_descriptive':f'{beststatic[0]}_{beststatic[1]}' if beststatic else None,
           'partial_prerequisites':prereq,'partial_transfer_gate_met':bool(robust),'static_safeguard_met':bool(static_ok),
           'all_contrasts':[pair_report(rows,n,g,k,access) for n,g in METHODS if n!='bilateral' for k in [None,*KINDS]]}
    return {'complete':complete,'method_runs':len(rows),'groups':groups,
       'advance_transfer_gate_met':complete and all(groups.get(a,{}).get('partial_transfer_gate_met',False) and groups.get(a,{}).get('static_safeguard_met',False) for a in ACCESS),
       'scope':'Controlled semantic label changes on real public digits features; ONE validation split; no natural drift, test-set result, biological mechanism, EEG or firstness claim.',
       'original_synthetic_gate':'Not evaluated or reclassified here. Prior failure remains unchanged.',
       'primary_metric':'Mean validation onehot MSE at t=132..240 in 12-step increments; accuracy and prequential metrics secondary.'}

def validate_input_and_causality(package):
    data=[generate(package,k,a,399) for a in ACCESS for k in KINDS]
    assert all(np.array_equal(d['K'][:120],data[0]['K'][:120]) and np.array_equal(d['V'][:120],data[0]['V'][:120]) for d in data)
    assert all(np.array_equal(data[0]['K'],d['K']) for d in data[1:3])
    assert all(np.array_equal(data[3]['K'],d['K']) for d in data[4:6])
    static,partial,whole=data[:3]
    assert np.array_equal(static['V'][120:],np.eye(4)[static['stream_original_labels'][120:]])
    assert np.array_equal(partial['V'][120:],np.eye(4)[np.array([1,0,2,3])[partial['stream_original_labels'][120:]]])
    assert np.array_equal(whole['V'][120:],np.eye(4)[(whole['stream_original_labels'][120:]+1)%4])
    maxpredict=0.
    for method,g in METHODS:
        a=new_memory(method,g);b=new_memory(method,g)
        for k,v in zip(partial['K'][:120],partial['V'][:120]):
            a.step(k,v);b.step(k,v)
        before=pickle.dumps(a,protocol=5)
        a.predict(partial['queries']);a.predict(partial['queries'][::-1]*3)
        assert pickle.dumps(a,protocol=5)==before,'Query modified state'
        assert pickle.dumps(a,protocol=5)==pickle.dumps(b,protocol=5),'Query prefix changed state'
        maxpredict=max(maxpredict,float(np.max(np.abs(a.predict(partial['queries'])-b.predict(partial['queries'])))))
        saved=a.predict(partial['queries']).copy()
        # Only b receives a different future suffix; frozen earlier a must stay equal.
        b.step(partial['K'][120],np.roll(partial['V'][120],1))
        assert np.array_equal(saved,a.predict(partial['queries']))
    assert maxpredict==0.
    return {'first120_common_all_conditions':True,'kind_same_input_keys_within_access':True,
        'label_remaps_exact':True,'normalized_keys':True,'no_repeated_stream_ids':True,
        'train_val_disjoint':True,'all28_query_read_only_and_prefix_equal':True,
        'prefix_prediction_max_error':maxpredict,'heldout_query_labels_not_supplied_to_step':True,
        'test_never_transformed_or_scored':True,'smoke_validation_seed':399}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--job',choices=['digits_stream','digits_stream_smoke'],required=True)
    ap.add_argument('--workers',type=int,default=4);ap.add_argument('--out-root',type=Path,default=ROOT/'results');a=ap.parse_args()
    out=a.out_root/a.job;out.mkdir(parents=True,exist_ok=True)
    if (out/'status.json').exists():raise RuntimeError('Output exists; select new --out-root; never overwrite')
    rows=[];done=0;start=time.time();pool=None
    base=[(k,m,s) for k in KINDS for m in ACCESS for s in SEEDS]
    if a.job.endswith('smoke'):base=[(k,m,398) for k in KINDS for m in ACCESS]
    frozen.save(out/'status.json',{'state':'running','phase':'validation','progress':0,'total':len(base),'elapsed_seconds':0})
    try:
        package,data_checks=prepare(out)
        validation={'old':frozen.old.validate(),'bilateral':frozen.validate(),'data_checks':data_checks,
            'input_causality':validate_input_and_causality(package),
            'constants':{n:getattr(frozen.old,n) for n in ['LAM','BLOCK','COS','GAMMA']},
            'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'source_sha256':{str(Path(m.__file__)):hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for m in [frozen.old,frozen.ref,frozen]}}
        assert validation['constants']=={'LAM':.001,'BLOCK':32,'COS':.5,'GAMMA':.95}
        frozen.save(out/'validation.json',validation)
        configs=[(i,*c,str(package),str(out)) for i,c in enumerate(base)]
        pool=ProcessPoolExecutor(max_workers=a.workers) if a.workers>1 else None
        completed=(future.result() for future in as_completed([pool.submit(worker,c) for c in configs])) if pool else (worker(c) for c in configs)
        for batch in completed:
            rows.extend(batch);done+=1;rows.sort(key=lambda r:(r['sequence'],METHODS.index((r['method'],r['gamma']))));elapsed=time.time()-start
            if done%8==0 or done==len(configs):frozen.save(out/'raw.json',rows);frozen.save(out/'summary.json',summary(rows,False))
            frozen.save(out/'status.json',{'state':'running','phase':'streams','progress':done,'total':len(configs),'method_runs':len(rows),
                'elapsed_seconds':elapsed,'estimated_remaining_seconds':(len(configs)-done)*elapsed/done})
            print(f'DONE {done}/{len(configs)} elapsed={elapsed:.1f}',flush=True)
        frozen.save(out/'summary.json',summary(rows,not a.job.endswith('smoke')))
        frozen.save(out/'status.json',{'state':'complete','progress':done,'total':len(configs),'method_runs':len(rows),'elapsed_seconds':time.time()-start,
            'test_scored':False,'teacher_trained':False})
    except BaseException:
        frozen.save(out/'status.json',{'state':'failed','progress':done,'total':len(base),'elapsed_seconds':time.time()-start,'error':traceback.format_exc()});raise
    finally:
        if pool:pool.shutdown(wait=True,cancel_futures=True)
if __name__=='__main__':main()
