import os
for _n in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[_n]='1'
import argparse,json,time,traceback,hashlib
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import run_memory as frozen
from version_memory import VersionMemory,validate_versions
ROOT=Path(__file__).resolve().parent
MODES=['local','global','scrambled','uniform','latest']
METHODS=[('versions_'+m,0) for m in MODES]+frozen.METHODS

def trial(data,mode):
    mem=VersionMemory(data['K'].shape[1],data['V'].shape[1],mode);curve=[];start=time.time()
    for t,(k,v) in enumerate(zip(data['K'],data['V']),1):
        mem.step(k,v)
        if t%12==0:
            pred=mem.predict(data['queries'])@data['rotation'].T;target=data['v0'] if t<=120 else data['v1']
            e=(pred-target)**2;mask=data['querymask']
            curve.append({'t':t,'mse':float(e.mean()),'changed_mse':float(e[mask].mean()) if mask.any() else None,
                'unchanged_mse':float(e[~mask].mean()) if (~mask).any() else None})
    return {'method':'versions_'+mode,'gamma':0,'post_mse':float(np.mean([r['mse'] for r in curve if r['t']>120])),
            'final_mse':curve[-1]['mse'],'trajectory':curve,'events':mem.events,'state_scalars':mem.capacity(),'seconds':time.time()-start}

def worker(config):
    i,f,r,k,n,s,out=config;data=frozen.generate(f,r,k,n,s,8);rows=[]
    np.savez_compressed(Path(out)/f'seq{i:04d}.npz',**data)
    for method,g in METHODS:
        row=trial(data,method.removeprefix('versions_')) if method.startswith('versions_') else frozen.trial(data,method,g)
        row.update({'sequence':i,'family':f,'rho':r,'kind':k,'noise':n,'seed':s,'dimension':8});rows.append(row)
    frozen.save(Path(out)/f'rows{i:04d}.json',rows);return rows

def summary(rows,complete):
    result={}
    for f in ['repeated','continuous']:
        group=[r for r in rows if r['family']==f]
        if not group:continue
        methods={}
        for name,g in METHODS:
            rr=[r for r in group if r['method']==name and r['gamma']==g]
            if not rr:continue
            methods[f'{name}_{g}']={k:float(np.mean([r['post_mse'] for r in rr if k=='all' or r['kind']==k])) if any(k=='all' or r['kind']==k for r in rr) else None for k in ['all','static','partial','whole']}
        result[f]={'methods':methods,'candidate':'versions_local_0','contrasts':[]}
        # Reuse paired analysis by relabeling only the candidate in a copy; all old rows preserved.
        rr=[dict(r,method='bilateral' if r['method']=='versions_local' else r['method'],gamma=.95 if r['method']=='versions_local' else r['gamma']) for r in group if r['method']!='bilateral']
        for name,g in METHODS:
            if name in ['versions_local','bilateral']:continue
            for kind in [None,'static','partial','whole']:
                contrast=frozen.paired_report(rr,name,g,kind)
                if contrast:contrast['candidate']='versions_local';result[f]['contrasts'].append(contrast)
    return {'complete':complete,'groups':result,'method_runs':len(rows),'novelty':'Known expert/version-memory family; concrete local-routing variant is exploratory, no firstness.',
            'decision_rule':'Human review: local route must improve mean partial MSE >=5% vs global, scrambled, sliding32, sliding64, Delta1 and dict.3 in BOTH families; static deterioration <=5% vs best fixed control. Whole failure must remain visible. This does not change the old failed gate.'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--job',choices=['memory_versions','memory_versions_smoke'],required=True);ap.add_argument('--workers',type=int,default=4)
    ap.add_argument('--out-root',type=Path,default=ROOT/'results');a=ap.parse_args();out=a.out_root/a.job;out.mkdir(parents=True,exist_ok=True)
    if (out/'status.json').exists():raise RuntimeError('Output exists; use a new --out-root')
    base=[(f,r,k,n,s) for f in ['repeated','continuous'] for r in [0.,.8] for k in ['static','partial','whole'] for n in [0.,.05,.15] for s in range(300,308)]
    if a.job.endswith('smoke'):base=[(f,.8,k,.15,998) for f in ['repeated','continuous'] for k in ['static','partial','whole']]
    cfg=[(i,*c,str(out)) for i,c in enumerate(base)];rows=[];done=0;start=time.time();pool=None
    frozen.save(out/'status.json',{'state':'running','progress':0,'total':len(cfg),'elapsed_seconds':0})
    try:
        frozen.save(out/'validation.json',{'versions':validate_versions(),'old':frozen.old.validate(),'bilateral':frozen.validate(),
            'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'version_memory.py',ROOT/'run_memory.py']}})
        pool=ProcessPoolExecutor(max_workers=a.workers) if a.workers>1 else None
        complete=(f.result() for f in as_completed([pool.submit(worker,c) for c in cfg])) if pool else (worker(c) for c in cfg)
        for batch in complete:
            rows.extend(batch);done+=1;elapsed=time.time()-start;rows.sort(key=lambda r:(r['sequence'],r['method'],r['gamma']))
            if done%32==0 or done==len(cfg):frozen.save(out/'raw.json',rows);frozen.save(out/'summary.json',summary(rows,False))
            frozen.save(out/'status.json',{'state':'running','progress':done,'total':len(cfg),'method_runs':len(rows),'elapsed_seconds':elapsed,'estimated_remaining_seconds':(len(cfg)-done)*elapsed/done})
            print(f'DONE {done}/{len(cfg)} elapsed={elapsed:.1f}',flush=True)
        frozen.save(out/'summary.json',summary(rows,not a.job.endswith('smoke')))
        frozen.save(out/'status.json',{'state':'complete','progress':done,'total':len(cfg),'method_runs':len(rows),'elapsed_seconds':time.time()-start})
    except BaseException:
        frozen.save(out/'status.json',{'state':'failed','progress':done,'total':len(cfg),'elapsed_seconds':time.time()-start,'error':traceback.format_exc()});raise
    finally:
        if pool:pool.shutdown(wait=True,cancel_futures=True)
if __name__=='__main__':main()
