"""Bounded frozen-version arbitration. Known expert-memory family, novelty unclaimed."""
import numpy as np
from run_memory import old

class VersionMemory:
    def __init__(self,d,m,mode='local'):
        self.d,self.m,self.mode=d,m,mode;self.t=0;self.buffer=[];self.versions=[]
        self.theta=np.zeros((m,d));self.events=[];self.generator=np.random.default_rng(46321)
    def step(self,k,v):
        self.t+=1
        # Each frozen version sees the observation only after its prediction.
        for version in self.versions:
            e=float(np.mean((version['W']@k-v)**2))
            version['scores'].append((k.copy(),e));version['scores']=version['scores'][-16:]
        self.buffer.append((k.copy(),v.copy()));self.buffer=self.buffer[-32:]
        K=np.stack([p[0] for p in self.buffer]);V=np.stack([p[1] for p in self.buffer])
        self.theta=np.linalg.solve(K.T@K+old.LAM*np.eye(self.d),K.T@V).T
        if self.t%32==0:
            self.versions.append({'W':self.theta.copy(),'scores':[],'birth':self.t})
            if len(self.versions)>8:self.versions.pop(1) # First version + newest seven.
            self.events.append({'t':self.t,'action':'append_frozen_snapshot','library_size':len(self.versions)})
    def predict(self,queries):
        eligible=[v for v in self.versions if len(v['scores'])==16]
        if not eligible:return queries@self.theta.T
        W=np.stack([v['W'] for v in eligible])
        if self.mode=='uniform':return np.einsum('qd,nmd->qm',queries,W)/len(eligible)
        if self.mode=='latest':return queries@W[-1].T
        E=np.array([[e for k,e in v['scores']] for v in eligible])
        # Equal last16 observed timestamps for all eligible frozen versions.
        K=np.stack([k for k,e in eligible[0]['scores']])
        assert all(np.array_equal(K,np.stack([k for k,e in v['scores']])) for v in eligible)
        if self.mode=='global':scores=np.broadcast_to(E.mean(1)[None,:],(len(queries),len(eligible)))
        else:
            if self.mode=='scrambled':K=K[np.random.default_rng(74129).permutation(16)]
            relevance=.001+(queries@K.T)**2
            scores=(relevance@E.T)/relevance.sum(1,keepdims=True)
        ids=np.argmin(scores,axis=1)
        return np.einsum('qd,qmd->qm',queries,W[ids])
    def capacity(self):
        return self.d*self.m+len(self.buffer)*(self.d+self.m)+sum(self.d*self.m+len(v['scores'])*(self.d+1) for v in self.versions)

def validate_versions():
    rng=np.random.default_rng(441);d=8;m=4
    K=rng.normal(size=(100,d));K/=np.linalg.norm(K,axis=1,keepdims=True);V=rng.normal(size=(100,m));Q=K[:9]
    Rk=np.linalg.qr(rng.normal(size=(d,d)))[0];Rv=np.linalg.qr(rng.normal(size=(m,m)))[0]
    maxerr=0.;a=VersionMemory(d,m);b=VersionMemory(d,m)
    for k,v in zip(K,V):
        a.step(k,v);b.step(k@Rk,v@Rv)
        maxerr=max(maxerr,float(np.max(np.abs(a.predict(Q)@Rv-b.predict(Q@Rk)))))
        assert np.isfinite(a.predict(Q)).all()
    assert maxerr<1e-7
    before=a.predict(Q).copy();state=[v['W'].copy() for v in a.versions]
    a.predict(Q[::-1]);assert np.array_equal(before,a.predict(Q))
    assert all(np.array_equal(w,v['W']) for w,v in zip(state,a.versions))
    assert all(len(v['scores'])==16 for v in a.versions if a.t-v['birth']>=16)
    # Scores are made only after birth, and snapshot W is never updated.
    c=VersionMemory(d,m)
    for k,v in zip(K[:32],V[:32]):c.step(k,v)
    w=c.versions[0]['W'].copy();assert c.versions[0]['scores']==[]
    c.step(K[32],V[32]);assert np.array_equal(w,c.versions[0]['W'])
    assert abs(c.versions[0]['scores'][0][1]-float(np.mean((w@K[32]-V[32])**2)))<1e-12
    return {'rotation_max_error':maxerr,'frozen_snapshots':True,'query_read_only':True,
            'prequential_loss_after_birth':True,'common_last16_scoring':True,'library_cap':8}
