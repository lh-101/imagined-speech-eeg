"""Exploratory implicit-computation variants, NOT claimed as new principles.

No remote connections or data downloads. Requires torch, numpy, scikit-learn.
Default is --plan, so invoking without arguments never starts training.
Exploration evaluates only validation data. Reservation requires a frozen file.
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import math
import random
import time
from pathlib import Path

import numpy as np
import torch
from sklearn.datasets import load_breast_cancer, load_digits
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch import nn
from torch.nn import functional as F

EXPLORE_SEEDS = [17, 29]
RESERVE_SEEDS = [101, 211, 307]
SPLIT_SEED = 20261007
LR_GRID = [0.001, 0.003]
HIDDEN, LATENT, RANK = 32, 8, 4
VARIANTS = ["solve", "diag", "multiply", "poly2", "mlp", "deep_mlp",
            "cubic", "cubic_diag", "cubic_linear", "cubic_explicit",
            "cubic_mlp", "cubic_deep_mlp"]


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


class Elimination(nn.Module):
    def __init__(self, d, classes, variant):
        super().__init__()
        self.variant = variant
        self.stem = nn.Linear(d, HIDDEN)
        self.u = nn.Linear(HIDDEN, LATENT)
        self.matrix = nn.Linear(HIDDEN, LATENT * RANK)
        self.back = nn.Linear(LATENT, HIDDEN)
        self.head = nn.Linear(HIDDEN, classes)

    def forward(self, x):
        h = F.gelu(self.stem(x))
        u = self.u(h).unsqueeze(-1)
        # B bounded to keep polynomial/explicit controls numerically reasonable.
        B = torch.tanh(self.matrix(h)).reshape(-1, LATENT, RANK) / math.sqrt(RANK)
        G = B @ B.transpose(-1, -2)
        I = torch.eye(LATENT, device=x.device, dtype=x.dtype)
        A = I + G
        if self.variant == "solve":
            z = torch.linalg.solve(A, u)
        elif self.variant == "diag":
            z = u / A.diagonal(dim1=-2, dim2=-1).unsqueeze(-1)
        elif self.variant == "multiply":
            z = u + G @ u
        elif self.variant == "poly2":
            # Two terms of A^-1=t sum_j (I-tA)^j; t bounds the spectral radius.
            t = 1.0 / (1.0 + G.diagonal(dim1=-2, dim2=-1).sum(-1))
            t = t[:, None, None]
            z0 = t * u
            z = z0 + (I - t * A) @ z0
        else:
            raise ValueError(self.variant)
        return self.head(F.gelu(h + self.back(z.squeeze(-1))))


class Cubic(nn.Module):
    def __init__(self, d, classes, variant):
        super().__init__()
        self.variant = variant
        self.stem = nn.Linear(d, HIDDEN)
        self.u = nn.Linear(HIDDEN, LATENT)
        self.coupling = nn.Parameter(torch.randn(LATENT, RANK) * 0.1)
        self.back = nn.Linear(LATENT, HIDDEN)
        self.head = nn.Linear(HIDDEN, classes)
        self.last_residual = 0.0

    def forward(self, x):
        h = F.gelu(self.stem(x))
        b = torch.tanh(self.u(h))
        I = torch.eye(LATENT, device=x.device, dtype=x.dtype)
        A = I + self.coupling @ self.coupling.T / RANK
        alpha = 0.25
        if self.variant == "cubic_linear":
            z = torch.linalg.solve(A, b.T).T
        elif self.variant == "cubic_diag":
            diag = A.diagonal()
            z = b / diag
            for _ in range(6):
                z = z - (z * diag + alpha * z.pow(3) - b) / (diag + 3 * alpha * z.pow(2))
        elif self.variant == "cubic_explicit":
            # Fixed six explicit steps, same A/b and parameterization. Not an exact solver.
            t = 1.0 / (A.trace() + 3 * alpha)
            z = torch.zeros_like(b)
            for _ in range(6):
                z = z - t * (z @ A.T + alpha * z.pow(3) - b)
        elif self.variant == "cubic":
            z = torch.linalg.solve(A, b.T).T
            for _ in range(6):
                residual = z @ A.T + alpha * z.pow(3) - b
                J = A + torch.diag_embed(3 * alpha * z.pow(2))
                z = z - torch.linalg.solve(J, residual.unsqueeze(-1)).squeeze(-1)
        else:
            raise ValueError(self.variant)
        with torch.no_grad():
            if self.variant == "cubic_diag":
                residual = z * A.diagonal() + alpha * z.pow(3) - b
            elif self.variant == "cubic_linear":
                residual = z @ A.T - b
            else:
                residual = z @ A.T + alpha * z.pow(3) - b
            self.last_residual = residual.abs().max().item()
        return self.head(F.gelu(h + self.back(z)))


class MLP(nn.Module):
    def __init__(self, d, classes, width, depth):
        super().__init__()
        layers = [nn.Linear(d, HIDDEN), nn.GELU()]
        old = HIDDEN
        for _ in range(depth):
            layers += [nn.Linear(old, width), nn.GELU()]
            old = width
        layers += [nn.Linear(old, classes)]
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


def nparams(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def make_model(d, classes, name):
    if "mlp" not in name:
        return Cubic(d, classes, name) if name.startswith("cubic") else Elimination(d, classes, name)
    reference = Cubic(d, classes, "cubic") if name.startswith("cubic") else Elimination(d, classes, "solve")
    target = nparams(reference)
    depth = 2 if "deep" in name else 1
    # Matching never adds unused parameters. Count analytically, avoiding random draws.
    def count(w):
        return d * HIDDEN + HIDDEN + HIDDEN * w + w + (depth - 1) * (w*w+w) + w*classes + classes
    width = min(range(2, 257), key=lambda w: abs(count(w)-target))
    return MLP(d, classes, width, depth)


def data_for(name, device):
    dataset = load_digits() if name == "digits" else load_breast_cancer()
    x = dataset.data.astype(np.float32)
    y = dataset.target.astype(np.int64)
    all_ids = np.arange(len(y))
    train, rest = train_test_split(all_ids, test_size=0.4, stratify=y, random_state=SPLIT_SEED)
    val, test = train_test_split(rest, test_size=0.5, stratify=y[rest], random_state=SPLIT_SEED + 1)
    scaler = StandardScaler().fit(x[train])
    x = scaler.transform(x).astype(np.float32)
    fingerprint = hashlib.sha256(np.concatenate([train, val, test]).tobytes()).hexdigest()
    return {"x": torch.tensor(x, device=device), "y": torch.tensor(y, device=device),
            "train": torch.tensor(train, device=device), "val": torch.tensor(val, device=device),
            "test": torch.tensor(test, device=device), "d": x.shape[1], "classes": len(np.unique(y)),
            "split_hash": fingerprint}


def sync(device):
    if device.type == "cuda":
        torch.cuda.synchronize(device)


@torch.no_grad()
def metrics(model, data, split):
    model.eval()
    ids = data[split]
    logits = model(data["x"][ids])
    target = data["y"][ids]
    return {"nll": F.cross_entropy(logits, target).item(),
            "accuracy": (logits.argmax(-1) == target).float().mean().item()}


def train_one(data, name, seed, lr, epochs, args, evaluate_test=False):
    seed_everything(seed)
    model = make_model(data["d"], data["classes"], name).to(args.device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    # CPU generator fixes order across architecture/device, independently of initialization.
    generator = torch.Generator().manual_seed(seed + 50000)
    best_nll, best_epoch, best_state = float("inf"), 0, None
    train_ids = data["train"]
    steps, max_residual = 0, 0.0
    sync(args.device)
    started = time.perf_counter()
    train_seconds = 0.0
    for epoch in range(1, epochs+1):
        model.train()
        epoch_started = time.perf_counter()
        order = torch.randperm(len(train_ids), generator=generator).to(args.device)
        for chunk in order.split(args.batch):
            ids = train_ids[chunk]
            opt.zero_grad(set_to_none=True)
            logits = model(data["x"][ids])
            loss = F.cross_entropy(logits, data["y"][ids])
            if not torch.isfinite(loss):
                raise RuntimeError(f"Nonfinite loss: {name}, seed={seed}, epoch={epoch}")
            loss.backward()
            opt.step()
            steps += 1
            max_residual = max(max_residual, getattr(model, "last_residual", 0.0))
        sync(args.device)
        train_seconds += time.perf_counter() - epoch_started
        val = metrics(model, data, "val")
        if val["nll"] < best_nll:
            best_nll, best_epoch = val["nll"], epoch
            best_state = copy.deepcopy(model.state_dict())
        # Time budgets count training, excluding validation/latency measurement.
        if args.seconds_per_run and train_seconds >= args.seconds_per_run:
            break
    sync(args.device)
    wall = time.perf_counter() - started
    # Exploration selects an epoch; reserve evaluates exactly the frozen epoch.
    if not evaluate_test:
        model.load_state_dict(best_state)
    final_val = metrics(model, data, "val")
    probe = data["x"][data["val"][:min(args.batch, len(data["val"]))]]
    model.eval()
    with torch.no_grad():
        for _ in range(3):
            model(probe)
        sync(args.device)
        lat_start = time.perf_counter()
        for _ in range(20):
            model(probe)
        sync(args.device)
        latency = (time.perf_counter()-lat_start)/20
    result = {"variant": name, "seed": seed, "lr": lr, "parameters": nparams(model),
              "epochs_done": epoch, "best_epoch": best_epoch, "steps": steps,
              "train_seconds": train_seconds, "wall_seconds": wall, "batch_forward_ms": latency*1000,
              "val_nll": final_val["nll"], "val_accuracy": final_val["accuracy"],
              "max_solver_residual": max_residual, "split_hash": data["split_hash"]}
    if evaluate_test:
        result.update({f"test_{key}": value for key, value in metrics(model, data, "test").items()})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=["plan", "benchmark", "explore", "reserve"], default="plan")
    parser.add_argument("--datasets", nargs="+", choices=["digits", "breast_cancer"], default=["digits", "breast_cancer"])
    parser.add_argument("--variants", nargs="+", choices=VARIANTS, default=VARIANTS)
    parser.add_argument("--epochs", type=int, default=60)
    parser.add_argument("--batch", type=int, default=128)
    parser.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--seconds-per-run", type=float, default=0.0)
    parser.add_argument("--frozen", type=Path)
    parser.add_argument("--output", type=Path, default=Path(__file__).parent / "outputs")
    args = parser.parse_args()
    if args.epochs < 1 or args.batch < 1 or args.seconds_per_run < 0:
        parser.error("epochs/batch must be positive and time budget nonnegative")
    if args.mode == "reserve" and (args.frozen is None or args.seconds_per_run):
        parser.error("reserve requires --frozen and rejects exploratory time-budget stopping")
    torch.set_num_threads(args.threads)
    args.device = torch.device("cuda" if torch.cuda.is_available() else "cpu") if args.device == "auto" else torch.device(args.device)
    plan = {"mode": args.mode, "device": str(args.device), "explore_seeds": EXPLORE_SEEDS,
            "reserve_seeds": RESERVE_SEEDS, "split_seed": SPLIT_SEED, "lr_grid": LR_GRID,
            "datasets": args.datasets, "variants": args.variants, "epochs": args.epochs,
            "torch_version": torch.__version__, "seconds_per_run": args.seconds_per_run,
            "novelty_status": "Existing implicit/optimization principles; specific variants unvalidated"}
    print(json.dumps(plan, ensure_ascii=False, indent=2), flush=True)
    if args.mode == "plan":
        for dataset in args.datasets:
            data = data_for(dataset, args.device)
            for name in args.variants:
                model = make_model(data["d"], data["classes"], name)
                print(dataset, name, nparams(model))
        return
    args.output.mkdir(parents=True, exist_ok=True)
    prefix = args.output / f"{args.mode}_{time.strftime('%Y%m%d_%H%M%S')}"
    Path(str(prefix)+"_plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    frozen = json.loads(args.frozen.read_text(encoding="utf-8")) if args.mode == "reserve" else None
    rows = []
    for dataset in args.datasets:
        data = data_for(dataset, args.device)
        for name in args.variants:
            if args.mode == "reserve":
                selection = frozen[dataset][name]
                settings = [(seed, selection["lr"], selection["epochs"]) for seed in RESERVE_SEEDS]
            elif args.mode == "benchmark":
                settings = [(EXPLORE_SEEDS[0], LR_GRID[0], min(args.epochs, 3))]
            else:
                settings = [(seed, lr, args.epochs) for seed in EXPLORE_SEEDS for lr in LR_GRID]
            for seed, lr, epochs in settings:
                result = train_one(data, name, seed, lr, epochs, args, evaluate_test=args.mode == "reserve")
                result["dataset"] = dataset
                rows.append(result)
                with Path(str(prefix)+"_runs.jsonl").open("a", encoding="utf-8") as fp:
                    fp.write(json.dumps(result, ensure_ascii=False)+"\n")
                print(json.dumps(result, ensure_ascii=False), flush=True)
    if args.mode == "explore" and not args.seconds_per_run:
        # Freeze LR by mean validation NLL across BOTH exploration seeds, not best seed.
        selections = {}
        for dataset in args.datasets:
            selections[dataset] = {}
            for name in args.variants:
                relevant = [r for r in rows if r["dataset"] == dataset and r["variant"] == name]
                selected_lr = min(LR_GRID, key=lambda lr: np.mean([r["val_nll"] for r in relevant if r["lr"] == lr]))
                chosen = [r for r in relevant if r["lr"] == selected_lr]
                selected_epoch = int(round(float(np.mean([r["best_epoch"] for r in chosen]))))
                selections[dataset][name] = {"lr": selected_lr, "epochs": selected_epoch}
        Path(str(prefix)+"_frozen.json").write_text(json.dumps(selections, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
