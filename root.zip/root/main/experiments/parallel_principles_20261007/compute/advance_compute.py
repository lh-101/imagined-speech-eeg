"""Detached, bounded follow-up. No promotion based on best seed or test data."""
import json,time,subprocess,sys,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results'/'compute_followup'
OUT.mkdir(parents=True,exist_ok=True)
START=time.time()
def save(name,obj):
 p=OUT/name;q=p.with_suffix('.tmp');q.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf8');q.replace(p)
def status(stage,state='running',**kw):
 save('status.json',dict(state=state,stage=stage,elapsed_seconds=time.time()-START,**kw))
def qualify(folder):
 rows=json.loads((folder/'raw.json').read_text())
 results={}
 for candidate,controls in [('solve',['diag','multiply','poly2','mlp','deep_mlp']),('cubic',['cubic_diag','cubic_linear','cubic_explicit','cubic_mlp','cubic_deep_mlp'])]:
  result={}
  for data in ['digits','breast_cancer']:
   means={}
   for model in [candidate]+controls:
    subset=[r for r in rows if r['dataset']==data and r['variant']==model]
    settings=sorted({r['lr'] for r in subset})
    assert settings
    means[model]=min(sum(r['val_nll'] for r in subset if r['lr']==lr)/sum(r['lr']==lr for r in subset) for lr in settings)
   strongest=min(controls,key=lambda x:means[x]);result[data]=dict(candidate_nll=means[candidate],strongest_control=strongest,control_nll=means[strongest],relative_reduction=1-means[candidate]/means[strongest])
  results[candidate]=dict(datasets=result,advance=all(z['relative_reduction']>=.05 for z in result.values()))
 return results
def child(job,args):
 status(job)
 p=subprocess.run([sys.executable,'-u',str(ROOT/'run_compute_v1.py'),'--job',job,'--device','cuda']+args,check=True)
 folder=ROOT/'results'/job
 check=json.loads((folder/'validation.json').read_text());assert check['passed'],check
 return folder
try:
 status('await_equal_steps_screen')
 folder=ROOT/'results'/'compute_screen'
 while True:
  if time.time()-START>1800:raise RuntimeError('Bounded wait exceeded 30 minutes')
  if (folder/'status.json').exists():
   st=json.loads((folder/'status.json').read_text())
   if st['state']=='failed':raise RuntimeError(st)
   if st['state']=='complete':break
  time.sleep(5)
 assert json.loads((folder/'validation.json').read_text())['passed']
 step_gate=qualify(folder);save('summary.json',{'equal_step_gate':step_gate,'criterion':'candidate validation NLL >=5% below strongest five controls, mean over both seeds and best LR for EVERY model, on BOTH datasets. Exploration only.'})
 if any(z['advance'] for z in step_gate.values()):
  timed=child('compute_time',['--mode','explore','--epochs','1000','--seconds-per-run','3'])
  time_gate=qualify(timed)
  save('summary.json',{'equal_step_gate':step_gate,'equal_training_time_gate':time_gate,'time_budget_seconds_per_run':3,'time_excludes_validation':True})
  if any(step_gate[c]['advance'] and time_gate[c]['advance'] for c in step_gate):
   # Freeze LR/epoch before revealing reserve test. Keep every listed control.
   reserved=child('compute_reserve',['--mode','reserve','--frozen',str(folder/'frozen.json')])
   save('review.json',{'reserved_results':str(reserved/'summary.json'),'claim':'Independent initialization and reserved test split on same datasets, not cross-dataset transfer or new-principle proof.'})
   status('reserved_confirmation_complete','complete')
  else:status('no_candidate_passed_equal_time_gate','complete')
 else:status('no_candidate_passed_equal_steps_gate','complete')
 save('validation.json',{'passed':True,'no_test_based_promotion':True,'known_prior_family':True})
except BaseException:
 status('exception','failed',error=traceback.format_exc());raise
