import json,time,torch
from pathlib import Path
from run_compute_v1 import Elimination,Cubic
ROOT=Path(__file__).resolve().parent/'results'/'compute_numeric'
ROOT.mkdir(parents=True,exist_ok=True)
torch.set_num_threads(1);torch.manual_seed(9921);dtype=torch.float64
checks={}
for name in ['solve','cubic']:
 model=(Elimination(5,3,name) if name=='solve' else Cubic(5,3,name)).double()
 x=torch.randn(2,5,dtype=dtype,requires_grad=True)
 checks[name+'_input_gradient']=torch.autograd.gradcheck(model,(x,),eps=1e-6,atol=1e-5,rtol=1e-3)
 if name=='cubic':checks['cubic_stationarity']=model.last_residual;assert model.last_residual<1e-9
B=torch.randn(2,8,4,dtype=dtype)*.5;u=torch.randn(2,8,1,dtype=dtype)
A=torch.eye(8,dtype=dtype)+B@B.transpose(-1,-2)
exact=torch.linalg.solve(A,u)
woodbury=u-B@torch.linalg.solve(torch.eye(4,dtype=dtype)+B.transpose(-1,-2)@B,B.transpose(-1,-2)@u)
checks['woodbury_max_error']=(exact-woodbury).abs().max().item();assert checks['woodbury_max_error']<1e-10
checks['min_eigenvalue']=torch.linalg.eigvalsh(A).min().item();assert checks['min_eigenvalue']>=1-1e-10
checks['passed']=True
(ROOT/'validation.json').write_text(json.dumps(checks,indent=2))
(ROOT/'status.json').write_text(json.dumps({'state':'complete','progress':1,'total':1}))
print(json.dumps(checks))
