# 检索后处置与可证伪协议

记录时间：2026-10-07；以下均为检索定位或决策，不是实验发现。

## 检索边界

采用公开网络索引；仅把原始论文、作者代码与正式会议页面作为论断依据。检索主题为 implicit layers、linear system、cubic energy、signature/Lévy area 与 rational networks。未系统检索全部期刊/专利；未证明所有最近邻均已穷尽，也不能由未找到同公式推出新颖性。

已核验原始来源：

- Amos & Kolter, OptNet, ICML 2017： https://proceedings.mlr.press/v70/amos17a.html 。把优化问题作为可训练层，直接覆盖“前向求解”的一般构想。
- Gould, Hartley & Campbell, Deep Declarative Networks, 2019 preprint / TPAMI： https://arxiv.org/abs/1909.04866 ， https://doi.org/10.1109/TPAMI.2021.3059462 。把节点定义为优化解；C1/C3 都属此框架。
- Bai, Kolter & Koltun, Deep Equilibrium Models, NeurIPS 2019： https://arxiv.org/abs/1909.01377 。平衡求解替代显式深度，C3 不能以“求平衡”宣称新原理。
- Bonnier, Kidger, Perez Arribas, Salvi & Lyons, Deep Signature Transforms, NeurIPS 2019： https://papers.neurips.cc/paper/8574-deep-signature-transforms.pdf 。学习变换后再做路径签名；C2 的面积交互有直接代数近邻。
- Boullé, Nakatsukasa & Townsend, Rational Neural Networks, NeurIPS 2020： https://arxiv.org/abs/2004.01902 。有理激活先例；C1 的求逆得到有理映射，不能说“有理计算”首次。
- Tsuchida et al., Declarative Nets that are Equilibrium Models, ICLR 2022： https://openreview.net/pdf?id=q4HaTeMO--y 。进一步连接优化节点与平衡模型，增加 C3 原理重叠风险。

## 处置

C2：拒绝进入本轮代码。现阶段没有超越路径签名和普通双线性交互的明确独立机制。用相邻面积替换全路径面积不构成新计算原理。

C1：仅保留为“输入依赖正定消元的具体变体”，原理新颖性未成立。最直接可证伪对照为共享完全相同矩阵生成器的对角消元、同矩阵显式乘法与二阶 Richardson 多项式。强 MLP 同参数及同训练时间版本必须同时报告。

C3：仅保留为“强凸四次能量隐式单元的具体变体”，原理新颖性未成立。共享低秩耦合和输入投影的线性消元、对角三次解、六步显式固定点版本，以及匹配容量 MLP 可以推翻耦合非线性解释。

结论边界：即便 C1/C3 小数据表现更好，也只支持其在这些测试上的预测性表现；没有推导支持新通用原理、EEG优势或发表级贡献。可以据此全部淘汰，不强迫选出胜者。

## 脚本冻结方案

`run_compute_pilots.py` 不联网下载，使用 sklearn 内置 digits/breast_cancer；支持 CPU/CUDA。固定分层 split_seed=20261007（60/20/20），仅训练集拟合 StandardScaler。探索初始化和批顺序种子为 17,29；确认性运行种子保留为 101,211,307。split 相同，因此保留种子只验证初始化稳定性，不能称独立数据复现。

所有模型默认 60 epochs、batch=128、AdamW，lr=0.001/0.003 两值均获得相同训练机会；用探索验证 NLL 选择学习率与 epoch，再冻结后进入 reserve 模式。测试集只在 reserve 阶段评估；探索没有读取测试标签进行指标计算。参数误差最接近匹配并报告实际误差，不能以空占位参数补齐。时间匹配基线通过训练候选校准的平均耗时显式指定 `--seconds-per-run`，由训练过程完成的步数决定；与等 epoch 的结果分开。

原理检验主要看候选与所有强对照的成对差值；两任务都需要方向一致且保留种子多数有益，同时 wall-time 不被同时间 MLP 支配。该门槛是淘汰规则，不是统计证明。小样本不进行虚假的显著性宣称。

运行规模：每任务 C1 与 C3 各有候选、三种等参数机制对照、两种匹配参数显式 MLP；默认探索合计 2任务×12模型×2种子×2lr=96 次。单个几千参数小模型 CPU 训练预计为秒至数十秒级，但尚未实测；全矩阵可能需十余分钟，必须先执行单模型 benchmark 实测后设总体预算。启动前不会自动跑全矩阵。

技能引用：使用 scientific-brainstorming 和 hypothesis-generation 记录提案、查新边界与反驳控制；对应技能位置 C:/Users/123/.codex/skills/scientific-brainstorming/SKILL.md 与 C:/Users/123/.codex/skills/hypothesis-generation/SKILL.md。技能要求的库论文尚未验证，故未伪造引文信息。
