"""Fixed multiscale rule on two already available additional cohorts."""
import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
import sys,json,time,hashlib,traceback,multiprocessing
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
sys.path[:0]=['/root/FAST/experiments/nature_stage_20261002','/root/FAST']
import numpy as np,torch,h5py
from torch import nn
from torch.nn import functional as F
from transformers import PretrainedConfig
import inner_models as im
import run_inner_study as original
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results'/'external_multiscale'
STAGE=Path('/root/FAST/experiments/nature_stage_20261002')
def save(p,z):
 p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix('.tmp');q.write_text(json.dumps(z,indent=2));q.replace(p)
def paths(kind,s,f):
 if kind=='pressel':
  parent=Path('/root/FAST/experiments/pressel_20261004');return parent/'prepared'/f'sub-{s:02d}.npz',parent/'results'/'loo'/f'sub{s:02d}_fold{f}.pt'
 return Path('/root/autodl-tmp/eeg_research/nature_stage_20261002/inner_prepared_action_corrected')/f'sub-{s:02d}.npz',STAGE/'validation_20261003'/'gpu'/'fast'/'loo'/f'seed42_sub{s:02d}_ses{f}_base.pt'
def indices(kind,ck):
 if kind=='pressel':return np.asarray(ck['train']),np.asarray(ck['test'])
 return np.asarray(ck['split']['source']),np.asarray(ck['split']['held'])
def build(kind):
 if kind=='inner':
  geometry=json.loads((paths(kind,1,1)[0].parent/'geometry.json').read_text());return im.build('fast',geometry)
 return im.FAST(PretrainedConfig(electrodes=['F3','F4','C3','C4','P3','P4'],zone_dict={'Frontal':['F3','F4'],'Central':['C3','C4'],'Parietal':['P3','P4']},dim_cnn=32,dim_token=32,seq_len=1024,window_len=256,slide_step=128,head='Conv4Layers',n_classes=6,num_layers=4,num_heads=8,dropout=.1))
def audit(kind):
 rows=[]
 for s in range(1,16 if kind=='pressel' else 11):
  p,_=paths(kind,s,0 if kind=='pressel' else 1)
  with np.load(p) as z:data={k:z[k] for k in z.files}
  x=data['X'];y=data['y'].astype(np.int64);assert np.isfinite(x).all()
  hashes=[hashlib.sha256(a.tobytes()).hexdigest() for a in x]
  checks=[]
  for f in (range(5) if kind=='pressel' else range(1,4)):
   _,cp=paths(kind,s,f);ck=torch.load(cp,map_location='cpu');tr,te=indices(kind,ck)
   assert not set(tr)&set(te)
   assert not set(hashes[i] for i in tr)&set(hashes[i] for i in te)
   norm=original.normalization(x[tr]);assert all(np.allclose(a,b,rtol=1e-5,atol=1e-6) for a,b in zip(norm,ck['normalization']))
   with np.load(cp.with_suffix('.npz')) as z:
    assert np.array_equal(z['y'],y[te]);assert np.array_equal(z['test' if kind=='pressel' else 'indices'],te)
   if kind=='inner':assert not set(data['session'][tr])&set(data['session'][te])
   checks.append({'fold_or_session':f,'checkpoint':str(cp),'disjoint':True,'normalization_train_only_verified':True,'labels_and_indices_match_saved_predictions':True})
  rows.append({'subject':s,'shape':list(x.shape),'class_counts':np.bincount(y).tolist(),'finite':True,'exact_duplicate_trials':len(hashes)-len(set(hashes)),'folds':checks})
 save(OUT/(kind+'_data_audit.json'),{'passed':True,'subjects':rows,'limits':'Finite,duplicate,label/index and normalization checks do not establish signal quality, exclude near-duplicate drift, or prove biological validity.'})
 return rows
class Adapter(nn.Module):
 def __init__(self,train):
  super().__init__();z=torch.asinh(train.float());d=train.shape[2]*train.shape[3]
  self.register_buffer('center',z.mean((0,1),keepdim=True));self.register_buffer('scale',z.std((0,1),unbiased=False,keepdim=True).clamp_min(.1))
  self.down=nn.Linear(d,32);self.out=nn.Linear(32,32);nn.init.zeros_(self.out.weight);nn.init.zeros_(self.out.bias)
 def norm(self,x):return ((torch.asinh(x.float())-self.center)/self.scale).clamp(-6,6).flatten(2)
 def forward(self,x):return .5*torch.tanh(self.out(F.gelu(self.down(self.norm(x))))/.5)
class Correction(nn.Module):
 def __init__(self,saved,arm):
  super().__init__();self.saved=saved;self.saved.requires_grad_(False);self.arm=arm;d=saved.down.in_features
  self.down=nn.Linear(3*d,8);self.out=nn.Linear(8,32);nn.init.zeros_(self.out.weight);nn.init.zeros_(self.out.bias)
 def forward(self,x):
  z=self.saved.norm(x)
  if self.arm=='multiscale':
   def smooth(k):return F.avg_pool1d(F.pad(z.transpose(1,2),(k//2,k//2),mode='replicate'),k,1).transpose(1,2)
   a=smooth(3);b=smooth(5);features=torch.cat([z-a,a-b,b],-1)
  else:features=torch.cat([z,z.square()/6,torch.tanh(z)],-1)
  return self.saved(x)+.5*torch.tanh(self.out(F.gelu(self.down(features)))/.5)
def rep(base,adapter,x):
 delta=adapter(x)
 with torch.autocast('cuda',dtype=torch.bfloat16):
  tokens=base.input_layer(x.flatten(2))+delta
  tokens=torch.cat([base.cls_token.expand(len(x),-1,-1),tokens],1)
  hidden=base.transformer(tokens+base.pos_embedding[:,:base.n_tokens+1])[:,0];logits=base.last_layer(hidden)
 q=torch.cat([F.normalize(torch.asinh(x.float()).flatten(1),dim=-1),F.normalize(hidden.float(),dim=-1)],-1)/2**.5
 return logits.float(),q,delta.float()
def loo(q,y):
 k=torch.exp(-2*(1-q.double()@q.double().T));a=k+.1*torch.eye(len(q),device=q.device);b=torch.cholesky_inverse(torch.linalg.cholesky(a));targets=F.one_hot(y,int(y.max())+1).double()
 return (targets-(b@targets)/b.diag()[:,None]).float()
def fit(base,adapter,x,y):
 parameters=[p for p in adapter.parameters() if p.requires_grad];opt=torch.optim.AdamW(parameters,lr=.001,weight_decay=.01)
 for step in range(200):
  for group in opt.param_groups:group['lr']=.001*(.1+.9*.5*(1+np.cos(np.pi*step/199)))
  opt.zero_grad(set_to_none=True);logits,q,delta=rep(base,adapter,x)
  if isinstance(adapter,Correction):
   with torch.no_grad():delta=delta-adapter.saved(x)
  loss=F.cross_entropy(logits,y)+.3*F.cross_entropy(4*loo(q,y),y)+.01*delta.square().mean();assert torch.isfinite(loss);loss.backward()
  assert all(p.grad is None or torch.isfinite(p.grad).all() for p in parameters);opt.step()
 return adapter
def worker(config):
 kind,s,f=config;torch.set_num_threads(2);seed=42+s*101+f*17;im.seed_all(seed);p,cp=paths(kind,s,f)
 with np.load(p) as z:x=z['X'];y=z['y'].astype(np.int64)
 ck=torch.load(cp,map_location='cpu');tr,te=indices(kind,ck);norm=ck['normalization'];xx=((x-norm[0])/norm[1]).astype(np.float32)
 base=build(kind).cuda();base.load_state_dict(ck['state_dict']);base.eval().requires_grad_(False)
 before=original.state_hash(base)
 with torch.no_grad():
  features=[]
  for i in range(0,len(xx),32):
   with torch.autocast('cuda',dtype=torch.bfloat16):features.append(base.forward_head(torch.from_numpy(xx[i:i+32]).cuda()))
  full=torch.cat(features);train,test=full[tr],full[te]
  # Check frozen backbone predictions via zero adapter, with same autocast.
  initial=Adapter(train).cuda();prob=rep(base,initial,test)[0].softmax(-1).cpu().numpy()
  with np.load(cp.with_suffix('.npz')) as z:assert np.array_equal(prob.argmax(-1),z['prob'].argmax(-1))
 target=torch.from_numpy(y[tr]).cuda();im.seed_all(seed);saved=fit(base,Adapter(train).cuda(),train,target);saved.eval().requires_grad_(False)
 rows=[]
 for arm in ['generic_adapter','multiscale','pointwise_control']:
  im.seed_all(seed);model=saved if arm=='generic_adapter' else fit(base,Correction(saved,arm).cuda(),train,target)
  with torch.no_grad():prob=rep(base,model,test)[0].softmax(-1).cpu().numpy()
  dest=OUT/kind/arm;dest.mkdir(parents=True,exist_ok=True);name=f'sub{s:02d}_fold{f}'
  np.savez_compressed(dest/(name+'.npz'),prob=prob,pred=prob.argmax(-1),y=y[te],train_idx=tr,test_idx=te)
  torch.save({'state_dict':model.cpu().state_dict(),'source':str(cp),'train_idx':tr,'test_idx':te},dest/(name+'.pt'))
  rows.append({'dataset':kind,'subject':s,'fold':f,'arm':arm,'accuracy':float((prob.argmax(-1)==y[te]).mean()),'new_parameters':sum(p.numel() for n,p in model.named_parameters() if not n.startswith('saved.'))})
  if arm=='generic_adapter':saved.cuda()
  elif arm!='generic_adapter':saved.cuda()
 assert original.state_hash(base)==before
 print('FOLD_DONE',kind,s,f,flush=True);return rows
def main():
 OUT.mkdir(parents=True,exist_ok=True)
 if (OUT/'status.json').exists():raise RuntimeError('Preserve run')
 save(OUT/'protocol.json',{'datasets':['Pressel-Coretto15subjects,5trialfolds','ThinkingOutLoud10subjects,3heldsessions'],'preserved':'BCI2020 original author dataset and all prior results unchanged','source':'Historical LOO backbones reused; original preprocessing,train/test labels,train-only normalization checked. TOL corrected preprocessing and corrected validation checkpoints. No old backbone retraining.','design':'Fresh genericadapter200steps then freeze, multiscale and pointwise each200steps; same family as original two cohorts. Feature dimension geometry-dependent:Pressel96,Inner256; correction2600/6440params respectively,matched within dataset. Fixed3/5windows, no dataset-specific score tuning.','limits':'Exploratory previously examined datasets. Different tasks/channel montages and splittypes; raw scores not comparable across datasets. Testing additional cohorts does not establish prior cohort poor-quality, new computational principle, or SOTA. Preserve all outcomes.'})
 start=time.time();rows=[];failures={}
 try:
  save(OUT/'status.json',{'state':'running','stage':'data_audit'})
  # Preserve BCI data and report finite/label shape checks only.
  with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5') as h:
   bci=[]
   for key in sorted(h):
    x=h[key+'/X'][:];y=h[key+'/Y'][:];bci.append({'subject':key,'shape':list(x.shape),'class_counts':np.bincount(y.astype(int)).tolist(),'finite':bool(np.isfinite(x).all())})
  save(OUT/'bci_readonly_audit.json',{'subjects':bci,'unchanged':True,'boundary':'Same processed source; official preprocessor equivalence not established by these checks.'})
  valid=[]
  for kind in ['pressel','inner']:
   try:audit(kind);valid.append(kind)
   except BaseException:failures[kind]=traceback.format_exc();save(OUT/(kind+'_audit_failure.json'),{'error':failures[kind]})
  configs=[(k,s,f) for k in valid for s in range(1,16 if k=='pressel' else 11) for f in (range(5) if k=='pressel' else range(1,4))]
  save(OUT/'status.json',{'state':'running','stage':'training','progress':0,'total':len(configs),'audit_failures':failures})
  with ProcessPoolExecutor(2,mp_context=multiprocessing.get_context('spawn')) as pool:
   for future in as_completed([pool.submit(worker,z) for z in configs]):
    rows.extend(future.result());save(OUT/'rows.json',rows);done=len(rows)//3;elapsed=time.time()-start
    save(OUT/'status.json',{'state':'running','stage':'training','progress':done,'total':len(configs),'elapsed_seconds':elapsed,'estimated_remaining_seconds':elapsed*(len(configs)-done)/done,'audit_failures':failures})
  summary={}
  for k in valid:
   subjects=sorted({r['subject'] for r in rows if r['dataset']==k});summary[k]={}
   for arm in ['generic_adapter','multiscale','pointwise_control']:
    acc=[]
    for s in subjects:
     yy=[];pp=[]
     for f in (range(5) if k=='pressel' else range(1,4)):
      with np.load(OUT/k/arm/f'sub{s:02d}_fold{f}.npz') as z:yy.extend(z['y']);pp.extend(z['pred'])
     acc.append(float((np.asarray(yy)==np.asarray(pp)).mean()))
    summary[k][arm]=float(np.mean(acc))
  save(OUT/'summary.json',{'datasets':summary,'audit_failures':failures});save(OUT/'status.json',{'state':'complete','datasets':valid,'folds':len(configs),'fits':len(rows),'audit_failures':failures})
 except BaseException:save(OUT/'status.json',{'state':'failed','error':traceback.format_exc()});raise
if __name__=='__main__':main()
