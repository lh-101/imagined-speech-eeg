"""Parameter/budget-controlled real-data secant-feature screen.

Known family: bivariate activations. Specific secant rule's novelty is unproven.
No data download, server access, implicit solve, attention, gates or auxiliary loss.
Requires numpy, torch, scikit-learn; no arguments -> plan only.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import random
import time
from pathlib import Path

import numpy as np
import torch
from sklearn.datasets import load_digits, load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch import nn
from torch.nn import functional as F

SEEDS = [17, 29]
RESERVE = [101, 211, 307]
LRS = [0.001, 0.003]
SPLIT_SEED = 20261007
K, READOUT = 12, 32
VARIANTS = ["secant", "product", "square_diff", "tanh_sum", "learned_pair",
            "mlp_gelu", "deep_mlp_gelu", "mlp_tanh"]


def secant(a, b):
    d = a-b
    near = d.abs() < 1e-3
    safe_d = torch.where(near, torch.ones_like(d), d)
    ordinary = torch.tanh(d) / safe_d
    taylor = 1-d.square()/3+2*d.pow(4)/15
    return torch.where(near, taylor, ordinary) * (1-torch.tanh(a)*torch.tanh(b))


class PairModel(nn.Module):
    def __init__(self, d, c, kind):
        super().__init__()
        self.kind = kind
        self.stem = nn.Linear(d, K)
        self.readout = nn.Linear(K+K*(K-1)//2, READOUT)
        self.head = nn.Linear(READOUT, c)
        pairs = torch.triu_indices(K, K, offset=1)
        self.register_buffer("left", pairs[0])
        self.register_buffer("right", pairs[1])
        if kind == "learned_pair":
            self.inner = nn.Sequential(nn.Linear(2, 8), nn.GELU(), nn.Linear(8, 1))

    def forward(self, x):
        h = self.stem(x)
        a, b = h[:, self.left], h[:, self.right]
        unary = torch.tanh(h)
        if self.kind == "secant":
            q = secant(a, b)
        elif self.kind == "product":
            q = torch.tanh(a)*torch.tanh(b)
        elif self.kind == "square_diff":
            q = (torch.tanh(a)-torch.tanh(b)).square()/4
        elif self.kind == "tanh_sum":
            q = torch.tanh(a+b)
        elif self.kind == "learned_pair":
            q = self.inner(torch.stack([a, b], dim=-1)).squeeze(-1)
        else:
            raise ValueError(self.kind)
        return self.head(F.gelu(self.readout(torch.cat([unary, q], dim=-1))))


class MLP(nn.Module):
    def __init__(self, d, c, w, depth, activation):
        super().__init__()
        layers = []
        old = d
        for _ in range(depth):
            layers += [nn.Linear(old, w), nn.Tanh() if activation == "tanh" else nn.GELU()]
            old = w
        layers += [nn.Linear(old, c)]
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


def count(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def build(d, c, name):
    if "mlp" not in name:
        return PairModel(d, c, name)
    target = (d+1)*K+(K+K*(K-1)//2+1)*READOUT+(READOUT+1)*c
    depth = 2 if name.startswith("deep") else 1
    def number(w):
        return (d+1)*w+(depth-1)*(w+1)*w+(w+1)*c
    w = min(range(2, 257), key=lambda x: abs(number(x)-target))
    return MLP(d, c, w, depth, "tanh" if name.endswith("tanh") else "gelu")


def data(name, device):
    ds = load_digits() if name == "digits" else load_breast_cancer()
    x, y = ds.data.astype(np.float32), ds.target.astype(np.int64)
    ids = np.arange(len(y))
    train, hold = train_test_split(ids, test_size=.4, stratify=y, random_state=SPLIT_SEED)
    val, test = train_test_split(hold, test_size=.5, stratify=y[hold], random_state=SPLIT_SEED+1)
    x = StandardScaler().fit(x[train]).transform(x).astype(np.float32)
    return dict(x=torch.tensor(x, device=device), y=torch.tensor(y, device=device),
                train=torch.tensor(train, device=device), val=torch.tensor(val, device=device),
                test=torch.tensor(test, device=device), d=x.shape[1], c=len(np.unique(y)),
                split_hash=hashlib.sha256(np.concatenate([train, val, test]).tobytes()).hexdigest())


def sync(device):
    if device.type == "cuda":
        torch.cuda.synchronize(device)


@torch.no_grad()
def evaluate(model, ds, split):
    model.eval()
    ids = ds[split]
    z = model(ds["x"][ids])
    y = ds["y"][ids]
    return dict(nll=F.cross_entropy(z, y).item(), accuracy=(z.argmax(-1)==y).float().mean().item())


def run(ds, name, seed, lr, epochs, args):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    model = build(ds["d"], ds["c"], name).to(args.device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    g = torch.Generator().manual_seed(seed+50000)
    best, best_epoch, checkpoint = float("inf"), 0, None
    steps = 0
    sync(args.device)
    began = time.perf_counter()
    training_seconds = 0.
    for epoch in range(1, epochs+1):
        model.train()
        start = time.perf_counter()
        shuffled = torch.randperm(len(ds["train"]), generator=g).to(args.device)
        for part in shuffled.split(args.batch):
            ids = ds["train"][part]
            optimizer.zero_grad(set_to_none=True)
            loss = F.cross_entropy(model(ds["x"][ids]), ds["y"][ids])
            if not torch.isfinite(loss):
                raise RuntimeError(f"Nonfinite {name} seed {seed} epoch {epoch}")
            loss.backward()
            optimizer.step()
            steps += 1
        sync(args.device)
        training_seconds += time.perf_counter()-start
        val = evaluate(model, ds, "val")
        if val["nll"] < best:
            best, best_epoch, checkpoint = val["nll"], epoch, copy.deepcopy(model.state_dict())
    # Reserve uses the frozen endpoint, not a new validation-selected checkpoint.
    if args.mode != "reserve":
        model.load_state_dict(checkpoint)
    val = evaluate(model, ds, "val")
    sync(args.device)
    total_seconds = time.perf_counter()-began
    probe = ds["x"][ds["val"][:args.batch]]
    with torch.no_grad():
        for _ in range(3): model(probe)
        sync(args.device)
        start = time.perf_counter()
        for _ in range(20): model(probe)
        sync(args.device)
        latency = (time.perf_counter()-start)*1000/20
    result = dict(variant=name, seed=seed, lr=lr, parameters=count(model), epochs=epochs,
                  steps=steps, best_epoch=best_epoch, train_seconds=training_seconds,
                  wall_seconds=total_seconds, forward_batch_ms=latency, val_nll=val["nll"],
                  val_accuracy=val["accuracy"], split_hash=ds["split_hash"])
    if args.mode == "reserve":
        result.update({"test_"+k:v for k,v in evaluate(model, ds, "test").items()})
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--job")
    p.add_argument("--mode", choices=["plan", "explore", "reserve"], default="plan")
    p.add_argument("--smoke", action="store_true")
    p.add_argument("--epochs", type=int, default=30)
    p.add_argument("--batch", type=int, default=128)
    p.add_argument("--threads", type=int, default=2)
    p.add_argument("--device", choices=["cpu", "cuda", "auto"], default="auto")
    p.add_argument("--datasets", nargs="+", default=["digits", "breast_cancer"], choices=["digits", "breast_cancer"])
    p.add_argument("--variants", nargs="+", default=VARIANTS, choices=VARIANTS)
    p.add_argument("--frozen", type=Path)
    p.add_argument("--output", type=Path)
    args = p.parse_args()
    if args.job and args.mode == "plan": args.mode = "explore"
    if args.mode == "reserve" and (args.frozen is None or args.smoke): p.error("reserve requires frozen and rejects smoke")
    if args.epochs < 1 or args.batch < 1: p.error("epochs and batch must be positive")
    args.device = torch.device("cuda" if torch.cuda.is_available() else "cpu") if args.device == "auto" else torch.device(args.device)
    torch.set_num_threads(args.threads)
    if args.smoke:
        args.datasets, args.variants, args.epochs = ["digits"], ["secant", "product", "learned_pair", "mlp_gelu"], 2
    args.output = args.output or Path(__file__).parent/"results"/(args.job or "secant_screen")
    plan = dict(mode=args.mode, datasets=args.datasets, variants=args.variants, epochs=args.epochs,
                seeds=SEEDS, reserved=RESERVE, lrs=LRS, split_seed=SPLIT_SEED, device=str(args.device),
                torch_version=torch.__version__, numpy_version=np.__version__,
                novelty="Specific bivariate secant rule only; general principle known, novelty unproven")
    print(json.dumps(plan, ensure_ascii=False), flush=True)
    if args.mode == "plan":
        for dataset in args.datasets:
            ds = data(dataset, args.device)
            print(dataset, {name:count(build(ds["d"], ds["c"], name)) for name in args.variants})
        return
    args.output.mkdir(parents=True, exist_ok=True)
    def save(name, obj):
        path = args.output/name
        temporary = path.with_suffix(".tmp")
        temporary.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(path)
    began = time.perf_counter()
    rows = []
    seeds = RESERVE if args.mode == "reserve" else SEEDS[:1] if args.smoke else SEEDS
    lrs = LRS[:1] if args.smoke else LRS
    repeats = len(seeds) * (1 if args.mode == "reserve" else len(lrs))
    total = len(args.datasets)*len(args.variants)*repeats
    def status(state, error=None):
        save("status.json", dict(state=state, progress=len(rows), total=total, elapsed=time.perf_counter()-began, error=error))
    status("running")
    save("plan.json", plan)
    try:
        a = torch.linspace(-3, 3, 101, device=args.device, requires_grad=True)
        b = a.detach().clone().requires_grad_(True)
        diag_error = (secant(a,b)-(1-torch.tanh(a).square())).abs().max().item()
        secant(a,b).sum().backward()
        finite_gradient = bool(torch.isfinite(a.grad).all() and torch.isfinite(b.grad).all())
        b2 = a.detach()+.25
        identity_error = (secant(a,b2)-(torch.tanh(a)-torch.tanh(b2))/(a-b2)).abs().max().item()
        # Smoke includes exact/near equality, saturation, symmetry and central FD gradients.
        points = torch.tensor([[0.,0.], [1e-8,-1e-8], [2.,2.0001], [20.,20.],
                               [-20.,-20.], [20.,-20.], [1.,-2.]], dtype=torch.float64, device=args.device, requires_grad=True)
        values = secant(points[:,0], points[:,1])
        analytic = torch.autograd.grad(values.sum(), points)[0]
        fd_columns = []
        with torch.no_grad():
            for column in range(2):
                plus, minus = points.detach().clone(), points.detach().clone()
                plus[:,column] += 1e-5
                minus[:,column] -= 1e-5
                fd_columns.append((secant(plus[:,0], plus[:,1])-secant(minus[:,0], minus[:,1]))/2e-5)
            finite_diff_error = (analytic-torch.stack(fd_columns,-1)).abs().max().item()
            symmetry_error = (values-secant(points[:,1],points[:,0])).abs().max().item()
            negation_error = (values-secant(-points[:,0],-points[:,1])).abs().max().item()
        finite_stress_gradient = bool(torch.isfinite(analytic).all())
        if (diag_error > 1e-5 or identity_error > 1e-5 or not finite_gradient or not finite_stress_gradient
                or finite_diff_error > 1e-6 or symmetry_error > 1e-12 or negation_error > 1e-12):
            raise RuntimeError("Secant numerical identity/gradient check failed")
        frozen = json.loads(args.frozen.read_text(encoding="utf-8")) if args.mode == "reserve" else None
        for dataset in args.datasets:
            ds = data(dataset, args.device)
            for name in args.variants:
                setting = frozen[dataset][name] if frozen else None
                schedule = [(s, setting["lr"], setting["epochs"]) for s in seeds] if setting else [(s, lr, args.epochs) for s in seeds for lr in lrs]
                for seed, lr, epochs in schedule:
                    row = run(ds, name, seed, lr, epochs, args)
                    row["dataset"] = dataset
                    rows.append(row)
                    save("raw.json", rows)
                    status("running")
                    print(json.dumps(row), flush=True)
        selections, summary, gates = {}, [], {}
        gate_metric = "test_nll" if args.mode == "reserve" else "val_nll"
        for dataset in args.datasets:
            selections[dataset] = {}
            means = {}
            for name in args.variants:
                group = [r for r in rows if r["dataset"]==dataset and r["variant"]==name]
                best_lr = min(set(r["lr"] for r in group), key=lambda lr: np.mean([r["val_nll"] for r in group if r["lr"]==lr]))
                selected = [r for r in group if r["lr"]==best_lr]
                selections[dataset][name] = dict(lr=best_lr, epochs=int(round(np.mean([r["best_epoch"] for r in selected]))))
                means[name] = float(np.mean([r[gate_metric] for r in selected]))
                item = dict(dataset=dataset, variant=name, selected_lr=best_lr, parameters=selected[0]["parameters"], n_runs=len(selected))
                for key in ["val_nll", "val_accuracy", "train_seconds", "forward_batch_ms"]:
                    values = [r[key] for r in selected]
                    item[key+"_mean"] = float(np.mean(values))
                    item[key+"_sd"] = float(np.std(values, ddof=1)) if len(values)>1 else None
                if args.mode == "reserve":
                    item.update({key+"_mean":float(np.mean([r[key] for r in selected])) for key in ["test_nll", "test_accuracy"]})
                summary.append(item)
            if "secant" in means and len(means)>1:
                strongest = min((n for n in means if n!="secant"), key=lambda n:means[n])
                improvement = (means[strongest]-means["secant"])/means[strongest]
                paired = []
                for seed in seeds:
                    s = next(r for r in rows if r["dataset"]==dataset and r["variant"]=="secant" and r["lr"]==selections[dataset]["secant"]["lr"] and r["seed"]==seed)
                    control = next(r for r in rows if r["dataset"]==dataset and r["variant"]==strongest and r["lr"]==selections[dataset][strongest]["lr"] and r["seed"]==seed)
                    paired.append(s[gate_metric]-control[gate_metric])
                gates[dataset] = dict(strongest_control=strongest, relative_nll_improvement=improvement,
                    paired_nll_difference=paired, passes=improvement>=.01 and all(d<=0 for d in paired))
        if args.mode != "reserve" and not args.smoke: save("frozen.json", selections)
        save("summary.json", dict(results=summary, screening_gates=gates,
                both_dataset_gate_passes=not args.smoke and len(gates)==2 and all(g["passes"] for g in gates.values()),
                gate_metric=gate_metric, novelty=plan["novelty"], test_evaluated=args.mode=="reserve"))
        save("validation.json", dict(passed=len(rows)==total, diag_identity_error=diag_error,
                nondegenerate_identity_error=identity_error, finite_gradient=finite_gradient,
                finite_stress_gradient=finite_stress_gradient, finite_difference_gradient_max_error=finite_diff_error,
                symmetry_max_error=symmetry_error, global_negation_max_error=negation_error,
                parameter_counts={ds:{r["variant"]:r["parameters"] for r in rows if r["dataset"]==ds} for ds in args.datasets},
                exact_parameter_match=False, budget="same epochs/batch/lr-grid in explore; frozen epochs in reserve",
                time_match_performed=False, reserve_seed_independence="initialization only, same held-out data"))
        status("complete")
    except Exception as exc:
        save("validation.json", dict(passed=False, error=repr(exc)))
        status("failed", repr(exc))
        raise


if __name__ == "__main__": main()
