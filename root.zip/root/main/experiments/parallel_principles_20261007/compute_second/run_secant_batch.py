"""Bounded smoke->exploratory screen->optional sealed confirmation."""
import subprocess,sys,json,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results'/'secant_batch';OUT.mkdir(parents=True,exist_ok=True)
T=time.time()
def save(name,z):
 p=OUT/name;q=p.with_suffix('.tmp');q.write_text(json.dumps(z,ensure_ascii=False,indent=2));q.replace(p)
def status(stage,state='running',**z):save('status.json',dict(state=state,stage=stage,elapsed_seconds=time.time()-T,**z))
def run(job,args):
 status(job)
 subprocess.run([sys.executable,'-u',str(ROOT/'run_secant_v1.py'),'--job',job,'--device','cuda']+args,check=True)
 p=ROOT/'results'/job;assert json.loads((p/'validation.json').read_text())['passed'];return p
try:
 smoke=run('secant_smoke',['--smoke'])
 screen=run('secant_screen',[])
 summary=json.loads((screen/'summary.json').read_text());save('summary.json',summary)
 if summary['both_dataset_gate_passes']:
  reserve=run('secant_reserve',['--mode','reserve','--frozen',str(screen/'frozen.json')])
  save('review.json',{'reserve_summary':str(reserve/'summary.json'),'limits':'Same held-out data; new initialization. No exact time matching, independent dataset confirmation, novel algebra or new neural principle proof.'})
  status('reserved_confirmation_complete','complete')
 else:status('no_candidate_passed_validation_screen','complete')
 save('validation.json',{'passed':True,'promotion_without_test_selection':True,'no_firstness_claim':True})
except BaseException:
 status('exception','failed',error=traceback.format_exc());raise
