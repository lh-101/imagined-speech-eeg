"""SSH orchestration: credentials via stdin, never serialized."""
import argparse,json,shlex,sys
from pathlib import Path
import paramiko

ap=argparse.ArgumentParser();ap.add_argument('action',choices=['inspect','upload','run','status','fetch'])
ap.add_argument('--port',type=int,default=50840);ap.add_argument('--job');ap.add_argument('--source');ap.add_argument('--args',nargs='*',default=[]);ap.add_argument('--args-json')
a=ap.parse_args();ROOT=Path(__file__).resolve().parent
if a.args_json is not None:
 a.args=json.loads(a.args_json)
 assert isinstance(a.args,list) and all(isinstance(x,str) for x in a.args)
REMOTE='/root/FAST/experiments/parallel_principles_20261007'
c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('connect.westb.seetacloud.com',port=a.port,username='root',password=sys.stdin.readline().strip(),timeout=20)
s=c.open_sftp()
def execute(code):
 _,o,e=c.exec_command('/root/venv_fast/bin/python -c '+shlex.quote(code),timeout=60)
 text=o.read().decode();err=e.read().decode();rc=o.channel.recv_exit_status();print(text)
 if err:print(err)
 if rc:raise RuntimeError('Remote exit '+str(rc))
 return text
def mkdir(path):
 try:s.mkdir(path)
 except OSError:s.stat(path)
if a.action=='inspect':
 execute("""
import subprocess,pathlib,hashlib,json,os
print(subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.total,memory.used,utilization.gpu','--format=csv,noheader']).decode())
print(subprocess.check_output(['pgrep','-af','python']).decode()[-5000:])
print(subprocess.check_output(['df','-h','/root/autodl-tmp','/root']).decode())
print('cpu',os.cpu_count())
for rel in ['experiments/paired_evidence_replay_20261007/paired_replay.py','experiments/paired_evidence_replay_20261007/run_experiment.py','experiments/bilateral_revision_20261007/bilateral_memory.py','experiments/bilateral_revision_20261007/pilot/status.json']:
 p=pathlib.Path('/root/FAST')/rel
 print(rel,'exists',p.exists(),'sha256',hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None)
 if p.exists() and p.suffix=='.json':print(p.read_text())
""")
else:
 mkdir(REMOTE)
 if a.action=='upload':
  uploaded=[]
  for path in ROOT.rglob('*'):
   if not path.is_file() or path.suffix not in ['.py','.md','.json'] or '__pycache__' in path.parts:continue
   rel=path.relative_to(ROOT)
   if any(p in ['results','smoke','pilot','confirm','local_serial_checks'] for p in rel.parts):continue
   dest=REMOTE+'/'+rel.as_posix();parent=REMOTE
   for part in rel.parts[:-1]:parent+='/'+part;mkdir(parent)
   try:
    with s.open(dest,'rb') as f:assert f.read()==path.read_bytes(),'Refuse overwrite: '+str(rel)
   except FileNotFoundError:s.put(str(path),dest);uploaded.append(str(rel))
  print(json.dumps({'uploaded':uploaded},ensure_ascii=False))
 elif a.action=='run':
  assert a.job and a.source
  code="""
import pathlib,subprocess,json,os,hashlib
p=pathlib.Path(REMOTE);job=JOB;source=p/SOURCE
assert source.is_file(),source
record=p/(job+'_launch.json')
if record.exists():print(record.read_text());raise SystemExit(0)
with (p/(job+'.log')).open('ab') as f:
 proc=subprocess.Popen(['/root/venv_fast/bin/python','-u',str(source)]+ARGS,cwd=source.parent,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True,env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'2','MKL_NUM_THREADS':'2'})
record.write_text(json.dumps({'pid':proc.pid,'job':job,'source':SOURCE,'arguments':ARGS,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}));print(record.read_text())
""".replace('REMOTE',repr(REMOTE)).replace('JOB',repr(a.job)).replace('SOURCE',repr(a.source)).replace('ARGS',repr(a.args))
  execute(code)
 elif a.action in ['status','fetch']:
  code="""
import pathlib,json
p=pathlib.Path(REMOTE)
for rec in sorted(p.glob('*_launch.json')):
 r=json.loads(rec.read_text());source=p/r['source'];job=r['job'];q=source.parent/'results'/job/'status.json'
 z=json.loads(q.read_text()) if q.exists() else {'state':'initializing','status_path':str(q)}
 z.update(r);z['process_present']=pathlib.Path('/proc',str(r['pid'])).exists()
 print(json.dumps(z));log=p/(job+'.log');print(log.read_text()[-1400:] if log.exists() else '')
""".replace('REMOTE',repr(REMOTE))
  execute(code)
  if a.action=='fetch':
   # Download compact status/summary files for every registered job.
   for name in s.listdir(REMOTE):
    if not name.endswith('_launch.json'):continue
    with s.open(REMOTE+'/'+name) as f:r=json.loads(f.read())
    parent=Path(r['source']).parent.as_posix();folder=REMOTE+'/'+parent+'/results/'+r['job']
    local=ROOT/parent/'results'/r['job'];local.mkdir(parents=True,exist_ok=True)
    for fn in ['status.json','summary.json','raw.json','validation.json','review.json']:
     try:s.stat(folder+'/'+fn);s.get(folder+'/'+fn,str(local/fn))
     except FileNotFoundError:pass
s.close();c.close()
