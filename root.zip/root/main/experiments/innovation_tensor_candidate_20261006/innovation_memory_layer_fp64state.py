"""Numerical reference implementation: FP32 interface, FP64 internal state.

This is a precision repair, not a scientific contribution or efficiency claim.
The original FP32 implementation and failed stress test remain preserved.
"""
import torch
from innovation_memory_layer import InnovationMemory

class InnovationMemoryStable(InnovationMemory):
    def forward(self, keys, values, queries, return_state=False):
        dtype=queries.dtype
        result=super().forward(keys.double(),values.double(),queries.double(),return_state=return_state)
        if return_state:
            prediction,W,C=result
            return prediction.to(dtype),W,C
        return result.to(dtype)
