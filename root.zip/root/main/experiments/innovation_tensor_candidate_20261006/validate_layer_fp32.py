import torch,json,time
from pathlib import Path
from innovation_memory_layer import InnovationMemory
torch.set_num_threads(2);g=torch.Generator().manual_seed(94682)
b,t,d,m=2,240,8,4
keys=torch.randn(b,t,d,generator=g,dtype=torch.float64)
common=torch.randn(b,1,d,generator=g,dtype=torch.float64)
keys=.8*common+.2*keys;keys=keys/torch.linalg.vector_norm(keys,dim=-1,keepdim=True)
values=torch.randn(b,t,m,generator=g,dtype=torch.float64)
queries=torch.randn(b,12,d,generator=g,dtype=torch.float64)
start=time.time();rows=[]
for mode in ('rls','candidate_dual','key_dual'):
    layer=InnovationMemory(d,m,mode=mode)
    with torch.no_grad():ref=layer(keys,values,queries)
    inputs=[x.float().requires_grad_() for x in (keys,values,queries)]
    out,W,C=layer(*inputs,return_state=True)
    loss=out.square().mean();loss.backward()
    max_error=float((out.double()-ref).abs().max())
    relative_error=float(torch.linalg.vector_norm(out.double()-ref)/torch.linalg.vector_norm(ref).clamp_min(1e-12))
    gradients_finite=all(bool(torch.isfinite(x.grad).all()) for x in inputs)
    finite=bool(torch.isfinite(out).all()) and gradients_finite
    passed=finite and relative_error<.01
    rows.append({'mode':mode,'fp32_finite':finite,'fp32_max_error':max_error,'fp32_relative_error':relative_error,'gradient_norms':[float(torch.linalg.vector_norm(x.grad)) for x in inputs],'precision_min_eigenvalue':float(torch.linalg.eigvalsh(C.detach()+.001*torch.eye(m*d)).min()),'passed':passed})
result={'passed':all(r['passed'] for r in rows),'rows':rows,'elapsed_seconds':time.time()-start,'sequence_length':t,'EEG_tested':False}
Path(__file__).with_name('innovation_layer_fp32.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps(result));assert result['passed'],'FP32 implementation requires repair'
