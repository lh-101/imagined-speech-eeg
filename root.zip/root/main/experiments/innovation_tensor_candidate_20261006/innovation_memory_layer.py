"""Research prototype; novelty and EEG benefit unconfirmed.

Per-sequence state, no test-label access, no persistent state across trials.
Pure forward keys/values/queries. Full tensor state is expensive: O(m^2 d^2).
"""
import torch
from torch import nn

class InnovationMemory(nn.Module):
    def __init__(self, key_dim, value_dim, gamma=.95, ridge=.001,
                 mode='candidate_dual', warm=True):
        super().__init__()
        assert mode in ('candidate_dual','key_dual','rls')
        self.d=key_dim;self.m=value_dim;self.gamma=gamma;self.ridge=ridge
        self.mode=mode;self.warm=warm

    def forward(self, keys, values, queries, return_state=False):
        assert keys.ndim==values.ndim==queries.ndim==3
        b,t,d=keys.shape;assert d==self.d and values.shape==(b,t,self.m)
        assert queries.shape[0]==b and queries.shape[2]==d
        assert keys.dtype==values.dtype==queries.dtype
        p=d*self.m;eye=torch.eye(p,dtype=keys.dtype,device=keys.device)
        out_eye=torch.eye(self.m,dtype=keys.dtype,device=keys.device)
        theta=keys.new_zeros(b,p);C=keys.new_zeros(b,p,p)
        ready=torch.zeros(b,dtype=torch.bool,device=keys.device)
        for step in range(t):
            H=torch.einsum('ij,bk->bijk',out_eye,keys[:,step]).reshape(b,self.m,p)
            residual=values[:,step]-torch.bmm(H,theta.unsqueeze(-1)).squeeze(-1)
            if self.mode!='rls':
                if self.warm:
                    ready=ready|(torch.linalg.eigvalsh(C.detach()).amin(-1)>1e-8)
                else:ready=torch.ones_like(ready)
                if self.mode=='candidate_dual':
                    norm=torch.linalg.vector_norm(residual,dim=-1)
                    u=residual/norm.clamp_min(1e-12).unsqueeze(-1)
                    a=torch.bmm(H.transpose(1,2),u.unsqueeze(-1))
                    D=torch.linalg.solve(C+self.ridge*eye,a)
                    CD=torch.bmm(C,D)
                    denominator=torch.bmm(D.transpose(1,2),CD).reshape(b)
                    active=ready&(norm>1e-12)&(denominator>1e-24)
                    factor=self.gamma*active.to(keys.dtype)/denominator.clamp_min(1e-24)
                    C=C-factor[:,None,None]*torch.bmm(CD,CD.transpose(1,2))
                else:
                    D=torch.linalg.solve(C+self.ridge*eye,H.transpose(1,2))
                    CD=torch.bmm(C,D);A=torch.bmm(D.transpose(1,2),CD)
                    inverse=torch.linalg.pinv(A,hermitian=True,rcond=1e-10)
                    correction=torch.bmm(torch.bmm(CD,inverse),CD.transpose(1,2))
                    C=C-self.gamma*ready[:,None,None].to(keys.dtype)*correction
            C=C+torch.bmm(H.transpose(1,2),H);C=(C+C.transpose(1,2))/2
            rhs=torch.bmm(H.transpose(1,2),residual.unsqueeze(-1))
            theta=theta+torch.linalg.solve(C+self.ridge*eye,rhs).squeeze(-1)
        W=theta.reshape(b,self.m,d)
        prediction=torch.bmm(queries,W.transpose(1,2))
        return (prediction,W,C) if return_state else prediction

def smoke():
    import numpy as np
    torch.set_num_threads(2);rng=np.random.default_rng(3942)
    k=rng.normal(size=(2,12,3));v=rng.normal(size=(2,12,2));q=rng.normal(size=(2,4,3))
    tensors=[torch.tensor(x,dtype=torch.float64) for x in (k,v,q)]
    # Separate NumPy implementation; do not import the benchmark's operator.
    errs={}
    for mode in ('rls','candidate_dual','key_dual'):
        pred=InnovationMemory(3,2,mode=mode)(*tensors).detach().numpy()
        reference=[]
        for batch in range(2):
            C=np.zeros((6,6));theta=np.zeros(6);ready=False
            for key,value in zip(k[batch],v[batch]):
                H=np.kron(np.eye(2),key[None,:]);e=value-H@theta
                ready=ready or np.linalg.eigvalsh(C).min()>1e-8
                if mode!='rls' and ready and np.linalg.norm(e)>1e-12:
                    a=H.T if mode=='key_dual' else (H.T@(e/np.linalg.norm(e)))[:,None]
                    D=np.linalg.solve(C+.001*np.eye(6),a);CD=C@D
                    C-=.95*CD@np.linalg.pinv(D.T@CD,rcond=1e-10,hermitian=True)@CD.T
                C+=H.T@H;C=(C+C.T)/2
                theta+=np.linalg.solve(C+.001*np.eye(6),H.T@e)
            reference.append(q[batch]@theta.reshape(2,3).T)
        err=float(np.max(np.abs(pred-np.array(reference))))
        assert err<1e-7,(mode,err);errs[mode]=err
    # Smooth-region autograd check; geometric rank decision held by margin.
    inp=[torch.tensor(x[:1,:6,:2] if i<2 else x[:1,:,:2],dtype=torch.float64,requires_grad=True) for i,x in enumerate((k,v,q))]
    layer=InnovationMemory(2,2)
    passed=torch.autograd.gradcheck(layer,tuple(inp),eps=1e-6,atol=2e-4,rtol=2e-3)
    assert passed
    # Batched independence: running a sequence alone must agree with batching.
    layer=InnovationMemory(3,2);bat=layer(*tensors)
    singles=torch.cat([layer(*(x[i:i+1] for x in tensors)) for i in range(2)])
    assert torch.max(torch.abs(bat-singles))<1e-9
    return {'passed':True,'numpy_forward_max_errors':errs,'gradcheck':passed,'batch_independence':True,'torch':torch.__version__,'device':'cpu','dtype':'float64','novelty_confirmed':False,'EEG_tested':False}

if __name__=='__main__':
    import json
    from pathlib import Path
    result=smoke()
    Path(__file__).with_name('innovation_layer_smoke.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    print(json.dumps(result))
