import os
os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['OMP_NUM_THREADS']='2'
import numpy as np,json,time,argparse,hashlib
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--confirm',action='store_true');args=ap.parse_args()
ROOT=Path(__file__).resolve().parent/'tensor_fixed_confirm_results';ROOT.mkdir(exist_ok=True)
LAM=.001
def discount(C,D,g):
    CD=C@D;A=D.T@CD
    out=C-g*CD@np.linalg.pinv(A,rcond=1e-10,hermitian=True)@CD.T
    return (out+out.T)/2

def validate():
    rng=np.random.default_rng(738)
    X=rng.normal(size=(12,12));C=X@X.T;D=rng.normal(size=(12,2))
    c=discount(C,D,.95)
    assert np.linalg.eigvalsh(c).min()>0
    # Candidate rank-one formula agrees with explicit precision decomposition.
    a=D[:,0:1];one=discount(C,a,.5)
    assert np.max(np.abs(one-(C-.5*(C@a)@(C@a).T/float(a.T@C@a))))<1e-10
    # RLS full-parameter representation agrees with independent direct ridge.
    d=3;m=2;theta=np.zeros(m*d);C=np.zeros((m*d,m*d));K=[];V=[]
    for _ in range(15):
      k=rng.normal(size=d);v=rng.normal(size=m);H=np.kron(np.eye(m),k[None,:]);e=v-H@theta
      C+=H.T@H;theta+=np.linalg.solve(C+LAM*np.eye(m*d),H.T@e);K.append(k);V.append(v)
      direct=np.linalg.solve(np.array(K).T@np.array(K)+LAM*np.eye(d),np.array(K).T@np.array(V)).T
      assert np.max(np.abs(theta.reshape(m,d)-direct))<1e-8
    return {'passed':True,'rank_one_formula':True,'direct_ridge':True}

checks=validate();start=time.time();rows=[];sequence_count=0
ds=(8,12) if args.confirm else (8,)
noises=(0.,.05,.15) if args.confirm else (0.,.05)
for d in ds:
 for rho in (0.,.8):
  for kind in ('static','partial','whole'):
   for noise in noises:
    if not args.confirm and noise>0 and kind!='partial':continue
    for seed in range(16):
     rng=np.random.default_rng(7462000+seed+100*d+int(1000*rho)+10000*int(noise*100)+{'static':0,'partial':200000,'whole':400000}[kind])
     m=4;n=d;common=rng.normal(size=d);common/=np.linalg.norm(common)
     keys=np.sqrt(1-rho)*rng.normal(size=(n,d))/np.sqrt(d)+np.sqrt(rho)*common
     keys/=np.linalg.norm(keys,axis=1,keepdims=True)
     assert np.linalg.matrix_rank(keys)==d
     values=rng.normal(size=(n,m));changed=values.copy();mask=np.zeros((n,m),bool)
     if kind=='partial':mask[:2,0]=True
     elif kind=='whole':mask[:2,:]=True
     changed[mask]=rng.normal(size=mask.sum())
     rotation=np.linalg.qr(rng.normal(size=(m,m)))[0] if args.confirm else np.eye(m)
     # Retain canonical values to evaluate changed/unchanged directions after rotation.
     indices=np.array([j for _ in range(30) for j in rng.permutation(n)])[:240]
     indices[120:]=rng.choice(2,size=len(indices)-120,p=[.8,.2])
     true=np.stack([changed[j] if t>=120 else values[j] for t,j in enumerate(indices)])
     observations=(true+rng.normal(scale=noise,size=true.shape))@rotation
     np.savez_compressed(ROOT/f'sequence_{sequence_count:04d}.npz',keys=keys,values=values,changed=changed,mask=mask,indices=indices,observations=observations,rotation=rotation)
     methods=[('candidate_dual',.5),('rls',0.),('delta',0.),('candidate',.5)]+[('global',g) for g in (.03,.1,.3)]+[('key_dual',g) for g in (.03,.1,.3,.5,.95)]
     for method,g in methods:
      theta=np.zeros(m*d);C=np.zeros((m*d,m*d));metrics=[];ready=False
      for t,(j,v) in enumerate(zip(indices,observations),1):
       k=keys[j];H=np.kron(np.eye(m),k[None,:]);e=v-H@theta
       if method=='delta':theta+=H.T@e
       else:
        if not ready:ready=np.linalg.eigvalsh(C).min()>1e-8
        if ready and method=='global':C=(1-g)*C
        elif ready and method=='key':C=discount(C,H.T,g)
        elif ready and method=='key_dual':
         D=np.linalg.solve(C+LAM*np.eye(m*d),H.T)
         C=discount(C,D,g)
        elif ready and method=='candidate_dual' and np.linalg.norm(e)>1e-12:
         D=np.linalg.solve(C+LAM*np.eye(m*d),(H.T@(e/np.linalg.norm(e)))[:,None])
         C=discount(C,D,g)
        elif ready and method in ('output','candidate') and np.linalg.norm(e)>1e-12:
         u=e/np.linalg.norm(e)
         D=(H.T@u)[:,None] if method=='candidate' else np.kron(u[:,None],np.eye(d))
         C=discount(C,D,g)
        C+=H.T@H;C=(C+C.T)/2
        theta+=np.linalg.solve(C+LAM*np.eye(m*d),H.T@e)
       assert np.all(np.isfinite(theta))
       if t%12==0:
        if method!='delta':assert np.linalg.eigvalsh(C).min()>-1e-6
        prediction=(keys@theta.reshape(m,d).T)@rotation.T
        target=changed if t>120 else values
        errors=(prediction-target)**2
        entry={'t':t,'mse':float(errors.mean()),'changed_mse':float(errors[mask].mean()) if mask.any() else None,'unchanged_mse':float(errors[~mask].mean()) if (~mask).any() else None,'active_mse':float(errors[:2].mean()),'silent_mse':float(errors[2:].mean())}
        metrics.append(entry)
      rr={'d':d,'rho':rho,'kind':kind,'noise':noise,'seed':seed,'method':method,'gamma':g,'rotated':args.confirm,'final_mse':metrics[-1]['mse'],'post_mse':float(np.mean([r['mse'] for r in metrics if r['t']>120])),'post_changed_mse':float(np.mean([r['changed_mse'] for r in metrics if r['t']>120])) if mask.any() else None,'post_unchanged_mse':float(np.mean([r['unchanged_mse'] for r in metrics if r['t']>120])),'trajectory':metrics,'parameter_count':m*d,'stored_state_scalars':m*d+(0 if method=='delta' else (m*d)**2)}
      rr['post_active_mse']=float(np.mean([r['active_mse'] for r in metrics if r['t']>120]))
      rr['post_silent_mse']=float(np.mean([r['silent_mse'] for r in metrics if r['t']>120]))
      rows.append(rr)
     sequence_count+=1
     (ROOT/'status.json').write_text(json.dumps({'state':'running','sequences_done':sequence_count,'elapsed_seconds':time.time()-start}),encoding='utf8')
     print('DONE',d,rho,kind,noise,seed,flush=True)
summary=[]
groups={tuple(r[k] for k in ('d','rho','kind','noise','method','gamma')) for r in rows}
for group in sorted(groups):
 rr=[r for r in rows if tuple(r[k] for k in ('d','rho','kind','noise','method','gamma'))==group]
 entry=dict(zip(('d','rho','kind','noise','method','gamma'),group));entry['n']=len(rr)
 for metric in ('final_mse','post_mse','post_changed_mse','post_unchanged_mse','post_active_mse','post_silent_mse'):
  x=[r[metric] for r in rr if r[metric] is not None]
  entry[metric]=float(np.mean(x)) if x else None
  entry[metric+'_sd']=float(np.std(x,ddof=1)) if x else None
 summary.append(entry)
result={'state':'complete','sequences':sequence_count,'method_runs':len(rows),'elapsed_seconds':time.time()-start,'validation':checks,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'summary':summary}
(ROOT/'raw.json').write_text(json.dumps(rows,indent=2),encoding='utf8');(ROOT/'summary.json').write_text(json.dumps(result,indent=2),encoding='utf8')
(ROOT/'status.json').write_text(json.dumps({k:v for k,v in result.items() if k!='summary'}),encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k!='summary'}),flush=True)
