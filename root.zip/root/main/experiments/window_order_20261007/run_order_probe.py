"""Bounded frozen readout audit; temporal first moments are known controls."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='4'
import argparse, json, sys, time, traceback
from pathlib import Path
sys.path.insert(0,'/root/FAST/experiments/compression_source_20261006')
import run_study as src
import numpy as np
import torch
from torch.nn import functional as F
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.exceptions import ConvergenceWarning
import warnings

ROOT=Path('/root/FAST/experiments/window_order_20261007')
ARMS=['cls','cls_mean','cls_moment','moment']

@torch.no_grad()
def collect_moments(kind,base,x,full,tr,te,norm):
    buffers={};handles=[]
    def hook_for(area):
        def hook(module,inputs,out):
            activation=F.gelu(out).squeeze(-2)
            t=torch.linspace(-1,1,activation.shape[-1],device=out.device,dtype=torch.float32)
            buffers[area]=(activation.mean(-1), (activation.float()*t).mean(-1))
        return hook
    for area,encoder in base.head.encoders.items():
        assert encoder.__class__.__name__=='Conv4Layers'
        handles.append(encoder.cnn4.register_forward_hook(hook_for(area)))
    try:
        xx=x if norm is None else ((x-norm[0])/norm[1]).astype(np.float32)
        moment=np.empty(tuple(full.shape),dtype=np.float32)
        for indices in ([np.arange(len(x))] if kind=='main' else [tr,te]):
            size=len(indices) if kind=='main' else 64
            for j in range(0,len(indices),size):
                ii=indices[j:j+size]
                with torch.autocast('cuda',dtype=torch.bfloat16,enabled=kind=='external'):
                    replay=base.forward_head(torch.from_numpy(xx[ii]).cuda())
                assert torch.equal(replay,full[ii]),'Head replay changed features'
                z=torch.stack([buffers[a][0] for a in base.head.encoders],1)
                z=z.reshape(len(ii),full.shape[1],full.shape[2],full.shape[3])
                assert torch.equal(z,replay),'Hook mean does not reproduce actual pooling'
                m=torch.stack([buffers[a][1] for a in base.head.encoders],1)
                moment[ii]=m.reshape(len(ii),*full.shape[1:]).cpu().numpy()
        assert np.isfinite(moment).all()
        return moment
    finally:
        for h in handles:h.remove()

@torch.no_grad()
def ambiguity(base):
    """Exact multiset construction, separated from edges and later windows."""
    device=next(base.parameters()).device
    channels=len(base.config.electrodes)
    length=base.config.seq_len
    g=torch.Generator(device=device).manual_seed(7301)
    a=torch.randn(channels,24,generator=g,device=device)
    b=torch.randn(channels,24,generator=g,device=device)
    x=torch.zeros(2,channels,length,device=device)
    x[0,:,12:36]=a;x[0,:,52:76]=b
    x[1,:,12:36]=b;x[1,:,52:76]=a
    full=base.forward_head(x)
    logits=base.forward_transformer(full)
    assert torch.allclose(full[0],full[1],atol=2e-5,rtol=1e-5)
    assert torch.allclose(logits[0],logits[1],atol=2e-5,rtol=1e-5)
    moments=collect_moments('main',base,x.cpu().numpy(),full,np.array([0]),np.array([1]),None)
    diff=float(np.max(np.abs(moments[0]-moments[1])))
    assert diff>1e-6
    return {'head_max_abs_difference':float((full[0]-full[1]).abs().max()),
            'logits_max_abs_difference':float((logits[0]-logits[1]).abs().max()),
            'moment_max_abs_difference':diff,'construction':'Two separated 24-sample motifs exchanged within first stride; no arbitrary-permutation claim'}

def run_fold(kind,s,f,tr,te,x,y,dest):
    start=time.time()
    base,full,old,prob,norm,err=src.load_source(kind,'loo',s,f,tr,te,x,y)
    before=src.ref.main_ref.tensorhash(base)
    views=src.extract_views(kind,base,full,tr,te,old)
    moment=collect_moments(kind,base,x,full,tr,te,norm).reshape(len(x),-1).astype(np.float64)
    mean=views['regional'].reshape(len(x),-1).astype(np.float64)
    pc_mean,meta_mean=src.pca_train_only(mean,tr)
    pc_moment,meta_moment=src.pca_train_only(moment,tr)
    arrays={'cls':views['cls'].astype(np.float64),'moment':pc_moment}
    arrays['cls_mean']=np.concatenate([arrays['cls'],pc_mean],axis=1)
    arrays['cls_moment']=np.concatenate([arrays['cls'],pc_moment],axis=1)
    predictions={};rows={};weights={}
    classes=5 if kind=='main' else 3
    for arm in ARMS:
        scale=StandardScaler().fit(arrays[arm][tr])
        model=LogisticRegression(C=1.,max_iter=2000,tol=1e-4,random_state=42)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always',ConvergenceWarning)
            model.fit(scale.transform(arrays[arm][tr]),y[tr])
        assert not any(issubclass(w.category,ConvergenceWarning) for w in caught),arm+' not converged'
        assert np.array_equal(model.classes_,np.arange(classes))
        p=model.predict_proba(scale.transform(arrays[arm][te]))
        assert np.isfinite(p).all()
        predictions[arm+'_pred']=p.argmax(-1)
        predictions[arm+'_prob']=p
        rows[arm]=src.metrics(y[te],p.argmax(-1),classes)
        weights[arm+'_coef']=model.coef_;weights[arm+'_intercept']=model.intercept_
        weights[arm+'_scaler_mean']=scale.mean_;weights[arm+'_scaler_scale']=scale.scale_
    assert src.ref.main_ref.tensorhash(base)==before
    assert all(p.grad is None for p in base.parameters())
    name=kind+'_'+src.ref.name(kind,s,f)
    src.save_npz(dest/(name+'.npz'),y=y[te],train_idx=tr,test_idx=te,source_prob=prob,**predictions)
    src.save_npz(dest/(name+'_weights.npz'),**weights)
    row={'dataset':kind,'subject':s,'fold':f,'views':rows,'seconds':time.time()-start,
         'source_accuracy':float((prob.argmax(-1)==y[te]).mean()),
         'source_replay_error':err,'frozen_unchanged':True,
         'source_sha256':src.sha(src.source_path(kind,'loo',s,f)),
         'code_sha256':src.sha(Path(__file__)),
         'pca_mean':meta_mean,'pca_moment':meta_moment}
    if f==0:
        row['ambiguity']=ambiguity(base)
    src.save(dest/(name+'.json'),row)
    del base,full,old
    torch.cuda.empty_cache()
    return row

def summarize(rows,dest):
    reports={}
    rng=np.random.default_rng(87231)
    for kind in ['main','external']:
        selected=[r for r in rows if r['dataset']==kind]
        if not selected:continue
        people=[]
        for s in sorted(set(r['subject'] for r in selected)):
            rr=[r for r in selected if r['subject']==s]
            saved=[np.load(dest/(kind+'_'+src.ref.name(kind,s,r['fold'])+'.npz')) for r in rr]
            y=np.concatenate([z['y'] for z in saved])
            values={arm:src.metrics(y,np.concatenate([z[arm+'_pred'] for z in saved]),5 if kind=='main' else 3) for arm in ARMS}
            people.append({'subject':s,'folds':len(rr),'metrics':values})
            for z in saved:z.close()
        means={arm:{m:float(np.mean([p['metrics'][arm][m] for p in people])) for m in ['accuracy','macro_f1']} for arm in ARMS}
        contrasts={}
        for control in ['cls_mean','cls']:
            delta=np.array([p['metrics']['cls_moment']['accuracy']-p['metrics'][control]['accuracy'] for p in people])
            boot=delta[rng.integers(0,len(delta),(10000,len(delta)))].mean(1)
            contrasts[control]={'mean_delta_pp':float(delta.mean()*100),'positive_subjects':int((delta>0).sum()),'subjects':len(delta),
                                'bootstrap95_pp':(np.quantile(boot,[.025,.975])*100).tolist()}
        reports[kind]={'subject_metrics':people,'mean_metrics':means,'contrasts':contrasts}
    complete=len(rows)==105
    meets=complete and all(reports[k]['contrasts'][c]['mean_delta_pp']>=1 and reports[k]['contrasts'][c]['positive_subjects']>reports[k]['contrasts'][c]['subjects']/2 for k in ['main','external'] for c in ['cls','cls_mean'])
    return {'completed_folds':len(rows),'complete_cohorts':complete,'datasets':reports,
            'prespecified_triage_met':meets,'claim':'Exploratory frozen readout only; known temporal moments; no new network score or novelty proof'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['smoke','full'],required=True);a=ap.parse_args()
    dest=ROOT/a.phase;dest.mkdir(exist_ok=True)
    start=time.time();rows=[]
    jobs=[]
    for kind in ['main','external']:
        ss=src.ref.subjects(kind) if a.phase=='full' else src.ref.subjects(kind)[:1]
        for s in ss:
            x,y=src.ref.dataset(kind,s)
            for f,(tr,te) in enumerate(src.ref.splits(kind,x,y)):
                if a.phase=='smoke' and f!=0:continue
                jobs.append((kind,s,f))
    total=len(jobs)
    try:
        current=None
        for kind,s,f in jobs:
            if current!=(kind,s):x,y=src.ref.dataset(kind,s);current=(kind,s)
            tr,te=list(src.ref.splits(kind,x,y))[f]
            name=kind+'_'+src.ref.name(kind,s,f)
            path=dest/(name+'.json')
            smoke=ROOT/'smoke'/(name+'.json')
            if path.exists():row=json.loads(path.read_text())
            elif a.phase=='full' and smoke.exists():
                import shutil
                for suffix in ['.json','.npz','_weights.npz']:
                    shutil.copy2(ROOT/'smoke'/(name+suffix),dest/(name+suffix))
                row=json.loads(path.read_text())
            else:row=run_fold(kind,s,f,tr,te,x,y,dest)
            rows.append(row)
            elapsed=time.time()-start
            src.save(dest/'raw.json',rows)
            src.save(dest/'summary.json',summarize(rows,dest))
            status={'state':'running','completed':len(rows),'total':total,'elapsed_seconds':elapsed,
                    'estimated_remaining_seconds':(total-len(rows))*float(np.median([r['seconds'] for r in rows])),
                    'current':[kind,s,f]}
            src.save(dest/'status.json',status)
            print('FOLD_DONE',kind,s,f,row['views'],row['seconds'],flush=True)
        src.save(dest/'status.json',{'state':'complete','completed':len(rows),'total':total,'elapsed_seconds':time.time()-start})
    except Exception:
        src.save(dest/'status.json',{'state':'failed','completed':len(rows),'total':total,'error':traceback.format_exc()})
        raise
if __name__=='__main__':main()
