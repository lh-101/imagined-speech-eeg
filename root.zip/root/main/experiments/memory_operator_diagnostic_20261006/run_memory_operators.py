import os
os.environ['OPENBLAS_NUM_THREADS']='2'
os.environ['OMP_NUM_THREADS']='2'
import numpy as np
import json,time,hashlib
from pathlib import Path

ROOT=Path(__file__).resolve().parent/'memory_operator_results'
ROOT.mkdir(exist_ok=True)
LAM=1e-3

def cg(A,Q,steps,pre=False):
    X=np.zeros_like(Q);R=Q.copy()
    D=np.diag(A)[:,None] if pre else np.ones((len(A),1))
    Z=R/D;P=Z.copy();rz=np.sum(R*Z,axis=0)
    for _ in range(steps):
        AP=A@P;den=np.sum(P*AP,axis=0)
        active=(rz>1e-28)&(den>1e-28)
        alpha=np.divide(rz,den,out=np.zeros_like(rz),where=active)
        X+=P*alpha;R-=AP*alpha;Z=R/D
        nrz=np.sum(R*Z,axis=0)
        beta=np.divide(nrz,rz,out=np.zeros_like(rz),where=active)
        P=Z+P*beta;rz=nrz
    return X

def mse(A,B):return float(np.mean((A-B)**2))

start=time.time();rows=[];checks=[]
for d in (16,32):
 for workload in ('orthogonal','correlated','duplicates','revisions'):
  for seed in range(8):
   rng=np.random.default_rng(62000+seed+d*100);n=3*d//4;m=4
   Q,_=np.linalg.qr(rng.normal(size=(d,d)))
   keys=Q[:,:n].T.copy()
   if workload=='correlated':
    common=Q[:,n]
    keys=np.sqrt(.97)*common+np.sqrt(.03)*keys
   values=rng.normal(size=(n,m));current=values.copy()
   changed=values.copy();changed[:n//3]=rng.normal(size=(n//3,m))
   order=list(rng.permutation(n))
   for t in range(n,160):
    order.append(int(0 if workload=='duplicates' and rng.random()<.8 else rng.integers(n)))
   A=LAM*np.eye(d);B=np.zeros((m,d));P=np.eye(d)/LAM
   states={k:np.zeros((m,d)) for k in ('delta','implicit','diag','rls')}
   diag=np.full(d,LAM);hist=[]
   for t,j in enumerate(order,1):
    k=keys[j];v=changed[j] if workload=='revisions' and t>80 else values[j]
    current[j]=v;hist.append((k.copy(),v.copy()))
    for method in ('delta','implicit'):
     e=v-states[method]@k
     rate=1. if method=='delta' else 1./(1.+k@k)
     states[method]+=rate*np.outer(e,k)
    diag+=k*k;z=k/diag
    states['diag']+=np.outer(v-states['diag']@k,z)/(1.+k@z)
    pk=P@k;gain=pk/(1.+k@pk)
    states['rls']+=np.outer(v-states['rls']@k,gain)
    P-=np.outer(pk,pk)/(1.+k@pk)
    A+=np.outer(k,k);B+=np.outer(v,k)
    if t not in (40,80,120,160):continue
    exact=np.linalg.solve(A,B.T).T;ref=exact@keys.T
    residual=float(np.max(np.abs(exact@A-B)))
    err=float(np.max(np.abs(states['rls']-exact)))
    assert residual<1e-9 and err<1e-7,(residual,err)
    K=np.stack([h[0] for h in hist]);V=np.stack([h[1] for h in hist])
    direct=np.linalg.lstsq(np.vstack([K,np.sqrt(LAM)*np.eye(d)]),np.vstack([V,np.zeros((d,m))]),rcond=None)[0].T
    assert np.max(np.abs(direct-exact))<1e-7
    checks.append({'d':d,'workload':workload,'seed':seed,'t':t,'rls_maxerr':err,'solve_residual':residual})
    models={**states,'exact':exact}
    for steps in (2,4,8):models['cg'+str(steps)]=cg(A,B.T,steps).T
    models['pcg4']=cg(A,B.T,4,True).T
    def objective(W):return float(np.sum((K@W.T-V)**2)+LAM*np.sum(W*W))
    opt=objective(exact)
    for method,W in models.items():
     gap=objective(W)-opt
     assert gap>=-1e-7
     rows.append({'dimension':d,'workload':workload,'seed':seed,'writes':t,'method':method,'retrieval_mse':mse(W@keys.T,current.T),'ridge_prediction_mse':mse(W@keys.T,ref),'objective_gap_per_write':max(0.,gap)/t})
   print(f'DONE {d} {workload} {seed}',flush=True)

summary=[]
for d in (16,32):
 for w in ('orthogonal','correlated','duplicates','revisions'):
  for method in ('delta','implicit','diag','rls','exact','cg2','cg4','cg8','pcg4'):
   rr=[r for r in rows if r['dimension']==d and r['workload']==w and r['method']==method and r['writes']==160]
   a=np.array([r['retrieval_mse'] for r in rr])
   summary.append({'dimension':d,'workload':w,'method':method,'n_sequences':len(rr),'retrieval_mse_mean':float(a.mean()),'retrieval_mse_sd':float(a.std(ddof=1)),'ridge_prediction_mse_mean':float(np.mean([r['ridge_prediction_mse'] for r in rr])),'objective_gap_per_write_mean':float(np.mean([r['objective_gap_per_write'] for r in rr]))})
result={'state':'complete','elapsed_seconds':time.time()-start,'sequences':64,'records':len(rows),'validation_nodes':len(checks),'max_rls_error':max(c['rls_maxerr'] for c in checks),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'summary':summary}
(ROOT/'raw.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
(ROOT/'checks.json').write_text(json.dumps(checks,indent=2),encoding='utf8')
(ROOT/'summary.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k!='summary'}),flush=True)
