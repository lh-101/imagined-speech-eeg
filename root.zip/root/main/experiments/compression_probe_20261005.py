"""Fixed exploratory frozen-feature probe, not a model improvement experiment."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='4'
import sys,time,json
from pathlib import Path
sys.path[:0]=['/root/FAST/experiments','/root/FAST','/root/FAST/experiments/residual_20260925']
import numpy as np,h5py,torch
from torch.nn import functional as F
from sklearn.model_selection import KFold
import context_adapter_20261004 as harness
v4=harness.v4
OUT=Path('/root/FAST/experiments/compression_probe_20261005')
SUBJECTS=[0,7,10]

def report():
    subjects=[]
    for s in SUBJECTS:
        paths=[OUT/f'{s}-fold{i}.npz' for i in range(5)]
        if not all(p.exists() for p in paths):continue
        truth=[];pred={k:[] for k in ['retained','null','combined','full','source']}
        for p in paths:
            with np.load(p) as z:
                truth.extend(z['y'])
                for k in pred:pred[k].extend(z[k])
        subjects.append({'subject':s,**{k:float((np.array(a)==np.array(truth)).mean()) for k,a in pred.items()}})
    result={'complete':len(subjects)==len(SUBJECTS),'subjects':subjects,
        'means':{k:float(np.mean([r[k] for r in subjects])) for k in ['retained','null','combined','full','source']} if subjects else {},
        'limits':'Exploratory repeatedly observed development folds; fixed kernel probe not matched capacity, not FAST performance or proof of useful discarded information conditional on retained features; no biological conclusions.'}
    harness.save(OUT/'summary.json',result)

@torch.no_grad()
def main():
    OUT.mkdir(exist_ok=True);torch.set_num_threads(4);started=time.time()
    harness.save(OUT/'protocol.json',{'subjects':SUBJECTS,'folds':5,'source':str(harness.SOURCE),
        'design':'SVD of frozen 32x256 token projection W; raw features split into rowspace and nullspace. Verify W times null features approximately zero. Fixed gamma=2 ridge=.1, query evaluated only on held-out folds. No neural training, no baseline rerun.',
        'representations':['normalized asinh retained coordinates across five windows','normalized asinh null features across five windows','equal-norm concatenation retained/null','normalized asinh original full regional features'],
        'normalization':'Each representation L2 normalized per trial. No test-label tuning.',
        'limits':['Rank deficiency is a linear algebra fact, not proof of discarded task information','Different dimensions and nonlinear feature transforms make kernel comparisons diagnostic only','All development subjects previously selected and repeatedly observed','Frozen encoder used all training labels; this is not a new independent study','Null-space adapters and orthogonal methods have precedents; no originality claim']})
    try:
        for s in SUBJECTS:
            with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5') as h:
                x=h[f'{s+1:02d}/X'][:];y=h[f'{s+1:02d}/Y'][:].astype(np.int64)
            for fi,(tr,te) in enumerate(KFold(5,shuffle=False).split(x)):
                path=OUT/f'{s}-fold{fi}.npz'
                if path.exists():continue
                v4.seed_all(42+s*5+fi)
                base,full,mean,old,source=harness.load_fold(s,fi,tr,te,x,y)
                w=base.input_layer[0].weight.double()
                _,sv,vh=torch.linalg.svd(w,full_matrices=False)
                rank=int((sv>sv.max()*1e-10).sum())
                basis=vh[:rank].T
                f=full.flatten(2).double()
                coordinates=f@basis
                null=f-coordinates@basis.T
                relative=float((null@w.T).norm()/(f@w.T).norm().clamp_min(1e-12))
                assert relative<1e-8
                def norm(z):return F.normalize(torch.asinh(z.float()).flatten(1),dim=-1)
                retained=norm(coordinates);nq=norm(null)
                qs={'retained':retained,'null':nq,'combined':torch.cat([retained,nq],-1)/2**.5,'full':norm(f)}
                predictions={};yt=torch.from_numpy(y[tr]).cuda()
                for name,q in qs.items():
                    alpha=v4.ridge_fit(q[tr],yt)[0]
                    scores=v4.kernel(q[te],q[tr])@alpha
                    assert torch.isfinite(scores).all()
                    predictions[name]=scores.argmax(-1).cpu().numpy()
                np.savez_compressed(path,y=y[te],train_idx=tr,test_idx=te,source=source,**predictions)
                harness.save(OUT/f'{s}-fold{fi}.json',{'rank':rank,'null_dimension':256-rank,'annihilation_relative_error':relative,'source_sha256':harness.sha(harness.SOURCE/f'{s}-fold{fi}.pt')})
                n=len(list(OUT.glob('*-fold*.npz')))
                harness.save(OUT/'status.json',{'state':'running','pid':os.getpid(),'completed_folds':n,'total_folds':15,'elapsed_seconds':time.time()-started})
                print('PROBE_DONE',s,fi,{k:float((p==y[te]).mean()) for k,p in predictions.items()},flush=True)
                report();del base,full,mean,old,f,qs;torch.cuda.empty_cache()
        report();harness.save(OUT/'status.json',{'state':'complete','completed_folds':15,'total_folds':15,'elapsed_seconds':time.time()-started})
    except Exception as e:
        harness.save(OUT/'status.json',{'state':'failed','error':repr(e)});raise

if __name__=='__main__':main()
