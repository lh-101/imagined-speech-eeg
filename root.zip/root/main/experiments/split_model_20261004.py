"""Exploratory mean/residual regional fusion. New architecture, originality unproven."""
import os
os.environ['OMP_NUM_THREADS']='8';os.environ['OPENBLAS_NUM_THREADS']='1'
import sys,json,time,hashlib,fcntl,argparse
from pathlib import Path
sys.path[:0]=['/root/FAST','/root/FAST/experiments/residual_20260925']
import numpy as np,h5py,torch
from torch import nn
from torch.nn import functional as F
from sklearn.model_selection import KFold
from sklearn.metrics import f1_score
import run_metric_v4 as v4

OUT=Path('/root/FAST/experiments/split_model_20261004');OUT.mkdir(exist_ok=True)
OLD=Path('/root/FAST/experiments/mechanism_20260927/results')
SUBJECTS=[0,7,10]+[s for s in range(15) if s not in [0,7,10]]
ARMS=['split_ce','split_loo'];EPOCHS=200

def save(p,d):
    t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(d,indent=2));t.replace(p)

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
    return h.hexdigest()

def state_hash(model,base_only=False):
    h=hashlib.sha256()
    for k,t in model.state_dict().items():
        if base_only and k.startswith(('mean_encoders.','fusion_gate.')):continue
        h.update(k.encode());h.update(t.detach().cpu().numpy().tobytes())
    return h.hexdigest()

class SplitFAST(v4.FAST):
    def __init__(self,config):
        super().__init__(config)
        # Preserve original backbone initial random stream. Paired arms same seed.
        with torch.random.fork_rng(devices=[]):
            self.mean_encoders=nn.ModuleDict({area:nn.Sequential(nn.Linear(len(idx),config.dim_cnn),nn.GELU()) for area,idx in self.head.index_dict.items()})
            self.fusion_gate=nn.Sequential(nn.LayerNorm(2*config.dim_cnn),nn.Linear(2*config.dim_cnn,16),nn.GELU(),nn.Linear(16,1))
            nn.init.zeros_(self.fusion_gate[-1].weight);nn.init.zeros_(self.fusion_gate[-1].bias)
        self.visible=(self.n_tokens-1)*config.slide_step+config.window_len

    def components(self,x):
        mean=x[...,:self.visible].float().mean(-1,keepdim=True)
        residual=x-mean
        dynamic=super().forward_head(residual)
        static=torch.stack([encoder(torch.asinh(mean[:,idx,0])) for area,idx in self.head.index_dict.items() for encoder in [self.mean_encoders[area]]],dim=1)
        static=static[:,None].expand(-1,dynamic.shape[1],-1,-1)
        return static,dynamic

    def repr(self,x,mode='full'):
        static,dynamic=self.components(x)
        gate=torch.sigmoid(self.fusion_gate(torch.cat([static,dynamic],dim=-1)))
        # Ablations keep full-input gate fixed, removing only a branch's feature contribution.
        if mode=='without_mean':static=torch.zeros_like(static)
        elif mode=='without_dynamic':dynamic=torch.zeros_like(dynamic)
        elif mode!='full':raise ValueError(mode)
        f=gate*static+(1-gate)*dynamic
        tokens=self.input_layer(f.flatten(2));tokens=torch.cat([self.cls_token.expand(len(x),-1,-1),tokens],1)
        hidden=self.transformer(tokens+self.pos_embedding[:,:self.n_tokens+1])[:,0]
        logits=self.last_layer(self.dropout(hidden))
        with torch.autocast('cuda',enabled=False):
            regional=F.normalize(torch.asinh(f.float()).flatten(1),dim=-1);cls=F.normalize(hidden.float(),dim=-1)
            q=torch.cat([regional,cls],dim=-1)/(2**.5)
        return logits,q,gate

    def forward(self,x):return self.repr(x)[0]

def smoke():
    v4.seed_all(42);torch.set_float32_matmul_precision('highest')
    model=SplitFAST(v4.config()).cuda();x=torch.randn(10,64,800,device='cuda');y=torch.arange(10,device='cuda')%5
    mean=x[:,:,:750].mean(-1,keepdim=True);res=x-mean
    assert torch.allclose((mean+res)[:,:,:750],x[:,:,:750],atol=1e-6)
    assert res[:,:,:750].mean(-1).abs().max()<1e-6
    assert model.visible==750
    model.eval()
    with torch.no_grad():
        z=model(x);changed=x.clone();changed[:,:,750:]+=10000
        assert torch.equal(z,model(changed)),'Ignored tail used'
        assert torch.allclose(z[:1],model(x[:1]),atol=2e-6,rtol=2e-5),'Batch-dependent eval'
    model.train()
    with torch.autocast('cuda',dtype=torch.bfloat16):logits,q,g=model.repr(x);main=F.cross_entropy(logits,y)
    aux=.3*F.cross_entropy(4*v4.ridge_fit(q,y)[1],y);(main+aux).backward()
    for prefix in ['head.','mean_encoders.','fusion_gate.']:
        grads=[p.grad for n,p in model.named_parameters() if n.startswith(prefix) and p.grad is not None]
        assert grads and all(torch.isfinite(z).all() for z in grads) and sum(float(z.abs().sum()) for z in grads)>0,prefix
    save(OUT/'smoke.json',{'passed':True,'checks':['Visible750point exact mean+residual reconstruction','Residual visible temporal mean zero','Ignoredlast50points invariant','Single-vs-batch evaluation independent','BF16main+LOO gradients finite/nonzero in bothbranches andgate'],'parameter_count':sum(p.numel() for p in model.parameters())})
    print('SPLIT_SMOKE_OK',flush=True)

def old_predictions(s,fi,tr,te,y):
    result={}
    for name in ['ce','additive']:
        p=OLD/f'full_{name}_seed42'/f'{s}-fold{fi}.npz'
        with np.load(p) as z:
            assert np.array_equal(z['train_idx'],tr) and np.array_equal(z['test_idx'],te) and np.array_equal(z['y'],y[te])
            result[name]=z['primary_pred'].copy()
    return result

def train(s,fi,tr,te,x,y,arm):
    dest=OUT/arm;dest.mkdir(exist_ok=True);p=dest/f'{s}-fold{fi}.npz'
    if p.exists():return
    old=old_predictions(s,fi,tr,te,y)
    v4.seed_all(42+s*5+fi);m=SplitFAST(v4.config()).cuda();initial=state_hash(m);baseinitial=state_hash(m,True)
    for oldarm in ['ce','additive']:
        j=json.loads((OLD/f'full_{oldarm}_seed42'/f'{s}-fold{fi}.json').read_text())
        assert j['initial_state_sha256']==baseinitial,'Backboneinitial mismatch'
    other=OUT/('split_loo' if arm=='split_ce' else 'split_ce')/f'{s}-fold{fi}.json'
    if other.exists():assert json.loads(other.read_text())['initial_state_sha256']==initial
    opt=torch.optim.AdamW(m.parameters(),lr=.0005);xt=torch.from_numpy(x[tr]).cuda();yt=torch.from_numpy(y[tr]).cuda();schedule=v4.cosine_scheduler(1,.1,EPOCHS,1,warmup_epochs=10);start=time.time();trace=[]
    for epoch in range(EPOCHS):
        m.train();opt.zero_grad(set_to_none=True)
        for g in opt.param_groups:g['lr']=.0005*float(schedule[epoch-1])
        with torch.autocast('cuda',dtype=torch.bfloat16):
            logits,q,gate=m.repr(xt);main=F.cross_entropy(logits,yt)
        aux=.3*F.cross_entropy(4*v4.ridge_fit(q,yt)[1],yt) if arm=='split_loo' else torch.zeros((),device='cuda')
        loss=main+aux
        if not torch.isfinite(loss):raise RuntimeError('Nonfinite loss')
        loss.backward()
        if not all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters()):raise RuntimeError('Nonfinite gradient')
        opt.step()
        if epoch==0 or (epoch+1)%50==0:
            r={'epoch':epoch+1,'main_loss':float(main.detach()),'aux_loss':float(aux.detach()),'mean_static_weight':float(gate.detach().float().mean())};trace.append(r);print('TRAIN',arm,s,fi,json.dumps(r),flush=True)
    m.eval();zt=torch.from_numpy(x[te]).cuda()
    with torch.no_grad():
        logits,q,gates=m.repr(zt);prob=logits.softmax(-1).cpu().numpy();pred=prob.argmax(-1)
        removed_mean=m.repr(zt,'without_mean')[0].argmax(-1).cpu().numpy();removed_dynamic=m.repr(zt,'without_dynamic')[0].argmax(-1).cpu().numpy()
        training_acc=float((m(xt).argmax(-1)==yt).float().mean())
    info={'arm':arm,'subject':s,'fold':fi,'initial_state_sha256':initial,'initial_backbone_sha256':baseinitial,'accuracy':float((pred==y[te]).mean()),'old_ce':float((old['ce']==y[te]).mean()),'old_loo':float((old['additive']==y[te]).mean()),'train_accuracy':training_acc,'without_mean_accuracy':float((removed_mean==y[te]).mean()),'without_dynamic_accuracy':float((removed_dynamic==y[te]).mean()),'gate_by_region':gates.float().mean((0,1,3)).cpu().tolist(),'seconds':time.time()-start,'trace':trace}
    torch.save({'state_dict':m.cpu().state_dict(),'config':v4.config().to_dict(),'train_idx':tr,'test_idx':te,'arm':arm},dest/f'{s}-fold{fi}.pt')
    save(dest/f'{s}-fold{fi}.json',info)
    with p.with_suffix('.npz.tmp').open('wb') as f:np.savez_compressed(f,primary_pred=pred,primary_prob=prob,y=y[te],train_idx=tr,test_idx=te,without_mean=removed_mean,without_dynamic=removed_dynamic,gate=gates.cpu().float().numpy())
    p.with_suffix('.npz.tmp').replace(p);print('FOLD_DONE',arm,s,fi,info['accuracy'],info['seconds'],flush=True)

def report():
    groups=[]
    for arm in ARMS:
        subjects=[]
        for s in SUBJECTS:
            files=[OUT/arm/f'{s}-fold{fi}.npz' for fi in range(5)]
            if not all(p.exists() for p in files):continue
            target=[];pred=[];base=[];oldloo=[];meanoff=[];dynoff=[]
            for fi,p in enumerate(files):
                with np.load(p) as z:
                    tr=z['train_idx'];te=z['test_idx'];target.extend(z['y']);pred.extend(z['primary_pred']);meanoff.extend(z['without_mean']);dynoff.extend(z['without_dynamic'])
                    for name,out in [('ce',base),('additive',oldloo)]:
                        with np.load(OLD/f'full_{name}_seed42'/f'{s}-fold{fi}.npz') as b:assert np.array_equal(b['y'],z['y']);out.extend(b['primary_pred'])
            yy=np.array(target);subjects.append({'subject':s,'accuracy':float((np.array(pred)==yy).mean()),'old_ce':float((np.array(base)==yy).mean()),'old_loo':float((np.array(oldloo)==yy).mean()),'macro_f1':float(f1_score(yy,pred,average='macro')),'without_mean':float((np.array(meanoff)==yy).mean()),'without_dynamic':float((np.array(dynoff)==yy).mean())})
        groups.append({'arm':arm,'n_subjects':len(subjects),'subjects':subjects,'means':{k:float(np.mean([r[k] for r in subjects])) for k in ['accuracy','old_ce','old_loo','macro_f1','without_mean','without_dynamic']} if subjects else {},'complete':len(subjects)==15})
    save(OUT/'summary.json',{'groups':groups,'complete':all(r['complete'] for r in groups),'interpretation':'Architecture development on repeatedlyviewed folds; not independentconfirmation. Branch removal sensitivity not proof ofneural origin. No selectingdifferentmodels foreachsubject.'})

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');a=ap.parse_args();torch.set_num_threads(8)
    if a.smoke:smoke();return
    with (OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        sources=[Path(__file__),Path('/root/FAST/FAST.py'),Path('/root/FAST/experiments/residual_20260925/run_metric_v4.py')]
        protocol={'architecture':'Mean/residual regionalfusion: visible750point per-electrode mean, Conv4Layers regionalencoder only on x-mean, perregion learned asinh(mean) linear32+GELU, shared regional/window scalar sigmoidgate(64LayerNorm->16GELU->1), convex featurefusion before original32token4layerTransformer. Gate initially.5. Mean acrosswholevisibletrial, no onlinecausalityclaim.','arms':ARMS,'subjects_order':SUBJECTS,'subjects_total':15,'folds':5,'new_fits':150,'epochs':EPOCHS,'seed':42,'comparison':'Existing samefold sameinitialbackbone CE and additiveLOO predictions reused, not retrained. NewCE and newLOO same full initialization.','objective':'CE or CE+.3CE(4×exactGaussianridgeLOOprediction) on fusedregional+CLS representation; gamma2,ridge.1; no protectedgradient/no supportfusionatdeployment.','optimizer':'AdamW lr.0005 historicalcosineschedule[epoch-1], BF16training, originalseed_allmatmulprecision; fixedlast200epoch; fulltrainingfold batch','development':'Existing folds/subjects repeatedlyinspected. All15run, no scorebasedearlystop, no heldoutnoveltyclaim, no performancetuning; first3development subjects for technicalprogress only.','primary':'newCE-vs-oldCE(structure);newLOO-vs-oldLOO(structure withsameaux);newLOO-vs-newCE(aux). Reportallsubjects, not just first3.','diagnostics':'Mean/dynamicfeature contributionremoval holding full-inputgate fixed, trainingaccuracy, regionalgateweights. Neither feature is guaranteed neural/artefact; weights are not physiological causal importance.','novelty':'Dualbranch and gates alreadyexist. Candidatearchitecture, not original/firstclaim; review relatedliteraturebeforemanuscript.','rejected_previous':'Not rawinput+latecovariance/statistics logitbranch; historicalspectral and zoneGaussianfailed. Explicitinputdecompositionbeforeencoders, learnedfusionbeforeTransformer.','sources':{str(p):sha(p) for p in sources},'data_sha256':sha('/root/FAST/Processed/BCIC2020Track3.h5')}
        p=OUT/'protocol.json'
        if p.exists():assert json.loads(p.read_text())==protocol,'Protocol changed; use newdirectory'
        else:save(p,protocol)
        started=time.time()
        try:
            for s in SUBJECTS:
                with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5') as h:x=h[f'{s+1:02d}/X'][:];y=h[f'{s+1:02d}/Y'][:].astype(np.int64)
                for fi,(tr,te) in enumerate(KFold(5,shuffle=False).split(x)):
                    for arm in ARMS:
                        n=sum(len(list((OUT/b).glob('*-fold*.npz'))) for b in ARMS)
                        save(OUT/'status.json',{'state':'running','pid':os.getpid(),'subject':s,'fold':fi,'arm':arm,'completed_folds':n,'total_folds':150,'elapsed_seconds':time.time()-started,'estimated_remaining_seconds':(time.time()-started)*(150-n)/n if n else None,'updated':time.time()})
                        train(s,fi,tr,te,x,y,arm)
                    report()
            report();save(OUT/'status.json',{'state':'complete','completed_folds':150,'total_folds':150,'elapsed_seconds':time.time()-started,'updated':time.time()})
        except Exception as e:save(OUT/'status.json',{'state':'failed','error':repr(e),'updated':time.time()});raise
if __name__=='__main__':main()
