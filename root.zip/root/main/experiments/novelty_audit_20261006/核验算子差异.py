"""CPU-only algebra and cached-operator audit; no fitting of EEG networks."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json,time,hashlib,ast
import numpy as np
import torch
from torch.nn import functional as F

OUT=Path('/root/FAST/experiments/novelty_audit_20261006')
CACHE=Path('/root/FAST/experiments/compression_source_20261006/feature_cache')
BCI_CODE=Path('/root/FAST/experiments/residual_20260925/run_metric_v4.py')
NGUYEN_CODE=Path('/root/FAST/experiments/nguyen_regional_adapter_20261005.py')

def write(name,obj):
 (OUT/name).write_text(json.dumps(obj,indent=2),encoding='utf8')

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def kernel(q):return np.exp(-2*(1-q@q.T))

def operators(k):
 b=np.linalg.solve(k+.1*np.eye(len(k)),np.eye(len(k)))
 c=np.eye(len(k))-b/b.diagonal()[:,None]
 np.fill_diagonal(c,0.)
 d=k.copy();np.fill_diagonal(d,0.);d/=d.sum(1,keepdims=True)
 return b,c,d

def source_function(path,names,env):
 tree=ast.parse(path.read_text())
 selected=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
 assert len(selected)==len(names)
 exec(compile(ast.Module(body=selected,type_ignores=[]),str(path),'exec'),env)
 return env

def main():
 OUT.mkdir(exist_ok=True)
 torch.set_num_threads(1)
 started=time.time()
 protocol={'purpose':'Verify mathematical distinction from nonnegative normalized cross-instance averaging; not performance/novelty/biological verification.',
  'scope':'All105 existing LOO-source feature caches, all15BCI and6Nguyen subjects,5folds; no subjects selected by observed coefficients.',
  'operations':'Float64 kernel and inverse; no training, hyperparameter changes or heldout accuracy calculation. Fixed gamma2,ridge0.1.',
  'toy':'Same two query-to-support similarities, two different support-to-support similarities. Show NW unchanged and KRR changed.',
  'checks':['Exact LOO scores match individual support refits for fixed representations','Fixed-representation self-label coefficient zero','Joint representation kernel equals product of branch kernels','Real-source weights may be negative and do not form a probability average','Actual source functions match float32-return analytical identity'],
  'existing_data':'Repeatedly inspected development data; coefficients from final frozen sources, not the entire stochastic training trajectory.',
  'code_sha256':digest(Path(__file__)),'source_sha256':{str(p):digest(p) for p in [BCI_CODE,NGUYEN_CODE]}}
 write('protocol.json',protocol)
 q=np.array([[1.,0.],[.8,.6],[.6,-.8]])
 qa=np.array([[1.,0.],[.8,.6],[.6,.8]])
 labels=np.eye(3)
 examples=[]
 for name,z in [('supports_less_similar',q),('supports_more_similar',qa)]:
  k=kernel(z);b,c,d=operators(k)
  refit=k[0,1:]@np.linalg.solve(k[1:,1:]+.1*np.eye(2),labels[1:])
  assert np.allclose(c[0]@labels,refit,atol=1e-12)
  examples.append({'case':name,'query_support_kernels':k[0,1:].tolist(),
   'support_mutual_kernel':float(k[1,2]),'nw_weights':d[0,1:].tolist(),
   'krr_weights':c[0,1:].tolist(),'krr_refit_max_error':float(abs(c[0]@labels-refit).max())})
 assert np.array_equal(np.array(examples[0]['query_support_kernels']),np.array(examples[1]['query_support_kernels']))
 assert np.array_equal(np.array(examples[0]['nw_weights']),np.array(examples[1]['nw_weights']))
 assert min(examples[1]['krr_weights'])<0
 env=source_function(BCI_CODE,['kernel','ridge_fit'],{'torch':torch,'F':F,'CFG':{'kernel_gamma':2.,'ridge':.1}})
 target=torch.tensor([0,1,2])
 actual=env['ridge_fit'](torch.from_numpy(qa),target)[1].double().numpy()
 expected=operators(kernel(qa))[1]@np.eye(5)[target.numpy()]
 error_main=float(abs(actual-expected).max());assert error_main<1e-7
 env2=source_function(NGUYEN_CODE,['ridge'],{'torch':torch,'F':F})
 actual2=env2['ridge'](torch.from_numpy(qa),target).double().numpy()
 expected2=operators(kernel(qa))[1]@np.eye(3)[target.numpy()]
 error_external=float(abs(actual2-expected2).max());assert error_external<1e-7
 # Fixed feature self-label cancellation, independent of learned encoder origin.
 _,c,_=operators(kernel(qa));changed=np.eye(3).copy();changed[0]=[0,1,0]
 assert np.array_equal((c@np.eye(3))[0],(c@changed)[0])
 rows=[]
 for kind,subjects in [('main',range(15)),('external',range(1,7))]:
  for s in subjects:
   for fold in range(5):
    name=f'{s}-fold{fold}' if kind=='main' else f'sub{s:02d}_fold{fold}'
    p=CACHE/kind/'loo'/(name+'.npz')
    with np.load(p) as z:
     tr=z['train_idx'];te=z['test_idx'];assert not set(tr)&set(te)
     regional=torch.from_numpy(z['regional'][tr]).float().flatten(1)
     cls=torch.from_numpy(z['cls'][tr]).float()
     r=F.normalize(torch.asinh(regional),dim=1).double().numpy()
     h=F.normalize(cls,dim=1).double().numpy()
    joint=np.concatenate([r,h],axis=1)/np.sqrt(2.)
    k=kernel(joint);b,c,d=operators(k)
    product=np.exp(-(1-r@r.T))*np.exp(-(1-h@h.T))
    product_error=float(abs(k-product).max());assert product_error<1e-12
    mask=~np.eye(len(k),dtype=bool)
    off=c[mask]
    targets=np.eye(5 if kind=='main' else 3)[np.arange(len(k))%(5 if kind=='main' else 3)]
    errors=[]
    for i in [0,len(k)//2,len(k)-1]:
     keep=np.arange(len(k))!=i
     refit=k[i,keep]@np.linalg.solve(k[np.ix_(keep,keep)]+.1*np.eye(keep.sum()),targets[keep])
     errors.append(float(abs(refit-(c@targets)[i]).max()))
    assert max(errors)<1e-10
    row={'dataset':kind,'subject':s,'fold':fold,'training_samples':len(k),'cache_sha256':digest(p),
         'negative_fraction':float((off<-1e-10).mean()),'negative_min':float(off.min()),
         'positive_max':float(off.max()),'row_sum_min':float(c.sum(1).min()),
         'row_sum_max':float(c.sum(1).max()),'row_sum_deviation_mean':float(abs(c.sum(1)-1).mean()),
         'NW_negative_weights':int((d[mask]<0).sum()),'NW_row_sum_max_error':float(abs(d.sum(1)-1).max()),
         'self_label_coefficient_max':float(abs(c.diagonal()).max()),
         'three_refits_max_error':max(errors),'kernel_product_max_error':product_error,
         'kernel_condition_number':float(np.linalg.cond(k+.1*np.eye(len(k))))}
    rows.append(row)
  print('OPERATOR_CHECKED',kind,s,flush=True)
 groups={}
 for kind in ['main','external']:
  rr=[r for r in rows if r['dataset']==kind]
  groups[kind]={'folds':len(rr),'folds_with_negative_weights':sum(r['negative_fraction']>0 for r in rr),
   'mean_negative_fraction':float(np.mean([r['negative_fraction'] for r in rr])),
   'maximum_absolute_negative':float(max(-r['negative_min'] for r in rr)),
   'max_refit_error':max(r['three_refits_max_error'] for r in rr)}
 write('算子数值核验.json',{'complete':len(rows)==105,'seconds':time.time()-started,
   'toy':examples,'actual_source_max_error':{'BCI':error_main,'Nguyen':error_external},
   'datasets':groups,'folds':rows,
   'limits':'Standard KRR properties, not new invention. Coefficient signs do not establish redundancy rejection, noise robustness, biological meaning or performance advantage over DWAC-style supervision. Frozen-representation LOO does not remove the query label from encoder training. No EEG model training or benchmark evaluation.'})
 print(json.dumps(groups),flush=True)

if __name__=='__main__':main()
