from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parent
for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:args=p.joinpath('cmdline').read_bytes().split(b'\0')
    except OSError:continue
    if str(ROOT/'priority_queue.py').encode() in args:
        print('PRIORITY_QUEUE_ALREADY_RUNNING',p.name);raise SystemExit(0)
subprocess.run([sys.executable,str(ROOT/'launch_priority_queue.py')],check=True)
