import urllib.request,json,re
from pathlib import Path
root=Path('/root/FAST/experiments/nature_stage_20261002')
files=[]
for subject in ['015','018']:
 name=f'sub{int(subject)}_sess1_50_ica_eeg.fif';path=f'derivatives/preprocessed/sub-{subject}/ses-01/eeg/{name}'
 link=urllib.request.urlopen('https://raw.githubusercontent.com/OpenNeuroDatasets/ds004306/main/'+path,timeout=35).read().decode()
 m=re.search(r'SHA256E-s(\d+)--([a-f0-9]{64})',link);assert m,(path,link)
 size=int(m.group(1));sha=m.group(2);url='https://s3.amazonaws.com/openneuro.org/ds004306/'+path
 req=urllib.request.Request(url,headers={'Range':'bytes=0-0','User-Agent':'EEG-research'})
 with urllib.request.urlopen(req,timeout=35) as response:
  assert response.status==206 and response.headers['Content-Range']==f'bytes 0-0/{size}'
  response.read(1)
 files.append(dict(subject=subject,session='01',filename=name,path=path,url=url,size=size,sha256=sha))
report=dict(subjects=files,selection='Next two lexicographically ordered participants after sub-011 whose session-01 preprocessed FIF has no -1 split dependency: sub-015, sub-018. Selected from repository file inventory before any results in those participants.',methods=['ce','additive','protected'],fits_per_subject=90,epochs=200,seed=42,changes='Only subject/file identity and dataset output directory; same event pairing, geometry rule, preprocessing, folds, normalization, model and training settings as sub-011.',all_results_reported=True,total_bytes=sum(f['size'] for f in files))
(root/'multicue_extension_manifest.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
