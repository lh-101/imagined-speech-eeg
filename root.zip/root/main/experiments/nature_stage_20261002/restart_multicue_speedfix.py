from pathlib import Path
import os,signal,time,json,subprocess
root=Path('/root/FAST/experiments/nature_stage_20261002');out=root/'multicue_extension_20261003'
status=json.loads((out/'status.json').read_text());launch=json.loads((out/'launch.json').read_text());pid=launch['pid']
if status['state']!='waiting_for_download':raise RuntimeError('Do not interrupt an active training stage')
cmd=Path(f'/proc/{pid}/cmdline').read_bytes().decode().replace('\x00',' ')
if 'multicue_extension_queue.py' not in cmd:raise RuntimeError('PID identity mismatch')
os.kill(pid,signal.SIGTERM)
for _ in range(30):
 if not Path(f'/proc/{pid}').exists():break
 time.sleep(.2)
else:raise RuntimeError('Old queue has not exited')
status['restart_reason']='Transport improvement: persistent sessions and 32 workers; verified chunks preserved'
(out/'status_before_speedfix.json').write_text(json.dumps(status,indent=2));status['state']='failed';(out/'status.json').write_text(json.dumps(status,indent=2))
subprocess.run([str(root/'data_env/bin/python'),str(root/'launch_multicue_extension.py')],check=True)
