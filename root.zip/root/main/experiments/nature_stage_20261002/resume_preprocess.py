from pathlib import Path
import json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
try:
    subprocess.run([sys.executable,str(ROOT/'preprocess_inner.py')],check=True,
        env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
    print('PREPROCESS_RESUME_SUCCESS',flush=True)
except Exception as e:
    p=ROOT/'inner_data_failure.json';tmp=p.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(dict(state='failed',error=repr(e),updated=time.time())));tmp.replace(p)
    raise
