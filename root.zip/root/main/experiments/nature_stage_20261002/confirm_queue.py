"""Resumable frozen-cohort download, prepare, train and report queue."""
import os
os.environ['OMP_NUM_THREADS']='4';os.environ['OPENBLAS_NUM_THREADS']='2'
from pathlib import Path
import concurrent.futures,fcntl,hashlib,json,queue,re,requests,shutil,subprocess,sys,threading,time,traceback
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'multicue_confirm_20261003';DATA=Path('/root/autodl-tmp/eeg_research/multicue_confirm_20261003')
DATA.mkdir(parents=True,exist_ok=True)
MAN=json.loads((OUT/'protocol.json').read_text());CHUNK=1024*1024;WORKERS=128;SESSION=threading.local()

def atomic(p,x):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(x,indent=2));t.replace(p)

def download(meta,subject):
 folder=DATA/('sub-'+subject);folder.mkdir(exist_ok=True)
 target=folder/meta['filename'];parts=folder/(meta['filename']+'.parts');parts.mkdir(exist_ok=True)
 size=meta['size'];start=time.time();stat=OUT/f'download_{subject}_{meta["filename"]}.json'
 def update(**kw):
  status.update(kw);status['updated']=time.time();atomic(stat,status)
 status=dict(subject=subject,filename=meta['filename'],size=size,pid=os.getpid(),started=start,state='starting')
 def fetch(indices):
  lo=min(indices)*CHUNK;hi=min(size,(max(indices)+1)*CHUNK)-1
  for attempt in range(6):
   try:
    if time.time()-start>10800:raise TimeoutError('3h per-file invocation cap')
    if not hasattr(SESSION,'client'):SESSION.client=requests.Session()
    request_start=time.monotonic()
    with SESSION.client.get(meta['url'],headers={'Range':f'bytes={lo}-{hi}','User-Agent':'EEG-research'},stream=True,timeout=(10,10)) as r:
     assert r.status_code==206 and r.headers['Content-Range']==f'bytes {lo}-{hi}/{size}'
     payload=bytearray()
     for piece in r.iter_content(16384):
      payload.extend(piece)
      if time.monotonic()-request_start>120:raise TimeoutError('Range request wall-time cap120s')
    assert len(payload)==hi-lo+1
    completed=0
    for i in indices:
     left=i*CHUNK;right=min(size,(i+1)*CHUNK)
     p=parts/f'chunk_{i:04d}';tmp=p.with_suffix('.tmp')
     tmp.write_bytes(payload[left-lo:right-lo]);tmp.replace(p);completed+=right-left
    return completed
   except Exception:
    if attempt==5:raise
    time.sleep(2+attempt)
 if not target.exists():
  if shutil.disk_usage(DATA).free<2*size+3*1024**3:raise RuntimeError('Download free-space reserve insufficient; no historical files deleted')
  count=(size+CHUNK-1)//CHUNK;missing=[];done=0
  for i in range(count):
   p=parts/f'chunk_{i:04d}';expected=min(CHUNK,size-i*CHUNK)
   if p.exists() and p.stat().st_size==expected:done+=expected
   else:missing.append(i)
  baseline=done;transfer=time.time();update(state='downloading',downloaded_bytes=done,percent=100*done/size,workers=WORKERS)
  batches={}
  for i in missing:batches.setdefault(i,[]).append(i)
  with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as pool:
   upcoming=iter(batches.values());pending={pool.submit(fetch,next(upcoming)) for _ in range(min(WORKERS,len(batches)))}
   while pending:
    finished,pending=concurrent.futures.wait(pending,return_when=concurrent.futures.FIRST_COMPLETED)
    for f in finished:
     done+=f.result();i=next(upcoming,None)
     if i is not None:pending.add(pool.submit(fetch,i))
    rate=(done-baseline)/max(1,time.time()-transfer)
    update(downloaded_bytes=done,percent=100*done/size,bytes_per_second=rate,eta_seconds=(size-done)/rate if rate else None)
  update(state='assembling')
  with target.open('wb') as f:
   for i in range(count):
    with (parts/f'chunk_{i:04d}').open('rb') as g:shutil.copyfileobj(g,f,CHUNK)
 update(state='verifying')
 h=hashlib.sha256()
 with target.open('rb') as f:
  for b in iter(lambda:f.read(8*CHUNK),b''):h.update(b)
 assert target.stat().st_size==size and h.hexdigest()==meta['sha256'],'Published source checksum mismatch'
 for p in parts.glob('chunk_[0-9][0-9][0-9][0-9]'):p.unlink()
 if not any(parts.iterdir()):parts.rmdir()
 update(state='complete',sha256=h.hexdigest(),downloaded_bytes=size,percent=100,elapsed_seconds=time.time()-start)
 return target

def replace_exact(text,old,new):
 assert old in text,('Template changed',old[:120]);return text.replace(old,new)

def adapt(meta):
 sub=meta['subject'];folder=OUT/('sub-'+sub);folder.mkdir(exist_ok=True)
 target=DATA/('sub-'+sub)/meta['files'][0]['filename']
 pilot=(ROOT/'multicue_pilot.py').read_text()
 block=pilot[pilot.index('    rows=[]; pair=-1;'):pilot.index('    bands=[(1,4)')]
 block='\n'.join(line[4:] if line.startswith('    ') else line for line in block.splitlines())
 audit=folder/'multicue_pilot_20261003';audit.mkdir(exist_ok=True)
 prefix="import mne,json\nfrom pathlib import Path\nROOT=Path(__file__).resolve().parent/'multicue_pilot_20261003'\ndef update(**kw):pass\n"
 prefix+=f"raw=mne.io.read_raw_fif({str(target)!r},preload=False,verbose='ERROR')\npicks=mne.pick_types(raw.info,eeg=True,exclude='bads')\n"
 prefix+=f"expected={sorted(f['filename'] for f in meta['files'])!r}\nassert sorted(Path(p).name for p in raw.filenames)==expected, (raw.filenames,expected)\n"
 (folder/'audit_events.py').write_text(prefix+block)
 prepare=(ROOT/'prepare_fast.py').read_text()
 prepare=replace_exact(prepare,'/root/autodl-tmp/eeg_research/multicue_pilot_20261003/sub11_sess1_50_ica_eeg.fif',str(target))
 prepare=replace_exact(prepare,'7aec12c9473ad10508a1d0c25363bfe92866c924d9f92debdb206d01b4b5ec26',meta['files'][0]['sha256'])
 prepare+="\natomic(OUT/'source_files.json',"+repr(meta)+")\n"
 (folder/'prepare_fast.py').write_text(prepare)
 run=(ROOT/'run_fast.py').read_text()
 run=replace_exact(run,"TASKS=['imagination','perception'];MODS=['audio','text','image']","TASKS=['perception'];MODS=['text']")
 run=replace_exact(run,'for t in TASKS:',"for t in ['imagination','perception']:")
 run=replace_exact(run,'for dest in MODS:',"for dest in ['audio','text','image']:")
 run=replace_exact(run,'90','15')
 run=replace_exact(run,'sub-011','sub-'+sub)
 run=replace_exact(run,"session='01'","session="+repr(meta['session']))
 run=replace_exact(run,'Equal average of three within-imagination modality accuracies; protected-minus-CE; additive comparator reported separately','Perception-text to imagination-image pooled balanced accuracy; additive/protected-minus-CE, all fixed validation participants')
 run=replace_exact(run,'Within-imagination mean across audio/text/image: protected minus CE','Perception-text to imagination-image balanced accuracy; additive/protected minus CE')
 run=replace_exact(run,"'one subject and one frozen seed'","'One frozen seed; this record is one of nine fixed unobserved validation participants'")
 run=replace_exact(run,'Exploratory new dataset, no test-based checkpoint selection or hyperparameter search. Downloaded recording selected before classification. Pilot spectral results are already known; this is not a blind confirmatory study.','Prespecified validation in remaining public participants after three-participant discovery. No test-based selection or hyperparameter search; local plan, not registered. See parent protocol.json.')
 run=replace_exact(run,"model.eval();pred=[];probs=[]","model.eval();pred=[];probs=[];representations=[]")
 run=replace_exact(run,"a=model(torch.from_numpy(xx[batch]).cuda());pred.extend(a.argmax(1).cpu().tolist());probs.extend(a.float().softmax(1).cpu().tolist())","a,qe=v4.representation(model,torch.from_numpy(xx[batch]).cuda());pred.extend(a.argmax(1).cpu().tolist());probs.extend(a.float().softmax(1).cpu().tolist());representations.extend(qe.float().cpu().tolist())")
 run=replace_exact(run,'prob=np.array(probs),test_index=test','prob=np.array(probs),representation=np.array(representations,dtype=np.float32),test_index=test')
 (folder/'run_fast.py').write_text(run)
 atomic(folder/'template_changes.json',dict(source_condition_only=True,actual_source_and_template_files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'run_fast.py',ROOT/'prepare_fast.py',ROOT/'multicue_pilot.py',folder/'run_fast.py',folder/'prepare_fast.py']},frozen_protocol_sha256=hashlib.sha256((OUT/'protocol.json').read_bytes()).hexdigest()))
 return folder

def main():
 lf=(OUT/'queue.lock').open('w');fcntl.flock(lf,fcntl.LOCK_EX|fcntl.LOCK_NB)
 remaining=sum(f['size'] for m in MAN['cohort'] for f in m['files'] if not (DATA/('sub-'+m['subject'])/f['filename']).exists())
 assert shutil.disk_usage(DATA).free>remaining+7*1024**3,'Need room for retained raw, caches and new models; do not delete existing results'
 ready=queue.Queue();failures=[];completed=[];start=time.time()
 def downloader():
  for m in MAN['cohort']:
   try:
    for f in m['files']:download(f,m['subject'])
    ready.put((m,None))
   except Exception as e:
    atomic(OUT/f"download_failure_{m['subject']}.json",dict(error=str(e),traceback=traceback.format_exc()));ready.put((m,str(e)))
 thread=threading.Thread(target=downloader,daemon=False);thread.start()
 for _ in MAN['cohort']:
  atomic(OUT/'status.json',dict(state='waiting_for_download',pid=os.getpid(),started=start,updated=time.time(),completed_subjects=completed,failures=failures))
  m,error=ready.get();sub=m['subject']
  if error:failures.append(dict(subject=sub,phase='download',error=error));continue
  try:
   folder=adapt(m)
   with (folder/'pipeline.log').open('ab') as log:
    for phase,python,script in [('event_audit',ROOT/'data_env/bin/python','audit_events.py'),('preparing',ROOT/'data_env/bin/python','prepare_fast.py'),('training',Path('/root/venv_fast/bin/python'),'run_fast.py'),('spectral_reference',ROOT/'data_env/bin/python',str(ROOT/'confirm_analyze.py'))]:
     atomic(OUT/'status.json',dict(state=phase,subject=sub,pid=os.getpid(),started=start,updated=time.time(),completed_subjects=completed,failures=failures))
     args=[str(python),'-u',str(folder/script)] if phase!='spectral_reference' else [str(python),'-u',script,'--subject',sub]
     subprocess.run(args,cwd=str(folder),stdout=log,stderr=subprocess.STDOUT,check=True)
   completed.append(sub);print('VALIDATION_SUBJECT_COMPLETE',sub,flush=True)
  except Exception as e:
   failures.append(dict(subject=sub,phase='pipeline',error=str(e)));print('VALIDATION_SUBJECT_FAILED',sub,str(e),flush=True)
 thread.join()
 atomic(OUT/'status.json',dict(state='analyzing',pid=os.getpid(),started=start,updated=time.time(),completed_subjects=completed,failures=failures))
 with (OUT/'analysis.log').open('ab') as log:
  subprocess.run([str(ROOT/'data_env/bin/python'),'-u',str(ROOT/'confirm_analyze.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic(OUT/'status.json',dict(state='complete' if not failures else 'complete_with_failures',pid=os.getpid(),started=start,updated=time.time(),elapsed_seconds=time.time()-start,completed_subjects=completed,failures=failures))

if __name__=='__main__':
 try:main()
 except Exception as e:atomic(OUT/'status.json',dict(state='failed',error=str(e),traceback=traceback.format_exc()));raise
