import os
os.environ['OMP_NUM_THREADS']='4'
from pathlib import Path
import sys,json,time,traceback
import numpy as np,torch
from torch.nn import functional as F
from sklearn.metrics import accuracy_score,f1_score
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'multicue_fast_20261003';DEST=OUT/'diagnostics';DEST.mkdir(exist_ok=True)
sys.path[:0]=[str(ROOT),'/root/FAST','/root/FAST/experiments/residual_20260925']
import run_fast as study
from transformers import PretrainedConfig
START=time.time()
def save(name,o):
 p=DEST/name;t=p.with_suffix('.tmp');t.write_text(json.dumps(o,indent=2));t.replace(p)
def main():
 assert json.loads((OUT/'status.json').read_text())['state']=='complete'
 torch.set_num_threads(4)
 with np.load(OUT/'epochs.npz') as z:X=z['X'];y=z['y'];pair=z['pair'];groups=z['groups']
 rows=[];files=sorted((OUT/'results').glob('*.pt'));assert len(files)==90
 save('status.json',dict(state='running',done=0,total=90,pid=os.getpid()))
 for i,p in enumerate(files):
  ck=torch.load(p,map_location='cpu');info=json.loads(p.with_suffix('.json').read_text());tr=ck['train'];te=ck['test'];assert not set(pair[tr])&set(pair[te]);assert not set(groups[tr])&set(groups[te])
  m=study.v4.FAST(PretrainedConfig(**ck['config'])).cuda().eval();m.load_state_dict(ck['state_dict']);xx=((X-ck['mean'])/ck['std']).astype(np.float32)
  with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):
   a,q=study.v4.representation(m,torch.from_numpy(xx[tr]).cuda());target=torch.from_numpy(y[tr]).cuda();la=study.loo(q,target)
   train_acc=float((a.argmax(1)==target).float().mean());train_ce=float(F.cross_entropy(a,target));loo_acc=float((la.argmax(1)==target).float().mean());loo_ce=float(F.cross_entropy(4*la,target))
   pred=[]
   for batch in np.array_split(te,max(1,(len(te)+63)//64)):pred.extend(m(torch.from_numpy(xx[batch]).cuda()).argmax(1).cpu().tolist())
  with np.load(p.with_suffix('.npz')) as z:
   mismatch=int(np.sum(np.array(pred)!=z['pred']));assert mismatch==0
   # The diagonal target condition, not all six target conditions pooled.
   keep=(z['target_tasks']==info['source_task'])&(z['target_modalities']==info['modality'])
   test_acc=float(accuracy_score(z['y'][keep],z['pred'][keep]))
  rows.append(dict(name=p.stem,task=info['source_task'],modality=info['modality'],method=info['method'],fold=info['fold'],train_accuracy=train_acc,train_cross_entropy=train_ce,loo_train_accuracy=loo_acc,loo_train_cross_entropy=loo_ce,test_accuracy=test_acc,replay_mismatches=mismatch,initial_main_loss=info['trace'][0]['main_loss'],final_main_loss=info['trace'][-1]['main_loss'],initial_aux_loss=info['trace'][0]['aux_loss'],final_aux_loss=info['trace'][-1]['aux_loss']))
  save('status.json',dict(state='running',done=i+1,total=90,pid=os.getpid(),elapsed_seconds=time.time()-START))
  del m,a,q,la,ck;torch.cuda.empty_cache()
 aggregated=[]
 for task in study.TASKS:
  for mod in study.MODS:
   for method in study.METHODS:
    rr=[r for r in rows if r['task']==task and r['modality']==mod and r['method']==method];assert len(rr)==5
    aggregated.append(dict(task=task,modality=mod,method=method,**{k:float(np.mean([r[k] for r in rr])) for k in ['train_accuracy','train_cross_entropy','loo_train_accuracy','test_accuracy','initial_main_loss','final_main_loss']}))
 save('summary.json',dict(complete=True,rows=rows,groups=aggregated,replay_mismatches=sum(r['replay_mismatches'] for r in rows),note='Training predictions and fixed-checkpoint replay only; no retraining, hyperparameter selection or new independent evaluation. Fold-mean test numbers here may differ from pooled out-of-fold primary summary. LOO here is a training diagnostic, not unbiased performance.'))
 save('status.json',dict(state='complete',done=90,total=90,elapsed_seconds=time.time()-START))
 print(json.dumps(aggregated,indent=2),flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:save('status.json',dict(state='failed',error=str(e),traceback=traceback.format_exc()));raise
