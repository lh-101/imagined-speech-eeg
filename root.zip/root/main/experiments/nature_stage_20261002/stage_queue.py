"""One-shot sequential GPU queue for explicitly authorized experiments."""
from pathlib import Path
import os,sys,json,time,subprocess,fcntl
ROOT=Path(__file__).resolve().parent
PY='/root/venv_fast/bin/python'
def atomic(p,obj):
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(obj,indent=2));tmp.replace(p)
def read(p):return json.loads(p.read_text()) if p.exists() else {}
def status(phase,**kw):atomic(ROOT/'queue_status.json',dict(state='running',pid=os.getpid(),phase=phase,updated=time.time(),**kw))
def run(script,log,python=PY,args=()):
    with (ROOT/log).open('a') as out:
        child=subprocess.Popen([python,'-u',str(ROOT/script),*args],cwd='/root/FAST',stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,
          env=dict(os.environ,OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',PYTHONUNBUFFERED='1'))
        status(str(script),child_pid=child.pid,log=log)
        ret=child.wait()
        if ret:raise RuntimeError(f'{script} exited {ret}; see {log}')
def main():
    with (ROOT/'queue.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            cpu=None
            while True:
                data=read(ROOT/'inner_prepared/prepare_status.json');core=read(ROOT/'core/status.json')
                if read(ROOT/'inner_data_failure.json').get('state')=='failed':raise RuntimeError('Data preparation failed; see inner_data_failure.json')
                if core.get('state')=='failed':raise RuntimeError('Core training failed; see core/status.json')
                if data.get('state')=='complete' and cpu is None and not (ROOT/'cpu_controls/results.json').exists():
                    log=(ROOT/'cpu_controls.log').open('a')
                    cpu=subprocess.Popen([PY,'-u',str(ROOT/'run_cpu_controls.py')],cwd='/root/FAST',stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,
                       env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTHONUNBUFFERED='1'))
                    log.close()
                status('waiting_core_and_data',core_state=core.get('state'),data_state=data.get('state'),cpu_pid=cpu.pid if cpu else None)
                if data.get('state')=='complete' and core.get('state')=='complete':break
                # Core owns this GPU until every prescribed fold is complete.
                time.sleep(30)
            run('run_inner_study.py','inner_smoke.log',python=str(ROOT/'data_env/bin/python'),args=['--smoke'])
            run('run_inner_study.py','inner_training.log',python=str(ROOT/'data_env/bin/python'))
            run('run_signal_controls.py','signal_training.log')
            if cpu is not None and cpu.wait()!=0:raise RuntimeError('CPU signal controls failed; see cpu_controls.log')
            atomic(ROOT/'queue_status.json',dict(state='complete',pid=os.getpid(),updated=time.time()))
            print('ALL_PLANNED_STAGES_COMPLETE',flush=True)
        except Exception as e:
            atomic(ROOT/'queue_status.json',dict(state='failed',error=repr(e),pid=os.getpid(),updated=time.time()));raise
if __name__=='__main__':main()
