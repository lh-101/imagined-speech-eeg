"""Read-only inventory of the cloned experiment and storage."""
from pathlib import Path
import json
import os
import shutil
import subprocess

ROOT = Path('/root/FAST/experiments/nature_stage_20261002')
for path in ['/root/FAST', '/root/autodl-tmp', '/root/autodl-fs', '/root', '/tmp']:
    p = Path(path)
    if p.exists():
        u = shutil.disk_usage(p)
        print('DISK', path, 'resolved', p.resolve(), json.dumps(dict(total=u.total, used=u.used, free=u.free)))
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit() or int(proc.name) == os.getpid():
        continue
    try:
        args = proc.joinpath('cmdline').read_bytes().decode(errors='replace').replace('\0', ' ')
        if '/root/FAST' in args or 'aria2' in args or 'wget' in args:
            print('PROCESS', proc.name, args)
    except OSError:
        pass
for rel in ['core/status.json', 'core/summary.json', 'inner_data/download_status.json',
            'queue_status.json', 'pause_record.json', 'inner_data_failure.json']:
    p = ROOT / rel
    if p.exists():
        obj = json.loads(p.read_text())
        if rel == 'core/summary.json':
            obj = {'complete': obj.get('complete'), 'runs': [{k: r.get(k) for k in ['job','complete','n_subjects','means']} for r in obj.get('runs', [])]}
        print('STATUS', rel, json.dumps(obj)[:14000])
data = ROOT / 'inner_data'
if data.exists():
    files = list(data.rglob('*'))
    print('DATA_BYTES', sum(p.stat().st_size for p in files if p.is_file()))
    print('PART_FILES', [(str(p.relative_to(data)), p.stat().st_size) for p in files if p.name.endswith('.part')])
for args in [['nvidia-smi'], ['df', '-h'],
             ['du', '-x', '-B1', '--max-depth=1', '/root/autodl-tmp'],
             ['du', '-x', '-B1', '--max-depth=1', '/root/.cache']]:
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=70)
        print('COMMAND', args, '\n', r.stdout, r.stderr)
    except (OSError, subprocess.TimeoutExpired) as e:
        print('COMMAND_ERROR', args, repr(e))
