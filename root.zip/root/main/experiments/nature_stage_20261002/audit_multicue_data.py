"""Bounded public metadata audit; no EEG payloads or model fitting."""
import json, pathlib, urllib.request, time, traceback
ROOT = pathlib.Path(__file__).resolve().parent / 'multicue_audit_20261003'
ROOT.mkdir(exist_ok=True)
def get(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'EEG-research-metadata-audit'})
    with urllib.request.urlopen(req, timeout=35) as r:
        data = r.read(12_000_001)
    if len(data)>12_000_000: raise ValueError('Metadata limit exceeded')
    return data
report={'started':time.time(),'sources':{},'errors':{},'state':'running'}
def save():
    (ROOT/'status.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
save()
for repo in ['OpenNeuroDatasets/ds004306','hWils/Semantics-EEG-Perception-and-Imagination']:
    try:
        info=json.loads(get('https://api.github.com/repos/'+repo))
        branch=info['default_branch']
        tree=json.loads(get('https://api.github.com/repos/'+repo+'/git/trees/'+branch+'?recursive=1'))
        name=repo.split('/')[-1]
        (ROOT/(name+'_tree.json')).write_text(json.dumps(tree,indent=2))
        entries=[x for x in tree['tree'] if x['type']=='blob']
        selected=[x for x in entries if x['path'].endswith(('_events.tsv','_events.json','_channels.tsv','_eeg.json')) or x['path'] in ['README','README.md','participants.tsv','dataset_description.json','epoch-save.ipynb','convert_bids.ipynb']]
        # Sample one recording's event/channel metadata, all task dictionaries and processing code.
        seen=set(); chosen=[]
        for x in selected:
            p=x['path']; typ=next((s for s in ['_events.tsv','_channels.tsv','_eeg.json'] if p.endswith(s)),None)
            if typ and typ in seen: continue
            if typ: seen.add(typ)
            if x.get('size',0)>3_000_000: continue
            chosen.append(x)
        dest=ROOT/name; dest.mkdir(exist_ok=True)
        for x in chosen:
            data=get('https://raw.githubusercontent.com/'+repo+'/'+branch+'/'+x['path'])
            (dest/x['path'].replace('/','__')).write_bytes(data)
        report['sources'][repo]={'branch':branch,'commit_tree':tree.get('sha'),'truncated':tree.get('truncated'),'total_files':len(entries),'fetched_metadata':[x['path'] for x in chosen],'data_paths':[x for x in entries if x['path'].endswith(('.fif','.set','.fdt','.vhdr','.eeg','.edf','.cnt','.npy','.npz'))]}
    except Exception:
        report['errors'][repo]=traceback.format_exc()
    save()
report['state']='complete'; report['finished']=time.time(); save()
print(json.dumps(report,indent=2))
