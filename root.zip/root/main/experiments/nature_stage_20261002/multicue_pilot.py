"""Frozen single-participant cross-modal feasibility job, not confirmatory evidence."""
import os
os.environ['OMP_NUM_THREADS']='2'
os.environ['OPENBLAS_NUM_THREADS']='2'
import concurrent.futures, hashlib, json, pathlib, re, time, urllib.request, shutil
ROOT=pathlib.Path(__file__).resolve().parent/'multicue_pilot_20261003'
ROOT.mkdir(exist_ok=True)
DATA=pathlib.Path('/root/autodl-tmp/eeg_research/multicue_pilot_20261003')
DATA.mkdir(parents=True,exist_ok=True)
PATH='derivatives/preprocessed/sub-011/ses-01/eeg/sub11_sess1_50_ica_eeg.fif'
SIZE=1898906210
SHA='7aec12c9473ad10508a1d0c25363bfe92866c924d9f92debdb206d01b4b5ec26'
URL='https://s3.amazonaws.com/openneuro.org/ds004306/'+PATH
CHUNK=1024*1024
WORKERS=16
START=time.time()
status={'state':'starting','started':START,'pid':os.getpid(),'expected_bytes':SIZE}
def update(**values):
    status.update(values); status['updated']=time.time()
    p=ROOT/'status.tmp'; p.write_text(json.dumps(status,indent=2)); p.replace(ROOT/'status.json')
protocol={'subject':'sub-011','session':'01','selection':'first lexicographic recording without split FIF dependency, chosen before outcomes',
 'source':URL,'expected_sha256':SHA,'primary':'imagined auditory -> imagined orthographic, 1 to 3 seconds after imagination annotation',
 'features':'log Welch power: 1-4,4-8,8-13,13-30,30-45Hz; EEG channels; per-trial spatial-centering in each band',
 'classifier':'source training StandardScaler + LogisticRegression C=1 max_iter=2000',
 'split':'5 outer GroupKFold on consecutive five perception-imagination pairs in each contiguous modality sequence; paired events and all windows remain together',
 'secondary':'3x3 imagination modality matrix; early0-1s vs late1-3s; matched 0-1s perception/imagination comparison',
 'no_target_calibration':True,'limitations':['one participant only','author full-recording ICA is transductive preprocessing','no matched maintain-only or interference condition','no independently identified EOG/EMG control guaranteed','cross-modal decoding is not itself proof of language specificity or novel semantics'],
 'pairing_amendment':'2026-10-03 before any classification: exclude only a final perception event without an imagination partner at recording end; audit exclusion; all internal pairing errors still stop',
 'failure_rule':'stop if no complete paired sequence, annotations fail parsing, missing EEG, hash mismatch, insufficient groups/classes, or disk below reserve',
 'download_budget':'one 1.9GB recording; up to 16 range workers, 3h wall cap per invocation; no whole-dataset download'}
(ROOT/'protocol.json').write_text(json.dumps(protocol,indent=2))
def request(url,headers=None):
    return urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'EEG-research',**(headers or {})}),timeout=25)
def fetch(i):
    lo=i*CHUNK; hi=min(SIZE,lo+CHUNK)-1; p=DATA/f'chunk_{i:04d}'
    if p.exists() and p.stat().st_size==hi-lo+1: return hi-lo+1
    for attempt in range(4):
        if time.time()-START>10800: raise TimeoutError('3h download cap')
        try:
            with request(URL,{'Range':f'bytes={lo}-{hi}'}) as r:
                if r.status!=206 or not r.headers.get('Content-Range','').startswith(f'bytes {lo}-{hi}/'): raise ValueError('Invalid range response')
                payload=r.read(hi-lo+2)
            if len(payload)!=hi-lo+1: raise ValueError('Incomplete chunk')
            tmp=p.with_suffix('.tmp'); tmp.write_bytes(payload); tmp.replace(p)
            return len(payload)
        except Exception as exc:
            print(f'chunk {i} attempt {attempt+1}: {type(exc).__name__}: {exc}',flush=True)
            if attempt==3: raise
            time.sleep(2+attempt*2)
def main():
    target=DATA/'sub11_sess1_50_ica_eeg.fif'
    if not target.exists():
        if shutil.disk_usage(DATA).free<2*SIZE+2*1024**3: raise RuntimeError('Insufficient free space reserve')
        count=(SIZE+CHUNK-1)//CHUNK
        missing=[]; baseline=0
        for i in range(count):
            p=DATA/f'chunk_{i:04d}'; expected=min(CHUNK,SIZE-i*CHUNK)
            if p.exists() and p.stat().st_size==expected: baseline+=expected
            else: missing.append(i)
        transfer_start=time.time()
        update(state='downloading',downloaded_bytes=baseline,resumed_bytes=baseline,workers=WORKERS,download_eta_seconds=None)
        with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as pool:
            done=baseline; upcoming=iter(missing); pending={pool.submit(fetch,next(upcoming)) for _ in range(min(WORKERS,len(missing)))}
            while pending:
                finished,pending=concurrent.futures.wait(pending,return_when=concurrent.futures.FIRST_COMPLETED)
                for f in finished:
                    done+=f.result()
                    i=next(upcoming,None)
                    if i is not None: pending.add(pool.submit(fetch,i))
                elapsed=time.time()-START
                rate=(done-baseline)/max(time.time()-transfer_start,1)
                update(downloaded_bytes=done,percent=round(done/SIZE*100,2),elapsed_seconds=elapsed,bytes_per_second=rate,download_eta_seconds=(SIZE-done)/rate if rate else None)
        update(state='assembling')
        with target.open('wb') as out:
            for i in range(count):
                with (DATA/f'chunk_{i:04d}').open('rb') as src: shutil.copyfileobj(src,out,1024*1024)
    update(state='verifying')
    h=hashlib.sha256()
    with target.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    if target.stat().st_size!=SIZE or h.hexdigest()!=SHA: raise ValueError('Published annex hash or size mismatch')
    # Remove only known chunks belonging to this job after checksum passes; retain verified FIF.
    for p in DATA.glob('chunk_[0-9][0-9][0-9][0-9]'): p.unlink()
    update(state='extracting',sha256=h.hexdigest())
    import mne, numpy as np
    from scipy.signal import welch
    from sklearn.preprocessing import StandardScaler
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import make_pipeline
    from sklearn.model_selection import GroupKFold
    from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
    raw=mne.io.read_raw_fif(target,preload=False,verbose='ERROR')
    picks=mne.pick_types(raw.info,eeg=True,exclude='bads')
    if len(picks)<20: raise ValueError('Unexpected channel count')
    rows=[]; pair=-1; modality_prev=None; sequence=-1; index_sequence=0; pending=None
    for a in raw.annotations:
        desc=a['description']; low=desc.lower()
        if 'perception' not in low and 'imagination' not in low: continue
        task='imagination' if 'imagination' in low else 'perception'
        word=next((w for w in ['flower','guitar','penguin'] if w in low),None)
        mod='audio' if ('_a_' in low or 'perceptiona_' in low or 'audio' in low) else 'text' if '_t_' in low else 'image' if '_image_' in low else None
        if not word or not mod: raise ValueError('Unrecognized task annotation: '+desc)
        if task=='perception':
            if pending is not None: raise ValueError('Missing imagination partner')
            pair+=1
            if mod!=modality_prev: sequence+=1; index_sequence=0
            group=f'{sequence}_{index_sequence//5}'; index_sequence+=1; modality_prev=mod
            pending=(word,mod,group,pair)
        elif pending is None or pending[:2]!=(word,mod): raise ValueError('Missing or mismatched perception partner')
        else: group=pending[2]; pair=pending[3]
        onset=float(a['onset'])-raw.first_time
        rows.append({'task':task,'word':word,'modality':mod,'group':group,'pair':pair,'onset':onset,'description':desc})
        if task=='imagination': pending=None
    excluded=[]
    if pending is not None:
        if not rows or rows[-1]['task']!='perception' or rows[-1]['pair']!=pending[3]:
            raise ValueError('Invalid terminal pair state')
        excluded.append({'event':rows.pop(),'reason':'Final perception has no imagination partner before recording ends'})
        pending=None
    if len(rows)<100: raise ValueError('Insufficient complete paired data')
    if len(rows)%2: raise ValueError('Odd paired event count')
    update(state='extracting_features',paired_events=len(rows),complete_pairs=len(rows)//2,excluded_terminal_events=len(excluded),features_done=0,features_total=len(rows))
    (ROOT/'event_audit.json').write_text(json.dumps({'sfreq':raw.info['sfreq'],'channels':[raw.ch_names[i] for i in picks],'bads':raw.info['bads'],'events':rows,'excluded':excluded},indent=2))
    bands=[(1,4),(4,8),(8,13),(13,30),(30,45)]; fs=raw.info['sfreq']; cache=[]; valid=[]
    for row in rows:
        vectors=[]
        for left,right in [(0,1),(1,3)]:
            # For perception audio duration is only 2s. Do not extract 1-3s there.
            if row['task']=='perception': left,right=0,1
            st=int(round((row['onset']+left)*fs)); en=int(round((row['onset']+right)*fs))
            if st<0 or en>raw.n_times: raise ValueError('Epoch outside recording')
            x=raw.get_data(picks=picks,start=st,stop=en)
            if not np.isfinite(x).all(): raise ValueError('Nonfinite EEG')
            freq,psd=welch(x,fs=fs,nperseg=int(fs),noverlap=int(fs/2),axis=-1)
            v=np.stack([np.log(np.maximum(psd[:,(freq>=a)&(freq<b)].sum(axis=-1)*(freq[1]-freq[0]),1e-30)) for a,b in bands],axis=-1)
            v-=v.mean(axis=0,keepdims=True); vectors.append(v.ravel())
        cache.append(vectors); valid.append(row)
        if len(valid)%10==0 or len(valid)==len(rows): update(features_done=len(valid),elapsed_seconds=time.time()-START)
    X=np.asarray(cache); y=np.array([['flower','guitar','penguin'].index(r['word']) for r in valid]); groups=np.array([r['group'] for r in valid]); mods=np.array([r['modality'] for r in valid]); tasks=np.array([r['task'] for r in valid])
    np.savez_compressed(ROOT/'features.npz',X=X,y=y,groups=groups,modalities=mods,tasks=tasks)
    outer=list(GroupKFold(5).split(X,y,groups)); results=[]; predictions=[]
    jobs=[('imagination',s,'imagination',t,w) for w in [0,1] for s in ['audio','text','image'] for t in ['audio','text','image']]
    jobs += [('perception',s,'imagination',t,0) for s in ['audio','text','image'] for t in ['audio','text','image']]
    update(state='evaluating',evaluations_total=len(jobs)*5,evaluations_done=0)
    for source_task,source,target_task,dest,w in jobs:
        actual=[]; predicted=[]; fold_stats=[]
        for fold,(train,test) in enumerate(outer):
            tr=train[(tasks[train]==source_task)&(mods[train]==source)]; te=test[(tasks[test]==target_task)&(mods[test]==dest)]
            if len(te)==0 or len(np.unique(y[tr]))!=3 or len(np.unique(y[te]))!=3: raise ValueError('Insufficient class coverage in grouped fold')
            model=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=2000))
            model.fit(X[tr,w],y[tr]); pred=model.predict(X[te,w])
            actual.extend(y[te].tolist()); predicted.extend(pred.tolist())
            fold_stats.append({'fold':fold,'n_train':len(tr),'n_test':len(te),'accuracy':float(accuracy_score(y[te],pred))})
            predictions.extend({'source_task':source_task,'source':source,'target':dest,'window':w,'fold':fold,'event_index':int(i),'truth':int(v),'predicted':int(p)} for i,v,p in zip(te,y[te],pred))
            update(evaluations_done=status['evaluations_done']+1)
        results.append({'source_task':source_task,'source':source,'target':dest,'window':'early0_1' if w==0 else 'late1_3','accuracy':float(accuracy_score(actual,predicted)),'macro_f1':float(f1_score(actual,predicted,average='macro',labels=[0,1,2],zero_division=0)),'confusion':confusion_matrix(actual,predicted,labels=[0,1,2]).tolist(),'folds':fold_stats})
    (ROOT/'summary.json').write_text(json.dumps({'protocol':protocol,'results':results,'interpretation':'Single-subject feasibility only; no causal or population inference; no outcome-based tuning.'},indent=2))
    (ROOT/'predictions.json').write_text(json.dumps(predictions))
    update(state='complete',elapsed_seconds=time.time()-START)
if __name__=='__main__':
    try: main()
    except Exception as exc:
        import traceback
        update(state='failed',error=str(exc),traceback=traceback.format_exc())
        raise
