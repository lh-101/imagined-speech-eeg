from pathlib import Path
import json,time,argparse,statistics,datetime
R=Path(__file__).resolve().parent/'validation_20261003'
def read(p):
    try:return json.loads(p.read_text())
    except (OSError,ValueError):return {}
def show():
    s=read(R/'status.json');rows=[read(p) for p in R.glob('gpu/fast/*/*_base.json')];n=len(rows)
    print('Time-origin validation | state:',s.get('state'),'| phase:',s.get('phase'),'| pid:',s.get('pid'))
    print('Corrected-window GPU fits:',n,'/60',f'({n/60*100:.1f}%)')
    print('CPU completed subjects:',read(R/'cpu_results.json').get('completed_subjects',0),'/10')
    print('Current subject/session/method:',s.get('subject'),s.get('held_session'),s.get('method'))
    seconds=0
    for m,default in [('ce',30),('loo',55)]:
        a=[r['seconds'] for r in rows if r.get('method')==m];speed=statistics.median(a) if a else default
        seconds+=(30-len(a))*speed
    print('Approx GPU time remaining:',round(seconds/60,1),'minutes; preprocessing/CPU checks excluded')
    if s.get('error'):print('ERROR:',s['error'])
    for g in read(R/'gpu_summary.json').get('groups',[]):print(g['method'],g['n_fits'],'fits; complete-subject mean:',g['mean_accuracy'])
def main():
    a=argparse.ArgumentParser();a.add_argument('--watch',action='store_true');args=a.parse_args()
    try:
        while True:
            if args.watch:print('\033[2J\033[H',end='')
            show()
            if not args.watch:return
            time.sleep(5)
    except KeyboardInterrupt:print('Display stopped; jobs continue.')
if __name__=='__main__':main()
