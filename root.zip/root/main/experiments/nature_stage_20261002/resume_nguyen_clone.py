"""Resume frozen Nguyen replay after clone; verify data and completion markers."""
import os,json,time,fcntl
import numpy as np
from sklearn.model_selection import StratifiedKFold
import run_nguyen_external as r
def main():
    with (r.OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        old=json.loads((r.OUT/'status.json').read_text())
        protocol=json.loads((r.OUT/'protocol.json').read_text())
        try:
            r.atomic(r.OUT/'status.json',dict(state='running',phase='clone_resume_audit',pid=os.getpid(),started=time.time()))
            for name,value in protocol['source_hashes'].items():assert r.digest(r.ROOT/name)==value,('Source changed',name)
            assert r.digest(r.DATA/'Short_words.zip','md5')==r.MD5,'Archive integrity failed'
            audit=json.loads((r.OUT/'data_audit.json').read_text());geometry=json.loads((r.OUT/'geometry.json').read_text())
            verified=[]
            for row in audit['subjects']:
                s=row['subject'];p=r.DATA/'extracted'/f'sub-{s:02d}.mat'
                assert r.digest(p)==row['mat_sha256'],('Source data changed',s)
                with np.load(r.OUT/f'sub-{s:02d}.npz') as f:
                    x=f['X'];y=f['y'];trial=f['original_trial']
                assert x.shape==(300,60,1024) and np.isfinite(x).all()
                assert np.array_equal(y,np.repeat(np.arange(3),100))
                assert np.array_equal(trial,np.arange(300))
                folds=list(StratifiedKFold(5,shuffle=True,random_state=42).split(x,y))
                split=json.loads((r.OUT/f'splits_sub{s:02d}.json').read_text()) if (r.OUT/f'splits_sub{s:02d}.json').exists() else None
                for i,(tr,ev) in enumerate(folds):
                    if split:assert split['folds'][i]==dict(train=tr.tolist(),test=ev.tolist())
                    for job in protocol['jobs']:
                        dest=r.OUT/'results'/job;name=f'sub{s:02d}_fold{i}'
                        info=dest/(name+'.json')
                        if not info.exists():continue
                        record=json.loads(info.read_text());assert record['job']==job and record['subject']==s and record['fold']==i
                        with np.load(dest/(name+'.npz')) as f:
                            assert np.array_equal(f['train'],tr) and np.array_equal(f['test'],ev)
                            assert np.array_equal(f['y'],y[ev]) and np.array_equal(f['original_trial'],trial[ev])
                            prob=f['prob'];assert prob.shape==(60,3) and np.isfinite(prob).all()
                            assert np.isclose((prob.argmax(1)==y[ev]).mean(),record['evaluation']['accuracy'])
                        if job!='spectral_logistic':assert (dest/(name+'.pt')).exists()
                        verified.append(str(info.relative_to(r.OUT)))
            r.atomic(r.OUT/'clone_resume_record.json',dict(previous_status=old,verified_complete_records=verified,
                preserved_protocol_sha256=r.digest(r.OUT/'protocol.json'),pid=os.getpid(),updated=time.time(),
                policy='Skip verified completed fits. Restart only the interrupted fit from its original seed; never claim epoch-level continuation.'))
            print('CLONE_RESUME_AUDIT_PASSED',len(verified),'completed fits preserved',flush=True)
            r.experiment(geometry)
            r.atomic(r.OUT/'status.json',dict(state='complete',updated=time.time()))
        except Exception as e:
            r.atomic(r.OUT/'status.json',dict(state='failed',error=repr(e),updated=time.time()));raise
if __name__=='__main__':main()
