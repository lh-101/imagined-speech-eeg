import pathlib,subprocess,json,time,os
root=pathlib.Path('/root/FAST/experiments/nature_stage_20261002')
status=root/'multicue_pilot_20261003/status.json'
old=json.loads(status.read_text())
if old.get('state') not in ['failed','complete']: raise RuntimeError('Existing job may still run')
(root/'multicue_pilot_20261003/status_before_pair_fix.json').write_text(json.dumps(old,indent=2))
log=(root/'multicue_pilot_pairfix.log').open('ab')
p=subprocess.Popen([str(root/'data_env/bin/python'),'-u',str(root/'multicue_pilot.py')],cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(root/'multicue_pilot_pairfix.pid').write_text(str(p.pid))
print(json.dumps({'started_pid':p.pid,'log':str(root/'multicue_pilot_pairfix.log')},indent=2))
