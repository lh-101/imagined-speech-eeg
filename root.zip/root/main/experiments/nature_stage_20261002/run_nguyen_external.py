"""Frozen external dataset replay, one complete original trial per sample."""
from pathlib import Path
import os,sys,json,time,hashlib,zipfile,concurrent.futures,threading,ast
import numpy as np,requests
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'nguyen_external_20261003'
DATA=Path('/root/autodl-tmp/eeg_research/nguyen2017_short_words')
SIZE=1645774121
MD5='39a67a381da4c897321efd0f25cffc7b'
URL='https://zenodo.org/api/records/19502794/files/Short_words.zip/content'
def atomic(p,o):
    p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(o,indent=2));t.replace(p)
def digest(p,kind='sha256'):
    h=hashlib.new(kind)
    with p.open('rb') as f:
        for x in iter(lambda:f.read(4*1024**2),b''):h.update(x)
    return h.hexdigest()
def download():
    DATA.mkdir(parents=True,exist_ok=True);p=DATA/'Short_words.zip';parts=DATA/'parts';parts.mkdir(exist_ok=True)
    if p.exists():assert p.stat().st_size==SIZE and digest(p,'md5')==MD5;return p
    step=16*1024**2;pieces=list(range(0,SIZE,step));lock=threading.Lock();done=0;started=time.time()
    def worker(start):
        nonlocal done
        end=min(SIZE,start+step)-1;dest=parts/f'{start:012d}.part'
        if not dest.exists() or dest.stat().st_size!=end-start+1:
            for attempt in range(5):
                try:
                    with requests.get(URL,headers={'Range':f'bytes={start}-{end}'},stream=True,timeout=(15,90)) as r:
                        assert r.status_code==206 and r.headers.get('Content-Range')==f'bytes {start}-{end}/{SIZE}',r.headers
                        t=dest.with_suffix('.tmp')
                        with t.open('wb') as f:
                            for b in r.iter_content(1024**2):f.write(b)
                        assert t.stat().st_size==end-start+1;t.replace(dest)
                    break
                except Exception:
                    if attempt==4:raise
                    time.sleep(2*(attempt+1))
        with lock:
            done+=end-start+1
            atomic(OUT/'download_status.json',dict(state='downloading',bytes=done,total=SIZE,seconds=time.time()-started))
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(worker,pieces))
    t=p.with_suffix('.zip.tmp')
    with t.open('wb') as f:
        for start in pieces:
            with (parts/f'{start:012d}.part').open('rb') as g:
                for b in iter(lambda:g.read(4*1024**2),b''):f.write(b)
    assert t.stat().st_size==SIZE and digest(t,'md5')==MD5;t.replace(p)
    # Remove only these verified, redundant download fragments.
    for start in pieces:(parts/f'{start:012d}.part').unlink()
    atomic(OUT/'download_status.json',dict(state='complete',bytes=SIZE,total=SIZE,md5=MD5,sha256=digest(p),seconds=time.time()-started))
    return p
def prepare(p):
    from scipy.io import loadmat
    import mne
    folder=DATA/'extracted';folder.mkdir(exist_ok=True)
    with zipfile.ZipFile(p) as z:
        inventory=[dict(name=i.filename,size=i.file_size,crc=i.CRC) for i in z.infolist()]
        for member in z.infolist():
            name=Path(member.filename).name
            if name in ['README.md','Read_me.txt'] or (name.startswith('sub-') and name.endswith('.mat') and 'supplementary' not in member.filename):
                target=folder/name
                if not target.exists() or target.stat().st_size!=member.file_size:
                    with z.open(member) as g,target.open('wb') as f:
                        for b in iter(lambda:g.read(4*1024**2),b''):f.write(b)
        z.testzip() and (_ for _ in ()).throw(RuntimeError('ZIP CRC failed'))
    readmes={p.name:p.read_text(errors='replace') for p in folder.glob('*') if p.suffix in ['.md','.txt']}
    atomic(OUT/'archive_audit.json',dict(inventory=inventory,readmes=readmes,zip_md5=MD5))
    adapter=OUT/'moabb_nguyen_adapter.py'
    if not adapter.exists():
        r=requests.get('https://raw.githubusercontent.com/NeuroTechX/moabb/develop/moabb/datasets/nguyen2017.py',timeout=30);r.raise_for_status();adapter.write_text(r.text)
    tree=ast.parse(adapter.read_text());positions=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_CH_POSITIONS' for t in n.targets))
    names=list(positions);assert len(names)==64
    excluded=[0,9,32,63];keep=[i for i in range(64) if i not in excluded];channels=[names[i] for i in keep]
    sys.path.insert(0,'/root/FAST');from BCIC2020Track3_preprocess import Electrodes,Zones
    montage=mne.channels.make_standard_montage('standard_1005').get_positions()['ch_pos']
    refs=np.array([montage[n] for n in Electrodes]);refs/=np.linalg.norm(refs,axis=1,keepdims=True)
    cap=np.array([montage[n] for n in channels]);cap/=np.linalg.norm(cap,axis=1,keepdims=True)
    owner={n:k for k,v in Zones.items() for n in v};groups={k:[] for k in Zones}
    for n,i in zip(channels,np.argmax(cap@refs.T,axis=1)):groups[owner[Electrodes[i]]].append(n)
    assert all(groups.values()) and sum(map(len,groups.values()))==60
    geometry=dict(channels=channels,zone_dict=groups,excluded_channel_indices_zero_based=excluded,rule='Fixed standard cap nearest-angular reference group; no fitted localization')
    atomic(OUT/'geometry.json',geometry)
    audits=[]
    for subject in range(1,7):
        file=folder/f'sub-{subject:02d}.mat';assert file.exists(),file
        raw=loadmat(file);cell=raw['eeg_data_wrt_task_rep_no_eog_256Hz_last_beep'];assert cell.shape==(3,100),cell.shape
        x=[];y=[];group=[]
        for c in range(3):
            for j in range(100):
                a=np.asarray(cell[c,j]);assert a.ndim==2 and a.shape[0] in [64,80] and a.shape[1]>=1024,a.shape
                x.append(a[keep,:1024].astype(np.float32));y.append(c);group.append(c*100+j)
        x=np.asarray(x);assert x.shape==(300,60,1024) and np.isfinite(x).all()
        np.savez_compressed(OUT/f'sub-{subject:02d}.npz',X=x,y=np.asarray(y),original_trial=np.asarray(group))
        audits.append(dict(subject=subject,n_trials=300,classes=3,original_shape=list(cell[0,0].shape),mat_sha256=digest(file),signal_std=float(x.std()),variables=[k for k in raw if not k.startswith('__')]))
        print('NGUYEN_AUDITED',subject,flush=True)
    atomic(OUT/'data_audit.json',dict(subjects=audits,readmes=readmes,adapter_sha256=digest(adapter),
       window='First four seconds after last auditory beep; one 1024-sample trial, not overlapping trial fragments',units='Native released amplitude units; training-only per-channel normalization makes constant scaling irrelevant'))
    return geometry
def experiment(geometry):
    import torch
    from torch import nn
    from torch.nn import functional as F
    from transformers import PretrainedConfig
    from sklearn.model_selection import StratifiedKFold
    from sklearn.metrics import accuracy_score,f1_score,cohen_kappa_score
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.linear_model import LogisticRegression
    import inner_models as im
    import run_inner_study as r
    from scipy.signal import welch
    def bandpower(x):
        f,p=welch(x,fs=256.,nperseg=256,noverlap=128,axis=-1)
        return np.concatenate([np.log(np.maximum(p[...,(f>=a)&(f<b)].sum(-1),1e-12)) for a,b in [(8,13),(13,30),(30,70)]],axis=1)
    torch.set_num_threads(4)
    def loo(q,y):
        k=im.kernel(q,q);a=k+.1*torch.eye(len(q),device=q.device,dtype=k.dtype);b=torch.cholesky_inverse(torch.linalg.cholesky(a))
        target=F.one_hot(y,3).to(k.dtype);return (target-(b@target)/b.diag()[:,None]).float()
    im.loo=loo
    def build(arch):
        if arch=='fast':
            return im.FAST(PretrainedConfig(electrodes=geometry['channels'],zone_dict=geometry['zone_dict'],dim_cnn=32,dim_token=32,seq_len=1024,window_len=256,slide_step=128,head='Conv4Layers',n_classes=3,num_layers=4,num_heads=8,dropout=.1))
        m=im.EEGNet();m.spatial=nn.Conv2d(8,16,(60,1),groups=8,bias=False);m.classifier=nn.Linear(16*32,3);return m
    def metrics(y,p):
        pred=p.argmax(1);return dict(accuracy=float(accuracy_score(y,pred)),macro_f1=float(f1_score(y,pred,average='macro')),kappa=float(cohen_kappa_score(y,pred)))
    def summary():
        rows=[json.loads(p.read_text()) for p in (OUT/'results').glob('*/*.json')];groups=[]
        for job in ['fast_ce','fast_loo','eegnet_ce','spectral_logistic']:
            a=[x for x in rows if x['job']==job];subjects=[]
            for s in range(1,7):
                q=[x for x in a if x['subject']==s]
                if len(q)==5:subjects.append(dict(subject=s,**{k:float(np.mean([x['evaluation'][k] for x in q])) for k in ['accuracy','macro_f1','kappa']}))
            groups.append(dict(job=job,n_fits=len(a),subjects=subjects,mean_accuracy=float(np.mean([x['accuracy'] for x in subjects])) if subjects else None))
        atomic(OUT/'summary.json',dict(groups=groups,complete=all(g['n_fits']==30 for g in groups),note='One frozen seed; mean folds within subject then mean subjects; not original paper protocol'))
    # Actual shape/gradient smoke and arbitrary-three-class analytical LOO check.
    im.seed_all(9);q=F.normalize(torch.randn(9,12,device='cuda'),dim=1).requires_grad_();y=torch.arange(9,device='cuda')%3
    actual=loo(q,y)
    for i in range(9):
        mask=torch.arange(9,device='cuda')!=i;k=im.kernel(q[mask],q[mask]);a=k+.1*torch.eye(8,device=q.device,dtype=k.dtype)
        expected=im.kernel(q[i:i+1],q[mask])@torch.linalg.solve(a,F.one_hot(y[mask],3).double())
        assert torch.allclose(actual[i],expected.float()[0],atol=1e-5)
    for arch in ['fast','eegnet']:
        m=build(arch).cuda();x=torch.randn(9,60,1024,device='cuda')
        logits,z=r.representation(m,x);assert logits.shape==(9,3)
        loss=F.cross_entropy(logits,y)+im.auxiliary(z,y,'loo');loss.backward()
        assert all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters());del m;torch.cuda.empty_cache()
    atomic(OUT/'smoke.json',dict(passed=True,checks=['Three-class analytic LOO equals refits','60 channels and 1024 time samples','Both backbones finite gradients']))
    started=time.time()
    for subject in range(1,7):
        with np.load(OUT/f'sub-{subject:02d}.npz') as f:x=f['X'];y=f['y'];trial=f['original_trial']
        folds=list(StratifiedKFold(5,shuffle=True,random_state=42).split(x,y))
        atomic(OUT/f'splits_sub{subject:02d}.json',dict(folds=[dict(train=tr.tolist(),test=ev.tolist()) for tr,ev in folds],one_trial_per_sample=True))
        feat=bandpower(x)
        for fold,(tr,ev) in enumerate(folds):
            assert not set(trial[tr])&set(trial[ev]);norm=r.normalization(x[tr]);xx=((x-norm[0])/norm[1]).astype(np.float32)
            for job in ['fast_ce','fast_loo','eegnet_ce','spectral_logistic']:
                dest=OUT/'results'/job;dest.mkdir(parents=True,exist_ok=True);name=f'sub{subject:02d}_fold{fold}'
                if (dest/(name+'.json')).exists():continue
                atomic(OUT/'status.json',dict(state='running',phase='training',pid=os.getpid(),subject=subject,fold=fold+1,job=job,started=started,updated=time.time()))
                if job=='spectral_logistic':
                    t=time.time();m=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=2000));m.fit(feat[tr],y[tr]);p=m.predict_proba(feat[ev]);timing=dict(seconds=time.time()-t)
                else:
                    arch,method=job.split('_');im.seed_all(42+subject*101+fold*17);m=build(arch);initial=r.state_hash(m)
                    if method=='loo':assert initial==json.loads((OUT/'results/fast_ce'/(name+'.json')).read_text())['initial_state_sha256']
                    m,timing=r.train(m,xx[tr],y[tr],method,200,.0005);p=r.predict(m,xx[ev])
                    torch.save(dict(state_dict=m.cpu().state_dict(),normalization=norm,train=tr,test=ev,architecture=arch,method=method),dest/(name+'.pt'))
                    del m;torch.cuda.empty_cache();timing['initial_state_sha256']=initial
                np.savez_compressed(dest/(name+'.npz'),prob=p,y=y[ev],train=tr,test=ev,original_trial=trial[ev])
                atomic(dest/(name+'.json'),dict(subject=subject,fold=fold,job=job,evaluation=metrics(y[ev],p),**timing))
                summary();print('NGUYEN_FOLD_DONE',job,subject,fold,metrics(y[ev],p),flush=True)
def main():
    OUT.mkdir(exist_ok=True)
    import fcntl
    with (OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            atomic(OUT/'protocol.json',dict(dataset='Nguyen2017 ShortWords; Zenodo 19502794',classes=['out','in','up'],label_order_source='MOABB adapter; original readme retained in archive audit',subjects=6,seed=42,folds=5,
              jobs=['fast_ce','fast_loo','eegnet_ce','spectral_logistic'],new_gpu_fits=90,cpu_fits=30,epochs=200,lr=.0005,
              primary='FAST joint LOO versus identically initialized FAST CE; unchanged ridge=.1 gamma=2 aux=.3 score_scale=4',
              input='60 non-EOG channels; first 4 seconds after last beep; no overlapping fragments',
              split='One full original trial per sample; stratified fivefold with fixed seed42; source-only channel normalization',
              limitations=['Exploratory independent-dataset extension after ds003626 failure; retain both datasets','Same acquisition corpus does not prove across-subject/cross-day deployment','One seed, six subjects; more repeats only after this bounded replay','No raw run/time IDs; random trial folds cannot rule out slow drift','Inherited author preprocessing; not prospective causal validation','Reported original paper accuracies use different segmentation and CV and are not directly comparable'],
              source_hashes={p:digest(ROOT/p) for p in ['run_nguyen_external.py','inner_models.py','run_inner_study.py']},download_md5=MD5))
            atomic(OUT/'status.json',dict(state='running',phase='download',pid=os.getpid(),started=time.time()))
            p=download();atomic(OUT/'status.json',dict(state='running',phase='audit_prepare',pid=os.getpid(),started=time.time()))
            geometry=prepare(p);experiment(geometry)
            atomic(OUT/'status.json',dict(state='complete',updated=time.time()))
        except Exception as e:
            atomic(OUT/'status.json',dict(state='failed',error=repr(e),updated=time.time()));raise
if __name__=='__main__':main()
