from pathlib import Path
import json,subprocess,time
root=Path('/root/FAST/experiments/nature_stage_20261002');out=root/'multicue_extension_20261003';out.mkdir(exist_ok=True)
p=out/'status.json'
if p.exists() and json.loads(p.read_text()).get('state') not in ['failed','complete','complete_with_failures']:raise RuntimeError('Queue may already run')
log=(out/'queue.log').open('ab')
process=subprocess.Popen([str(root/'data_env/bin/python'),'-u',str(root/'multicue_extension_queue.py')],cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(out/'launch.json').write_text(json.dumps(dict(pid=process.pid,started=time.time()),indent=2));print('EXTENSION_STARTED',process.pid)
