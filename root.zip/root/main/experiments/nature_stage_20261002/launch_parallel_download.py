from pathlib import Path
import json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:args=p.joinpath('cmdline').read_bytes().split(b'\0')
    except OSError:continue
    if any(a in [str(ROOT/'download_parallel.py').encode(),str(ROOT/'prepare_inner_data.py').encode()] for a in args):
        raise RuntimeError(f'Download already running: {p.name}')
failure=ROOT/'inner_data_failure.json'
if failure.exists():failure.rename(ROOT/f'inner_data_failure_before_resume_{int(time.time())}.json')
with (ROOT/'download_parallel.log').open('a') as log:
    p=subprocess.Popen([sys.executable,'-u',str(ROOT/'download_parallel.py')],cwd='/root/FAST',stdin=subprocess.DEVNULL,
        stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,PYTHONUNBUFFERED='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
(ROOT/'download.pid').write_text(str(p.pid))
print('PARALLEL_DOWNLOAD_LAUNCHED',p.pid)
