from pathlib import Path
import json,time,argparse,statistics
R=Path(__file__).resolve().parent/'nguyen_external_20261003'
def read(p):
    try:return json.loads(p.read_text())
    except (OSError,ValueError):return {}
def show():
    s=read(R/'status.json');d=read(R/'download_status.json')
    print('Nguyen external validation:',s.get('state'),'phase:',s.get('phase'),'PID:',s.get('pid'))
    if d:
        n=d.get('bytes',0);total=d.get('total',1);print('Download:',round(n/1e9,2),'/',round(total/1e9,2),'GB',round(n/total*100,1),'%')
        if d.get('state')!='complete' and n>0:print('Approx download remaining:',round((total-n)*d.get('seconds',0)/n/60,1),'minutes')
    rows=[read(p) for p in R.glob('results/*/*.json')];gpu=[r for r in rows if r.get('job')!='spectral_logistic']
    print('GPU fits:',len(gpu),'/90',round(len(gpu)/90*100,1),'% | CPU:',len(rows)-len(gpu),'/30')
    remaining=0
    for job,default in [('fast_ce',40),('fast_loo',45),('eegnet_ce',20)]:
        a=[r['seconds'] for r in rows if r.get('job')==job];remaining+=(30-len(a))*(statistics.median(a) if a else default)
    print('Approx training remaining:',round(remaining/60,1),'minutes; download/preparation excluded')
    print('Current subject/fold/job:',s.get('subject'),s.get('fold'),s.get('job'))
    if s.get('error'):print('ERROR:',s['error'])
    for g in read(R/'summary.json').get('groups',[]):print(g['job'],g['n_fits'],'fits; complete-subject mean:',g['mean_accuracy'])
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--watch',action='store_true');a=ap.parse_args()
    try:
        while True:
            if a.watch:print('\033[2J\033[H',end='')
            show()
            if not a.watch:return
            time.sleep(5)
    except KeyboardInterrupt:print('Display exited; background experiment continues.')
if __name__=='__main__':main()
