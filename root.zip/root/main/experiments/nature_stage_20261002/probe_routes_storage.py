"""Read-only storage inventory and bounded public-source speed probes."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import subprocess
import time
import requests

ROOT = Path('/root/FAST/experiments/nature_stage_20261002')
inv = json.loads((ROOT/'inner_data/inventory.json').read_text())
obj = next(f for f in inv['files'] if f['key'].endswith('sub-01_ses-01_eeg-epo.fif'))
key = obj['key']
urls = [base+key for base in ['https://s3.amazonaws.com/openneuro.org/',
        'https://openneuro.org.s3.amazonaws.com/',
        'https://openneuro.org.s3.us-east-1.amazonaws.com/',
        'https://s3.us-east-1.amazonaws.com/openneuro.org/']]
urls.append('https://data.nemar.org/on003626/v1.0.0/'+key.removeprefix('ds003626/'))

def probe(url):
    start = time.monotonic()
    out = {'url': url}
    try:
        with requests.get(url, headers={'Range':'bytes=0-1048575'}, stream=True,
                          timeout=(12,20)) as r:
            out.update(status=r.status_code, final_url=r.url, etag=r.headers.get('ETag'),
                       content_range=r.headers.get('Content-Range'), length=r.headers.get('Content-Length'))
            r.raise_for_status()
            # Never fetch an entire large file if the route ignores Range.
            if r.status_code != 206:
                out['error'] = 'Range not honored'
            else:
                data = bytearray()
                for chunk in r.iter_content(65536):
                    data.extend(chunk)
                    if len(data) >= 1048576 or time.monotonic()-start > 40:
                        break
                out.update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    except Exception as e:
        out['error'] = repr(e)
    out['seconds'] = round(time.monotonic()-start,3)
    out['MiB_per_sec'] = round(out.get('bytes',0)/1048576/max(out['seconds'],.001),3)
    print('ROUTE', json.dumps(out), flush=True)
    return out

with ThreadPoolExecutor(max_workers=5) as pool:
    rows = [f.result() for f in as_completed([pool.submit(probe,u) for u in urls])]
report = {'official_object': obj, 'routes': rows, 'time': time.time()}
(ROOT/'route_probes.json').write_text(json.dumps(report,indent=2))
for args in [['du','-x','-B1','--max-depth=2','/root/FAST'],
             ['du','-x','-B1','--max-depth=1','/root'],
             ['findmnt','-T','/root/autodl-tmp'],
             ['findmnt','-T','/root/FAST']]:
    r = subprocess.run(args, capture_output=True, text=True, timeout=70)
    print('STORAGE', args, '\n',r.stdout,r.stderr)
large=[]
for p in Path('/root/FAST').rglob('*'):
    if p.is_file() and not p.is_symlink() and p.stat().st_size>=100*1024**2:
        large.append((p.stat().st_size,str(p)))
print('LARGE_FILES',json.dumps(sorted(large,reverse=True)[:60]))
