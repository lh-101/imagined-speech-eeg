"""Exploratory matched-duration cross-phase and resting-associated controls."""
from pathlib import Path
import os,json,time,fcntl,hashlib
import numpy as np
from scipy.io import loadmat
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression,Ridge
from nguyen_spectral_study import power,metrics
import run_nguyen_external as old
R=old.ROOT;PRE=old.OUT;OUT=R/'nguyen_phase_20261003';atomic=old.atomic
N_PERM=50
JOBS=['early_to_early','late_to_late','rest_to_rest','early_to_rest','rest_to_early','late_to_rest','rest_to_late','rest_residual','shuffled_rest_residual']
def fit(x,y):
    m=LogisticRegression(C=1,max_iter=2000);m.fit(x,y);return m
def score_model(m,x):return m.predict_proba(x)
def summary():
    rows=[json.loads(p.read_text()) for p in (OUT/'fits').glob('*/*.json')];groups=[]
    for job in JOBS:
        a=[r for r in rows if r['job']==job];sub=[]
        for s in range(1,7):
            b=[r for r in a if r['subject']==s]
            if len(b)==5:sub.append(dict(subject=s,accuracy=float(np.mean([r['evaluation']['accuracy'] for r in b])),macro_f1=float(np.mean([r['evaluation']['macro_f1'] for r in b]))))
        groups.append(dict(job=job,n_fits=len(a),subjects=sub,mean_accuracy=float(np.mean([s['accuracy'] for s in sub])) if sub else None))
    atomic(OUT/'summary.json',dict(groups=groups,complete=len(rows)==270))
def prepare(s):
    p=OUT/f'features_sub{s:02d}.npz'
    if p.exists():
        with np.load(p) as f:return {k:f[k] for k in f.files}
    raw=loadmat(old.DATA/'extracted'/f'sub-{s:02d}.mat');a=raw['eeg_data_wrt_task_rep_no_eog_256Hz_last_beep'];b=raw['eeg_data_wrt_task_rep_no_eog_256Hz_end_trial'];assert a.shape==b.shape==(3,100)
    keep=[i for i in range(64) if i not in [0,9,32,63]]
    early=np.asarray([a[c,j][keep,:512] for c in range(3) for j in range(100)],dtype=np.float32)
    late=np.asarray([a[c,j][keep,768:1280] for c in range(3) for j in range(100)],dtype=np.float32)
    rest=np.asarray([b[c,j][keep,:512] for c in range(3) for j in range(100)],dtype=np.float32)
    assert early.shape==late.shape==rest.shape==(300,60,512)
    with np.load(PRE/f'sub-{s:02d}.npz') as f:
        assert np.array_equal(f['X'][:,:,:512],early);y=f['y']
    d=dict(early=power(early),late=power(late),rest=power(rest),y=y)
    assert all(np.isfinite(d[k]).all() for k in ['early','late','rest'])
    np.savez_compressed(p,**d);return d
def fold_inputs(s,fold,d,split):
    tr=np.asarray(split['train']);ev=np.asarray(split['test']);assert not set(tr)&set(ev)
    pairs={}
    for source,target in [('early','early'),('late','late'),('rest','rest'),('early','rest'),('rest','early'),('late','rest'),('rest','late')]:
        scaler=StandardScaler().fit(d[source][tr]);pairs[source+'_to_'+target]=(scaler.transform(d[source][tr]),scaler.transform(d[target][ev]))
    # Regression and every scaler are fit without labels on training trials only.
    full=np.load(R/'nguyen_spectral_20261003'/f'features_sub{s:02d}.npz')
    imagery=full['imagery'];full.close();si=StandardScaler().fit(imagery[tr]);sr=StandardScaler().fit(d['rest'][tr])
    it=si.transform(imagery[tr]);ie=si.transform(imagery[ev]);rt=sr.transform(d['rest'][tr]);re=sr.transform(d['rest'][ev])
    diagnostics={}
    for job,shuffle in [('rest_residual',False),('shuffled_rest_residual',True)]:
        if shuffle:
            rng=np.random.RandomState(60000+s*101+fold*17);rt0=rt[rng.permutation(len(tr))];re0=re[rng.permutation(len(ev))]
        else:rt0=rt;re0=re
        nuisance=Ridge(alpha=10).fit(rt0,it);a=it-nuisance.predict(rt0);b=ie-nuisance.predict(re0)
        sc=StandardScaler().fit(a);pairs[job]=(sc.transform(a),sc.transform(b))
        diagnostics[job]=dict(train_explained_fraction=float(1-np.mean(a*a)/np.mean(it*it)),test_explained_fraction=float(1-np.mean(b*b)/np.mean(ie*ie)))
    return tr,ev,pairs,diagnostics
def null_summary():
    files=list((OUT/'null').glob('sub*.npz'))
    if len(files)!=6:return
    matrices=[]
    for p in sorted(files):
        with np.load(p) as f:assert np.array_equal(f['jobs'],np.asarray(JOBS));matrices.append(f['accuracy'])
    null=np.mean(matrices,axis=0) # [permutation,job], subjects independent unit
    real=json.loads((OUT/'summary.json').read_text())['groups'];observed=np.array([g['mean_accuracy'] for g in real]);assert np.isfinite(observed).all()
    # Conditional labels are exchangeable within frozen folds only as an
    # exploratory assumption; cannot remove unknown collection-time confounds.
    rows=[]
    for i,job in enumerate(JOBS):
        rows.append(dict(job=job,observed=float(observed[i]),null_mean=float(null[:,i].mean()),null_range=np.quantile(null[:,i],[.025,.975]).tolist(),
          empirical_upper_tail=(1+int((null[:,i]>=observed[i]).sum()))/(N_PERM+1),
          max_over_jobs_upper_tail=(1+int((null.max(1)>=observed[i]).sum()))/(N_PERM+1)))
    atomic(OUT/'permutation_summary.json',dict(rows=rows,n_permutations=N_PERM,
      warning='Exploratory conditional randomization only; fold membership fixed, labels shuffled consistently within held-fold groups, full pipeline fitted again. Unknown run/time dependencies and post-hoc questions limit exchangeability. Tail fractions do not establish neural or speech specificity.'))
def main():
    OUT.mkdir(exist_ok=True)
    with (OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        protocol=dict(subjects=6,folds=5,jobs=JOBS,n_real_fits=270,n_permutations=N_PERM,n_null_fits=13500,
          intervals='Early imagery last_beep[0,2)s; late imagery[3,5)s; end_trial rest[0,2)s. All cross-phase comparisons use 512 samples.',
          crossphase='Fit scaler and classifier on source-phase training original trials; evaluate target-phase held original trials. Neither phase of a held trial is used for fitting.',
          nuisance='Paired rest->4s-imagery regression Ridge alpha10, train-only phase scalers and regression, residual classifier and residual scaler. Random rest pairing fixed separately within train/test, using no labels.',
          classification='LogisticRegression C1 max_iter2000; identical saved fivefold. No hyperparameter or window selection on evaluation.',
          permutation='For each subject/repeat, shuffle labels consistently within five frozen held-fold groups, then reuse that subject-level permuted vector across every fit and phase. Preserves original fold class counts. Same permutations across jobs for paired/max-over-job summaries.',
          limitations=['Post-hoc exploration on already-inspected folds','Rest follows imagery and may contain cognitive carryover, not an independent blank','No reliable raw run/order IDs: do not fabricate temporal grouping','Residualization uses evaluation trial resting features; offline extra input, not causal online decoder','Removing shared signal can remove genuine task information','Conditional permutations cannot resolve unmeasured time/run confounds','Cross-phase transfer does not prove all decoding is nuisance'],
          source_sha256=old.digest(Path(__file__)),prior_protocol_sha256=old.digest(PRE/'protocol.json'))
        if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==protocol
        else:atomic(OUT/'protocol.json',protocol)
        started=time.time()
        try:
            for s in range(1,7):
                atomic(OUT/'status.json',dict(state='running',phase='real_controls',subject=s,pid=os.getpid(),started=started,updated=time.time()))
                d=prepare(s);splits=json.loads((PRE/f'splits_sub{s:02d}.json').read_text())['folds'];inputs=[]
                for fold,split in enumerate(splits):
                    tr,ev,pairs,diagnostics=fold_inputs(s,fold,d,split);inputs.append((tr,ev,pairs))
                    for job,(xt,xe) in pairs.items():
                        dest=OUT/'fits'/job;dest.mkdir(parents=True,exist_ok=True);name=f'sub{s:02d}_fold{fold}'
                        if (dest/(name+'.json')).exists():continue
                        tick=time.time();m=fit(xt,d['y'][tr]);p=score_model(m,xe)
                        if job=='rest_to_rest':
                            with np.load(R/'nguyen_spectral_20261003/fits/rest_logistic'/(name+'.npz')) as f:assert np.allclose(p,f['prob'],atol=1e-6),'Rest pipeline mismatch'
                        np.savez_compressed(dest/(name+'.npz'),prob=p,y=d['y'][ev],train=tr,test=ev)
                        atomic(dest/(name+'.json'),dict(job=job,subject=s,fold=fold,evaluation=metrics(d['y'][ev],p),seconds=time.time()-tick,nuisance=diagnostics.get(job)))
                summary();print('PHASE_REAL_DONE',s,flush=True)
                dest=OUT/'null';dest.mkdir(exist_ok=True);file=dest/f'sub{s:02d}.npz'
                if file.exists():continue
                scores=[]
                for rep in range(N_PERM):
                    atomic(OUT/'status.json',dict(state='running',phase='permutation',subject=s,permutation=rep+1,total_per_subject=N_PERM,pid=os.getpid(),started=started,updated=time.time()))
                    yp=d['y'].copy();rng=np.random.RandomState(71000+s*1000+rep)
                    for split in splits:
                        ix=np.asarray(split['test']);yp[ix]=yp[ix][rng.permutation(len(ix))]
                    values=[]
                    for tr,ev,pairs in inputs:
                        values.append([float((score_model(fit(pairs[j][0],yp[tr]),pairs[j][1]).argmax(1)==yp[ev]).mean()) for j in JOBS])
                    scores.append(np.mean(values,axis=0))
                np.savez_compressed(file,accuracy=np.asarray(scores),jobs=np.asarray(JOBS));print('PHASE_NULL_DONE',s,flush=True)
            null_summary();atomic(OUT/'status.json',dict(state='complete',updated=time.time()))
        except Exception as e:atomic(OUT/'status.json',dict(state='failed',error=repr(e),updated=time.time()));raise
if __name__=='__main__':main()
