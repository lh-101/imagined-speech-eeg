"""One-shot staged queue that ends after the explicitly scoped priority batch."""
from pathlib import Path
import fcntl,json,os,subprocess,time
ROOT=Path(__file__).resolve().parent
PY='/root/venv_fast/bin/python'

def read(p):return json.loads(p.read_text()) if p.exists() else {}
def status(state,phase,**kw):
    p=ROOT/'priority_status.json';tmp=p.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(dict(state=state,phase=phase,pid=os.getpid(),updated=time.time(),**kw),indent=2));tmp.replace(p)

def run(phase,python):
    with (ROOT/'priority_training.log').open('a') as log:
        child=subprocess.Popen([python,'-u',str(ROOT/'run_priority_experiments.py'),phase],cwd='/root/FAST',
            stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,
            env=dict(os.environ,PYTHONUNBUFFERED='1',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4'))
        status('running',phase,child_pid=child.pid)
        ret=child.wait()
        if ret:raise RuntimeError(f'{phase} failed ({ret}); inspect priority_training.log')

def main():
    with (ROOT/'priority_queue.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            run('core',PY)
            while read(ROOT/'inner_prepared/prepare_status.json').get('state')!='complete':
                failure=read(ROOT/'inner_data_failure.json')
                if failure.get('state')=='failed':raise RuntimeError('Dataset download/preparation failed: '+str(failure.get('error')))
                status('running','waiting_for_second_dataset',core_priority_complete=True)
                time.sleep(10)
            run('inner',str(ROOT/'data_env/bin/python'))
            status('complete','priority_batch_complete',extended_experiments='deferred')
            print('PRIORITY_BATCH_COMPLETE',flush=True)
        except Exception as e:
            status('failed','error',error=repr(e));raise

if __name__=='__main__':main()
