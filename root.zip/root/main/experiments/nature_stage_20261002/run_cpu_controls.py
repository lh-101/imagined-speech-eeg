"""Linear signal controls. Descriptive probes, not a source-localization study."""
from pathlib import Path
import time,json,hashlib
import numpy as np,h5py
from sklearn.model_selection import KFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'cpu_controls';OUT.mkdir(exist_ok=True)
def atomic(p,obj):
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(obj,indent=2));tmp.replace(p)
def moments(x):
    return dict(mean=x.mean(-1),log_std=np.log(np.maximum(x.std(-1),1e-6)),mean_and_log_std=np.concatenate([x.mean(-1),np.log(np.maximum(x.std(-1),1e-6))],axis=1))
def linear(f,y,tr,te):
    model=make_pipeline(StandardScaler(),LogisticRegression(C=1.,max_iter=2000,solver='lbfgs'))
    model.fit(f[tr],y[tr]);prob=model.predict_proba(f[te]);pred=model.classes_[prob.argmax(1)]
    return dict(accuracy=float((pred==y[te]).mean()),macro_f1=float(f1_score(y[te],pred,average='macro',zero_division=0)),pred=pred.tolist(),y=y[te].tolist(),train_idx=tr.tolist(),test_idx=te.tolist())
def main():
    protocol=dict(classifier='train-only StandardScaler + multinomial LogisticRegression C=1, max_iter=2000',
       features=['channel time mean','log time standard deviation','mean plus log standard deviation'],
       bci='Original non-shuffled five-fold trial splits, model-visible first 750 points, all 15 subjects',
       inner='All 10 subjects; actual three-session holdout; action [1,3.5)s; EEG and EXG features separately; EXG1/2 reference excluded',
       interpretation='Linear decodability controls. A decodable feature is not proof of artifact; signal information alone does not establish source or language specificity.',
       sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    atomic(OUT/'protocol.json',protocol);rows=[]
    with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5') as f:
        for subject in range(15):
            x=f[f'{subject+1:02d}/X'][:,:,:750];y=f[f'{subject+1:02d}/Y'][:].astype(int)
            for name,feature in moments(x).items():
                for fold,(tr,te) in enumerate(KFold(5,shuffle=False).split(x)):
                    rows.append(dict(dataset='bci',subject=subject+1,fold=fold,feature=name,**linear(feature,y,tr,te)))
            print('CPU_BCI_CONTROL_DONE',subject+1,flush=True)
    for subject in range(1,11):
        with np.load(ROOT/'inner_prepared'/f'sub-{subject:02d}.npz') as d:
            y=d['y'];session=d['session'];features={}
            for source,x in [('eeg',d['X']),('exg',d['EXG'][:,2:])]:
                features.update({source+'_'+k:v for k,v in moments(x).items()})
            for name,feature in features.items():
                for held in range(1,4):
                    tr=np.flatnonzero(session!=held);te=np.flatnonzero(session==held)
                    assert not set(tr)&set(te)
                    rows.append(dict(dataset='inner',subject=subject,held_session=held,feature=name,**linear(feature,y,tr,te)))
        print('CPU_INNER_CONTROL_DONE',subject,flush=True)
    atomic(OUT/'results.json',dict(rows=rows,n_records=len(rows),updated=time.time()))
    atomic(OUT/'status.json',dict(state='complete',n_records=len(rows),updated=time.time()))
if __name__=='__main__':
    try:main()
    except Exception as e:atomic(OUT/'status.json',dict(state='failed',error=repr(e),updated=time.time()));raise
