import json,time,urllib.request,concurrent.futures,os
from pathlib import Path
root=Path('/root/FAST/experiments/nature_stage_20261002');meta=json.loads((root/'multicue_extension_manifest.json').read_text())['subjects'][0]
paths=[('global',meta['url']),('regional','https://s3.us-east-1.amazonaws.com/openneuro.org/'+meta['path'])]
def probe(item):
 name,url=item;start=time.time()
 try:
  req=urllib.request.Request(url,headers={'Range':'bytes=536870912-541065215','User-Agent':'EEG-research-speed-check'})
  with urllib.request.urlopen(req,timeout=25) as r:
   assert r.status==206;data=r.read(4194305)
  elapsed=time.time()-start;return dict(route=name,bytes=len(data),seconds=elapsed,MB_per_second=len(data)/elapsed/1e6)
 except Exception as e:return dict(route=name,error=str(e),seconds=time.time()-start)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:rows=list(p.map(probe,paths))
report=dict(probes=rows,proxy_configured=any(k.lower().endswith('_proxy') for k in os.environ),note='Bounded 4MiB range probes while existing transfer runs; rates are per connection, not whole-download rate.')
(root/'multicue_extension_20261003/speed_diagnosis.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
