import mne,json,collections
p='/root/autodl-tmp/eeg_research/multicue_pilot_20261003/sub11_sess1_50_ica_eeg.fif'
r=mne.io.read_raw_fif(p,preload=False,verbose='ERROR')
print(r)
print('ANNOTATIONS',len(r.annotations),json.dumps(collections.Counter(r.annotations.description.tolist()),indent=2))
print('FIRST',list(zip(r.annotations.onset[:15],r.annotations.duration[:15],r.annotations.description[:15])))
print('TIME',r.info['sfreq'],r.first_time)
print('CHANNELS',r.ch_names)
