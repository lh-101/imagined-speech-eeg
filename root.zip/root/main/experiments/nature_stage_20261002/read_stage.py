from pathlib import Path
import json,subprocess,sys
r=Path('/root/FAST/experiments/nature_stage_20261002')
for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:
        cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
        if any(k in cmd for k in ['setup_data_env.py','pip install','prepare_inner_data.py','run_core_study.py','run_inner_study.py','stage_queue.py']):print('PROCESS',p.name,cmd)
    except (OSError,PermissionError):pass
for p in ['inner_data/download_status.json','inner_data_failure.json','inner_prepared/prepare_status.json','core/status.json']:
    f=r/p
    if f.exists():print('STATUS',p,f.read_text())
for p in (r/'data_env').glob('lib/python*/site-packages/existing_fast_runtime.pth'): print('PTH',p.read_text())
print('FAST_ENV',sys.prefix)
for name in ['numpy','matplotlib','mne']:
    import importlib.util
    s=importlib.util.find_spec(name);print('MODULE',name,s.origin if s else None)
base=r/'inner_data/ds003626/derivatives/sub-01/ses-01'
for p in base.glob('*'):print('DATA_FILE',p.name,p.stat().st_size)
