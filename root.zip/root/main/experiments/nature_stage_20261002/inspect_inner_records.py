from pathlib import Path
import pickle,json,numpy as np,requests
r=Path('/root/FAST/experiments/nature_stage_20261002')
base=r/'inner_data/ds003626/derivatives'
for p in sorted(base.glob('sub-*/ses-*/*_events.dat'))[:4]:
    with p.open('rb') as f:x=pickle.load(f,encoding='latin1')
    print('EVENTS',p.name,type(x).__name__,np.shape(x))
    if isinstance(x,np.ndarray):
        print('ROWS',x[:6].tolist(),'UNIQUE_COLUMNS',[(np.unique(x[:,i])[:20]).tolist() for i in range(x.shape[1])])
for p in sorted(base.glob('sub-*/ses-*/*_report.pkl'))[:2]:
    with p.open('rb') as f:x=pickle.load(f,encoding='latin1')
    print('REPORT',p.name,repr(x))
resp=requests.get('https://api.github.com/repos/N-Nieto/Inner_Speech_Dataset/git/trees/master?recursive=1',timeout=40)
if resp.ok:
    j=resp.json();(r/'sources'/'author_tree.json').write_text(json.dumps(j))
    print('AUTHOR_TREE',j.get('sha'),[x['path'] for x in j.get('tree',[]) if any(s in x['path'].lower() for s in ['preprocessing','load','event','data_extraction'])])
else:print('AUTHOR_TREE_ERROR',resp.status_code)
