from pathlib import Path
import json,time,argparse
R=Path(__file__).resolve().parent/'nguyen_subject_phase_20261003'
def read(p):
    try:return json.loads(p.read_text())
    except (OSError,ValueError):return {}
def show():
    s=read(R/'status.json');n=len(list(R.glob('fits/*/*.json')));null=len(list(R.glob('null/sub*.npz')))
    print('Unseen-subject cross-segment capability:',s.get('state'),'phase:',s.get('phase'),'PID:',s.get('pid'))
    print('Real held-subject evaluations:',n,'/216 | completed permutation subjects:',null,'/6')
    print('Current held subject/repeat:',s.get('held_subject'),s.get('permutation'),'/50')
    elapsed=time.time()-s.get('started',time.time())
    if s.get('phase')=='permutation':
        work=null*50+s.get('permutation',0)
        if work:print('Rough remaining:',round(elapsed/max(work,1)*max(300-work,0)/60,1),'minutes; setup overhead included')
    if s.get('error'):print('ERROR:',s['error'])
    for g in read(R/'summary.json').get('groups',[]):
        if g['source']=='posttrial_rest' and g['target']=='segment0_2':print(g['view'],'primary-direction accuracy:',g['accuracy'],'completed subjects:',g['n_subjects'])
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--watch',action='store_true');a=ap.parse_args()
    try:
        while True:
            if a.watch:print('\033[2J\033[H',end='')
            show()
            if not a.watch:return
            time.sleep(5)
    except KeyboardInterrupt:print('Display closed; experiment continues.')
if __name__=='__main__':main()
