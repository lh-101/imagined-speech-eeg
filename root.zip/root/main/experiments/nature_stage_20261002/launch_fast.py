from pathlib import Path
import subprocess,json,sys,os,fcntl,time,traceback
root=Path('/root/FAST/experiments/nature_stage_20261002');out=root/'multicue_fast_20261003';out.mkdir(exist_ok=True)
if len(sys.argv)==1:
 status=out/'status.json'
 if status.exists() and json.loads(status.read_text()).get('state') not in ['failed','complete']:raise RuntimeError('Active job exists')
 log=(root/'multicue_fast_20261003.log').open('ab')
 p=subprocess.Popen([str(root/'data_env/bin/python'),'-u',str(Path(__file__)),'worker'],cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'launch.json').write_text(json.dumps({'pid':p.pid,'started':time.time(),'log':str(root/'multicue_fast_20261003.log')},indent=2));print('Started pipeline PID',p.pid)
else:
 try:
  (out/'status.json').write_text(json.dumps({'state':'preparing','pid':os.getpid(),'started':time.time()},indent=2))
  subprocess.run([str(root/'data_env/bin/python'),'-u',str(root/'prepare_fast.py')],check=True)
  subprocess.run(['/root/venv_fast/bin/python','-u',str(root/'run_fast.py')],check=True)
 except Exception as e:
  existing=json.loads((out/'status.json').read_text());existing.update(state='failed',pipeline_error=str(e),pipeline_traceback=traceback.format_exc());(out/'status.json').write_text(json.dumps(existing,indent=2));raise
