"""Read-only progress and heuristic ETA. Ctrl+C stops display only."""
from pathlib import Path
import json,time,statistics,sys,argparse,datetime
R=Path(__file__).resolve().parent
def read(p):
    try:return json.loads(p.read_text())
    except (OSError,json.JSONDecodeError):return {}
def duration(seconds):
    seconds=max(0,int(seconds));return f'{seconds//3600:02d}:{seconds%3600//60:02d}:{seconds%60:02d}'
def estimates(paths,key):
    paths=sorted(paths,key=lambda p:p.stat().st_mtime,reverse=True)[:20]
    values=[read(p).get(key) for p in paths]
    return statistics.median([x for x in values if isinstance(x,(int,float)) and x>0]) if any(isinstance(x,(int,float)) and x>0 for x in values) else None
def show():
    q=read(R/'queue_status.json');core=read(R/'core/status.json');data=read(R/'inner_data/download_status.json');inner=read(R/'inner_results/status.json');signal=read(R/'signal_controls/status.json')
    complete=0;remaining=0;core_n=0;inner_n=0;signal_n=0;measured=[]
    for method,default in [('ce',22),('joint_loo',45),('regional_loo',45),('global_loo',45),('joint_self_support',45),('supcon',35)]:
        paths=list((R/'core/results').glob(f'full_{method}_seed*/*-fold*.json'))
        n=len(list((R/'core/results').glob(f'full_{method}_seed*/*-fold*.npz')))
        speed=estimates(paths,'seconds');remaining+=(225-n)*(speed or default);complete+=n;core_n+=n
        if speed:measured.append(f'{method}={speed:.1f}s')
    for arch in ['fast','eegnet']:
        for method in ['ce','loo','supcon']:
            base=list((R/'inner_results'/arch/method).glob('*_base.npz'));n=len(base)
            speed=estimates(list((R/'inner_results'/arch/method).glob('*_base.json')),'seconds')
            default=({'ce':30,'loo':55,'supcon':40} if arch=='fast' else {'ce':8,'loo':12,'supcon':10})[method]
            remaining+=(90-n)*(speed or default);complete+=n;inner_n+=n
            if method!='supcon':
                paths=[p for suffix in ['25','50','100'] for p in (R/'inner_results'/arch/method).glob(f'*_cal{suffix}.json')]
                n=sum(len(list((R/'inner_results'/arch/method).glob(f'*_cal{suffix}.npz'))) for suffix in ['25','50','100'])
                speed=estimates(paths,'seconds');default=({'ce':8,'loo':14} if arch=='fast' else {'ce':2,'loo':3})[method]
                remaining+=(270-n)*(speed or default);complete+=n;inner_n+=n
    for method,default in [('ce',22),('joint_loo',45)]:
        n=len(list((R/'signal_controls/results').glob(f'*_{method}_seed42/*-fold*.npz')))
        speed=estimates(list((R/'signal_controls/results').glob(f'*_{method}_seed42/*-fold*.json')),'seconds')
        remaining+=(225-n)*(speed or default);complete+=n;signal_n+=n
    inventory=read(R/'inner_data/inventory.json');total=inventory.get('total_bytes',0);downloaded=0
    for item in inventory.get('files',[]):
        p=R/'inner_data'/item['key']
        part=p.with_suffix(p.suffix+'.part')
        try:downloaded+=min(item['size'],p.stat().st_size if p.exists() else part.stat().st_size if part.exists() else 0)
        except OSError:pass
    now=time.time();started=core.get('started',now);elapsed=now-started
    print('# EEG research stages | refresh 5s | Ctrl+C exits display only')
    print('Queue:',q.get('state','not started'),'| phase:',q.get('phase','unknown'))
    print(f'Completed training fits: {complete}/3420 ({complete/3420*100:.1f}%)')
    print(f'Core controls: {core_n}/1350 | second dataset + calibration: {inner_n}/1620 | signal controls: {signal_n}/450')
    print('Current core:',core.get('job'),'| subject:',core.get('subject',-1)+1,'/15 | fold:',core.get('fold',-1)+1,'/5')
    print(f'Official dataset download: {downloaded/1e9:.2f}/{total/1e9:.2f} GB | {data.get("state","pending")}')
    print('Inner data preparation:',read(R/'inner_prepared/prepare_status.json').get('state','pending'))
    if inner:print('Inner training:',inner)
    if signal:print('Signal training:',signal)
    print('Elapsed:',duration(elapsed))
    print('Training-only estimated remaining:',duration(remaining),'| rough range:',duration(.7*remaining),'-',duration(1.6*remaining))
    print('Training-only estimated total:',duration(elapsed+remaining))
    print('Estimated finish (server time):',datetime.datetime.fromtimestamp(now+remaining).strftime('%Y-%m-%d %H:%M:%S'))
    print('Measured core medians:',', '.join(measured) or 'none yet')
    print('ETA uses initial estimates for unstarted stages, excludes data stalls/setup, and is not a confidence interval.')
    for p in ['inner_data_failure.json','queue_status.json']:
        state=read(R/p)
        if state.get('state')=='failed':print('ERROR',p,state.get('error'))
    print('-'*90)
    log=R/'core/core.log'
    if log.exists():
        with log.open('rb') as f:
            f.seek(max(0,log.stat().st_size-12000));lines=f.read().decode(errors='replace').splitlines()
        print('\n'.join(lines[-4:]))
def main():
    if (R/'nguyen_subject_phase_20261003/protocol.json').exists():
        import runpy
        runpy.run_path(str(R/'subject_phase_progress.py'),run_name='__main__')
        return
    if (R/'nguyen_phase_20261003/protocol.json').exists():
        import runpy
        runpy.run_path(str(R/'phase_progress.py'),run_name='__main__')
        return
    if (R/'nguyen_spectral_20261003/protocol.json').exists():
        import runpy
        runpy.run_path(str(R/'spectral_progress.py'),run_name='__main__')
        return
    if (R/'nguyen_external_20261003/protocol.json').exists():
        import runpy
        runpy.run_path(str(R/'nguyen_progress.py'),run_name='__main__')
        return
    if (R/'validation_20261003/protocol.json').exists():
        import runpy
        runpy.run_path(str(R/'validation_progress.py'),run_name='__main__')
        return
    if (R/'diagnostics_20261003/protocol.json').exists():
        import runpy
        runpy.run_path(str(R/'diagnostic_progress.py'),run_name='__main__')
        return
    if (R/'priority_amendment.json').exists():
        import runpy
        runpy.run_path(str(R/'priority_progress.py'),run_name='__main__')
        return
    ap=argparse.ArgumentParser();ap.add_argument('--watch',action='store_true');a=ap.parse_args()
    try:
        while True:
            if a.watch:print('\033[2J\033[H',end='')
            show()
            if not a.watch:return
            time.sleep(5)
    except KeyboardInterrupt:print('\nDisplay closed; background jobs continue.')
if __name__=='__main__':main()
