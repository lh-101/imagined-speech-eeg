from pathlib import Path
import sys,os,subprocess
r=Path(__file__).resolve().parent;p=r/'queue.pid'
if p.exists():
    pid=int(p.read_text());cmd=Path(f'/proc/{pid}/cmdline')
    if cmd.exists() and b'stage_queue.py' in cmd.read_bytes():raise RuntimeError(f'Queue already running: {pid}')
with (r/'queue.log').open('a') as f:
    child=subprocess.Popen([sys.executable,'-u',str(r/'stage_queue.py')],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True,
         env=dict(os.environ,PYTHONUNBUFFERED='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
p.write_text(str(child.pid));print('ONE_SHOT_QUEUE_LAUNCHED',child.pid)
