from pathlib import Path
import json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'diagnostics_20261003'
PY=str(ROOT/'data_env/bin/python')
SCRIPTS=['diagnostic_cpu.py','diagnostic_gpu.py']
for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:args=p.joinpath('cmdline').read_bytes().split(b'\0')
    except OSError:continue
    if any(str(ROOT/s).encode() in args for s in SCRIPTS):raise RuntimeError(f'Diagnostic process already running: {p.name}')
assert json.loads((OUT/'gpu_smoke.json').read_text())['passed']
assert json.loads((OUT/'feature_smoke.json').read_text())['passed']
assert json.loads((OUT/'protocol.json').read_text())['new_gpu_fits']==150
records={}
for name in SCRIPTS:
    role='cpu' if name=='diagnostic_cpu.py' else 'gpu'
    status=OUT/role/'status.json'
    if status.exists() and json.loads(status.read_text()).get('state')=='complete':
        print('DIAGNOSTIC_ALREADY_COMPLETE',name,flush=True)
        continue
    logpath=OUT/(Path(name).stem+'.log')
    with logpath.open('a') as log:
        p=subprocess.Popen([PY,'-u',str(ROOT/name)],cwd='/root/FAST',stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,
            start_new_session=True,env=dict(os.environ,PYTHONUNBUFFERED='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1'))
    records[name]=dict(pid=p.pid,log=str(logpath))
    print('DIAGNOSTIC_LAUNCHED',name,p.pid,flush=True)
(OUT/'launch.json').write_text(json.dumps(dict(started=time.time(),processes=records),indent=2))
