from pathlib import Path
import argparse,json,statistics,time
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'diagnostics_20261003'
def read(p):
    try:return json.loads(p.read_text())
    except (OSError,ValueError):return {}
def duration(n):
    n=max(0,int(n));return f'{n//3600:02d}:{n//60%60:02d}:{n%60:02d}'
def show():
    cpu=read(OUT/'cpu/status.json');gpu=read(OUT/'gpu/status.json')
    rows=[read(p) for p in (OUT/'gpu').glob('sub*.json')];new=[r for r in rows if not r.get('training_reused',False)]
    elapsed=time.time()-read(OUT/'launch.json').get('started',time.time())
    remaining=0;timings={}
    for arch,context,default in [('fast','within_session',10),('fast','matched_source',10),('eegnet','within_session',3),('eegnet','matched_source',3),('eegnet','full_source',8)]:
        items=[r for r in new if r['architecture']==arch and r['context']==context]
        values=[r['seconds'] for r in items];speed=statistics.median(values) if values else default
        remaining+=(30-len(items))*speed;timings[arch+'/'+context]=dict(n=len(items),seconds=round(speed,2),measured=bool(values))
    print('# Second-dataset diagnostic batch | Ctrl+C stops display only')
    print('GPU:',gpu.get('state','starting'),'new fits:',len(new),'/150 | reused FAST cases:',len(rows)-len(new),'/30')
    print('CPU:',cpu.get('state','starting'),'fits:',len(list((OUT/'cpu').glob('sub*.json'))),'/630')
    print('Current:',gpu.get('architecture'),gpu.get('context'),'subject:',gpu.get('subject'),'session:',gpu.get('session'))
    print('Elapsed:',duration(elapsed),'| GPU training-only remaining:',duration(remaining),'rough range:',duration(.8*remaining),'-',duration(1.5*remaining))
    print('Timings:',timings,'(initial estimates where measured=false; checkpoint diagnostics/setup excluded)')
    for label,state in [('cpu',cpu),('gpu',gpu)]:
        if state.get('state')=='failed':print('ERROR',label,state.get('error'))
    log=OUT/'diagnostic_gpu.log'
    if log.exists():print('\n'.join(log.read_text().splitlines()[-5:]))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--watch',action='store_true');args=ap.parse_args()
    try:
        while True:
            if args.watch:print('\033[2J\033[H',end='')
            show()
            if not args.watch:break
            time.sleep(5)
    except KeyboardInterrupt:pass
