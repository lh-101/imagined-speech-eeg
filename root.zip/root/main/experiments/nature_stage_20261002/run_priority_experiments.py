"""Resource-budget amendment: complete one-seed primary contrasts first.

Uses original fit functions, splits, epochs and checkpoints without changing the
experimental methods. Extended experiments remain deferred, never complete.
"""
from pathlib import Path
import argparse,fcntl,json,os,sys,time
ROOT=Path(__file__).resolve().parent

def atomic(path,obj):
    tmp=path.with_suffix(path.suffix+'.priority.tmp');tmp.write_text(json.dumps(obj,indent=2));tmp.replace(path)

def core():
    sys.path.insert(0,str(ROOT/'core'))
    import run_core_study as r
    r.torch.set_num_threads(8)
    assert json.loads((r.ROOT/'manifest.json').read_text())==json.loads(json.dumps(r.manifest())), 'Historical core protocol changed'
    status=dict(state='running',pid=os.getpid(),started=time.time(),scope='priority CE/joint_loo seed42 only',completed_jobs=[],total_jobs=2)
    with (r.ROOT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            for i,method in enumerate(['ce','joint_loo']):
                job=dict(method=method,condition='full',seed=42)
                status.update(job_index=i,job=job)
                dest=r.OUT/r.job_name(job);dest.mkdir(parents=True,exist_ok=True)
                for subject in range(15):
                    r.subject(job,subject,dest,status);r.report()
                status['completed_jobs'].append(r.job_name(job))
            runs=json.loads((r.ROOT/'summary.json').read_text())['runs']
            primary=[v for v in runs if v['job']['seed']==42 and v['job']['method'] in ['ce','joint_loo']]
            assert len(primary)==2 and all(v['complete'] for v in primary)
            paired=[]
            for s in range(15):
                a=next(v for v in primary if v['job']['method']=='ce')['subjects'][s]['main']
                b=next(v for v in primary if v['job']['method']=='joint_loo')['subjects'][s]['main']
                paired.append(dict(subject=s+1,ce=a,joint_loo=b,delta=b-a))
            atomic(ROOT/'priority_core_summary.json',dict(complete=True,seed=42,n_subjects=15,runs=primary,paired=paired,
                mean_delta=sum(v['delta'] for v in paired)/15,scope='Exploratory one-seed primary replay; other arms/seeds not run',updated=time.time()))
            status.update(state='paused',priority_complete=True,pause_reason='Extended 1200 core fits deferred by resource-budget amendment')
            print('PRIORITY_CORE_COMPLETE',json.dumps({v['job']['method']:v['means']['main'] for v in primary}),flush=True)
        except Exception as e:
            status.update(state='failed',error=repr(e));raise
        finally:
            status['updated']=time.time();atomic(r.ROOT/'status.json',status)

def inner_summary(r):
    rows=[]
    for method in ['ce','loo']:
        subjects=[];records=[]
        for s in range(1,11):
            values=[]
            for held in range(1,4):
                p=r.OUT/'fast'/method/f'seed42_sub{s:02d}_ses{held}_base.json'
                marker=p.with_suffix('.npz')
                if p.exists() and marker.exists():
                    row=json.loads(p.read_text());records.append(row);values.append(row['evaluation']['accuracy'])
            if len(values)==3:subjects.append(dict(subject=s,accuracy=sum(values)/3))
        rows.append(dict(method=method,n_fits=len(records),n_complete_subjects=len(subjects),subjects=subjects,
            mean_accuracy=sum(v['accuracy'] for v in subjects)/len(subjects) if subjects else None))
    atomic(r.OUT/'priority_summary.json',dict(complete=all(v['n_fits']==30 for v in rows),seed=42,architecture='fast',
        expected_fits=60,runs=rows,scope='Single seed; all 10 subjects and 3 real session holdouts. Subject is independent unit.',updated=time.time()))

def inner():
    sys.path.insert(0,str(ROOT))
    import run_inner_study as r
    r.torch.set_num_threads(4)
    assert json.loads((r.PREP/'prepare_status.json').read_text())['state']=='complete'
    smoke=r.smoke();assert smoke['passed']
    r.atomic(ROOT/'priority_inner_smoke.json',smoke)
    geometry=json.loads((r.PREP/'geometry.json').read_text())
    r.OUT.mkdir(parents=True,exist_ok=True)
    protocol=dict(scope='Priority only: FAST CE/LOO, seed42, all subjects, all real session holdouts, no calibration',
        expected_fits=60,cfg=r.CFG,source_hashes={p.name:r.sha(p) for p in [ROOT/'run_inner_study.py',ROOT/'inner_models.py',ROOT/'preprocess_inner.py',Path(__file__)]},
        prepared_manifest_sha256=r.sha(r.PREP/'manifest.json'),geometry=geometry,
        choice_reason='Resource/time budget, fixed before any second-dataset accuracy was observed; no accuracy-based participant selection',
        primary_endpoint='Main classifier accuracy; mean over three held-out sessions per subject, then over 10 subjects',
        deferred='Other seeds, SupCon, EEGNet and calibration retained in original full plan; not executed by this driver')
    path=r.OUT/'priority_protocol.json'
    if path.exists():assert json.loads(path.read_text())==protocol
    else:r.atomic(path,protocol)
    started=time.time()
    with (r.OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            for subject in range(1,11):
                for held in range(1,4):
                    for method in ['ce','loo']:
                        r.atomic(r.OUT/'status.json',dict(state='running',scope='priority_60_fits',pid=os.getpid(),phase='base',seed=42,
                            architecture='fast',subject=subject,held_session=held,method=method,started=started,updated=time.time()))
                        r.base('fast',method,42,subject,held,geometry)
                        inner_summary(r)
            r.atomic(r.OUT/'status.json',dict(state='complete',scope='priority_60_fits_only',extended_plan_complete=False,started=started,updated=time.time()))
            inner_summary(r);r.summarize();print('PRIORITY_INNER_COMPLETE',flush=True)
        except Exception as e:
            r.atomic(r.OUT/'status.json',dict(state='failed',scope='priority_60_fits',error=repr(e),updated=time.time()));raise

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('phase',choices=['core','inner']);args=ap.parse_args()
    (core if args.phase=='core' else inner)()
