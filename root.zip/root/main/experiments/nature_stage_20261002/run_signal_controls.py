from pathlib import Path
import sys,json,time,os,fcntl
import numpy as np,torch
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'core'))
import run_core_study as core

def transform(x,condition):
    z=x.copy();mean=x[...,:750].mean(-1,keepdims=True)
    if condition=='demean':z-=mean
    elif condition=='mean_only':z[:]=mean
    elif condition=='time_shuffle':
        # Same permutation for all electrodes in a trial preserves instantaneous
        # spatial samples, but destroys temporal order. Stable across methods.
        rng=np.random.RandomState(709)
        for i in range(len(z)):z[i,:,:750]=x[i,:,:750][:,rng.permutation(750)]
    else:raise ValueError(condition)
    return z

def main():
    core.ROOT=ROOT/'signal_controls';core.OUT=core.ROOT/'results';core.OUT.mkdir(parents=True,exist_ok=True)
    core.JOBS=[dict(method=m,condition=c,seed=42) for c in ['demean','mean_only','time_shuffle'] for m in ['ce','joint_loo']]
    core.MASKS={c:None for c in ['demean','mean_only','time_shuffle']}
    core.mask_input=transform
    ones=np.ones((3,64,800),np.float32)
    assert np.all(transform(ones,'demean')==0) and np.all(transform(ones,'mean_only')==1)
    x=np.random.RandomState(7).randn(3,64,800).astype(np.float32);z=transform(x,'time_shuffle')
    assert np.allclose(x[:,:,:750].mean(-1),z[:,:,:750].mean(-1),atol=1e-6)
    assert np.allclose(x[:,:,:750]@x[:,:,:750].transpose(0,2,1),z[:,:,:750]@z[:,:,:750].transpose(0,2,1),atol=.01,rtol=1e-5)
    assert np.allclose(transform(x,'demean')[:,:,:750].mean(-1),0,atol=1e-6)
    protocol=dict(jobs=core.JOBS,n_fits=450,epochs=200,source_sha256=core.sha(Path(__file__)),core_sha256=core.sha(ROOT/'core/run_core_study.py'),
       transformations='Trial-wise mean over model-visible [0,750): subtract or repeat over all electrodes. Time shuffle shares one fixed permutation across electrodes per trial. Transform both training and testing; retrain each condition.',
       interpretation='Prespecified single-seed exploratory signal controls, not a neural source or artifact identification. Mean removal also removes real low-frequency neural information. Conditions do not imply causal mechanisms.',
       cfg=core.v4.CFG,data_sha256=core.sha(core.PROJECT/'Processed/BCIC2020Track3.h5'))
    p=core.ROOT/'protocol.json'
    if p.exists():assert json.loads(p.read_text())==protocol
    else:core.atomic_json(p,protocol)
    with (core.ROOT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);started=time.time()
        try:
            for ji,job in enumerate(core.JOBS):
                dest=core.OUT/core.job_name(job);dest.mkdir(exist_ok=True)
                for subject in range(15):
                    status=dict(state='running',pid=os.getpid(),started=started,job_index=ji,job=job,jobs=len(core.JOBS),updated=time.time())
                    core.subject(job,subject,dest,status);core.report()
            core.atomic_json(core.ROOT/'status.json',dict(state='complete',updated=time.time()));core.report()
        except Exception as e:core.atomic_json(core.ROOT/'status.json',dict(state='failed',error=repr(e),updated=time.time()));raise

if __name__=='__main__':main()
