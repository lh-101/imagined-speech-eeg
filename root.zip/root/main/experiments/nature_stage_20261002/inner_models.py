from pathlib import Path
import sys,json
sys.path[:0]=['/root/FAST','/root/FAST/experiments/residual_20260925']
import torch
from torch import nn
from torch.nn import functional as F
from transformers import PretrainedConfig
from FAST import FAST
from run_residual import seed_all,cosine_scheduler

ROOT=Path('/root/FAST/experiments/nature_stage_20261002')
CFG=dict(epochs=200,calibration_epochs=50,lr=.0005,calibration_lr=.0001,ridge=.1,kernel_gamma=2.,aux_weight=.3,score_scale=4.,supcon_temperature=.1,
         seeds=[42,142,242],calibration_fractions=[.25,.5,1.],classes=4,sfreq=256,input_samples=640,window_samples=256,step_samples=128)

def build(architecture,geometry):
    if architecture=='fast':
        cfg=PretrainedConfig(electrodes=geometry['channels'],zone_dict=geometry['zone_dict'],dim_cnn=32,dim_token=32,seq_len=640,
          window_len=256,slide_step=128,head='Conv4Layers',n_classes=4,num_layers=4,num_heads=8,dropout=.1)
        return FAST(cfg)
    if architecture=='eegnet':return EEGNet()
    raise ValueError(architecture)

class EEGNet(nn.Module):
    """EEGNet-8,2-style independent backbone. Fixed physical 0.5s temporal kernel.

    Same-padded temporal filter, depthwise spatial filter, separable temporal
    filter, ELU, average pools 4 and 8, dropout .5, dense four-class head.
    Local/global concatenation is FAST-specific; EEGNet uses its one penultimate
    feature vector for auxiliary supervision, never claims two independent views.
    """
    def __init__(self):
        super().__init__()
        self.temporal=nn.Conv2d(1,8,(1,128),padding='same',bias=False)
        self.bn1=nn.BatchNorm2d(8)
        self.spatial=nn.Conv2d(8,16,(128,1),groups=8,bias=False)
        self.bn2=nn.BatchNorm2d(16)
        self.depth=nn.Conv2d(16,16,(1,16),padding='same',groups=16,bias=False)
        self.point=nn.Conv2d(16,16,1,bias=False)
        self.bn3=nn.BatchNorm2d(16)
        self.drop=nn.Dropout(.5);self.classifier=nn.Linear(16*20,4)
    def features(self,x):
        x=self.bn1(self.temporal(x[:,None]))
        x=self.drop(F.avg_pool2d(F.elu(self.bn2(self.spatial(x))),(1,4)))
        x=self.drop(F.avg_pool2d(F.elu(self.bn3(self.point(self.depth(x)))),(1,8)))
        return x.flatten(1)
    def forward(self,x):return self.classifier(self.features(x))
    def constrain(self):
        with torch.no_grad():
            norm=self.spatial.weight.flatten(1).norm(dim=1).clamp_min(1e-12)
            self.spatial.weight.mul_((1./norm).clamp_max(1)[:,None,None,None])

def representation(model,x):
    if isinstance(model,EEGNet):
        f=model.features(x);return model.classifier(f),F.normalize(torch.asinh(f.float()),dim=1)
    f=model.forward_head(x)
    tokens=model.input_layer(f.flatten(2));tokens=torch.cat([model.cls_token.expand(len(x),-1,-1),tokens],dim=1)
    h=model.transformer(tokens+model.pos_embedding[:,:model.n_tokens+1])[:,0]
    main=model.last_layer(model.dropout(h))
    with torch.autocast('cuda',enabled=False):
        q=torch.cat([F.normalize(torch.asinh(f.float()).flatten(1),dim=1),F.normalize(h.float(),dim=1)],dim=1)/(2**.5)
    return main,q

def kernel(q,p):return torch.exp(-CFG['kernel_gamma']*(1-q.double()@p.double().T))
def loo(q,y):
    k=kernel(q,q);a=k+CFG['ridge']*torch.eye(len(q),device=q.device,dtype=k.dtype)
    chol=torch.linalg.cholesky(a);b=torch.cholesky_inverse(chol)
    target=F.one_hot(y,4).to(k.dtype)
    return (target-(b@target)/b.diag()[:,None]).float()
def supcon(q,y):
    with torch.autocast('cuda',enabled=False):
        sim=q.float()@q.float().T/CFG['supcon_temperature'];diag=torch.eye(len(q),device=q.device,dtype=torch.bool)
        positive=(y[:,None]==y[None,:])&~diag;valid=positive.sum(1)>0
        assert valid.any()
        logp=sim-torch.logsumexp(sim.masked_fill(diag,-torch.inf),dim=1,keepdim=True)
        return -(logp.masked_fill(~positive,0).sum(1)/positive.sum(1).clamp_min(1))[valid].mean()
def auxiliary(q,y,method):
    if method=='ce':return q.sum()*0
    if method=='loo':loss=F.cross_entropy(CFG['score_scale']*loo(q,y),y)
    elif method=='supcon':loss=supcon(q,y)
    else:raise ValueError(method)
    return CFG['aux_weight']*loss

def smoke():
    geometry=json.loads((ROOT/'inner_prepared/geometry.json').read_text()) if (ROOT/'inner_prepared/geometry.json').exists() else None
    if geometry is None:
        import mne
        from preprocess_inner import region_map
        geometry=region_map(mne.channels.make_standard_montage('biosemi128').ch_names)
    q=F.normalize(torch.randn(12,16,device='cuda'),dim=1).requires_grad_();y=torch.arange(12,device='cuda')%4
    actual=loo(q,y)
    for i in range(12):
        mask=torch.arange(12,device='cuda')!=i;k=kernel(q[mask],q[mask]);a=k+.1*torch.eye(11,device='cuda',dtype=torch.float64)
        alpha=torch.linalg.solve(a,F.one_hot(y[mask],4).double())
        expected=(kernel(q[i:i+1],q[mask])@alpha).float()[0]
        assert torch.allclose(actual[i],expected,atol=1e-5)
    changed=y.clone();changed[0]=(changed[0]+1)%4
    assert torch.allclose(actual[0],loo(q,changed)[0],atol=1e-5)
    for arch in ['fast','eegnet']:
        seed_all(9);m=build(arch,geometry).cuda().eval();x=torch.randn(12,128,640,device='cuda')
        with torch.autocast('cuda',dtype=torch.bfloat16):
            logits,z=representation(m,x)
            assert logits.shape==(12,4)
            assert torch.allclose(logits,m(x),atol=.005,rtol=.01)
            loss=F.cross_entropy(logits,y)+auxiliary(z,y,'loo')+auxiliary(z,y,'supcon')
        loss.backward()
        assert all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters())
        print('INNER_MODEL_SMOKE',arch,sum(p.numel() for p in m.parameters()),z.shape,flush=True)
    return dict(passed=True,architectures=['fast','eegnet'],classes=4,checks=['arbitrary-class LOO vs explicit refits','no direct self label in kernel prediction at fixed representation','BF16 finite complete model gradients','primary forward agrees','geometry covers all 128 channels'])

if __name__=='__main__':print(json.dumps(smoke(),indent=2))
