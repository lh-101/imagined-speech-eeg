"""Fixed source-vs-target-session diagnostic, using previously frozen splits."""
from pathlib import Path
import hashlib,json,time
import numpy as np

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'diagnostics_20261003'
PREP=ROOT/'inner_prepared'
CONTEXTS=['within_session','matched_source','full_source']
ARCHITECTURES=['fast','eegnet']
BANDS=[('delta',1,4),('theta',4,8),('alpha',8,13),('beta',13,30),('low_gamma',30,45)]

def atomic(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(obj,indent=2));tmp.replace(path)

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(4*1024**2),b''):h.update(block)
    return h.hexdigest()

def load_subject(subject):
    with np.load(PREP/f'sub-{subject:02d}.npz') as f:return {k:f[k] for k in f.files}

def fixed_split(subject,session,data):
    prior=ROOT/'inner_results/fast/ce'/f'seed42_sub{subject:02d}_ses{session}_base.json'
    split=json.loads(prior.read_text())['split']
    y=data['y'];pool=np.asarray(split['calibration_pool'],dtype=np.int64)
    evaluation=np.asarray(split['evaluation'],dtype=np.int64)
    source=np.asarray(split['source'],dtype=np.int64)
    rng=np.random.RandomState(10000+42+subject*101+session*17)
    target=[];matched=[]
    for c in range(4):
        a=pool[y[pool]==c]
        b=source[y[source]==c].copy();rng.shuffle(b)
        n=min(len(a),len(b));assert n>=1
        target.extend(a[:n]);matched.extend(b[:n])
    target=np.asarray(sorted(target),dtype=np.int64);matched=np.asarray(sorted(matched),dtype=np.int64)
    assert np.array_equal(np.bincount(y[target],minlength=4),np.bincount(y[matched],minlength=4))
    assert not set(source)&set(pool) and not set(pool)&set(evaluation)
    assert np.all(data['session'][source]!=session)
    assert np.all(data['session'][target]==session) and np.all(data['session'][evaluation]==session)
    train={'within_session':target,'matched_source':matched,'full_source':source}
    for v in train.values():assert not set(v)&set(evaluation)
    return train,evaluation

def moments(x):
    mean=x.mean(-1);logstd=np.log(np.maximum(x.std(-1),1e-6))
    return dict(mean=mean,log_std=logstd,mean_and_log_std=np.concatenate([mean,logstd],axis=1))

def bandpower(x):
    from scipy.signal import welch
    f,p=welch(x,fs=256.,window='hann',nperseg=256,noverlap=128,nfft=256,
              detrend='constant',scaling='density',axis=-1,average='mean')
    df=float(f[1]-f[0])
    return np.concatenate([np.log(np.maximum(p[..., (f>=lo)&(f<hi)].sum(-1)*df,1e-12))
                           for _,lo,hi in BANDS],axis=1).astype(np.float32)

def features(data):
    result={'eeg_'+k:v for k,v in moments(data['X']).items()}
    result.update({'exg_'+k:v for k,v in moments(data['EXG'][:,2:]).items()})
    result['eeg_log_bandpower']=bandpower(data['X'])
    assert len(result)==7 and all(np.isfinite(v).all() for v in result.values())
    return result

def summarize(rows,key_fields):
    groups={}
    for row in rows:
        key=tuple(row[k] for k in key_fields);groups.setdefault(key,[]).append(row)
    result=[]
    for key,records in groups.items():
        subjects=[]
        for s in range(1,11):
            completed=[r for r in records if r['subject']==s]
            if len(completed)==3:
                subjects.append(dict(subject=s,accuracy=float(np.mean([r['evaluation']['accuracy'] for r in completed])),
                    train_accuracy=float(np.mean([r['training']['accuracy'] for r in completed])),
                    macro_f1=float(np.mean([r['evaluation']['macro_f1'] for r in completed]))))
        result.append(dict(zip(key_fields,key),n_records=len(records),expected_records=30,n_complete_subjects=len(subjects),
            subjects=subjects,mean_accuracy=float(np.mean([r['accuracy'] for r in subjects])) if subjects else None,
            mean_train_accuracy=float(np.mean([r['train_accuracy'] for r in subjects])) if subjects else None))
    return dict(groups=result,updated=time.time(),aggregation='Mean over three sessions within subject; then over subjects. Single seed exploratory diagnostic.')

def prepare():
    import importlib.metadata
    OUT.mkdir(parents=True,exist_ok=True)
    assert json.loads((PREP/'prepare_status.json').read_text())['state']=='complete'
    splits=[];checkpoints={}
    for subject in range(1,11):
        data=load_subject(subject)
        for session in range(1,4):
            train,ev=fixed_split(subject,session,data)
            splits.append(dict(subject=subject,session=session,evaluation=ev.tolist(),
                train={k:v.tolist() for k,v in train.items()},train_class_counts={k:np.bincount(data['y'][v],minlength=4).tolist() for k,v in train.items()},
                evaluation_class_counts=np.bincount(data['y'][ev],minlength=4).tolist()))
            for method in ['ce','loo']:
                path=ROOT/'inner_results/fast'/method/f'seed42_sub{subject:02d}_ses{session}_base.pt'
                assert path.exists();checkpoints[str(path)]=sha(path)
    scripts=[ROOT/p for p in ['diagnostic_common.py','diagnostic_cpu.py','diagnostic_gpu.py','run_inner_study.py','inner_models.py','preprocess_inner.py']]
    protocol=dict(seed=42,subjects=10,sessions=3,contexts=CONTEXTS,architectures=ARCHITECTURES,objective='CE only for new model diagnostics',
        new_gpu_fits=150,reused_fast_ce_checkpoints=30,existing_fast_ce_loo_evaluations=60,cpu_fits=630,
        epochs=200,lr=.0005,source_class_sampling_seed='10000 + 42 + subject*101 + session*17',
        normalization='For each condition, fit per-channel means/std on its actual training trials only; no evaluation feature statistics',
        evaluation='Reuse the identical half-class evaluation indices frozen in previous second-dataset protocol. Within training uses disjoint labeled target-session pool; matched source uses equal per-class numbers from other two sessions; full source uses all other-session trials.',
        features=['eeg_mean','eeg_log_std','eeg_mean_and_log_std','eeg_log_bandpower','exg_mean','exg_log_std','exg_mean_and_log_std'],
        spectral=dict(bands_half_open=BANDS,method='Welch, Hann, 256-sample window, 128-sample overlap, 256 FFT, constant detrend, mean PSD; log absolute integrated density',units='uV^2; frequency in Hz'),
        linear='Training-only StandardScaler, LogisticRegression C=1, max_iter=2000, lbfgs; fixed settings, no test-based selection',
        source_hashes={p.name:sha(p) for p in scripts},prepared_manifest_sha256=sha(PREP/'manifest.json'),
        previous_protocol_sha256=sha(ROOT/'inner_results/priority_protocol.json'),old_checkpoint_sha256=checkpoints,
        packages={k:importlib.metadata.version(k) for k in ['torch','numpy','scipy','scikit-learn','mne']},
        limitations=['Exploratory after seeing previous failure; not independent confirmation','Single seed and half-session evaluation, not directly compared to previous full-session scores',
            'Within-session condition uses permitted target labels; not zero-calibration deployment','Author preprocessing may use session-wide data; within-session random trial holdout can reflect slow drift',
            'Channel frequency features and EXG decodability do not prove cortical origin or language specificity','Matched training counts control amount and class balance, not every session-quality difference'])
    # JSON canonicalization accounts for tuples in fixed band definitions.
    protocol=json.loads(json.dumps(protocol));path=OUT/'protocol.json'
    if path.exists():assert json.loads(path.read_text())==protocol,'Diagnostic protocol changed; use a new directory'
    else:atomic(path,protocol)
    atomic(OUT/'splits.json',dict(rows=splits));print('DIAGNOSTIC_PROTOCOL_FROZEN',len(splits),'GPU new=150, CPU=630',flush=True)

def smoke_features():
    t=np.arange(640)/256.;x=np.broadcast_to(np.sin(2*np.pi*10*t),(3,2,640)).copy().astype(np.float32)
    z=bandpower(x).reshape(3,5,2)
    assert np.argmax(z[0,:,0])==2 and np.isfinite(z).all()
    atomic(OUT/'feature_smoke.json',dict(passed=True,checks=['10 Hz synthetic sinusoid peaks in alpha power feature','finite log powers']))

if __name__=='__main__':prepare();smoke_features()
