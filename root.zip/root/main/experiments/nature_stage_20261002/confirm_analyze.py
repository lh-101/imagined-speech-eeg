"""Frozen independent-participant endpoints; no outcome-based model selection."""
from pathlib import Path
import argparse,csv,hashlib,itertools,json,time
import numpy as np
from scipy.signal import welch
from sklearn.metrics import confusion_matrix,accuracy_score,balanced_accuracy_score,f1_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'multicue_confirm_20261003'
METHODS=['ce','additive','protected']

def atomic(p,x):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(x,indent=2));t.replace(p)

def metrics(y,p):
 cm=confusion_matrix(y,p,labels=[0,1,2]);counts=cm.sum(1)
 assert (counts>0).all(),'Target class missing; endpoint not estimable'
 return dict(accuracy=float(accuracy_score(y,p)),balanced_accuracy=float(balanced_accuracy_score(y,p)),macro_f1=float(f1_score(y,p,average='macro',labels=[0,1,2],zero_division=0)),confusion=cm.tolist(),class_recalls=(cm.diagonal()/counts).tolist(),n_test=len(y))

def spectral(subject):
 folder=OUT/('sub-'+subject);base=folder/'multicue_fast_20261003'
 dest=folder/'spectral_reference.json'
 if dest.exists():return
 with np.load(base/'epochs.npz') as z:
  X=z['X'];y=z['y'];tasks=z['tasks'];mods=z['modalities'];groups=z['groups'];pair=z['pair']
 f,p=welch(X,fs=256,nperseg=256,noverlap=128,axis=-1)
 features=np.stack([np.log(np.maximum(p[:,:,(f>=a)&(f<b)].sum(-1),1e-30)) for a,b in [(1,4),(4,8),(8,13),(13,30),(30,45)]],axis=-1)
 features-=features.mean(axis=1,keepdims=True);features=features.reshape(len(X),-1)
 indices=[];preds=[]
 for split in json.loads((base/'splits.json').read_text()):
  tr=np.array(split['train']);te=np.array(split['test'])
  tr=tr[(tasks[tr]=='perception')&(mods[tr]=='text')]
  assert not set(groups[tr])&set(groups[te]);assert not set(pair[tr])&set(pair[te])
  m=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=2000))
  m.fit(features[tr],y[tr]);indices.extend(te);preds.extend(m.predict(features[te]))
 order=np.argsort(indices);idx=np.array(indices)[order];pred=np.array(preds)[order]
 assert np.array_equal(idx,np.arange(len(X)))
 results=[]
 for task in ['imagination','perception']:
  for mod in ['audio','text','image']:
   keep=(tasks==task)&(mods==mod)
   results.append(dict(target_task=task,target=mod,**metrics(y[keep],pred[keep])))
 atomic(dest,dict(subject=subject,source_task='perception',source='text',method='spectral_logistic',results=results,secondary=True))

def holm(ps):
 ps=np.array(ps);order=np.argsort(ps);adj=np.empty(len(ps));value=0.
 for rank,index in enumerate(order):
  value=max(value,min(1.,(len(ps)-rank)*ps[index]));adj[index]=value
 return adj.tolist()

def signflip(delta):
 delta=np.array(delta);obs=delta.mean()
 signs=np.array(list(itertools.product([-1,1],repeat=len(delta))))
 null=(signs*delta).mean(1)
 return float(np.mean(null>=obs-1e-12))

def aggregate():
 man=json.loads((OUT/'protocol.json').read_text());rows=[];records=[];failures=[]
 for meta in man['cohort']:
  subject=meta['subject'];folder=OUT/('sub-'+subject);base=folder/'multicue_fast_20261003'
  p=base/'summary.json'
  if not p.exists() or not json.loads(p.read_text()).get('complete'):
   failures.append(dict(subject=subject,reason='No complete frozen-source 15-fit summary'));continue
  summary=json.loads(p.read_text());results=summary['results'];by=[];index0=None;y0=None;groups0=None
  with np.load(base/'epochs.npz') as z:all_tasks=z['tasks'];all_mods=z['modalities']
  for method in METHODS:
   rs=next(r for r in results if r['method']==method and r['target_task']=='imagination' and r['target']=='image')
   info=[]
   for fold in range(5):
    with np.load(base/'results'/f'perception_text_{method}_fold{fold}.npz') as z:
     assert ((all_tasks[z['train_index']]=='perception')&(all_mods[z['train_index']]=='text')).all()
     keep=(z['target_tasks']=='imagination')&(z['target_modalities']=='image')
     info.extend(zip(z['test_index'][keep].tolist(),z['y'][keep].tolist(),z['pred'][keep].tolist(),z['groups'][keep].tolist()))
   info.sort();idx=np.array([r[0] for r in info]);y=np.array([r[1] for r in info]);pred=np.array([r[2] for r in info]);groups=np.array([r[3] for r in info])
   assert len(set(idx))==len(idx)
   calc=metrics(y,pred)
   for metric in ['accuracy','balanced_accuracy','macro_f1']:assert abs(calc[metric]-rs[metric])<1e-12
   if index0 is None:index0=idx;y0=y;groups0=groups
   else:assert np.array_equal(index0,idx) and np.array_equal(y0,y) and np.array_equal(groups0,groups)
   by.append(pred)
   rows.append(dict(subject=subject,session=meta['session'],method=method,**{k:calc[k] for k in ['accuracy','balanced_accuracy','macro_f1','n_test']},recall_flower=calc['class_recalls'][0],recall_guitar=calc['class_recalls'][1],recall_penguin=calc['class_recalls'][2]))
  group_indices=[np.where(groups0==g)[0] for g in np.unique(groups0)]
  mixed=sum(len(np.unique(y0[ix]))>1 for ix in group_indices)
  records.append(dict(subject=subject,y=y0,pred=np.array(by),group_indices=group_indices,mixed_groups=mixed,total_groups=len(group_indices)))
 if not rows:atomic(OUT/'analysis.json',dict(complete=False,missing=failures,error='No complete participant endpoints'));return
 with (OUT/'primary_participant_results.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 ids=[r['subject'] for r in records];matrix=np.array([[next(r['balanced_accuracy'] for r in rows if r['subject']==s and r['method']==m) for m in METHODS] for s in ids])
 rng=np.random.RandomState(20261003);indices=rng.randint(len(ids),size=(10000,len(ids)))
 bootstrap=matrix[indices].mean(1);diff=matrix[:,1:]-matrix[:,0,None];bdiff=diff[indices].mean(1)
 paired=[];ps=[]
 for j,method in enumerate(METHODS[1:]):
  p=signflip(diff[:,j]);ps.append(p)
  paired.append(dict(method=method,mean_delta_pp=float(diff[:,j].mean()*100),subject_delta_pp=(diff[:,j]*100).tolist(),positive_subjects=int((diff[:,j]>0).sum()),negative_subjects=int((diff[:,j]<0).sum()),ties=int((abs(diff[:,j])<1e-12).sum()),bootstrap95_delta_pp=(np.quantile(bdiff[:,j],[.025,.975])*100).tolist(),one_sided_exact_signflip_p=p))
 for r,p in zip(paired,holm(ps)):r['holm_two_contrasts_p']=p
 coverage=[dict(subject=r['subject'],mixed_groups=r['mixed_groups'],total_groups=r['total_groups']) for r in records]
 # Conditional target-only permutation is valid only under the stated
 # within-group exchangeability assumption. No target label appears in any
 # training fit; consequently refitting on permuted target labels is identical.
 B=9999;null=np.zeros((B,3));identifiable=all(r['mixed_groups']>0 for r in records)
 if identifiable:
  for r in records:
   y=r['y'];pred=r['pred'];counts=np.bincount(y,minlength=3);n=len(y)
   for b in range(B):
    perm=y.copy()
    for ix in r['group_indices']:perm[ix]=perm[ix][rng.permutation(len(ix))]
    weight=n/(3*counts[perm]);null[b]+=np.mean((pred==perm[None,:])*weight[None,:],axis=1)/len(records)
   atomic(OUT/'analysis_progress.json',dict(state='conditional_target_permutation',last_subject=r['subject'],completed_subjects=ids[:ids.index(r['subject'])+1],n_permutations=B))
 means=matrix.mean(0);absolute=[]
 absps=[float((1+(null[:,j]>=means[j]-1e-12).sum())/(B+1)) for j in range(3)] if identifiable else [None]*3
 adj=holm(absps) if identifiable else [None]*3
 for j,m in enumerate(METHODS):
  absolute.append(dict(method=m,mean_balanced_accuracy=float(means[j]),subject_bootstrap95=np.quantile(bootstrap[:,j],[.025,.975]).tolist(),uniform_chance_reference=1/3,
   conditional_target_permutation_p=absps[j],holm_three_methods_p=adj[j],conditional_null_mean=float(null[:,j].mean()) if identifiable else None,conditional_null95=np.quantile(null[:,j],[.025,.975]).tolist() if identifiable else None))
 note='Nine fixed participants, one seed, participant is analysis unit. Local plan fixed before new outcomes; not formally preregistered. Conditional target-label permutation assumes exchangeability within acquisition groups, preserves group counts and does not test full source-label fitting null. Bootstrap conditional on fixed folds/models. No causal, speech-specific, Nature acceptance, novel-category or between-participant-decoder claim.'
 output=dict(complete=len(ids)==len(man['cohort']),observed_subjects=ids,fixed_subjects=[s['subject'] for s in man['cohort']],missing=failures,primary_rows=rows,paired_contrasts=paired,absolute_performance=absolute,permutation_coverage=coverage,n_permutations=B,notes=note,frozen_protocol_sha256=hashlib.sha256((OUT/'protocol.json').read_bytes()).hexdigest())
 atomic(OUT/'analysis.json',output)
 if identifiable:np.savez_compressed(OUT/'target_permutation_null.npz',balanced_accuracy=null,methods=np.array(METHODS),subjects=np.array(ids))
 atomic(OUT/'analysis_progress.json',dict(state='complete',subjects=len(ids),updated=time.time()))
 print(json.dumps(dict(subjects=ids,paired=paired,absolute=absolute,missing=failures),indent=2),flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--subject');a=p.parse_args()
 if a.subject:spectral(a.subject)
 else:aggregate()
