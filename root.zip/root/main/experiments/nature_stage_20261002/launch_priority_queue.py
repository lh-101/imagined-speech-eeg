from pathlib import Path
import json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:args=p.joinpath('cmdline').read_bytes().split(b'\0')
    except OSError:continue
    if any(a in [str(ROOT/'priority_queue.py').encode(),str(ROOT/'stage_queue.py').encode(),str(ROOT/'core/run_core_study.py').encode()] for a in args):
        raise RuntimeError(f'Training queue already running: {p.name}')
amendment=dict(date='2026-10-03',reason='User requests faster results and delegates experiment prioritization; external accuracy not yet observed',
    core_priority=dict(methods=['ce','joint_loo'],seed=42,subjects=15,folds=5,expected_fits=150),
    second_dataset_priority=dict(architecture='fast',methods=['ce','loo'],seed=42,subjects=10,held_out_sessions=3,expected_fits=60),
    total_priority_fits_including_saved=210,extended_matrix='deferred, not automatically resumed',
    unchanged='Original data splits, initializations, objectives, 200 epochs and hyperparameters. Main classifier remains primary endpoint.')
path=ROOT/'priority_amendment.json'
if path.exists():assert json.loads(path.read_text())==amendment
else:path.write_text(json.dumps(amendment,indent=2))
with (ROOT/'priority_queue.log').open('a') as log:
    p=subprocess.Popen([sys.executable,'-u',str(ROOT/'priority_queue.py')],cwd='/root/FAST',stdin=subprocess.DEVNULL,
        stdout=log,stderr=subprocess.STDOUT,start_new_session=True,
        env=dict(os.environ,PYTHONUNBUFFERED='1',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4'))
(ROOT/'priority_queue.pid').write_text(str(p.pid))
print('PRIORITY_QUEUE_LAUNCHED',p.pid)
