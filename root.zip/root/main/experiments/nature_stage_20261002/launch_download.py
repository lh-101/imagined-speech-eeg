from pathlib import Path
import os,sys,subprocess,json,time
r=Path(__file__).resolve().parent
pidfile=r/'download.pid'
if pidfile.exists():
    pid=int(pidfile.read_text());p=Path(f'/proc/{pid}/cmdline')
    if p.exists() and b'prepare_inner_data.py' in p.read_bytes():raise RuntimeError(f'Download already running: {pid}')
with (r/'download.log').open('a') as log:
    p=subprocess.Popen([sys.executable,'-u',str(r/'prepare_inner_data.py')],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,
       start_new_session=True,env=dict(os.environ,PYTHONUNBUFFERED='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
pidfile.write_text(str(p.pid));print('DATA_DOWNLOAD_LAUNCHED',p.pid,str(r/'download.log'))
