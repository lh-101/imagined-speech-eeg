import argparse,json,pathlib,time,os
p=argparse.ArgumentParser(); p.add_argument('--watch',action='store_true'); args=p.parse_args()
root=pathlib.Path(__file__).resolve().parent
def span(s):
    if s is None: return '尚无法估计'
    return f'{int(s)//3600:02d}:{int(s)%3600//60:02d}:{int(s)%60:02d}'
while True:
    f=root/'multicue_pilot_20261003'/'status.json'
    if args.watch: print('\033[2J\033[H',end='')
    if not f.exists(): print('尚无状态文件')
    else:
        d=json.loads(f.read_text()); pid=d.get('pid'); print('跨提示单被试可行性实验 | Ctrl+C只退出显示')
        print('状态:',d['state'],'| PID:',pid,'| 进程存在:',pathlib.Path(f'/proc/{pid}').exists())
        print('已运行:',span(time.time()-d['started']))
        if 'downloaded_bytes' in d:
            print('下载:',round(d['downloaded_bytes']/1024**2,1),'/',round(d['expected_bytes']/1024**2,1),'MiB', '|',d.get('percent',0),'%')
            print('下载剩余粗估:',span(d.get('download_eta_seconds')),'（不含后续分析，速度可能变化）')
        if 'evaluations_done' in d: print('分析:',d['evaluations_done'],'/',d['evaluations_total'])
        if 'error' in d: print('错误:',d['error'])
        print('状态更新距现在:',round(time.time()-d['updated']),'秒')
    if not args.watch: break
    try: time.sleep(5)
    except KeyboardInterrupt: break
