from pathlib import Path
import json,hashlib
import numpy as np,mne
from scipy.signal import resample_poly
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'multicue_fast_20261003';OUT.mkdir(exist_ok=True)
def atomic(p,obj):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(obj,indent=2));t.replace(p)
events=json.loads((ROOT/'multicue_pilot_20261003/event_audit.json').read_text())
raw=mne.io.read_raw_fif('/root/autodl-tmp/eeg_research/multicue_confirm_20261003/sub-012/sub12_sess1_50_ica_eeg.fif',preload=False,verbose='ERROR')
picks=mne.pick_types(raw.info,eeg=True,exclude='bads');channels=[raw.ch_names[i] for i in picks]
import sys;sys.path.insert(0,'/root/FAST')
from BCIC2020Track3_preprocess import Electrodes,Zones
positions=mne.channels.make_standard_montage('standard_1005').get_positions()['ch_pos']
alias={'M1':'TP9','M2':'TP10'}
missing=[n for n in channels if alias.get(n,n) not in positions]
if missing:raise ValueError('Unmapped standard electrode names: '+str(missing))
refs=np.array([positions[n] for n in Electrodes]);refs/=np.linalg.norm(refs,axis=1,keepdims=True)
owner={n:k for k,v in Zones.items() for n in v};groups={k:[] for k in Zones}
for n in channels:
 p=positions[alias.get(n,n)];groups[owner[Electrodes[int(np.argmax(refs@(p/np.linalg.norm(p))))]]].append(n)
assert all(groups.values()) and sum(map(len,groups.values()))==len(channels)
atomic(OUT/'geometry.json',dict(channels=channels,zone_dict=groups,aliases=alias,rule='Fixed standard_1005 nearest angular FAST reference group; no data-fitted localization'))
X=[];rows=events['events'];fs=raw.info['sfreq'];assert fs==1024
for i,e in enumerate(rows):
 left=1 if e['task']=='imagination' else 0;right=left+2
 st=round((e['onset']+left)*fs);en=round((e['onset']+right)*fs)
 if st<0 or en>raw.n_times:raise ValueError('Window outside file')
 if i+1<len(rows) and e['onset']+right>rows[i+1]['onset']:raise ValueError('Window crosses next task event')
 x=raw.get_data(picks=picks,start=st,stop=en);x=resample_poly(x,1,4,axis=-1).astype(np.float32)
 assert x.shape==(len(channels),512) and np.isfinite(x).all();X.append(x)
X=np.asarray(X);labels=np.array([['flower','guitar','penguin'].index(r['word']) for r in rows])
np.savez_compressed(OUT/'epochs.npz',X=X,y=labels,groups=np.array([r['group'] for r in rows]),pair=np.array([r['pair'] for r in rows]),tasks=np.array([r['task'] for r in rows]),modalities=np.array([r['modality'] for r in rows]))
atomic(OUT/'data_audit.json',dict(source_sha256=events.get('sha256','e3e4b6c9aab87d890dc7e84d7abd9b2f91071482f8a7ba23b84b96edb8bdbb55'),n_events=len(X),n_pairs=len(set(r['pair'] for r in rows)),shape=list(X.shape),sfreq=256,original_sfreq=fs,windows={'perception':[0,2],'imagination':[1,3]},resampling='per-epoch scipy resample_poly 1/4; anti-alias filtering; no fitted cross-trial preprocessing',excluded=events['excluded'],bads=raw.info['bads'],units='Volts; source-training-only per-channel standardization',preprocessing_limitation='Released author full-recording ICA/50Hz processed signal; no independent fold-specific ICA'))
print('PREPARED',X.shape,flush=True)

atomic(OUT/'source_files.json',{'subject': '012', 'session': '01', 'files': [{'path': 'derivatives/preprocessed/sub-012/ses-01/eeg/sub12_sess1_50_ica_eeg.fif', 'filename': 'sub12_sess1_50_ica_eeg.fif', 'size': 2146030815, 'sha256': 'e3e4b6c9aab87d890dc7e84d7abd9b2f91071482f8a7ba23b84b96edb8bdbb55', 'url': 'https://s3.amazonaws.com/openneuro.org/ds004306/derivatives/preprocessed/sub-012/ses-01/eeg/sub12_sess1_50_ica_eeg.fif'}, {'path': 'derivatives/preprocessed/sub-012/ses-01/eeg/sub12_sess1_50_ica_eeg-1.fif', 'filename': 'sub12_sess1_50_ica_eeg-1.fif', 'size': 162627640, 'sha256': '5290c73968ec7b0ad12e223416c68de2568f41107617435a56031a1f20cadc11', 'url': 'https://s3.amazonaws.com/openneuro.org/ds004306/derivatives/preprocessed/sub-012/ses-01/eeg/sub12_sess1_50_ica_eeg-1.fif'}], 'total_bytes': 2308658455})
