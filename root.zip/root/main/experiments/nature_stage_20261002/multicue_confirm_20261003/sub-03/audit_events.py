import mne,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent/'multicue_pilot_20261003'
def update(**kw):pass
raw=mne.io.read_raw_fif('/root/autodl-tmp/eeg_research/multicue_confirm_20261003/sub-03/sub3_sess3_50_ica_eeg.fif',preload=False,verbose='ERROR')
picks=mne.pick_types(raw.info,eeg=True,exclude='bads')
expected=['sub3_sess3_50_ica_eeg-1.fif', 'sub3_sess3_50_ica_eeg.fif']
assert sorted(Path(p).name for p in raw.filenames)==expected, (raw.filenames,expected)
rows=[]; pair=-1; modality_prev=None; sequence=-1; index_sequence=0; pending=None
for a in raw.annotations:
    desc=a['description']; low=desc.lower()
    if 'perception' not in low and 'imagination' not in low: continue
    task='imagination' if 'imagination' in low else 'perception'
    word=next((w for w in ['flower','guitar','penguin'] if w in low),None)
    mod='audio' if ('_a_' in low or 'perceptiona_' in low or 'audio' in low) else 'text' if '_t_' in low else 'image' if '_image_' in low else None
    if not word or not mod: raise ValueError('Unrecognized task annotation: '+desc)
    if task=='perception':
        if pending is not None: raise ValueError('Missing imagination partner')
        pair+=1
        if mod!=modality_prev: sequence+=1; index_sequence=0
        group=f'{sequence}_{index_sequence//5}'; index_sequence+=1; modality_prev=mod
        pending=(word,mod,group,pair)
    elif pending is None or pending[:2]!=(word,mod): raise ValueError('Missing or mismatched perception partner')
    else: group=pending[2]; pair=pending[3]
    onset=float(a['onset'])-raw.first_time
    rows.append({'task':task,'word':word,'modality':mod,'group':group,'pair':pair,'onset':onset,'description':desc})
    if task=='imagination': pending=None
excluded=[]
if pending is not None:
    if not rows or rows[-1]['task']!='perception' or rows[-1]['pair']!=pending[3]:
        raise ValueError('Invalid terminal pair state')
    excluded.append({'event':rows.pop(),'reason':'Final perception has no imagination partner before recording ends'})
    pending=None
if len(rows)<100: raise ValueError('Insufficient complete paired data')
if len(rows)%2: raise ValueError('Odd paired event count')
update(state='extracting_features',paired_events=len(rows),complete_pairs=len(rows)//2,excluded_terminal_events=len(excluded),features_done=0,features_total=len(rows))
(ROOT/'event_audit.json').write_text(json.dumps({'sfreq':raw.info['sfreq'],'channels':[raw.ch_names[i] for i in picks],'bads':raw.info['bads'],'events':rows,'excluded':excluded},indent=2))