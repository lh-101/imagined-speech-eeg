import os
os.environ['OMP_NUM_THREADS']='4';os.environ['OPENBLAS_NUM_THREADS']='2'
from pathlib import Path
import sys,json,time,hashlib,traceback,fcntl
import numpy as np,torch
from torch.nn import functional as F
from sklearn.model_selection import GroupKFold
from sklearn.metrics import accuracy_score,f1_score,balanced_accuracy_score,confusion_matrix
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'multicue_fast_20261003'
sys.path[:0]=['/root/FAST','/root/FAST/experiments/residual_20260925']
import run_metric_v4 as v4
from transformers import PretrainedConfig
METHODS=['ce','additive','protected'];TASKS=['perception'];MODS=['text']
START=time.time();status={'state':'starting','started':START,'pid':os.getpid(),'fits_total':15,'fits_done':0}
def atomic(p,o):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(o,indent=2));t.replace(p)
def update(**kw):
 status.update(kw);status['updated']=time.time();status['elapsed_seconds']=time.time()-START;atomic(OUT/'status.json',status)
def state_hash(m):
 h=hashlib.sha256()
 for k,x in m.state_dict().items():h.update(k.encode());h.update(x.detach().cpu().numpy().tobytes())
 return h.hexdigest()
def loo(q,y):
 k=v4.kernel(q,q);b=torch.cholesky_inverse(torch.linalg.cholesky(k+.1*torch.eye(len(q),device=q.device,dtype=k.dtype)));target=F.one_hot(y,3).to(k.dtype)
 return (target-(b@target)/b.diag()[:,None]).float()
def metrics(y,p):
 return dict(accuracy=float(accuracy_score(y,p)),balanced_accuracy=float(balanced_accuracy_score(y,p)),macro_f1=float(f1_score(y,p,average='macro',labels=[0,1,2],zero_division=0)),confusion=confusion_matrix(y,p,labels=[0,1,2]).tolist(),n_test=len(y))
def build(geometry):
 cfg=v4.config().to_dict();cfg.update(electrodes=geometry['channels'],zone_dict=geometry['zone_dict'],seq_len=512,window_len=256,slide_step=128,n_classes=3)
 return v4.FAST(PretrainedConfig(**cfg)).cuda()
def summary():
 results=[]
 for task in TASKS:
  for mod in MODS:
   for method in METHODS:
    paths=[OUT/'results'/f'{task}_{mod}_{method}_fold{f}.npz' for f in range(5)]
    if not all(p.exists() for p in paths):continue
    for t in ['imagination','perception']:
     for dest in ['audio','text','image']:
      yy=[];pp=[]
      for p in paths:
       with np.load(p) as z:
        keep=(z['target_tasks']==t)&(z['target_modalities']==dest);yy.extend(z['y'][keep]);pp.extend(z['pred'][keep])
      results.append(dict(source_task=task,source=mod,method=method,target_task=t,target=dest,**metrics(yy,pp)))
 atomic(OUT/'summary.json',dict(complete=status['fits_done']==15,subject='sub-016',seed=42,results=results,primary='Perception-text to imagination-image pooled balanced accuracy; additive/protected-minus-CE, all fixed validation participants',limitations=['One frozen seed; this record is one of nine fixed unobserved validation participants','perception and imagination are different tasks despite matched 2s windows','all-recording author ICA','same word/stimulus exemplars can recur across folds','no inferred language-specific mechanism or population generalization']))
def main():
 lock=(OUT/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 torch.set_num_threads(4);torch.backends.cudnn.benchmark=False
 with np.load(OUT/'epochs.npz') as z:X=z['X'];y=z['y'];groups=z['groups'];pair=z['pair'];tasks=z['tasks'];mods=z['modalities']
 geo=json.loads((OUT/'geometry.json').read_text());outer=list(GroupKFold(5).split(X,y,groups))
 splits=[]
 for f,(tr,te) in enumerate(outer):
  assert not set(pair[tr])&set(pair[te]);assert not set(groups[tr])&set(groups[te])
  splits.append(dict(fold=f,train=tr.tolist(),test=te.tolist()))
 atomic(OUT/'splits.json',splits)
 manifest=dict(subject='sub-016',session='01',methods=METHODS,tasks=TASKS,modalities=MODS,n_fits=15,seed=42,epochs=200,optimizer='AdamW default weight_decay .01',lr=.0005,lr_schedule='Historical cosine scheduler index epoch-1; identical across arms',aux_weight=.3,ridge=.1,gamma=2,score_scale=4,gradient_cap=.5,primary_readout='main head only',windows={'imagination':[1,3],'perception':[0,2]},input_samples=512,sfreq=256,normalization='channel mean/std from source training epochs only; targets never fitted',split='Paired perception/imagination and consecutive groups retained; GroupKFold 5',primary='Perception-text to imagination-image balanced accuracy; additive/protected minus CE',secondary='additive comparison; matched-duration perception; complete source-task/modality to target-task/modality matrix',original_configuration=v4.config().to_dict(),source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'prepare_fast.py',Path(v4.__file__),Path('/root/FAST/FAST.py')]},note='Prespecified validation in remaining public participants after three-participant discovery. No test-based selection or hyperparameter search; local plan, not registered. See parent protocol.json.')
 atomic(OUT/'manifest.json',manifest)
 v4.seed_all(9);q=F.normalize(torch.randn(9,12,device='cuda'),dim=1).requires_grad_();yy=torch.arange(9,device='cuda')%3;s=loo(q,yy)
 for i in range(9):
  mask=torch.arange(9,device='cuda')!=i;k=v4.kernel(q[mask],q[mask]);expected=v4.kernel(q[i:i+1],q[mask])@torch.linalg.solve(k+.1*torch.eye(8,device='cuda',dtype=k.dtype),F.one_hot(yy[mask],3).double());assert torch.allclose(s[i],expected.float()[0],atol=1e-5)
 m=build(geo).eval();xx=torch.from_numpy(X[:9]).cuda()
 with torch.autocast('cuda',dtype=torch.bfloat16):a,q=v4.representation(m,xx);loss=F.cross_entropy(a,yy)+.3*F.cross_entropy(4*loo(q,yy),yy)
 assert a.shape==(9,3);loss.backward();assert all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters())
 with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):assert torch.allclose(a,m(xx),atol=.005,rtol=.01)
 del m,xx,a,q,loss;torch.cuda.empty_cache();atomic(OUT/'smoke.json',dict(passed=True,checks=['124-channel or actual cap forward shape','three-class analytic LOO matches explicit refits','finite BF16 backward','forward agrees with original FAST','paired groups separated']))
 (OUT/'results').mkdir(exist_ok=True);durations=[]
 for task in TASKS:
  for mod in MODS:
   for f,(train,test) in enumerate(outer):
    tr=train[(tasks[train]==task)&(mods[train]==mod)]
    assert len(np.unique(y[tr]))==3
    mean=X[tr].mean(axis=(0,2),keepdims=True);std=X[tr].std(axis=(0,2),keepdims=True).clip(1e-12);xx=((X-mean)/std).astype(np.float32)
    xt=torch.from_numpy(xx[tr]).cuda();yt=torch.from_numpy(y[tr]).cuda()
    for method in METHODS:
     stem=f'{task}_{mod}_{method}_fold{f}';dest=OUT/'results'/stem
     if dest.with_suffix('.npz').exists():status['fits_done']+=1;continue
     update(state='training',source_task=task,modality=mod,method=method,fold=f+1,epoch=0)
     v4.seed_all(42+f);model=build(geo);initial=state_hash(model);params=list(model.parameters());opt=torch.optim.AdamW(params,lr=.0005);schedule=v4.cosine_scheduler(1,.1,200,1,warmup_epochs=10);begin=time.time();trace=[]
     for epoch in range(200):
      model.train();opt.zero_grad(set_to_none=True)
      for g in opt.param_groups:g['lr']=.0005*float(schedule[epoch-1])
      with torch.autocast('cuda',dtype=torch.bfloat16):logits,q=v4.representation(model,xt);mainloss=F.cross_entropy(logits,yt)
      aux=None;scale=None
      if method=='ce':mainloss.backward()
      else:
       aux=.3*F.cross_entropy(4*loo(q,yt),yt)
       if method=='additive':(mainloss+aux).backward()
       else:gm=torch.autograd.grad(mainloss,params,retain_graph=True,allow_unused=True);ga=torch.autograd.grad(aux,params,allow_unused=True);_,scale=v4.protect(gm,ga,params)
      if not torch.isfinite(mainloss) or any(p.grad is not None and not torch.isfinite(p.grad).all() for p in params):raise ValueError('Nonfinite loss or gradients')
      opt.step()
      if epoch==0 or (epoch+1)%25==0:
       trace.append(dict(epoch=epoch+1,main_loss=float(mainloss.detach()),aux_loss=None if aux is None else float(aux.detach()),aux_scale=scale));update(epoch=epoch+1)
     model.eval();pred=[];probs=[];representations=[]
     with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):
      for batch in np.array_split(test,max(1,(len(test)+63)//64)):
       a,qe=v4.representation(model,torch.from_numpy(xx[batch]).cuda());pred.extend(a.argmax(1).cpu().tolist());probs.extend(a.float().softmax(1).cpu().tolist());representations.extend(qe.float().cpu().tolist())
     for other in METHODS:
      op=OUT/'results'/f'{task}_{mod}_{other}_fold{f}.json'
      if op.exists():assert json.loads(op.read_text())['initial_state_sha256']==initial
     seconds=time.time()-begin
     torch.save(dict(state_dict=model.cpu().state_dict(),config=model.config.to_dict(),mean=mean,std=std,train=tr,test=test),dest.with_suffix('.pt'))
     atomic(dest.with_suffix('.json'),dict(source_task=task,modality=mod,method=method,fold=f,initial_state_sha256=initial,seconds=seconds,trace=trace,n_train=len(tr),n_test=len(test)))
     tmp=dest.with_suffix('.npz.tmp')
     with tmp.open('wb') as stream:np.savez_compressed(stream,y=y[test],pred=np.array(pred),prob=np.array(probs),representation=np.array(representations,dtype=np.float32),test_index=test,train_index=tr,target_tasks=tasks[test],target_modalities=mods[test],groups=groups[test],pair=pair[test])
     tmp.replace(dest.with_suffix('.npz'));status['fits_done']+=1;durations.append(seconds);eta=float(np.mean(durations)*(15-status['fits_done']));update(estimated_remaining_seconds=eta)
     summary();print('FIT_DONE',stem,seconds,'done',status['fits_done'],'eta',eta,flush=True)
     del model,opt,logits,q,mainloss,aux;torch.cuda.empty_cache()
    del xt,yt
 update(state='complete',estimated_remaining_seconds=0);summary()
if __name__=='__main__':
 try:main()
 except Exception as exc:update(state='failed',error=str(exc),traceback=traceback.format_exc());raise
