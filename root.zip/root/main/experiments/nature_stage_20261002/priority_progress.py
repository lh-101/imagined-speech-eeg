from pathlib import Path
import argparse,json,statistics,time
ROOT=Path(__file__).resolve().parent
def read(p):
    try:return json.loads(p.read_text())
    except (OSError,ValueError):return {}
def duration(seconds):
    if seconds is None:return 'not yet estimated'
    seconds=max(0,int(seconds));return f'{seconds//3600:02d}:{seconds//60%60:02d}:{seconds%60:02d}'
def render():
    state=read(ROOT/'priority_status.json');core=read(ROOT/'core/status.json')
    download=read(ROOT/'inner_data/download_status.json');inner=read(ROOT/'inner_results/status.json')
    completed_core=[];times=[]
    for method in ['ce','joint_loo']:
        dest=ROOT/'core/results'/f'full_{method}_seed42'
        markers=list(dest.glob('*-fold*.npz'));completed_core.extend(markers)
        times.extend(read(p.with_suffix('.json')).get('seconds',0) for p in markers)
    ext=list((ROOT/'inner_results/fast').glob('*/seed42_sub*_ses*_base.npz'))
    ext=[p for p in ext if p.parent.name in ['ce','loo']]
    method_times={}
    remaining_training=0
    for method,default in [('ce',30),('loo',55)]:
        markers=[p for p in ext if p.parent.name==method]
        measured=[read(p.with_suffix('.json')).get('seconds',0) for p in markers]
        measured=[v for v in measured if v>0]
        speed=statistics.median(measured) if measured else default
        method_times[method]=dict(n=len(markers),seconds=speed,measured=bool(measured))
        remaining_training+=(30-len(markers))*speed
    print('# Priority EEG batch | Ctrl+C stops display only')
    print('Queue:',state.get('state'),'| phase:',state.get('phase'))
    print(f'First dataset paired core: {len(completed_core)}/150; second dataset FAST CE/LOO: {len(ext)}/60')
    print('Core:',core.get('job'),'subject:',core.get('subject',-1)+1,'fold:',core.get('fold',-1)+1)
    print('Second dataset:',inner.get('state'),'subject:',inner.get('subject'),'session:',inner.get('held_session'),'method:',inner.get('method'))
    rate=download.get('bytes_per_second',0)
    print('Download:',download.get('state'),f'{download.get("present_bytes",download.get("completed_bytes",0))/1e9:.2f}/{download.get("total_bytes",0)/1e9:.2f} GB',
          f'| measured average {rate/1048576:.2f} MiB/s | remaining {duration(download.get("eta_seconds"))}')
    print('Second-dataset training-only remaining:',duration(remaining_training),'| rough range:',duration(.8*remaining_training),'-',duration(1.4*remaining_training))
    print('Per-method seconds/fit:',method_times,'(unmeasured arms use initial estimates; data loading and setup excluded)')
    print('Data preparation:',read(ROOT/'inner_prepared/prepare_status.json'))
    if state.get('state')=='failed':print('ERROR:',state.get('error'))
    print('Extended 3420-fit plan is deferred. This queue ends after the 210-fit priority scope (including prior results).')
    log=ROOT/'priority_training.log'
    if log.exists():print('\n'.join(log.read_text().splitlines()[-5:]))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--watch',action='store_true');args=ap.parse_args()
    try:
        while True:
            if args.watch:print('\033[2J\033[H',end='')
            render()
            if not args.watch:break
            time.sleep(5)
    except KeyboardInterrupt:pass
