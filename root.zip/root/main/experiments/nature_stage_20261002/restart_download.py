from pathlib import Path
import os,signal,subprocess,sys,time
r=Path('/root/FAST/experiments/nature_stage_20261002')
p=r/'download.pid'
if p.exists():
    pid=int(p.read_text());cmd=Path(f'/proc/{pid}/cmdline')
    if cmd.exists() and b'prepare_inner_data.py' in cmd.read_bytes():
        os.kill(pid,signal.SIGTERM)
        for _ in range(30):
            stat=Path(f'/proc/{pid}/stat')
            if not stat.exists() or stat.read_text().split()[2]=='Z':break
            time.sleep(.1)
        else:raise RuntimeError('Old downloader did not stop; no duplicate launched')
subprocess.run([sys.executable,str(r/'launch_download.py')],check=True)
