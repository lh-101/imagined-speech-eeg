"""Resume the frozen official S3 snapshot using bounded verified byte ranges."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import fcntl
import hashlib
import json
import os
import re
import subprocess
import threading
import time
import requests

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'inner_data'
BASE='https://s3.us-east-1.amazonaws.com/openneuro.org/'
CHUNK=8*1024**2
WORKERS=16
TLS=threading.local()
STATUS=DATA/'download_status.json'

def atomic(path,obj):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(obj,indent=2));tmp.replace(path)

def hashes(path):
    sha=hashlib.sha256();md5=hashlib.md5()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(4*1024**2),b''):sha.update(b);md5.update(b)
    return sha.hexdigest(),md5.hexdigest()

def verify(obj,path):
    assert path.stat().st_size==obj['size'],f'Wrong full size {path}'
    sha,md5=hashes(path)
    if re.fullmatch(r'[a-fA-F0-9]{32}',obj['etag']):
        assert md5==obj['etag'].lower(),f'Official MD5/ETag mismatch {path}'
    return dict(obj,sha256=sha,path=str(path))

def piece(obj,start,end,path):
    expected=end-start+1
    if path.exists() and path.stat().st_size==expected:return
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.inflight')
    if not hasattr(TLS,'session'):TLS.session=requests.Session()
    for attempt in range(6):
        try:
            headers={'Range':f'bytes={start}-{end}','If-Match':'"'+obj['etag']+'"'}
            with TLS.session.get(BASE+obj['key'],headers=headers,stream=True,timeout=(20,60)) as r:
                r.raise_for_status()
                assert r.status_code==206,'Official endpoint must honor Range'
                assert r.headers.get('Content-Range')==f'bytes {start}-{end}/{obj["size"]}'
                assert r.headers.get('ETag','').strip('"')==obj['etag']
                with tmp.open('wb') as f:
                    for b in r.iter_content(256*1024):
                        if b:f.write(b)
            assert tmp.stat().st_size==expected
            tmp.replace(path)
            return
        except Exception as e:
            print('RANGE_RETRY',obj['key'],start,attempt+1,repr(e),flush=True)
            if attempt==5:raise
            time.sleep(min(20,2**attempt))

def assemble(obj,p,prefix,chunks):
    import shutil
    original=p.with_suffix(p.suffix+'.part')
    result=p.with_suffix(p.suffix+'.assembling')
    with result.open('wb') as out:
        if prefix:
            with original.open('rb') as src:
                shutil.copyfileobj(src,out,4*1024**2)
        for start,end,chunk in chunks:
            with chunk.open('rb') as src:shutil.copyfileobj(src,out,4*1024**2)
    checked=verify(obj,result)
    result.replace(p)
    checked['path']=str(p)
    if original.exists():original.unlink()
    parts=p.with_suffix(p.suffix+'.ranges')
    if parts.exists():
        assert parts.parent==p.parent and parts.name==p.name+'.ranges'
        shutil.rmtree(parts)
    return checked

def present_bytes(obj):
    p=DATA/obj['key']
    if p.exists():return min(p.stat().st_size,obj['size'])
    prefix=p.with_suffix(p.suffix+'.part')
    n=prefix.stat().st_size if prefix.exists() else 0
    ranges=p.with_suffix(p.suffix+'.ranges')
    if ranges.exists():n+=sum(x.stat().st_size for x in ranges.glob('*.range'))
    return min(n,obj['size'])

def main():
    with (ROOT/'download.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        inventory=json.loads((DATA/'inventory.json').read_text());objects=inventory['files']
        started=time.time();initial=sum(present_bytes(o) for o in objects);total=sum(o['size'] for o in objects)
        assert len(objects)==120 and total==inventory['total_bytes']
        complete=[];pending={};jobs=[];last=0
        for obj in sorted(objects,key=lambda o:(o['size']>100000,o['key'])):
            p=DATA/obj['key'];p.parent.mkdir(parents=True,exist_ok=True)
            if p.exists():complete.append(verify(obj,p));continue
            old=p.with_suffix(p.suffix+'.part');prefix=old.stat().st_size if old.exists() else 0
            assert prefix<=obj['size']
            chunks=[]
            for start in range(prefix,obj['size'],CHUNK):
                end=min(start+CHUNK,obj['size'])-1
                path=p.with_suffix(p.suffix+'.ranges')/f'{start}-{end}.range'
                chunks.append((start,end,path));jobs.append((obj,start,end,path))
            pending[obj['key']]=dict(obj=obj,p=p,prefix=prefix,chunks=chunks,left=len(chunks))
            if not chunks:complete.append(assemble(obj,p,prefix,chunks));pending.pop(obj['key'])

        def progress(force=False):
            nonlocal last
            now=time.time()
            if not force and now-last<5:return
            current=sum(present_bytes(o) for o in objects);elapsed=now-started
            rate=max(0,current-initial)/max(1,elapsed)
            atomic(STATUS,dict(state='downloading',pid=os.getpid(),mode='official_verified_parallel_ranges',workers=WORKERS,
                chunk_bytes=CHUNK,completed_files=len(complete),total_files=len(objects),completed_bytes=sum(o['size'] for o in complete),
                present_bytes=current,total_bytes=total,initial_bytes=initial,started=started,updated=now,
                bytes_per_second=rate,eta_seconds=(total-current)/rate if rate else None))
            atomic(DATA/'checksums.json',dict(files=complete));last=now
        progress(True)
        print('PARALLEL_DOWNLOAD_BEGIN',initial,total,'workers',WORKERS,'tasks',len(jobs),flush=True)
        with ThreadPoolExecutor(max_workers=WORKERS) as pool:
            futures={pool.submit(piece,*job):job[0]['key'] for job in jobs}
            for future in as_completed(futures):
                future.result();key=futures[future];record=pending[key];record['left']-=1
                if not record['left']:
                    complete.append(assemble(record['obj'],record['p'],record['prefix'],record['chunks']))
                    print('VERIFIED_FILE_DONE',len(complete),len(objects),key,flush=True)
                    del pending[key]
                progress()
        progress(True)
        assert len(complete)==len(objects)
        atomic(STATUS,dict(state='download_complete',completed_files=len(complete),total_files=len(objects),total_bytes=total,
            completed_bytes=total,present_bytes=total,started=started,updated=time.time(),mode='official_verified_parallel_ranges'))
        python=ROOT/'data_env/bin/python'
        subprocess.run([str(python),'-c','import mne; assert mne.__version__=="1.8.0"'],check=True)
        subprocess.run([str(python),str(ROOT/'preprocess_inner.py')],check=True,
            env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
        print('INNER_DATA_READY',flush=True)

if __name__=='__main__':
    try:main()
    except Exception as e:
        atomic(ROOT/'inner_data_failure.json',dict(state='failed',error=repr(e),updated=time.time()))
        raise
