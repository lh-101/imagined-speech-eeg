from pathlib import Path
import json,os,subprocess
ROOT=Path(__file__).resolve().parent
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
    try:args=proc.joinpath('cmdline').read_bytes().decode(errors='replace').split('\0')
    except OSError:continue
    if any(a.startswith(str(ROOT)+'/') and Path(a).name in ['download_parallel.py','priority_queue.py','run_priority_experiments.py','preprocess_inner.py','resume_preprocess.py'] for a in args):
        print('PROCESS',proc.name,' '.join(args))
for rel in ['priority_status.json','core/status.json','inner_data/download_status.json','inner_prepared/prepare_status.json','inner_results/status.json','inner_data_failure.json']:
    p=ROOT/rel
    if p.exists():print('STATUS',rel,p.read_text())
for rel in ['priority_queue.log','priority_training.log','download_parallel.log','preprocess_resume.log']:
    p=ROOT/rel
    if p.exists():print('LOG',rel,'\n'+'\n'.join(p.read_text().splitlines()[-8:]))
checks=ROOT/'inner_data/checksums.json'
if checks.exists():
    rows=json.loads(checks.read_text())['files']
    print('VERIFIED_FILES',len(rows),'verified_eeg',sum(r['key'].endswith('_eeg-epo.fif') for r in rows))
r=subprocess.run(['nvidia-smi','--query-gpu=utilization.gpu,memory.used','--format=csv,noheader'],capture_output=True,text=True)
print('GPU',r.stdout.strip())
