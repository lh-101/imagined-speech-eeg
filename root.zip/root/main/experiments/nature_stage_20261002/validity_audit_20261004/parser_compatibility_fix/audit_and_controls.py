"""Exploratory audit of existing EEG plus a frozen, bounded linear diagnostic."""
import os
os.environ['OMP_NUM_THREADS']='2'
os.environ['OPENBLAS_NUM_THREADS']='2'
os.environ['MKL_NUM_THREADS']='2'
from pathlib import Path
import collections,fcntl,hashlib,json,re,time,traceback
import mne,numpy as np
from scipy.signal import resample_poly
from scipy.linalg import cho_factor,cho_solve
from sklearn.model_selection import GroupKFold,KFold,StratifiedKFold
from sklearn.metrics import balanced_accuracy_score,confusion_matrix

BASE=Path('/root/FAST/experiments/nature_stage_20261002')
OLD=BASE/'multicue_confirm_20261003'
OUT=BASE/'validity_audit_20261004'
SUBJECTS=['03','08','010','012','013','014','016','017','019']
WORDS=['flower','guitar','penguin']
START=time.time()

def atomic(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(obj,indent=2,ensure_ascii=False));temp.replace(path)

def status(**kw):
    atomic(OUT/'cpu_status.json',dict(pid=os.getpid(),started=START,updated=time.time(),elapsed_seconds=time.time()-START,**kw))

def parse_description(desc):
    core=desc.split('###',1)[0].split(', ',1)[-1]
    match=re.fullmatch(r'(Perceptiona|Perception|Imagination)_(?:(a|t|image)_)?(flower|guitar|penguin)(?:_(.*))?',core)
    if not match:raise ValueError('Unknown original marker '+desc)
    prefix,mod,word,variant=match.groups()
    modality='audio' if prefix=='Perceptiona' or mod=='a' else {'t':'text','image':'image'}.get(mod)
    if modality is None:raise ValueError('Missing modality '+desc)
    return dict(task='imagination' if prefix=='Imagination' else 'perception',word=word,modality=modality,variant=variant or '')

def quality(X):
    ptp=np.ptp(X,axis=2)
    rms=np.sqrt(np.mean(X.astype(np.float64)**2,axis=(1,2)))
    return dict(ptp_channel_uv_quantiles=(np.quantile(ptp,[0,.5,.9,.99,1])*1e6).tolist(),
                trial_max_ptp_uv_quantiles=(np.quantile(ptp.max(1),[0,.5,.9,.99,1])*1e6).tolist(),
                trial_rms_uv_quantiles=(np.quantile(rms,[0,.5,.9,.99,1])*1e6).tolist(),
                trials_any_channel_gt150uv=int((ptp.max(1)>150e-6).sum()),
                trial_channel_flat_pairs=int((ptp<1e-12).sum()),n_trials=len(X),
                reference_mean_rms_uv=float(np.sqrt(np.mean(X.mean(1).astype(np.float64)**2))*1e6),
                note='150uV is descriptive only; no exclusion or tuning by these measurements')

def audit_subject(subject):
    parent=OLD/('sub-'+subject);cache=parent/'multicue_fast_20261003'
    eventdoc=json.loads((parent/'multicue_pilot_20261003/event_audit.json').read_text());rows=eventdoc['events']
    meta=json.loads((cache/'source_files.json').read_text());geo=json.loads((cache/'geometry.json').read_text())
    rawroot=Path('/root/autodl-tmp/eeg_research/multicue_confirm_20261003')/('sub-'+subject)
    raw=mne.io.read_raw_fif(rawroot/meta['files'][0]['filename'],preload=False,verbose='ERROR')
    picks=mne.pick_types(raw.info,eeg=True,exclude='bads');channels=[raw.ch_names[k] for k in picks]
    assert channels==geo['channels']==eventdoc['channels'],'Channel order mismatch'
    grouped=[n for members in geo['zone_dict'].values() for n in members]
    assert sorted(grouped)==sorted(channels) and len(set(grouped))==len(channels),'Channel grouping mismatch'
    assert sorted(Path(x).name for x in raw.filenames)==sorted(f['filename'] for f in meta['files'])
    files=[]
    for f in meta['files']:
        assert (rawroot/f['filename']).stat().st_size==f['size'],'File size mismatch'
        verify=OLD/f"download_{subject}_{f['filename']}.json"
        v=json.loads(verify.read_text())
        assert v['state']=='complete' and v['sha256']==f['sha256'],'No matching prior SHA verification'
        files.append(dict(filename=f['filename'],size=f['size'],verified_sha256=v['sha256']))
    original=[a for a in raw.annotations if re.search(r'Perception|Imagination',str(a['description']),re.I)]
    # Compare retained markers separately from the explicitly recorded terminal exclusion.
    dropped={(e['event']['description'],round(e['event']['onset'],6)) for e in eventdoc['excluded']}
    original=[a for a in original if (str(a['description']),round(float(a['onset'])-raw.first_time,6)) not in dropped]
    assert len(original)==len(rows),'Retained annotation count mismatch'
    endbaseline=np.array([float(a['onset'])-raw.first_time for a in raw.annotations if 'end_baseline' in a['description']])
    startbaseline=np.array([float(a['onset'])-raw.first_time for a in raw.annotations if 'start_baseline' in a['description']])
    assert len(endbaseline)>=5,'Cannot reconstruct acquisition blocks'
    blocks=[];timing=[];variants=[]
    for i,(a,e) in enumerate(zip(original,rows)):
        parsed=parse_description(str(a['description']))
        assert all(parsed[k]==e[k] for k in ['task','word','modality']),('Marker parsing mismatch',i)
        assert abs(float(a['onset'])-raw.first_time-e['onset'])<1e-6,'Onset mismatch'
        left=1 if e['task']=='imagination' else 0
        start=round((e['onset']+left)*raw.info['sfreq']);stop=start+int(2*raw.info['sfreq'])
        assert 0<=start<stop<=raw.n_times
        if i+1<len(rows):assert e['onset']+left+2<=rows[i+1]['onset'],'Epoch crosses next condition'
        blocks.append(int(np.searchsorted(endbaseline,e['onset'],side='right')-1));variants.append(parsed['variant'])
        if e['task']=='perception':
            other=rows[i+1]
            assert other['task']=='imagination' and all(e[k]==other[k] for k in ['word','modality','pair','group'])
            timing.append(dict(modality=e['modality'],perception_to_imagination_seconds=other['onset']-e['onset']))
    blocks=np.array(blocks);assert blocks.min()>=0
    with np.load(cache/'epochs.npz') as z:
        X=z['X'];y=z['y'];groups=z['groups'];pair=z['pair'];tasks=z['tasks'];mods=z['modalities']
    assert np.isfinite(X).all() and X.shape==(len(rows),len(channels),512)
    assert np.array_equal(y,[WORDS.index(e['word']) for e in rows])
    for name,arr in [('group',groups),('pair',pair),('task',tasks),('modality',mods)]:assert np.array_equal(arr,[e[name] for e in rows]),name
    assert all(len(set(blocks[pair==p]))==1 for p in np.unique(pair))
    hashes=collections.Counter(hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest() for x in X)
    sampled=[]
    for task in ['perception','imagination']:
        for mod in ['audio','text','image']:
            ids=np.flatnonzero((tasks==task)&(mods==mod))
            for i in sorted(set([int(ids[0]),int(ids[len(ids)//2]),int(ids[-1])])):
                left=1 if task=='imagination' else 0
                st=round((rows[i]['onset']+left)*raw.info['sfreq'])
                fresh=resample_poly(raw.get_data(picks=picks,start=st,stop=st+2048),1,4,axis=-1).astype(np.float32)
                error=float(np.max(np.abs(fresh-X[i])))
                assert error==0,('Cache reconstruction differs',subject,i,error)
                sampled.append(dict(index=i,task=task,modality=mod,max_absolute_difference_volts=error))
    splits=json.loads((cache/'splits.json').read_text());coverage=np.zeros(len(X),int);foldreports=[]
    for f,sp in enumerate(splits):
        tr=np.array(sp['train']);te=np.array(sp['test']);coverage[te]+=1
        assert not set(tr)&set(te) and not set(pair[tr])&set(pair[te]) and not set(groups[tr])&set(groups[te])
        overlap=sorted(set(blocks[tr])&set(blocks[te]));results=[]
        srctr=tr[(tasks[tr]=='perception')&(mods[tr]=='text')]
        for method in ['ce','additive','protected']:
            with np.load(cache/'results'/f'perception_text_{method}_fold{f}.npz') as z:
                assert np.array_equal(z['test_index'],te) and np.array_equal(z['train_index'],srctr)
                assert np.array_equal(z['y'],y[te]) and np.array_equal(z['groups'],groups[te]) and np.array_equal(z['pair'],pair[te])
                results.append(dict(method=method,saved_prediction_count=len(z['pred'])))
        foldreports.append(dict(fold=f,train_source_counts=np.bincount(y[srctr],minlength=3).tolist(),actual_blocks_in_both_train_and_test=overlap,n_actual_blocks_shared=len(overlap),results=results))
    assert np.all(coverage==1),'OOF coverage not exactly once'
    q=[]
    for task in ['perception','imagination']:
        for mod in ['audio','text','image']:
            ids=np.flatnonzero((tasks==task)&(mods==mod));counts=np.bincount(y[ids],minlength=3)
            q.append(dict(task=task,modality=mod,class_counts=counts.tolist(),**quality(X[ids])))
    gaps={mod:[v['perception_to_imagination_seconds'] for v in timing if v['modality']==mod] for mod in ['audio','text','image']}
    result=dict(subject=subject,passed=True,session=meta['session'],events=len(X),pairs=len(set(pair)),channels=len(channels),
                original_first_samp=raw.first_samp,original_first_time=raw.first_time,sfreq=raw.info['sfreq'],header_highpass=raw.info['highpass'],header_lowpass=raw.info['lowpass'],
                baseline_starts=len(startbaseline),baseline_ends=len(endbaseline),actual_acquisition_blocks=len(set(blocks)),
                short_pair_groups=len(set(groups)),excluded=eventdoc['excluded'],source_files=files,sample_reconstruction=sampled,
                exact_duplicate_extra_epochs=sum(v-1 for v in hashes.values()),folds=foldreports,quality=q,
                perception_to_imagination_quantiles={k:np.quantile(v,[0,.5,1]).tolist() for k,v in gaps.items()},
                timing_note='Windows remain 0-2s perception and 1-3s imagination; whole-recording author ICA retained; no fold-fitted ICA',
                stimulus_identity_note='Text/audio suffix IDs are recorded; image annotation gives complexity, not necessarily a unique image exemplar; no novel-exemplar claim',
                annot_non_task_counts=dict(collections.Counter(str(a['description']) for a in raw.annotations if not re.search(r'Perception|Imagination',str(a['description']),re.I))))
    atomic(OUT/f'sub-{subject}_structural_audit.json',result)
    np.savez_compressed(OUT/f'sub-{subject}_audit_metadata.npz',blocks=blocks,variants=np.array(variants),source_event_onsets=np.array([e['onset'] for e in rows]))
    return result,X,y,groups,pair,tasks,mods,blocks,splits

def prediction_matrix(F,tr,te):
    mu=F[tr].mean(0);sd=F[tr].std(0);sd[sd<1e-12]=1
    a=(F[tr]-mu)/sd;b=(F[te]-mu)/sd
    dim=F.shape[1]
    factor=cho_factor(a@a.T/dim+np.eye(len(tr)),lower=True,check_finite=False)
    H=cho_solve(factor,(b@a.T/dim).T,check_finite=False).T
    # Centered one-hot fit + source class prior: all affine terms included.
    H+=(1-H.sum(1))[:,None]/len(tr)
    return H

def ba_batch(labels,pred,nclass):
    scores=np.zeros(len(pred),float)
    for c in range(nclass):
        mask=labels==c;den=mask.sum(1)
        assert np.all(den>0)
        scores+=((pred==c)&mask).sum(1)/den/nclass
    return scores

def controls(subject,X,y,tasks,mods,blocks,saved_splits):
    rng=np.random.default_rng(20261004+int(subject))
    records=[]
    for mod in ['text','image']:
        ids=np.flatnonzero((tasks=='perception')&(mods==mod));target=y[ids];bg=blocks[ids]
        feats=resample_poly(X[ids].astype(np.float64),1,16,axis=-1).reshape(len(ids),-1)
        assert feats.shape[1]==X.shape[1]*32
        labels=np.tile(target,(100,1))
        for k in range(1,100):
            for b in np.unique(bg):
                select=np.flatnonzero(bg==b);labels[k,select]=rng.permutation(target[select])
        original_to_local={int(k):i for i,k in enumerate(ids)}
        short=[]
        for sp in saved_splits:
            tr=np.array([original_to_local[k] for k in sp['train'] if k in original_to_local]);te=np.array([original_to_local[k] for k in sp['test'] if k in original_to_local]);short.append((tr,te))
        protocols=dict(short_groups=short,acquisition_blocks=list(GroupKFold(5).split(feats,target,bg)),
                       random_trials=list(KFold(5,shuffle=True,random_state=42).split(feats)))
        onehot=np.eye(3)[labels]
        for name,folds in protocols.items():
            predictions=np.full(labels.shape,-1,int);coverage=np.zeros(len(ids),int);training=[]
            for fold,(tr,te) in enumerate(folds):
                assert set(target[tr])=={0,1,2}
                H=prediction_matrix(feats,tr,te)
                scores=np.einsum('ij,pjc->pic',H,onehot[:,tr,:],optimize=True)
                predictions[:,te]=scores.argmax(2);coverage[te]+=1
                ht=prediction_matrix(feats,tr,tr)
                tp=(ht@np.eye(3)[target[tr]]).argmax(1)
                training.append(dict(fold=fold,balanced_accuracy=float(balanced_accuracy_score(target[tr],tp)),n_train=len(tr),n_test=len(te)))
            assert np.all(coverage==1) and predictions.min()>=0
            scores=ba_batch(labels,predictions,3)
            p=(1+int((scores[1:]>=scores[0]).sum()))/100
            rec=dict(subject=subject,modality=mod,split=name,balanced_accuracy=float(scores[0]),conditional_full_fit_permutation_p=p,
                     permutation_scores=scores[1:].tolist(),confusion=confusion_matrix(target,predictions[0],labels=[0,1,2]).tolist(),
                     training=training,n_test=len(ids),counts=np.bincount(target,minlength=3).tolist(),
                     mixed_acquisition_blocks=sum(len(set(target[bg==b]))>1 for b in np.unique(bg)),n_acquisition_blocks=len(set(bg)))
            records.append(rec)
            print('CONTROL_DONE',subject,mod,name,float(scores[0]),flush=True)
    atomic(OUT/f'sub-{subject}_linear_controls.json',records)
    return records

def synthetic_check():
    rng=np.random.default_rng(81);y=np.tile(np.arange(3),30);F=rng.normal(0,.05,(90,24))+np.eye(3)[y].repeat(8,axis=1)
    pred=np.full(90,-1)
    for tr,te in StratifiedKFold(5,shuffle=True,random_state=42).split(F,y):
        H=prediction_matrix(F,tr,te);pred[te]=(H@np.eye(3)[y[tr]]).argmax(1)
        # Compare batched reuse to literal refitting of one shuffled target.
        yp=rng.permutation(y[tr]);mu=F[tr].mean(0);sd=F[tr].std(0);a=(F[tr]-mu)/sd;b=(F[te]-mu)/sd
        prior=np.eye(3)[yp].mean(0);alpha=np.linalg.solve(a@a.T/24+np.eye(len(tr)),np.eye(3)[yp]-prior)
        literal=b@a.T/24@alpha+prior
        assert np.allclose(literal,H@np.eye(3)[yp],atol=1e-10)
    assert balanced_accuracy_score(y,pred)==1
    atomic(OUT/'synthetic_check.json',dict(passed=True,balanced_accuracy=1,meaning='Technical algebra/OOF check only; not a real EEG positive control'))

def main():
    OUT.mkdir(exist_ok=True)
    lock=(OUT/'cpu.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    synthetic_check();audits=[];records=[];failures=[]
    for i,subject in enumerate(SUBJECTS):
        try:
            status(state='structural_audit',subject=subject,completed_subjects=[a['subject'] for a in audits],subjects_total=9)
            report,X,y,groups,pair,tasks,mods,blocks,splits=audit_subject(subject);audits.append(report)
            print('AUDIT_PASS',subject,report['events'],report['actual_acquisition_blocks'],flush=True)
            status(state='linear_controls',subject=subject,completed_subjects=[a['subject'] for a in audits],subjects_total=9)
            records+=controls(subject,X,y,tasks,mods,blocks,splits)
            del X,y,groups,pair,tasks,mods,blocks
        except Exception as e:
            failures.append(dict(subject=subject,error=str(e),traceback=traceback.format_exc()));print('AUDIT_FAIL',subject,str(e),flush=True)
    atomic(OUT/'structural_summary.json',dict(complete=len(audits)==9,subjects=audits,failures=failures))
    means=[]
    for mod in ['text','image']:
        for split in ['short_groups','acquisition_blocks','random_trials']:
            rows=[r for r in records if r['modality']==mod and r['split']==split]
            if len(rows)!=9:continue
            val=float(np.mean([r['balanced_accuracy'] for r in rows]));null=np.mean([r['permutation_scores'] for r in rows],axis=0)
            means.append(dict(modality=mod,split=split,mean_balanced_accuracy=val,subject_values=[r['balanced_accuracy'] for r in rows],
                              permutation_p=(1+int((null>=val).sum()))/100,null_mean=float(null.mean()),null95=np.quantile(null,[.025,.975]).tolist()))
    order=np.argsort([r['permutation_p'] for r in means]);previous=0
    for rank,k in enumerate(order):
        previous=max(previous,min(1,(len(means)-rank)*means[k]['permutation_p']));means[k]['holm_six_p']=previous
    atomic(OUT/'linear_summary.json',dict(complete=len(means)==6 and len(audits)==9,means=means,subject_records=records,
          limitations=['Exploratory: prior FAST outcomes already known','99 full linear-label refits, conditional on fixed label-independent preprocessing and splits',
                       'Within-acquisition-block exchangeability assumed','Author whole-recording ICA retained','2s windows do not test full duration','Repeated stimulus instances can remain across folds',
                       'Random protocol is a diagnostic, not replacement for held-out blocks','Time-domain probe is not FAST or evidence of speech-specific biology']))
    status(state='complete' if not failures else 'complete_with_failures',completed_subjects=[a['subject'] for a in audits],failures=failures,subjects_total=9)

if __name__=='__main__':
    try:main()
    except Exception as e:status(state='failed',error=str(e),traceback=traceback.format_exc());raise
