"""No optimization: verify existing FAST predictions and normalization."""
import os
os.environ['OMP_NUM_THREADS']='4'
os.environ['OPENBLAS_NUM_THREADS']='2'
from pathlib import Path
import fcntl,hashlib,json,sys,time,traceback
import numpy as np,torch
from sklearn.metrics import balanced_accuracy_score,accuracy_score
from transformers import PretrainedConfig
sys.path[:0]=['/root/FAST','/root/FAST/experiments/residual_20260925']
import run_metric_v4 as v4
BASE=Path('/root/FAST/experiments/nature_stage_20261002')
OLD=BASE/'multicue_confirm_20261003';OUT=BASE/'validity_audit_20261004'
SUBJECTS=['03','08','010','012','013','014','016','017','019']
START=time.time()

def atomic(path,obj):
    path.parent.mkdir(exist_ok=True,parents=True);tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(obj,indent=2));tmp.replace(path)

def status(**kw):
    atomic(OUT/'replay_status.json',dict(pid=os.getpid(),started=START,updated=time.time(),elapsed_seconds=time.time()-START,**kw))

def predict(model,X,indices):
    predictions=[];probs=[]
    with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
        for batch in np.array_split(indices,max(1,(len(indices)+63)//64)):
            logits,q=v4.representation(model,torch.from_numpy(X[batch]).cuda())
            predictions.extend(logits.argmax(1).cpu().tolist());probs.extend(logits.float().softmax(1).cpu().tolist())
    return np.array(predictions),np.array(probs)

def main():
    OUT.mkdir(exist_ok=True)
    lock=(OUT/'replay.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False
    records=[];failures=[];done=0
    for subject in SUBJECTS:
        try:
            folder=OLD/('sub-'+subject)/'multicue_fast_20261003'
            manifest=json.loads((folder/'manifest.json').read_text())
            for path in [Path(v4.__file__),Path('/root/FAST/FAST.py')]:
                assert hashlib.sha256(path.read_bytes()).hexdigest()==manifest['source_sha256'][str(path)],('Runtime source changed',path)
            with np.load(folder/'epochs.npz') as z:X=z['X'];y=z['y'];tasks=z['tasks'];mods=z['modalities']
            person=[];oof={m:dict(y=[],pred=[]) for m in ['ce','additive','protected']}
            for fold in range(5):
                for method in ['ce','additive','protected']:
                    stem=folder/'results'/f'perception_text_{method}_fold{fold}'
                    ck=torch.load(stem.with_suffix('.pt'),map_location='cpu')
                    tr=ck['train'];te=ck['test']
                    assert np.all((tasks[tr]=='perception')&(mods[tr]=='text'))
                    mean=X[tr].mean(axis=(0,2),keepdims=True);std=X[tr].std(axis=(0,2),keepdims=True).clip(1e-12)
                    assert np.array_equal(mean,ck['mean']) and np.array_equal(std,ck['std']),'Normalization differs from source training'
                    xx=((X-mean)/std).astype(np.float32)
                    model=v4.FAST(PretrainedConfig(**ck['config'])).cuda().eval();model.load_state_dict(ck['state_dict'],strict=True)
                    trainpred,_=predict(model,xx,tr);testpred,testprob=predict(model,xx,te)
                    with np.load(stem.with_suffix('.npz')) as z:
                        assert np.array_equal(z['test_index'],te) and np.array_equal(z['y'],y[te])
                        differences=int((testpred!=z['pred']).sum())
                        probability_difference=float(np.max(np.abs(testprob-z['prob'])))
                    mask=(tasks[te]=='perception')&(mods[te]=='text')
                    oof[method]['y'].extend(y[te][mask].tolist());oof[method]['pred'].extend(testpred[mask].tolist())
                    rec=dict(subject=subject,fold=fold,method=method,source_training_accuracy=float(accuracy_score(y[tr],trainpred)),
                             source_training_balanced_accuracy=float(balanced_accuracy_score(y[tr],trainpred)),
                             source_test_balanced_accuracy=float(balanced_accuracy_score(y[te][mask],testpred[mask])),n_source_train=len(tr),n_source_test=int(mask.sum()),
                             saved_prediction_mismatches=differences,max_probability_difference=probability_difference,normalization_exact=True)
                    records.append(rec);person.append(rec);done+=1
                    status(state='replaying',subject=subject,completed_models=done,total_models=135,saved_prediction_mismatches_total=sum(r['saved_prediction_mismatches'] for r in records))
                    del model,ck,xx;torch.cuda.empty_cache()
            summary=[]
            for method in oof:
                these=[r for r in person if r['method']==method]
                summary.append(dict(method=method,mean_source_train_balanced_accuracy=float(np.mean([r['source_training_balanced_accuracy'] for r in these])),
                                    pooled_oof_source_balanced_accuracy=float(balanced_accuracy_score(oof[method]['y'],oof[method]['pred']))))
            atomic(OUT/f'sub-{subject}_replay.json',dict(subject=subject,records=person,summary=summary))
            print('REPLAY_SUBJECT_DONE',subject,json.dumps(summary),flush=True)
            del X
        except Exception as e:
            failures.append(dict(subject=subject,error=str(e),traceback=traceback.format_exc()));print('REPLAY_FAILURE',subject,str(e),flush=True)
    atomic(OUT/'replay_summary.json',dict(complete=done==135,completed_models=done,records=records,failures=failures,
          saved_prediction_mismatches_total=sum(r['saved_prediction_mismatches'] for r in records),
          limitations=['No retraining or checkpoint selection','Training performance is eval-mode on seen labels, not generalization','BF16 CUDA and original test batching retained']))
    status(state='complete' if not failures else 'complete_with_failures',completed_models=done,total_models=135,failures=failures)

if __name__=='__main__':
    try:main()
    except Exception as e:status(state='failed',error=str(e),traceback=traceback.format_exc());raise
