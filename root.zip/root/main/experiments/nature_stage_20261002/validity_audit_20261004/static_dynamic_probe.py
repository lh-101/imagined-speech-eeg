"""Static/dynamic and dose-matched perturbations of existing FAST models only."""
import os
os.environ['OMP_NUM_THREADS']='4';os.environ['OPENBLAS_NUM_THREADS']='2'
from pathlib import Path
import fcntl,hashlib,json,sys,time,traceback
import h5py,numpy as np,torch
from sklearn.metrics import balanced_accuracy_score,confusion_matrix
from transformers import PretrainedConfig
sys.path.insert(0,'/root/FAST')
from FAST import FAST
BASE=Path('/root/FAST/experiments/nature_stage_20261002');OUT=BASE/'validity_audit_20261004/static_dynamic'
OLD=Path('/root/FAST/experiments/mechanism_20260927/results')
START=time.time();REGIONS=['Pre-frontal','Frontal','Pre-central','Central','Post-central','Temporal','Parietal','Occipital']
METHODS=['ce','additive','protected']

def atomic(path,obj):
    path.parent.mkdir(exist_ok=True,parents=True);tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(obj,indent=2));tmp.replace(path)

def status(**kw):
    atomic(OUT/'status.json',dict(pid=os.getpid(),started=START,updated=time.time(),elapsed_seconds=time.time()-START,**kw))

def forward(model,x):
    f=model.forward_head(x);tokens=model.input_layer(f.flatten(2));tokens=torch.cat([model.cls_token.expand(len(x),-1,-1),tokens],1)
    h=model.transformer(tokens+model.pos_embedding[:,:model.n_tokens+1])[:,0]
    return model.last_layer(model.dropout(h)),f

def infer(model,x,device='cuda',features=False):
    logits=[];fs=[]
    for a in range(0,len(x),35):
        z,f=forward(model,torch.from_numpy(np.ascontiguousarray(x[a:a+35])).to(device))
        logits.append(z);fs.append(f)
    return torch.cat(logits),torch.cat(fs) if features else None

def local_infer(model,x,features,region,indices):
    out=[];slot=list(model.config.zone_dict).index(region)
    for a in range(0,len(x),35):
        local=torch.from_numpy(np.ascontiguousarray(x[a:a+35,indices])).cuda()
        windows=local.unfold(-1,model.config.window_len,model.config.slide_step);b,c,n,t=windows.shape
        updated=model.head.encoders[region](windows.permute(0,2,1,3).reshape(b*n,c,t)).reshape(b,n,-1)
        f=features[a:a+35].clone();f[:,:,slot,:]=updated
        tokens=model.input_layer(f.flatten(2));tokens=torch.cat([model.cls_token.expand(b,-1,-1),tokens],1)
        h=model.transformer(tokens+model.pos_embedding[:,:model.n_tokens+1])[:,0]
        out.append(model.last_layer(model.dropout(h)))
    return torch.cat(out)

def measure(logits,y,anchor,x,z):
    p=logits.softmax(1).cpu().numpy();pred=p.argmax(1)
    return dict(accuracy=float((pred==y).mean()),balanced_accuracy=float(balanced_accuracy_score(y,pred)),
                accuracy_delta_pp=float(((pred==y).mean()-(anchor==y).mean())*100),
                nll=float(-np.log(np.maximum(p[np.arange(len(y)),y],1e-12)).mean()),
                mean_max_probability=float(p.max(1).mean()),confusion=confusion_matrix(y,pred,labels=range(5)).tolist(),
                relative_input_change_rms=float(np.sqrt(np.mean((z[:,:,:750].astype(np.float64)-x[:,:,:750])**2)/max(1e-30,np.mean(x[:,:,:750].astype(np.float64)**2)))))

def phases(x,subject,test):
    spectrum=np.fft.rfft(x[:,:,:750].astype(np.float64),axis=-1);rotations=[]
    for trial in test:
        rng=np.random.default_rng(20261004+subject*10000+int(trial))
        phase=np.exp(1j*rng.uniform(-np.pi,np.pi,spectrum.shape[-1]));phase[0]=1;phase[-1]=1;rotations.append(phase)
    changed=spectrum*np.asarray(rotations)[:,None,:]
    visible=np.fft.irfft(changed,n=750,axis=-1)
    z=np.pad(visible,((0,0),(0,0),(0,50)),mode='edge').astype(np.float32)
    return z,spectrum,changed

def interpolation_setup(xtrain):
    a=xtrain[:,:,:750].transpose(1,0,2).reshape(xtrain.shape[1],-1).astype(np.float64)
    mean=a.mean(1);sd=a.std(1).clip(1e-12);a=(a-mean[:,None])/sd[:,None]
    return mean,sd,a@a.T/a.shape[1]

def interpolation(x,indices,setup):
    mean,sd,cov=setup;kept=np.array([i for i in range(x.shape[1]) if i not in indices]);ix=np.array(indices)
    weights=np.linalg.solve(cov[np.ix_(kept,kept)]+np.eye(len(kept)),cov[np.ix_(kept,ix)])
    standardized=(x[:,kept,:].astype(np.float64)-mean[kept][None,:,None])/sd[kept][None,:,None]
    fitted=np.einsum('bkt,kj->bjt',standardized,weights,optimize=True)
    return (fitted*sd[ix][None,:,None]+mean[ix][None,:,None]).astype(np.float32)

def compatibility_smoke():
    ck=torch.load(OLD/'full_ce_seed42/0-fold0.pt',map_location='cpu')
    model=FAST(PretrainedConfig(**ck['config'])).eval();model.load_state_dict(ck['state_dict'],strict=True)
    with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5') as h:x=h['01/X'][:][ck['test_idx']];y=h['01/Y'][:][ck['test_idx']].astype(int)
    old=json.loads(Path('/root/FAST/experiments/analysis_20261002/results/spatial_ce_seed42/0-fold0.json').read_text())
    rows=[]
    with torch.inference_mode():
        baseline,_=infer(model,x,'cpu');assert float((baseline.argmax(1).numpy()==y).mean())==old['cpu_accuracy']
        for region in REGIONS:
            ix=[model.config.electrodes.index(e) for e in model.config.zone_dict[region]];z=x.copy();z[:,ix,:]=x[:,ix,:].mean(-1,keepdims=True)
            logits,_=infer(model,z,'cpu');acc=float((logits.argmax(1).numpy()==y).mean());expected=old['perturbations'][region+'__trial_mean']['accuracy']
            assert acc==expected,('Historical mean replay differs',region,acc,expected)
            rows.append(dict(region=region,replayed_accuracy=acc,historical_accuracy=expected))
    atomic(OUT/'historical_definition_check.json',dict(passed=True,replacement='Each target electrode temporal mean over 800 samples, broadcast along time',results=rows))
    print('HISTORICAL_DEFINITION_CONFIRMED',flush=True)

def run_fold(subject,fold,method,allx,ally):
    output=OUT/'results'/f'{method}_{subject}-fold{fold}.json'
    if output.exists():return json.loads(output.read_text())
    src=OLD/f'full_{method}_seed42'/f'{subject}-fold{fold}'
    ck=torch.load(src.with_suffix('.pt'),map_location='cpu');tr=np.asarray(ck['train_idx']);te=np.asarray(ck['test_idx'])
    assert not set(tr)&set(te)
    x=allx[te];y=ally[te];cfg=PretrainedConfig(**ck['config'])
    assert cfg.seq_len==800 and (cfg.seq_len-cfg.window_len)//cfg.slide_step*cfg.slide_step+cfg.window_len==750
    model=FAST(cfg).cuda().eval();model.load_state_dict(ck['state_dict'],strict=True)
    with np.load(src.with_suffix('.npz')) as saved:
        assert np.array_equal(saved['y'],y);historical=saved['primary_pred'].copy()
    start=time.time();predictions={};records={};localrows=[];randomrows=[]
    with torch.inference_mode():
        original,cached=infer(model,x,features=True);anchor=original.argmax(1).cpu().numpy()
        predictions['original']=anchor;records['original']=measure(original,y,anchor,x,x)
        mean=x[:,:,:750].mean(-1,keepdims=True)
        transformations=dict(visible_time_mean_only=np.broadcast_to(mean,x.shape).copy(),visible_time_demeaned=x-mean)
        randomized,spec,changed=phases(x,subject,te);transformations['shared_phase_randomized']=randomized
        if subject==0 and fold==0 and method=='ce':
            assert np.allclose(spec[:,:,0],changed[:,:,0],rtol=0,atol=0)
            assert np.allclose(np.abs(spec),np.abs(changed),rtol=1e-12,atol=1e-12)
            cross=spec[:,0,:]*spec[:,1,:].conj();newcross=changed[:,0,:]*changed[:,1,:].conj()
            assert np.allclose(cross,newcross,rtol=1e-12,atol=1e-10)
            atomic(OUT/'phase_check.json',dict(passed=True,dc_preserved=True,power_spectrum_preserved=True,shared_phase_cross_spectrum_preserved=True,visible_samples=750))
        for name,z in transformations.items():
            logits,_=infer(model,z);records[name]=measure(logits,y,anchor,x,z);predictions[name]=logits.argmax(1).cpu().numpy()
        if method=='ce':
            setup=interpolation_setup(allx[tr])
            for rid,region in enumerate(REGIONS):
                ix=[cfg.electrodes.index(e) for e in cfg.zone_dict[region]];kept=[i for i in range(x.shape[1]) if i not in ix]
                operations=dict(zero=0,legacy_temporal_mean_800=x[:,ix,:].mean(-1,keepdims=True),
                    visible_temporal_mean_750=mean[:,ix,:],visible_temporal_demean=x[:,ix,:]-mean[:,ix,:],
                    cross_electrode_mean=x.mean(1,keepdims=True),cross_electrode_mean_excluding_target=x[:,kept,:].mean(1,keepdims=True),
                    train_ridge_interpolation=interpolation(x,ix,setup))
                for name,values in operations.items():
                    z=x.copy();z[:,ix,:]=values;logits=local_infer(model,z,cached,region,ix)
                    if subject==0 and fold==0 and rid==0 and name=='visible_temporal_demean':
                        full,_=infer(model,z);error=float((full-logits).abs().max());assert torch.allclose(full,logits,atol=1e-4,rtol=1e-4)
                        atomic(OUT/'cached_head_check.json',dict(passed=True,max_absolute_error=error))
                    localrows.append(dict(region=region,operation=name,n_channels=len(ix),**measure(logits,y,anchor,x,z)))
                for rep in range(3):
                    rng=np.random.default_rng(20261004+subject*10000+rid*100+rep);random_ix=np.sort(rng.choice(x.shape[1],len(ix),replace=False))
                    for name,values in [('zero',0),('visible_temporal_mean_750',mean[:,random_ix,:])]:
                        z=x.copy();z[:,random_ix,:]=values;logits,_=infer(model,z)
                        randomrows.append(dict(matched_region=region,repeat=rep,operation=name,n_channels=len(ix),indices=random_ix.tolist(),**measure(logits,y,anchor,x,z)))
    np.savez_compressed(OUT/'results'/f'{method}_{subject}-fold{fold}.npz',test_idx=te,y=y,**predictions)
    result=dict(subject=subject,fold=fold,method=method,seed=42,precision='cuda_fp32_tf32_disabled',n_test=len(te),
                historical_bf16_prediction_mismatches=int((anchor!=historical).sum()),global_operations=records,local_operations=localrows,random_operations=randomrows,seconds=time.time()-start)
    atomic(output,result);print('PROBE_DONE',subject,fold,method,round(result['seconds'],2),flush=True)
    del model;torch.cuda.empty_cache();return result

def summarize(rows):
    summary=[]
    for method in METHODS:
        for operation in ['original','visible_time_mean_only','visible_time_demeaned','shared_phase_randomized']:
            vals=[]
            for subject in range(15):
                files=[OUT/'results'/f'{method}_{subject}-fold{f}.npz' for f in range(5)]
                if not all(p.exists() for p in files):continue
                ys=[];ps=[]
                for p in files:
                    with np.load(p) as z:ys.extend(z['y']);ps.extend(z[operation])
                vals.append(dict(subject=subject,accuracy=float((np.array(ys)==np.array(ps)).mean()),balanced_accuracy=float(balanced_accuracy_score(ys,ps))))
            if vals:summary.append(dict(method=method,operation=operation,n_subjects=len(vals),subject_values=vals,mean_accuracy=float(np.mean([v['accuracy'] for v in vals])),mean_balanced_accuracy=float(np.mean([v['balanced_accuracy'] for v in vals]))))
    atomic(OUT/'summary.json',dict(complete=len(rows)==225,models_done=len(rows),models_total=225,global_summary=summary,
          records=rows,historical_bf16_prediction_mismatches_total=sum(r['historical_bf16_prediction_mismatches'] for r in rows),
          limitations=['Exploratory development-used folds and seed42 only','Inference interventions alter input distribution; no causal brain localization',
                       'No newly fitted deep model: this does not test whether demeaned-data training recovers information','Random masks match size, not spatial shape',
                       'Train-fitted interpolation can reconstruct task-related signal','Mean-only uses finite-window temporal averages; their neural/artifact origin is unresolved']))

def main():
    OUT.mkdir(exist_ok=True,parents=True);(OUT/'results').mkdir(exist_ok=True)
    lock=(OUT/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    status(state='compatibility_check',models_done=0,models_total=225);compatibility_smoke();rows=[];durations=[]
    for subject in range(15):
        with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5') as h:allx=h[f'{subject+1:02d}/X'][:];ally=h[f'{subject+1:02d}/Y'][:].astype(int)
        for fold in range(5):
            for method in METHODS:
                status(state='inference',subject=subject,fold=fold,method=method,models_done=len(rows),models_total=225)
                row=run_fold(subject,fold,method,allx,ally);rows.append(row);durations.append(row['seconds'])
                ce=[r['seconds'] for r in rows if r['method']=='ce'];other=[r['seconds'] for r in rows if r['method']!='ce']
                if ce and other:
                    remaining_ce=75-len(ce);remaining_other=150-len(other);eta=remaining_ce*np.mean(ce)+remaining_other*np.mean(other)
                    status(state='inference',subject=subject,fold=fold,method=method,models_done=len(rows),models_total=225,estimated_remaining_seconds=float(eta))
        summarize(rows)
    summarize(rows);status(state='complete',models_done=225,models_total=225,estimated_remaining_seconds=0)

if __name__=='__main__':
    try:main()
    except Exception as e:status(state='failed',error=str(e),traceback=traceback.format_exc());raise
