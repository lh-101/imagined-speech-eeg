"""Record a non-experimental reporting bug fix; preserve all completed fits."""
from pathlib import Path
import hashlib,json,shutil,time
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'diagnostics_20261003'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
path=OUT/'protocol.json';protocol=json.loads(path.read_text())
previous=protocol['source_hashes']['diagnostic_gpu.py']
backup=ROOT/'diagnostic_gpu_before_summary_fix.py'
assert sha(backup)==previous
shutil.copy2(path,OUT/'protocol_before_summary_fix.json')
protocol['source_hashes']['diagnostic_gpu.py']=sha(ROOT/'diagnostic_gpu.py')
tmp=path.with_suffix('.json.tmp');tmp.write_text(json.dumps(protocol,indent=2));tmp.replace(path)
record=dict(time=time.time(),reason='Existing-checkpoint summary glob included its own summary.json; restrict to per-checkpoint seed42_sub*.json',
    old_source_sha256=previous,new_source_sha256=protocol['source_hashes']['diagnostic_gpu.py'],unchanged='Training objective, splits, data, normalization, model, epochs, seed, parameters and all completed fit files')
(OUT/'reporting_bug_repair.json').write_text(json.dumps(record,indent=2))
print('REPORTING_BUG_FIXED; completed training and CPU results preserved')
