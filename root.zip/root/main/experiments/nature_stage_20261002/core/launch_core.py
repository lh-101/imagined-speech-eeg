from pathlib import Path
import os,sys,subprocess,time,json
r=Path(__file__).resolve().parent
assert json.loads((r/'component_smoke.json').read_text())['passed']
pidfile=r/'core.pid'
if pidfile.exists():
    pid=int(pidfile.read_text())
    p=Path(f'/proc/{pid}/cmdline')
    if p.exists() and b'run_core_study.py' in p.read_bytes(): raise RuntimeError(f'Already running: {pid}')
with (r/'core.log').open('a') as log:
    p=subprocess.Popen([sys.executable,'-u',str(r/'run_core_study.py')],cwd='/root/FAST',
        stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,
        env=dict(os.environ,PYTHONUNBUFFERED='1',OMP_NUM_THREADS='8',OPENBLAS_NUM_THREADS='8'))
pidfile.write_text(str(p.pid))
(r/'launch.json').write_text(json.dumps(dict(pid=p.pid,started=time.time(),folds=1350,methods=['ce','joint_loo','regional_loo','global_loo','joint_self_support','supcon']),indent=2))
print('CORE_LAUNCHED',p.pid,str(r/'core.log'))
