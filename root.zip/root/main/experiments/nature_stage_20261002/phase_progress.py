from pathlib import Path
import json,time,argparse
R=Path(__file__).resolve().parent/'nguyen_phase_20261003'
def read(p):
    try:return json.loads(p.read_text())
    except (OSError,ValueError):return {}
def show():
    s=read(R/'status.json');n=len(list(R.glob('fits/*/*.json')));null=len(list(R.glob('null/sub*.npz')))
    print('Cross-phase controls:',s.get('state'),'phase:',s.get('phase'),'PID:',s.get('pid'))
    print('Real-data fits:',n,'/270 | completed permutation subjects:',null,'/6')
    print('Current subject/repeat:',s.get('subject'),s.get('permutation'),'/50')
    if s.get('state')=='running':
        elapsed=time.time()-s.get('started',time.time());rep=s.get('permutation',0) if s.get('phase')=='permutation' else 0
        work=null*50+rep
        if work>0:print('Rough remaining:',round(elapsed/max(work,1)*max(0,300-work)/60,1),'minutes; includes setup/control overhead, approximate')
    if s.get('error'):print('ERROR:',s['error'])
    for g in read(R/'summary.json').get('groups',[]):
        if g['n_fits']:print(g['job'],g['n_fits'],'fits; complete-subject accuracy:',g['mean_accuracy'])
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--watch',action='store_true');a=ap.parse_args()
    try:
        while True:
            if a.watch:print('\033[2J\033[H',end='')
            show()
            if not a.watch:return
            time.sleep(5)
    except KeyboardInterrupt:print('Display closed; background jobs continue.')
if __name__=='__main__':main()
