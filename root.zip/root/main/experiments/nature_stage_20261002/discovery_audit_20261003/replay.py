from pathlib import Path
import subprocess,json,time
r=Path('/root/FAST/experiments/nature_stage_20261002');dest=r/'discovery_audit_20261003';dest.mkdir(exist_ok=True)
for sub in ['sub-015','sub-018']:
 p=r/'multicue_extension_20261003'/sub
 (p/'diagnose_fast.py').write_text((r/'diagnose_fast.py').read_text())
 with (dest/(sub+'.log')).open('w') as log:
  ret=subprocess.run(['/root/venv_fast/bin/python',str(p/'diagnose_fast.py')],cwd=str(p),stdout=log,stderr=subprocess.STDOUT)
 (dest/(sub+'.status.json')).write_text(json.dumps(dict(exit_code=ret.returncode,finished=time.time())))
 if ret.returncode:break
