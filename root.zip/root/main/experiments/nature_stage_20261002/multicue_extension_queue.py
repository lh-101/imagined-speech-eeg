from pathlib import Path
import json,os,sys,time,hashlib,urllib.request,requests,concurrent.futures,queue,threading,subprocess,shutil,traceback,fcntl
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'multicue_extension_20261003';OUT.mkdir(exist_ok=True)
DATA=Path('/root/autodl-tmp/eeg_research/multicue_extension_20261003');DATA.mkdir(exist_ok=True)
MAN=json.loads((ROOT/'multicue_extension_manifest.json').read_text())
CHUNK=1024*1024
WORKERS=32
SESSION=threading.local()
lock=threading.Lock()
def atomic(p,o):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(o,indent=2));t.replace(p)
def download(meta):
 sub=meta['subject'];folder=DATA/f'sub-{sub}';folder.mkdir(exist_ok=True);target=folder/meta['filename'];size=meta['size'];start=time.time()
 status={'state':'downloading','subject':sub,'size':size,'started':start,'pid':os.getpid()}
 def update(**kw):
  status.update(kw);status['updated']=time.time();atomic(OUT/f'download_sub{sub}.json',status)
 def fetch(i):
  lo=i*CHUNK;hi=min(size,lo+CHUNK)-1;p=folder/f'chunk_{i:04d}'
  if p.exists() and p.stat().st_size==hi-lo+1:return hi-lo+1
  for attempt in range(5):
   try:
    if time.time()-start>10800:raise TimeoutError('3h file cap')
    if not hasattr(SESSION,'client'):
     SESSION.client=requests.Session()
    with SESSION.client.get(meta['url'],headers={'Range':f'bytes={lo}-{hi}','User-Agent':'EEG-research'},timeout=(15,30)) as r:
     assert r.status_code==206 and r.headers['Content-Range']==f'bytes {lo}-{hi}/{size}'
     payload=r.content
    assert len(payload)==hi-lo+1
    tmp=p.with_suffix('.tmp');tmp.write_bytes(payload);tmp.replace(p);return len(payload)
   except Exception:
    if attempt==4:raise
    time.sleep(2+attempt)
 if not target.exists():
  if shutil.disk_usage(folder).free<2*size+2*1024**3:raise RuntimeError('Free space reserve insufficient')
  count=(size+CHUNK-1)//CHUNK;missing=[];done=0
  for i in range(count):
   p=folder/f'chunk_{i:04d}';expected=min(CHUNK,size-i*CHUNK)
   if p.exists() and p.stat().st_size==expected:done+=expected
   else:missing.append(i)
  baseline=done;transfer=time.time();update(downloaded_bytes=done,percent=100*done/size,workers=WORKERS)
  with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as pool:
   upcoming=iter(missing);pending={pool.submit(fetch,next(upcoming)) for _ in range(min(WORKERS,len(missing)))}
   while pending:
    finished,pending=concurrent.futures.wait(pending,return_when=concurrent.futures.FIRST_COMPLETED)
    for f in finished:
     done+=f.result();i=next(upcoming,None)
     if i is not None:pending.add(pool.submit(fetch,i))
    rate=(done-baseline)/max(1,time.time()-transfer);update(downloaded_bytes=done,percent=100*done/size,bytes_per_second=rate,eta_seconds=(size-done)/rate if rate else None)
  update(state='assembling')
  with target.open('wb') as f:
   for i in range(count):
    with (folder/f'chunk_{i:04d}').open('rb') as g:shutil.copyfileobj(g,f,CHUNK)
 update(state='verifying')
 h=hashlib.sha256()
 with target.open('rb') as f:
  for b in iter(lambda:f.read(8*CHUNK),b''):h.update(b)
 if target.stat().st_size!=size or h.hexdigest()!=meta['sha256']:raise ValueError('Published hash/size mismatch')
 for p in folder.glob('chunk_[0-9][0-9][0-9][0-9]'):p.unlink()
 update(state='complete',sha256=h.hexdigest(),downloaded_bytes=size,percent=100,elapsed_seconds=time.time()-start)
 return target

def adapt(meta,target):
 sub=meta['subject'];folder=OUT/f'sub-{sub}';folder.mkdir(exist_ok=True)
 # Exact event parser from the completed pilot; only source identity changes.
 pilot=(ROOT/'multicue_pilot.py').read_text();block=pilot[pilot.index('    rows=[]; pair=-1;'):pilot.index('    bands=[(1,4)')]
 block='\n'.join(line[4:] if line.startswith('    ') else line for line in block.splitlines())
 audit=folder/'multicue_pilot_20261003';audit.mkdir(exist_ok=True)
 prefix="import mne,json\nfrom pathlib import Path\nROOT=Path(__file__).resolve().parent/'multicue_pilot_20261003'\ndef update(**kw):pass\n"
 prefix+=f"raw=mne.io.read_raw_fif({str(target)!r},preload=False,verbose='ERROR')\npicks=mne.pick_types(raw.info,eeg=True,exclude='bads')\n"
 (folder/'audit_events.py').write_text(prefix+block)
 prepare=(ROOT/'prepare_fast.py').read_text().replace('/root/autodl-tmp/eeg_research/multicue_pilot_20261003/sub11_sess1_50_ica_eeg.fif',str(target)).replace('7aec12c9473ad10508a1d0c25363bfe92866c924d9f92debdb206d01b4b5ec26',meta['sha256'])
 run=(ROOT/'run_fast.py').read_text().replace('sub-011',f'sub-{sub}')
 (folder/'prepare_fast.py').write_text(prepare);(folder/'run_fast.py').write_text(run)
 return folder

def main():
 lf=(OUT/'queue.lock').open('w');fcntl.flock(lf,fcntl.LOCK_EX|fcntl.LOCK_NB)
 atomic(OUT/'manifest.json',MAN);ready=queue.Queue();failures=[]
 def downloader():
  for meta in MAN['subjects']:
   try:ready.put((meta,download(meta),None))
   except Exception as e:
    atomic(OUT/f"download_sub{meta['subject']}.json",dict(state='failed',error=str(e),traceback=traceback.format_exc()));ready.put((meta,None,str(e)))
 thread=threading.Thread(target=downloader,daemon=False);thread.start()
 for _ in MAN['subjects']:
  atomic(OUT/'status.json',dict(state='waiting_for_download',pid=os.getpid(),updated=time.time(),failures=failures))
  meta,target,error=ready.get();sub=meta['subject']
  if error:failures.append(dict(subject=sub,phase='download',error=error));continue
  try:
   folder=adapt(meta,target)
   with (folder/'pipeline.log').open('ab') as log:
    for phase,python,script in [('event_audit',ROOT/'data_env/bin/python','audit_events.py'),('preparing',ROOT/'data_env/bin/python','prepare_fast.py'),('training',Path('/root/venv_fast/bin/python'),'run_fast.py')]:
     atomic(OUT/'status.json',dict(state=phase,subject=sub,pid=os.getpid(),updated=time.time(),failures=failures))
     subprocess.run([str(python),'-u',str(folder/script)],cwd=folder,stdout=log,stderr=subprocess.STDOUT,check=True)
   print('SUBJECT_COMPLETE',sub,flush=True)
  except Exception as e:
   failures.append(dict(subject=sub,phase='pipeline',error=str(e)));print('SUBJECT_FAILED',sub,str(e),flush=True)
 thread.join()
 # Include the already completed subject without retraining it.
 summaries=[ROOT/'multicue_fast_20261003/summary.json']+[OUT/f"sub-{m['subject']}/multicue_fast_20261003/summary.json" for m in MAN['subjects']]
 records=[]
 for p in summaries:
  if p.exists():
   summary=json.loads(p.read_text());records.append(summary)
 atomic(OUT/'combined_summary.json',dict(subjects=records,failures=failures,planned_subjects=['sub-011','sub-015','sub-018'],note='All predefined participants retained. Single seed exploratory paired evaluation; no population or causal claims.'))
 atomic(OUT/'status.json',dict(state='complete' if not failures else 'complete_with_failures',pid=os.getpid(),updated=time.time(),failures=failures))
if __name__=='__main__':
 try:main()
 except Exception as e:atomic(OUT/'status.json',dict(state='failed',error=str(e),traceback=traceback.format_exc()));raise
