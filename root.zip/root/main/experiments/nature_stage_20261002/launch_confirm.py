from pathlib import Path
import fcntl,json,subprocess,time
ROOT=Path('/root/FAST/experiments/nature_stage_20261002');OUT=ROOT/'multicue_confirm_20261003'
# Reject a second launch while the queue owns its lock. The child takes the
# same lock and is resumable after technical interruption.
with (OUT/'queue.lock').open('a') as f:
 fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 with (OUT/'queue.log').open('ab') as log:
  process=subprocess.Popen([str(ROOT/'data_env/bin/python'),'-u',str(ROOT/'confirm_queue.py')],cwd=str(ROOT),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (OUT/'launch.json').write_text(json.dumps(dict(pid=process.pid,started=time.time()),indent=2))
print('VALIDATION_QUEUE_STARTED',process.pid)
