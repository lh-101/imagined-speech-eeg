"""Stop this experiment's processes at the user's explicit request; preserve files."""
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path('/root/FAST/experiments/nature_stage_20261002')
SCRIPTS = {'nguyen_subject_phase.py', 'nguyen_phase_controls.py', 'nguyen_spectral_study.py', 'resume_nguyen_clone.py', 'run_nguyen_external.py', 'validation_stage.py', 'stage_queue.py', 'prepare_inner_data.py', 'preprocess_inner.py',
           'run_inner_study.py', 'run_signal_controls.py', 'run_cpu_controls.py',
           'run_core_study.py', 'priority_queue.py', 'run_priority_experiments.py',
           'download_parallel.py', 'resume_preprocess.py', 'diagnostic_cpu.py', 'diagnostic_gpu.py'}

def snapshot():
    found = {}
    for p in Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name) == os.getpid():
            continue
        try:
            args = p.joinpath('cmdline').read_bytes().decode(errors='replace').split('\0')
            stat = p.joinpath('stat').read_text().rsplit(')', 1)[1].split()
            found[int(p.name)] = {'args': [a for a in args if a], 'ppid': int(stat[1]),
                                 'start_ticks': stat[19], 'state': stat[0]}
        except (OSError, ValueError, IndexError):
            continue
    return found

def same(pid, info):
    now = snapshot().get(pid)
    return now and now['start_ticks'] == info['start_ticks'] and now['state'] != 'Z'

def send(pid, info, sig):
    if same(pid, info):
        try:
            os.kill(pid, sig)
        except ProcessLookupError:
            pass

def atomic(path, obj):
    tmp = path.with_suffix(path.suffix + '.pause.tmp')
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False))
    tmp.replace(path)

all_processes = snapshot()
roots = {pid for pid, info in all_processes.items()
         if any(a.startswith(str(ROOT) + '/') and Path(a).name in SCRIPTS
                for a in info['args'])}
for pid in roots:
    if any(Path(a).name == 'stage_queue.py' for a in all_processes[pid]['args']):
        send(pid, all_processes[pid], signal.SIGSTOP)

all_processes = snapshot()
targets = set(roots)
while True:
    expanded = targets | {pid for pid, info in all_processes.items() if info['ppid'] in targets}
    if expanded == targets:
        break
    targets = expanded
selected = {pid: all_processes[pid] for pid in targets if pid in all_processes}
for pid, info in selected.items():
    send(pid, info, signal.SIGSTOP)

prior = {}
for rel in ['queue_status.json', 'priority_status.json', 'core/status.json',
            'nguyen_subject_phase_20261003/status.json', 'nguyen_phase_20261003/status.json', 'nguyen_spectral_20261003/status.json', 'nguyen_external_20261003/status.json', 'validation_20261003/status.json', 'inner_results/status.json', 'inner_data/download_status.json',
            'inner_prepared/prepare_status.json', 'diagnostics_20261003/cpu/status.json',
            'diagnostics_20261003/gpu/status.json']:
    path = ROOT / rel
    if path.exists():
        prior[rel] = json.loads(path.read_text())

for pid, info in selected.items():
    send(pid, info, signal.SIGTERM)
    send(pid, info, signal.SIGCONT)
deadline = time.monotonic() + 8
while any(same(pid, info) for pid, info in selected.items()) and time.monotonic() < deadline:
    time.sleep(0.25)
forced = []
for pid, info in selected.items():
    if same(pid, info):
        send(pid, info, signal.SIGKILL)
        forced.append(pid)
time.sleep(0.5)
live = snapshot()
remaining = {pid: info for pid, info in live.items()
             if info['state'] != 'Z' and any(a.startswith(str(ROOT) + '/') and Path(a).name in SCRIPTS
                                           for a in info['args'])}
record = {'state': 'paused' if not remaining else 'pause_incomplete',
          'reason': 'user_requested_pause_before_shutdown', 'updated': time.time(),
          'stopped_processes': selected, 'forced_pids': forced,
          'remaining_processes': remaining, 'previous_statuses': prior}
atomic(ROOT / 'pause_record.json', record)
if not remaining:
    for rel, old in prior.items():
        if old.get('state') in ('running', 'downloading', 'preparing'):
            atomic(ROOT / rel, {**old, 'state': 'paused', 'paused_at': time.time(),
                               'pause_reason': 'user_request'})
print(json.dumps({'state': record['state'], 'stopped_pids': sorted(selected),
                  'forced_pids': forced, 'remaining_pids': sorted(remaining)}, ensure_ascii=False))
gpu = subprocess.run(['nvidia-smi', '--query-compute-apps=pid,process_name,used_gpu_memory',
                      '--format=csv,noheader'], text=True, capture_output=True)
print('GPU_COMPUTE_PROCESSES:', gpu.stdout.strip() or '(none)')
print('FILES_PRESERVED:', str(ROOT))
if remaining:
    raise SystemExit(1)
