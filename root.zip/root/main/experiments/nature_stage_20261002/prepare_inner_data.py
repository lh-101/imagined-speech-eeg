"""Official OpenNeuro derivative snapshot; no performance-based choices."""
from pathlib import Path
import os,sys,json,time,hashlib,subprocess,sysconfig,urllib.request,urllib.parse
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor,as_completed
import requests

ROOT=Path('/root/FAST/experiments/nature_stage_20261002')
DATA=ROOT/'inner_data'
BASE='https://s3.amazonaws.com/openneuro.org/'
def atomic(p,obj):
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(obj,indent=2));tmp.replace(p)
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()
def inventory():
    ns={'s':'http://s3.amazonaws.com/doc/2006-03-01/'};token=None;files=[]
    while True:
        params={'list-type':'2','prefix':'ds003626/derivatives/'}
        if token:params['continuation-token']=token
        response=requests.get(BASE,params=params,timeout=60);response.raise_for_status()
        xml=ET.fromstring(response.content)
        for obj in xml.findall('s:Contents',ns):
            key=obj.findtext('s:Key',namespaces=ns)
            if any(key.endswith(s) for s in ['_eeg-epo.fif','_exg-epo.fif','_events.dat','_report.pkl']):
                files.append(dict(key=key,size=int(obj.findtext('s:Size',namespaces=ns)),etag=obj.findtext('s:ETag',namespaces=ns).strip('"')))
        token=xml.findtext('s:NextContinuationToken',namespaces=ns)
        if not token:break
    assert len([f for f in files if f['key'].endswith('_eeg-epo.fif')])==30, 'Expected all 10 subjects x 3 sessions'
    return sorted(files,key=lambda f:f['key'])
def download(obj):
    p=DATA/obj['key'];p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists() and p.stat().st_size==obj['size']:return dict(obj,sha256=digest(p),path=str(p))
    tmp=p.with_suffix(p.suffix+'.part')
    for attempt in range(6):
        try:
            size=tmp.stat().st_size if tmp.exists() else 0
            headers={'If-Match':'"'+obj['etag']+'"'}
            if size:headers['Range']=f'bytes={size}-'
            response=requests.get(BASE+urllib.parse.quote(obj['key'],safe='/'),headers=headers,stream=True,timeout=(30,120))
            response.raise_for_status()
            append=size>0 and response.status_code==206
            with tmp.open('ab' if append else 'wb') as f:
                for chunk in response.iter_content(chunk_size=1024*1024):
                    if chunk:f.write(chunk)
            assert tmp.stat().st_size==obj['size'],f'Unexpected size for {obj["key"]}'
            tmp.replace(p)
            return dict(obj,sha256=digest(p),path=str(p))
        except Exception as e:
            print('DOWNLOAD_RETRY',obj['key'],attempt+1,repr(e),flush=True)
            if attempt==5:raise
            time.sleep(min(30,2**attempt))

def main():
    ROOT.mkdir(parents=True,exist_ok=True);DATA.mkdir(exist_ok=True)
    files=inventory();total=sum(f['size'] for f in files)
    import shutil
    assert shutil.disk_usage(DATA).free>total+5*1024**3,'Insufficient disk headroom'
    atomic(DATA/'inventory.json',dict(source=BASE,prefix='ds003626/derivatives/',files=files,total_bytes=total,listed_at=time.time(),
      note='Official S3 derivative objects pinned by ETag and local SHA256; snapshot, not an asserted OpenNeuro release version. Author preprocessing includes session-wise unsupervised ICA; report this in downstream evaluation.'))
    print('DOWNLOAD_BEGIN',len(files),total,flush=True)
    # Small records first, then EEG and external signals from all sessions.
    ordered=sorted(files,key=lambda f:(f['size']>100000,f['key']))
    complete=[];started=time.time()
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures={pool.submit(download,obj):obj for obj in ordered}
        for future in as_completed(futures):
            complete.append(future.result())
            atomic(DATA/'download_status.json',dict(state='downloading',completed_files=len(complete),total_files=len(files),completed_bytes=sum(f['size'] for f in complete),total_bytes=total,started=started,updated=time.time(),last_file=complete[-1]['key']))
            atomic(DATA/'checksums.json',dict(files=complete))
            print('DOWNLOAD_DONE',len(complete),len(files),complete[-1]['key'],flush=True)
    atomic(DATA/'download_status.json',dict(state='download_complete',completed_files=len(files),total_files=len(files),completed_bytes=total,total_bytes=total,started=started,updated=time.time()))
    # An isolated data environment reuses the existing packages read-only.
    env=ROOT/'data_env';subprocess.run([sys.executable,'-m','venv',str(env)],check=True)
    python=env/'bin/python'
    site=Path(subprocess.check_output([str(python),'-c','import sysconfig; print(sysconfig.get_paths()["purelib"])'],text=True).strip())
    (site/'existing_fast_runtime.pth').write_text('import sys; sys.path[:0] = '+repr([p for p in sys.path if p.endswith('site-packages')])+'\n')
    subprocess.run([str(python),'-m','pip','install','mne==1.8.0','pooch==1.8.2','lazy-loader==0.4'],check=True)
    subprocess.run([str(python),str(ROOT/'preprocess_inner.py')],check=True,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
    print('INNER_DATA_READY',flush=True)

if __name__=='__main__':
    try:main()
    except Exception as e:
        ROOT.mkdir(parents=True,exist_ok=True);atomic(ROOT/'inner_data_failure.json',dict(state='failed',error=repr(e),updated=time.time()));raise
