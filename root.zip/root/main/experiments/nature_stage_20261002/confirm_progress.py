from pathlib import Path
import json,time,os
R=Path('/root/FAST/experiments/nature_stage_20261002/multicue_confirm_20261003')
def read(p):
 try:return json.loads(p.read_text())
 except Exception:return {}
def duration(x):
 if x is None:return 'pending measurement'
 x=int(max(0,x));return f'{x//3600:02d}:{x//60%60:02d}:{x%60:02d}'
def show():
 man=read(R/'protocol.json');stat=read(R/'status.json');files=list(R.glob('download_*.json'));ds=[read(p) for p in files if 'failure' not in p.name]
 downloaded=sum(s.get('downloaded_bytes',0) for s in ds);total=man.get('total_download_bytes',0)
 trainings=[read(p) for p in R.glob('sub-*/multicue_fast_20261003/status.json')]
 fits=sum(s.get('fits_done',0) for s in trainings)
 active=[s for s in ds if s.get('state')=='downloading'];rate=active[-1].get('bytes_per_second',0) if active else 0
 pid=stat.get('pid');present=bool(pid and Path(f'/proc/{pid}').exists())
 print('Frozen validation | Ctrl+C exits display only')
 print('State:',stat.get('state'),'| subject:',stat.get('subject'),'| process:',pid,'present' if present else 'not present')
 print('Subjects complete:',len(stat.get('completed_subjects',[])),'/9 | GPU fits:',fits,'/135')
 print('Download:',f'{downloaded/1e9:.2f}/{total/1e9:.2f} GB',f'({100*downloaded/total:.1f}%)' if total else '')
 if active:print('Current file:',active[-1].get('subject'),active[-1].get('filename'),f'{active[-1].get("percent",0):.1f}%',f'{rate/1e6:.2f} MB/s')
 elapsed=time.time()-stat.get('started',time.time());print('Elapsed:',duration(elapsed))
 seconds=[read(p).get('seconds') for p in R.glob('sub-*/multicue_fast_20261003/results/*.json')];seconds=[s for s in seconds if s]
 train_eta=(sum(seconds)/len(seconds))*(135-fits) if seconds else (135-fits)*20
 dl_eta=(total-downloaded)/rate if rate>0 else None
 if stat.get('state') in ['complete','complete_with_failures']:print('Finished. Analysis:',R/'analysis.json')
 elif dl_eta is not None:
  lower=max(dl_eta,train_eta);upper=dl_eta+train_eta
  print('Remaining rough range:',duration(lower),'-',duration(upper),'| download and training overlap; network estimate is unstable')
 else:print('Training-only remaining estimate:',duration(train_eta),'| overall ETA awaits measured download speed')
 for s in trainings:
  if s.get('state')=='training':print('Training:',s.get('source_task'),s.get('modality'),s.get('method'),'fold',s.get('fold'),'epoch',s.get('epoch'))
 if stat.get('failures'):print('Failures:',json.dumps(stat['failures']))
 if stat.get('error'):print('ERROR:',stat['error'])
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--watch',action='store_true');a=p.parse_args()
 while True:
  if a.watch:os.system('clear')
  show()
  if not a.watch:break
  time.sleep(5)
