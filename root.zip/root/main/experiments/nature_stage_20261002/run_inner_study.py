"""Frozen same-day session holdout and nested calibration evaluation.

No held-out evaluation label reaches fitting, stopping, normalization, or kernel
support. Calibration labels are explicitly permitted target-session training
data and use a permanently disjoint evaluation subset for every budget.
"""
from pathlib import Path
import os,sys,json,time,hashlib,copy,fcntl,argparse
import numpy as np,torch
from torch.nn import functional as F
from sklearn.metrics import f1_score
from inner_models import ROOT,CFG,build,representation,auxiliary,loo,seed_all,cosine_scheduler,smoke

OUT=ROOT/'inner_results'
PREP=ROOT/'inner_prepared'
def atomic(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(obj,indent=2));tmp.replace(p)
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
    return h.hexdigest()
def state_hash(m):
    h=hashlib.sha256()
    for k,v in m.state_dict().items():h.update(k.encode());h.update(v.detach().cpu().numpy().tobytes())
    return h.hexdigest()
def normalization(x):
    mu=x.mean(axis=(0,2),keepdims=True,dtype=np.float64).astype(np.float32)
    sd=x.std(axis=(0,2),keepdims=True,dtype=np.float64).astype(np.float32)
    return mu,np.maximum(sd,1e-6)
def metrics(y,prob,flagged):
    pred=prob.argmax(1);clean=~flagged
    return dict(accuracy=float((pred==y).mean()),macro_f1=float(f1_score(y,pred,average='macro',labels=[0,1,2,3],zero_division=0)),
      n=int(len(y)),clean_n=int(clean.sum()),clean_accuracy=float((pred[clean]==y[clean]).mean()) if clean.any() else None,
      class_recalls=[float((pred[y==c]==c).mean()) if (y==c).any() else None for c in range(4)])

def partition_calibration(y,held,seed,subject,session):
    rng=np.random.RandomState(seed+subject*101+session*17)
    pool=[];evaluation=[]
    for c in range(4):
        ix=held[y[held]==c].copy();rng.shuffle(ix)
        assert len(ix)>=2,'Each class needs separate calibration and evaluation trials'
        count=len(ix)//2;pool.extend(ix[:count]);evaluation.extend(ix[count:])
    pool=np.array(pool,dtype=np.int64);evaluation=np.array(sorted(evaluation),dtype=np.int64)
    assert not set(pool)&set(evaluation)
    subsets={}
    for fraction in CFG['calibration_fractions']:
        ix=np.concatenate([pool[y[pool]==c][:max(1,int(np.floor(sum(y[pool]==c)*fraction)))] for c in range(4)])
        assert not set(ix)&set(evaluation)
        subsets[fraction]=ix
    assert set(pool)|set(evaluation)==set(held)
    return pool,evaluation,subsets

def train(model,x,y,method,epochs,lr,source_n=None):
    model=model.cuda();xt=torch.from_numpy(x).cuda();yt=torch.from_numpy(y).cuda()
    optimizer=torch.optim.AdamW(model.parameters(),lr=lr)
    schedule=cosine_scheduler(1,.1,epochs,1,warmup_epochs=min(10,epochs//5))
    trace=[];torch.cuda.reset_peak_memory_stats();start=time.time()
    for epoch in range(epochs):
        model.train();optimizer.zero_grad(set_to_none=True)
        for g in optimizer.param_groups:g['lr']=lr*float(schedule[epoch])
        with torch.autocast('cuda',dtype=torch.bfloat16):
            logits,q=representation(model,xt)
            if source_n is None:
                main=F.cross_entropy(logits,yt);extra=auxiliary(q,yt,method)
            else:
                main=.5*(F.cross_entropy(logits[:source_n],yt[:source_n])+F.cross_entropy(logits[source_n:],yt[source_n:]))
                if method=='loo':
                    scores=CFG['score_scale']*loo(q,yt)
                    extra=CFG['aux_weight']*.5*(F.cross_entropy(scores[:source_n],yt[:source_n])+F.cross_entropy(scores[source_n:],yt[source_n:]))
                else:assert method=='ce';extra=q.sum()*0
            loss=main+extra
        loss.backward()
        if not torch.isfinite(loss) or not all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters()):raise RuntimeError('Nonfinite training loss/gradient')
        optimizer.step()
        if hasattr(model,'constrain'):model.constrain()
        if epoch==0 or (epoch+1)%50==0:
            row=dict(epoch=epoch+1,lr=optimizer.param_groups[0]['lr'],main_loss=float(main.detach()),aux_loss=float(extra.detach()))
            trace.append(row);print('INNER_TRAIN',method,json.dumps(row),flush=True)
    model.eval()
    return model,dict(seconds=time.time()-start,peak_cuda_bytes=torch.cuda.max_memory_allocated(),trace=trace)

def predict(model,x):
    model.eval();parts=[]
    with torch.no_grad():
        for begin in range(0,len(x),64):
            with torch.autocast('cuda',dtype=torch.bfloat16):logits,_=representation(model,torch.from_numpy(x[begin:begin+64]).cuda())
            parts.append(logits.float().softmax(1).cpu().numpy())
    return np.concatenate(parts)

def write_prediction(path,prob,y,indices,data,train_idx,calibration_idx):
    assert not set(indices)&set(train_idx)
    assert not set(indices)&set(calibration_idx)
    tmp=path.with_suffix('.npz.tmp')
    with tmp.open('wb') as f:np.savez(f,prob=prob,y=y,indices=indices,train_idx=train_idx,calibration_idx=calibration_idx,
        session=data['session'][indices],original_trial=data['original_trial'][indices],original_sample=data['original_sample'][indices],emg_flagged=data['emg_flagged'][indices])
    tmp.replace(path)

def summarize():
    groups={}
    for path in OUT.glob('*/*/*.json'):
        row=json.loads(path.read_text())
        if 'evaluation' not in row:continue
        key=(row['architecture'],row['method'],row['phase'],row.get('fraction',0))
        groups.setdefault(key,[]).append(row)
    summary=[]
    for (arch,method,phase,fraction),rows in groups.items():
        seeds=[];subjects=[]
        for seed in CFG['seeds']:
            sub=[]
            for subject in range(1,11):
                a=[r['evaluation'] for r in rows if r['seed']==seed and r['subject']==subject]
                if len(a)==3:sub.append(dict(subject=subject,accuracy=float(np.mean([v['accuracy'] for v in a])),macro_f1=float(np.mean([v['macro_f1'] for v in a]))))
            seeds.append(dict(seed=seed,n_complete_subjects=len(sub),subjects=sub,accuracy=float(np.mean([v['accuracy'] for v in sub])) if sub else None))
        for subject in range(1,11):
            values=[v['accuracy'] for seed in seeds for v in seed['subjects'] if v['subject']==subject]
            if len(values)==3:subjects.append(dict(subject=subject,accuracy=float(np.mean(values))))
        summary.append(dict(architecture=arch,method=method,phase=phase,fraction=fraction,n_records=len(rows),expected_records=90,
          complete=len(rows)==90,seeds=seeds,subject_mean_over_seeds=subjects,
          note='Held-out sessions and seeds are repeated measures. Subjects are the independent unit. Source-session training, no unseen-subject claim.'))
    atomic(OUT/'summary.json',dict(groups=summary,updated=time.time()))

def base(arch,method,seed,subject,held_session,geometry):
    dest=OUT/arch/method;dest.mkdir(parents=True,exist_ok=True)
    name=f'seed{seed}_sub{subject:02d}_ses{held_session}'
    predfile=dest/(name+'_base.npz');infofile=dest/(name+'_base.json');weightfile=dest/(name+'_base.pt')
    with np.load(PREP/f'sub-{subject:02d}.npz') as f:data={k:f[k] for k in f.files}
    y=data['y'].astype(np.int64);source=np.flatnonzero(data['session']!=held_session);held=np.flatnonzero(data['session']==held_session)
    assert len(source)>0 and len(held)>0 and not set(source)&set(held)
    pool,evaluation,subsets=partition_calibration(y,held,seed,subject,held_session)
    norm=normalization(data['X'][source]);x=((data['X']-norm[0])/norm[1]).astype(np.float32)
    split=dict(source=source.tolist(),held=held.tolist(),calibration_pool=pool.tolist(),evaluation=evaluation.tolist(),
       budgets={str(fr):dict(indices=ix.tolist(),n=int(len(ix)),class_counts=np.bincount(y[ix],minlength=4).tolist()) for fr,ix in subsets.items()})
    if predfile.exists():
        assert weightfile.exists() and infofile.exists()
        info=json.loads(infofile.read_text());assert info['split']==split
        checkpoint=torch.load(weightfile,map_location='cpu')
    else:
        seed_all(seed+subject*101+held_session*17);model=build(arch,geometry);initial=state_hash(model)
        for other in ['ce','loo','supcon']:
            p=OUT/arch/other/(name+'_base.json')
            if p.exists():assert json.loads(p.read_text())['initial_state_sha256']==initial
        model,timing=train(model,x[source],y[source],method,CFG['epochs'],CFG['lr'])
        probability=predict(model,x[held]);lookup={int(k):i for i,k in enumerate(held)}
        common=probability[[lookup[int(k)] for k in evaluation]]
        info=dict(architecture=arch,method=method,seed=seed,subject=subject,held_session=held_session,phase='base',split=split,
          initial_state_sha256=initial,evaluation=metrics(y[held],probability,data['emg_flagged'][held]),
          common_evaluation=metrics(y[evaluation],common,data['emg_flagged'][evaluation]),**timing)
        checkpoint=dict(state_dict={k:v.detach().cpu() for k,v in model.state_dict().items()},normalization=norm,split=split,architecture=arch,method=method)
        tmp=weightfile.with_suffix('.pt.tmp');torch.save(checkpoint,tmp);tmp.replace(weightfile)
        atomic(infofile,info)
        # Separate zero-calibration predictions for the common evaluation set.
        write_prediction(dest/(name+'_cal0.npz'),common,y[evaluation],evaluation,data,source,np.array([],dtype=np.int64))
        atomic(dest/(name+'_cal0.json'),dict(architecture=arch,method=method,seed=seed,subject=subject,held_session=held_session,
             phase='calibration',fraction=0.,n_calibration=0,evaluation=info['common_evaluation'],seconds=0,split=split))
        write_prediction(predfile,probability,y[held],held,data,source,np.array([],dtype=np.int64))
        print('INNER_BASE_DONE',arch,method,seed,subject,held_session,info['evaluation']['accuracy'],timing['seconds'],flush=True)
        del model;torch.cuda.empty_cache()
    return data,x,y,source,evaluation,subsets,checkpoint,name

def calibration(arch,method,seed,subject,held_session,geometry,pack):
    if method=='supcon':return
    data,x,y,source,evaluation,subsets,checkpoint,name=pack
    dest=OUT/arch/method
    for fraction,cal in subsets.items():
        suffix=f'_cal{int(fraction*100)}';predfile=dest/(name+suffix+'.npz')
        if predfile.exists():continue
        model=build(arch,geometry);model.load_state_dict(checkpoint['state_dict'])
        seed_all(seed+subject*101+held_session*17)
        ix=np.concatenate([source,cal]);assert not set(ix)&set(evaluation)
        model,timing=train(model,x[ix],y[ix],method,CFG['calibration_epochs'],CFG['calibration_lr'],source_n=len(source))
        probability=predict(model,x[evaluation])
        info=dict(architecture=arch,method=method,seed=seed,subject=subject,held_session=held_session,phase='calibration',fraction=fraction,
          n_calibration=len(cal),calibration_class_counts=np.bincount(y[cal],minlength=4).tolist(),
          evaluation=metrics(y[evaluation],probability,data['emg_flagged'][evaluation]),**timing)
        tmp=(dest/(name+suffix+'.pt')).with_suffix('.pt.tmp');torch.save(dict(state_dict=model.cpu().state_dict(),normalization=checkpoint['normalization'],source_idx=source,calibration_idx=cal,evaluation_idx=evaluation),tmp);tmp.replace(dest/(name+suffix+'.pt'))
        atomic(dest/(name+suffix+'.json'),info);write_prediction(predfile,probability,y[evaluation],evaluation,data,source,cal)
        print('INNER_CAL_DONE',arch,method,seed,subject,held_session,fraction,len(cal),info['evaluation']['accuracy'],timing['seconds'],flush=True)
        del model;torch.cuda.empty_cache()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');args=ap.parse_args()
    torch.set_num_threads(4)
    if args.smoke:
        result=smoke()
        y=np.tile(np.arange(4),20);held=np.arange(40,80)
        _,ev,budgets=partition_calibration(y,held,42,1,1)
        for ix in budgets.values():assert not set(ix)&set(ev)
        result['calibration_split_checks']=True;atomic(ROOT/'inner_smoke.json',result);return
    OUT.mkdir(parents=True,exist_ok=True)
    assert json.loads((PREP/'prepare_status.json').read_text())['state']=='complete'
    assert json.loads((ROOT/'inner_smoke.json').read_text())['passed']
    geometry=json.loads((PREP/'geometry.json').read_text())
    protocol=dict(cfg=CFG,architectures=['fast','eegnet'],methods=['ce','loo','supcon'],n_base_fits=540,n_calibration_fits=1080,
      source_hashes={p.name:sha(p) for p in [Path(__file__),ROOT/'inner_models.py',ROOT/'preprocess_inner.py']},prepared_manifest_sha256=sha(PREP/'manifest.json'),geometry=geometry,
      main_endpoint='Accuracy of primary classifier on held-out real session; mean over sessions within subject, then seeds, then subjects',
      normalization='128 per-channel source-training means/std only, fixed during calibration; no target evaluation feature statistics',
      calibration='Half of each target-session class reserved for evaluation once per seed, remaining half is calibration pool; nested .25/.5/1 fractions of that pool; actual counts reported. Source and target-calibration CE and LOO losses balanced 1:1; 50 fixed epochs at 1e-4, source support plus permitted labeled target calibration.',
      schedule='schedule[epoch], correct zero-based indexing for every arm; differs from historical BCI replay, comparison remains paired within this dataset',
      exclusions='All inner-speech trials included; official EMG flags only for prespecified clean-subset sensitivity; no accuracy-based exclusion or checkpoint selection',
      limitations=['Released session-wise unsupervised preprocessing, not prospective online validation','Same-day sessions, not cross-day','4 directional commands, not continuous semantics','Fixed objective hyperparameters, not independently tuned best baseline'])
    path=OUT/'protocol.json'
    if path.exists():assert json.loads(path.read_text())==protocol
    else:atomic(path,protocol)
    with (OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        started=time.time()
        try:
            # Base session holdouts first, then the calibration curves.
            for phase in ['base','calibration']:
                for seed in CFG['seeds']:
                    for arch in ['fast','eegnet']:
                        for subject in range(1,11):
                            for held_session in range(1,4):
                                for method in ['ce','loo','supcon'] if phase=='base' else ['ce','loo']:
                                    atomic(OUT/'status.json',dict(state='running',pid=os.getpid(),phase=phase,seed=seed,architecture=arch,subject=subject,held_session=held_session,method=method,started=started,updated=time.time()))
                                    pack=base(arch,method,seed,subject,held_session,geometry)
                                    if phase=='calibration':calibration(arch,method,seed,subject,held_session,geometry,pack)
                                    summarize()
            atomic(OUT/'status.json',dict(state='complete',started=started,updated=time.time()));summarize()
        except Exception as e:
            atomic(OUT/'status.json',dict(state='failed',error=repr(e),started=started,updated=time.time()));raise

if __name__=='__main__':main()
