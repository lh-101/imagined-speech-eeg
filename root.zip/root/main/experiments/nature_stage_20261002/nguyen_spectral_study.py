"""Post-hoc second-dataset diagnosis and frozen spectral-objective comparison."""
from pathlib import Path
import json,time,os,fcntl
import numpy as np
import run_nguyen_external as old
R=old.ROOT;PRE=old.OUT;OUT=R/'nguyen_spectral_20261003'
atomic=old.atomic
def metrics(y,p):
    from sklearn.metrics import f1_score,confusion_matrix
    pred=p.argmax(1);cm=confusion_matrix(y,pred,labels=[0,1,2])
    return dict(accuracy=float((pred==y).mean()),macro_f1=float(f1_score(y,pred,average='macro',labels=[0,1,2])),
      recalls=(np.diag(cm)/np.maximum(cm.sum(1),1)).tolist(),predicted_counts=np.bincount(pred,minlength=3).tolist(),confusion=cm.tolist())
def power(x):
    from scipy.signal import welch
    f,p=welch(x,fs=256.,nperseg=256,noverlap=128,axis=-1)
    return np.concatenate([np.log(np.maximum(p[...,(f>=a)&(f<b)].sum(-1),1e-12)) for a,b in [(8,13),(13,30),(30,70)]],axis=1).astype(np.float32)
def summarize():
    rows=[json.loads(p.read_text()) for p in (OUT/'fits').glob('*/*.json')];groups=[]
    for job in sorted(set(r['job'] for r in rows)):
        a=[r for r in rows if r['job']==job];subs=[]
        for s in range(1,7):
            q=[r for r in a if r['subject']==s]
            if len(q)==5:subs.append(dict(subject=s,accuracy=float(np.mean([r['evaluation']['accuracy'] for r in q])),macro_f1=float(np.mean([r['evaluation']['macro_f1'] for r in q]))))
        groups.append(dict(job=job,n_fits=len(a),subjects=subs,mean_accuracy=float(np.mean([s['accuracy'] for s in subs])) if subs else None,mean_macro_f1=float(np.mean([s['macro_f1'] for s in subs])) if subs else None))
    atomic(OUT/'summary.json',dict(groups=groups,complete=all(g['n_fits']==30 for g in groups) and len(groups)==5))
def diagnose():
    from scipy.io import loadmat
    from sklearn.preprocessing import StandardScaler
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import make_pipeline
    reports=[];geometry=json.loads((PRE/'geometry.json').read_text());keep=[i for i in range(64) if i not in [0,9,32,63]]
    assert len(geometry['channels'])==60 and sum(map(len,geometry['zone_dict'].values()))==60
    for s in range(1,7):
        with np.load(PRE/f'sub-{s:02d}.npz') as f:x=f['X'];y=f['y']
        mat=loadmat(old.DATA/'extracted'/f'sub-{s:02d}.mat');active=mat['eeg_data_wrt_task_rep_no_eog_256Hz_last_beep'];rest=mat['eeg_data_wrt_task_rep_no_eog_256Hz_end_trial']
        assert active.shape==rest.shape==(3,100)
        expected=np.asarray([active[c,j][keep,:1024] for c in range(3) for j in range(100)],dtype=np.float32)
        assert np.array_equal(expected,x) and np.array_equal(y,np.repeat(np.arange(3),100))
        rx=np.asarray([rest[c,j][keep,:512] for c in range(3) for j in range(100)],dtype=np.float32)
        exg=np.asarray([active[c,j][[0,9,32,63],:1024] for c in range(3) for j in range(100)],dtype=np.float32)
        feat=power(x);rp=power(rx);ef=power(exg)
        assert np.isfinite(feat).all() and np.isfinite(rp).all()
        np.savez_compressed(OUT/f'features_sub{s:02d}.npz',imagery=feat,rest=rp,contrast=feat-rp,exg=ef,y=y)
        class_reports=[]
        for job in ['fast_ce','fast_loo','eegnet_ce','spectral_logistic']:
            pp=np.zeros((300,3));seen=np.zeros(300,dtype=int)
            for fold in range(5):
                with np.load(PRE/'results'/job/f'sub{s:02d}_fold{fold}.npz') as f:
                    tr=f['train'];ev=f['test'];assert not set(tr)&set(ev) and np.array_equal(f['y'],y[ev]);pp[ev]=f['prob'];seen[ev]+=1
            assert (seen==1).all()
            class_reports.append(dict(job=job,**metrics(y,pp)))
        reports.append(dict(subject=s,raw_prepared_exact_match=True,native_channel_rms_quantiles=np.quantile(np.sqrt(np.mean(x*x,axis=-1)),[0,.5,.95,.99,1]).tolist(),classifiers=class_reports))
        atomic(OUT/'diagnosis.json',dict(subjects=reports,complete=s==6,limitations='Class bias quantified on prior OOF predictions; correlation does not prove loss causes bias. Rest has same trial label and follows imagery, so it is a carry-over/nuisance control, not an independent null. Cap locations inherited from adapter, not individually verified acquisition positions.'))
        print('SPECTRAL_DIAGNOSED',s,flush=True)
def representations():
    import torch
    import inner_models as im
    import run_inner_study as r
    from transformers import PretrainedConfig
    torch.set_num_threads(4)
    geometry=json.loads((PRE/'geometry.json').read_text());rows=[]
    for s in range(1,7):
        with np.load(PRE/f'sub-{s:02d}.npz') as f:x=f['X'];y=f['y']
        for fold in range(5):
            for job in ['fast_ce','fast_loo']:
                name=f'sub{s:02d}_fold{fold}';ck=torch.load(PRE/'results'/job/(name+'.pt'),map_location='cpu')
                tr=ck['train'];ev=ck['test'];mu,sd=ck['normalization'];expected=r.normalization(x[tr])
                assert np.array_equal(mu,expected[0]) and np.array_equal(sd,expected[1])
                xx=((x-mu)/sd).astype(np.float32)
                model=im.FAST(PretrainedConfig(electrodes=geometry['channels'],zone_dict=geometry['zone_dict'],dim_cnn=32,dim_token=32,seq_len=1024,window_len=256,slide_step=128,head='Conv4Layers',n_classes=3,num_layers=4,num_heads=8,dropout=.1)).cuda()
                model.load_state_dict(ck['state_dict']);model.eval();pp=[];zz=[]
                with torch.no_grad():
                    for begin in range(0,len(x),64):
                        with torch.autocast('cuda',dtype=torch.bfloat16):logits,q=r.representation(model,torch.from_numpy(xx[begin:begin+64]).cuda())
                        pp.append(logits.float().softmax(1).cpu().numpy());zz.append(q.float().cpu().numpy())
                p=np.concatenate(pp);z=np.concatenate(zz)
                held_probability=r.predict(model,xx[ev])
                with np.load(PRE/'results'/job/(name+'.npz')) as f:assert np.allclose(held_probability,f['prob'],atol=1e-5),'Checkpoint prediction mismatch'
                sim=z[ev]@z[ev].T;same=y[ev,None]==y[None,ev];diag=np.eye(len(ev),dtype=bool)
                rows.append(dict(subject=s,fold=fold,job=job,training=metrics(y[tr],p[tr]),evaluation=metrics(y[ev],held_probability),
                  held_same_cosine=float(sim[same&~diag].mean()),held_different_cosine=float(sim[~same].mean()),held_cosine_gap=float(sim[same&~diag].mean()-sim[~same].mean())))
                dest=OUT/'representations'/job;dest.mkdir(parents=True,exist_ok=True);np.savez_compressed(dest/(name+'.npz'),q=z,y=y,train=tr,test=ev)
                atomic(OUT/'representation_diagnosis.json',dict(rows=rows,complete=len(rows)==60))
                del model;torch.cuda.empty_cache()
        print('SAVED_MODEL_DIAGNOSED',s,flush=True)
def train():
    import torch
    from torch import nn
    from torch.nn import functional as F
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import make_pipeline
    from sklearn.linear_model import LogisticRegression
    import inner_models as im
    torch.set_num_threads(4)
    class Encoder(nn.Module):
        def __init__(self):
            super().__init__();self.encoder=nn.Sequential(nn.Linear(180,64),nn.GELU(),nn.Dropout(.1),nn.Linear(64,32));self.head=nn.Linear(32,3)
        def forward(self,x):
            h=self.encoder(x);return self.head(h),F.normalize(h,dim=1)
    def loo(q,y):
        a=torch.exp(-2*(1-q.double()@q.double().T))+.1*torch.eye(len(q),device=q.device,dtype=torch.float64)
        b=torch.cholesky_inverse(torch.linalg.cholesky(a));target=F.one_hot(y,3).double()
        return (target-(b@target)/b.diag()[:,None]).float()
    # Fixed representation LOO cannot optimize anything. A matched trainable
    # encoder makes CE versus CE+LOO a meaningful objective comparison.
    im.seed_all(42);q=F.normalize(torch.randn(12,16,device='cuda'),dim=1).requires_grad_();y=torch.arange(12,device='cuda')%3;actual=loo(q,y)
    for i in range(12):
        m=torch.arange(12,device='cuda')!=i;z=q[m];a=torch.exp(-2*(1-z.double()@z.double().T))+.1*torch.eye(11,device=q.device,dtype=torch.float64)
        expected=torch.exp(-2*(1-q[i:i+1].double()@z.double().T))@torch.linalg.solve(a,F.one_hot(y[m],3).double())
        assert torch.allclose(actual[i],expected.float()[0],atol=1e-5)
    loss=F.cross_entropy(4*actual,y);loss.backward();assert torch.isfinite(q.grad).all()
    atomic(OUT/'smoke.json',dict(passed=True,explicit_refits_match=True,finite_loo_gradients=True))
    started=time.time()
    for s in range(1,7):
        with np.load(OUT/f'features_sub{s:02d}.npz') as f:d={k:f[k] for k in f.files}
        y=d['y'];splits=json.loads((PRE/f'splits_sub{s:02d}.json').read_text())['folds']
        for fold,split in enumerate(splits):
            tr=np.asarray(split['train']);ev=np.asarray(split['test']);assert not set(tr)&set(ev)
            for job in ['spectral_mlp_ce','spectral_mlp_loo','rest_logistic','contrast_logistic','exg_logistic']:
                dest=OUT/'fits'/job;dest.mkdir(parents=True,exist_ok=True);name=f'sub{s:02d}_fold{fold}'
                if (dest/(name+'.json')).exists():continue
                atomic(OUT/'status.json',dict(state='running',phase='fitting',pid=os.getpid(),subject=s,fold=fold+1,job=job,started=started,updated=time.time()))
                tick=time.time()
                if job.startswith('spectral_mlp'):
                    scaler=StandardScaler().fit(d['imagery'][tr]);x=scaler.transform(d['imagery']).astype(np.float32)
                    im.seed_all(42+s*101+fold*17);m=Encoder().cuda()
                    import hashlib
                    initial=hashlib.sha256(b''.join(v.detach().cpu().numpy().tobytes() for v in m.state_dict().values())).hexdigest()
                    if job.endswith('loo'):assert initial==json.loads((OUT/'fits/spectral_mlp_ce'/(name+'.json')).read_text())['initial_state_sha256']
                    xt=torch.from_numpy(x[tr]).cuda();yt=torch.from_numpy(y[tr]).cuda();opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.01);trace=[]
                    for epoch in range(200):
                        m.train();opt.zero_grad(set_to_none=True);logits,q=m(xt);main=F.cross_entropy(logits,yt);aux=.3*F.cross_entropy(4*loo(q,yt),yt) if job.endswith('loo') else q.sum()*0
                        loss=main+aux;loss.backward();assert torch.isfinite(loss) and all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters());opt.step()
                        if epoch in [0,49,99,149,199]:trace.append(dict(epoch=epoch+1,ce=float(main.detach()),aux=float(aux.detach())))
                    m.eval()
                    with torch.no_grad():
                        logits,q=m(torch.from_numpy(x).cuda());p=logits[ev].softmax(1).cpu().numpy();trainp=logits[tr].softmax(1).cpu().numpy();z=q.cpu().numpy()
                    zt=z[ev];sim=zt@zt.T;same=y[ev,None]==y[None,ev];diag=np.eye(len(ev),dtype=bool)
                    gap=float(sim[same&~diag].mean()-sim[~same].mean())
                    torch.save(dict(state_dict=m.cpu().state_dict(),scaler_mean=scaler.mean_,scaler_scale=scaler.scale_,train=tr,test=ev),dest/(name+'.pt'))
                    details=dict(initial_state_sha256=initial,trace=trace,training=metrics(y[tr],trainp),held_representation_cosine_gap=gap)
                    del m;torch.cuda.empty_cache()
                else:
                    key=job.replace('_logistic','');x=d[key];m=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=2000));m.fit(x[tr],y[tr]);p=m.predict_proba(x[ev]);details={}
                np.savez_compressed(dest/(name+'.npz'),prob=p,y=y[ev],train=tr,test=ev)
                atomic(dest/(name+'.json'),dict(job=job,subject=s,fold=fold,evaluation=metrics(y[ev],p),seconds=time.time()-tick,**details))
                summarize();print('SPECTRAL_FIT_DONE',job,s,fold,metrics(y[ev],p)['accuracy'],flush=True)
def main():
    OUT.mkdir(exist_ok=True)
    with (OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        protocol=dict(dataset='Nguyen2017 ShortWords',scope='Post-hoc exploratory diagnosis; prior external test folds have already been inspected. No new independent test claim.',
          primary='Matched spectral MLP CE versus spectral MLP CE+LOO, fixed settings; not a new architecture contribution by itself',
          features='Welch fs256, default Hann, nperseg256 noverlap128, integrated bins [8,13),[13,30),[30,70), log floor1e-12; same definition as saved spectral baseline',
          model='180->64 GELU dropout.1 ->32 embedding ->3 logits; L2 embedding for Gaussian kernel',epochs=200,lr=.001,weight_decay=.01,ridge=.1,gamma=2.,aux_weight=.3,score_scale=4.,
          seed='42+subject*101+fold*17; identical CE/LOO initialization',new_gpu_fits=60,new_cpu_fits=90,
          folds='Reuse archived complete-original-trial splits. Training-only feature scaler; fixed budgets and settings, no evaluation-based checkpoint selection',
          control='Rest power, paired log imagery/rest power ratio, and EOG power logistic probes. Paired post-imagery resting data available at evaluation; contrast is an offline method with extra input and not directly identical deployment.',
          limitations=['Six subjects, one seed','Observed prior evaluation outcomes motivated this experiment','Rest carry-over and task-block drift can retain labels','EEG scalp patterns do not prove cortical or language specificity','Existing first-dataset results belong only to original method'],
          source_hashes={p:old.digest(R/p) for p in ['nguyen_spectral_study.py','inner_models.py']},prior_protocol_sha256=old.digest(PRE/'protocol.json'))
        if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==protocol
        else:atomic(OUT/'protocol.json',protocol)
        try:
            atomic(OUT/'status.json',dict(state='running',phase='diagnosis',pid=os.getpid(),started=time.time()))
            diagnose()
            atomic(OUT/'status.json',dict(state='running',phase='saved_model_diagnosis',pid=os.getpid(),started=time.time()))
            representations();train();atomic(OUT/'status.json',dict(state='complete',updated=time.time()))
        except Exception as e:atomic(OUT/'status.json',dict(state='failed',error=repr(e),updated=time.time()));raise
if __name__=='__main__':main()
