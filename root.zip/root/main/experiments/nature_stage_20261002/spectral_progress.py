from pathlib import Path
import json,time,argparse,statistics
R=Path(__file__).resolve().parent/'nguyen_spectral_20261003'
def read(p):
    try:return json.loads(p.read_text())
    except (OSError,ValueError):return {}
def show():
    s=read(R/'status.json');rows=[read(p) for p in R.glob('fits/*/*.json')];gpu=[r for r in rows if r.get('job','').startswith('spectral_mlp')]
    print('Second-dataset spectral mechanism:',s.get('state'),'| phase:',s.get('phase'),'| PID:',s.get('pid'))
    print('Input/prediction audit subjects:',len(read(R/'diagnosis.json').get('subjects',[])),'/6')
    print('Saved-model representation evaluations:',len(read(R/'representation_diagnosis.json').get('rows',[])),'/60')
    print('New GPU fits:',len(gpu),'/60 | new CPU controls:',len(rows)-len(gpu),'/90')
    remaining=0
    for job,default in [('spectral_mlp_ce',2),('spectral_mlp_loo',8)]:
        a=[r['seconds'] for r in gpu if r['job']==job];remaining+=(30-len(a))*(statistics.median(a) if a else default)
    print('Approx fitting time remaining:',round(remaining/60,1),'minutes, excludes diagnosis/setup')
    print('Current subject/fold/job:',s.get('subject'),s.get('fold'),s.get('job'))
    if s.get('error'):print('ERROR:',s['error'])
    for g in read(R/'summary.json').get('groups',[]):print(g['job'],g['n_fits'],'fits; complete-subject mean:',g['mean_accuracy'],'F1:',g['mean_macro_f1'])
def main():
    a=argparse.ArgumentParser();a.add_argument('--watch',action='store_true');args=a.parse_args()
    try:
        while True:
            if args.watch:print('\033[2J\033[H',end='')
            show()
            if not args.watch:return
            time.sleep(5)
    except KeyboardInterrupt:print('Display closed; jobs continue.')
if __name__=='__main__':main()
