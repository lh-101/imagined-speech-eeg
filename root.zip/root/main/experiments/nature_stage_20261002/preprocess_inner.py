"""Audit and retain all inner-speech trials with real session identifiers.

Use the author's released EEG/EXG derivatives. Do not re-fit ICA, select models,
or infer session identifiers from row order. Only the action interval [1,3.5)s
is used, as fixed from the acquisition protocol before examining accuracy.
"""
from pathlib import Path
import sys,json,time,pickle,hashlib
import numpy as np,mne

ROOT=Path('/root/FAST/experiments/nature_stage_20261002')
SRC=ROOT/'inner_data/ds003626/derivatives'
DEST=ROOT/'inner_prepared'
sys.path.insert(0,'/root/FAST')
from BCIC2020Track3_preprocess import Electrodes,Zones

def atomic(p,obj):
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(obj,indent=2));tmp.replace(p)
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
    return h.hexdigest()
def head_positions(montage):
    positions=montage.get_positions()['ch_pos']
    trans=mne.channels.compute_native_head_t(montage)
    return {n:mne.transforms.apply_trans(trans,p) for n,p in positions.items()}
def region_map(names):
    reference=head_positions(mne.channels.make_standard_montage('standard_1005'))
    bio=head_positions(mne.channels.make_standard_montage('biosemi128'))
    assert set(names)==set(bio),'Unexpected BioSemi channel naming'
    a=np.array([reference[n] for n in Electrodes]);a/=np.linalg.norm(a,axis=1,keepdims=True)
    b=np.array([bio[n] for n in names]);b/=np.linalg.norm(b,axis=1,keepdims=True)
    nearest=np.argmax(b@a.T,axis=1)
    source_group={n:k for k,v in Zones.items() for n in v}
    groups={k:[] for k in Zones}
    for n,i in zip(names,nearest):groups[source_group[Electrodes[i]]].append(n)
    assert all(groups.values()) and sum(map(len,groups.values()))==128
    return dict(channels=names,zone_dict=groups,positions={n:bio[n].tolist() for n in names},
       rule='Nearest angular position among original FAST 64 standard_1005 electrodes in MNE head coordinates; inherit reference electrode scalp group. Fixed label-independent geometry, no neural source claim.')

def main():
    DEST.mkdir(parents=True,exist_ok=True);all_rows=[];geometry=None
    for subject in range(1,11):
        parts=[]
        for session in range(1,4):
            pre=f'sub-{subject:02d}_ses-{session:02d}'
            folder=SRC/f'sub-{subject:02d}'/f'ses-{session:02d}'
            paths={k:folder/(pre+s) for k,s in [('eeg','_eeg-epo.fif'),('exg','_exg-epo.fif'),('events','_events.dat'),('report','_report.pkl')]}
            with paths['events'].open('rb') as f:events=np.asarray(pickle.load(f,encoding='latin1'),dtype=np.int64)
            with paths['report'].open('rb') as f:report=pickle.load(f,encoding='latin1')
            eeg=mne.read_epochs(paths['eeg'],preload=False,verbose='ERROR')
            exg=mne.read_epochs(paths['exg'],preload=False,verbose='ERROR')
            assert events.ndim==2 and events.shape[1]==4
            assert len(eeg)==len(events)==len(exg),'Epoch/event alignment failed'
            assert np.all(events[:,3]==session)
            assert np.array_equal(eeg.events[:,0],exg.events[:,0]),'EEG and EXG trial order differs'
            assert eeg.info['sfreq']==exg.info['sfreq']==256., 'Audit real sampling rate; do not infer from text'
            # The official epochs begin 0.5 s before the direction event.
            # Crop using the FIF's event-relative time axis, never row offsets.
            assert np.isclose(eeg.tmin,-.5) and np.isclose(exg.tmin,-.5)
            assert np.isclose(eeg.tmax,4.) and np.isclose(exg.tmax,4.)
            assert np.array_equal(eeg.times,exg.times) and len(eeg.times)==1153
            assert np.array_equal(eeg.events[:,0],events[:,0]), 'Metadata sample order differs'
            assert np.array_equal(eeg.events[:,2],events[:,1]+31), 'Metadata class order differs'
            assert len(eeg.ch_names)==128 and len(exg.ch_names)==8
            eeg_names=eeg.ch_names
            if geometry is None:geometry=region_map(eeg_names)
            else:assert eeg_names==geometry['channels']
            keep=np.flatnonzero(events[:,2]==1)
            assert len(keep)>0
            assert set(events[keep,1])=={0,1,2,3}
            e=eeg[keep].load_data().crop(tmin=1.,tmax=3.5,include_tmax=False).get_data(copy=True)*1e6
            z=exg[keep].load_data().crop(tmin=1.,tmax=3.5,include_tmax=False).get_data(copy=True)*1e6
            assert e.shape==(len(keep),128,640) and z.shape==(len(keep),8,640)
            assert np.isfinite(e).all() and np.isfinite(z).all()
            flagged=np.array(report.get('EMG_trials',[]),dtype=int).ravel()
            assert len(flagged)==0 or (flagged.min()>=0 and flagged.max()<len(events)), 'Unverified EMG trial indexing'
            contaminated=np.isin(keep,flagged)
            row=dict(subject=subject,session=session,n_all=len(events),n_inner=len(keep),counts=np.bincount(events[keep,1],minlength=4).tolist(),
                inner_emg_flagged=int(contaminated.sum()),sfreq=256.,action_interval_s=[1.,3.5],time_samples=640,
                source_time_interval_s=[float(eeg.tmin),float(eeg.tmax)],source_time_samples=len(eeg.times),
                original_event_samples=events[keep,0].tolist(),original_trial_indices=keep.tolist(),
                original_emg_flagged_indices=flagged.tolist(),exg_names=exg.ch_names,
                source_sha256={k:digest(p) for k,p in paths.items()})
            all_rows.append(row)
            parts.append(dict(X=e.astype(np.float32),EXG=z.astype(np.float32),y=events[keep,1],session=np.full(len(keep),session),
                original_trial=keep,original_sample=events[keep,0],emg_flagged=contaminated))
            print('INNER_SESSION_AUDITED',subject,session,len(keep),row['counts'],row['inner_emg_flagged'],flush=True)
        out=DEST/f'sub-{subject:02d}.npz';tmp=out.with_suffix('.npz.tmp')
        with tmp.open('wb') as f:np.savez_compressed(f,**{k:np.concatenate([p[k] for p in parts]) for k in parts[0]})
        tmp.replace(out)
        atomic(DEST/'prepare_status.json',dict(state='preparing',completed_subjects=subject,total_subjects=10,updated=time.time()))
    atomic(DEST/'geometry.json',geometry)
    manifest=dict(dataset='OpenNeuro ds003626 official derivative snapshot',n_subjects=10,n_sessions_per_subject=3,classes=['Arriba/up','Abajo/down','Derecha/right','Izquierda/left'],
        condition='inner speech only; events column 2 equals 1',subjects=all_rows,source_inventory_sha256=digest(ROOT/'inner_data/inventory.json'),
        source_script_sha256=digest(Path(__file__)),prepared_sha256={p.name:digest(p) for p in DEST.glob('sub-*.npz')},
        n_trials=sum(r['n_inner'] for r in all_rows),
        preprocessing='Author released EEG derivatives: rereferenced, broad filtering, downsampled, session-wise unsupervised ICA; inherited processing is not an online/causal pipeline. Convert V to uV, crop action [1,3.5)s. New model normalization uses training data only. EXG excluded from neural model inputs, retained for control probes. No subject/trial excluded according to accuracy; official EMG flags retained for sensitivity evaluation.',
        limitations=['Three same-day sessions, not cross-day validation','Direction labels and visual cues may have shared spatial information; no proof of language specificity','Use existing standardized cap positions, not individual anatomical localization'])
    atomic(DEST/'manifest.json',manifest)
    atomic(DEST/'prepare_status.json',dict(state='complete',completed_subjects=10,total_subjects=10,n_trials=manifest['n_trials'],updated=time.time()))
    print('PREPROCESS_COMPLETE',manifest['n_trials'],flush=True)

if __name__=='__main__':main()
