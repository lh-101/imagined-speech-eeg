"""Frozen same-fold input adaptation study; original FAST runs are reused."""
import os
os.environ['OMP_NUM_THREADS']='4';os.environ['OPENBLAS_NUM_THREADS']='2'
from pathlib import Path
import argparse,fcntl,hashlib,json,sys,time,traceback
import h5py,numpy as np,torch
from torch import nn
from torch.nn import functional as F
from sklearn.metrics import balanced_accuracy_score,f1_score,confusion_matrix
sys.path[:0]=['/root/FAST','/root/FAST/experiments/residual_20260925','/root/FAST/experiments/nature_stage_20261002']
import run_metric_v4 as v4
from inner_models import EEGNet
ROOT=Path('/root/FAST/experiments/nature_stage_20261002/demean_retrain_20261004')
OLD=Path('/root/FAST/experiments/mechanism_20260927/results/full_ce_seed42')
JOBS=['fast_demean','eegnet_raw','eegnet_demean'];START=time.time();STATE={}

def atomic(p,d):
    p.parent.mkdir(exist_ok=True,parents=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(d,indent=2));tmp.replace(p)

def update(**kw):
    STATE.update(kw);STATE.update(pid=os.getpid(),started=START,updated=time.time(),elapsed_seconds=time.time()-START)
    atomic(ROOT/'gpu_status.json',STATE)

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for piece in iter(lambda:f.read(4*1024**2),b''):h.update(piece)
    return h.hexdigest()

def weights_hash(model):
    h=hashlib.sha256()
    for k,v in model.state_dict().items():h.update(k.encode());h.update(v.detach().cpu().numpy().tobytes())
    return h.hexdigest()

def build(job):
    if job.startswith('fast'):return v4.FAST(v4.config())
    m=EEGNet();m.spatial=nn.Conv2d(8,16,(64,1),groups=8,bias=False);m.classifier=nn.Linear(16*(750//4//8),5)
    return m

def inputs(x):
    mean=x[:,:,:750].mean(-1,keepdims=True)
    return dict(raw=x,demean=(x-mean).astype(np.float32),mean_only=np.broadcast_to(mean,x.shape).copy())

def metrics(y,p):
    return dict(accuracy=float((p==y).mean()),balanced_accuracy=float(balanced_accuracy_score(y,p)),macro_f1=float(f1_score(y,p,average='macro',labels=range(5),zero_division=0)),confusion=confusion_matrix(y,p,labels=range(5)).tolist())

def prediction(model,x):
    ps=[]
    with torch.inference_mode():
        for a in range(0,len(x),35):ps.append(model(torch.from_numpy(np.ascontiguousarray(x[a:a+35])).cuda()).float().softmax(1).cpu().numpy())
    return np.concatenate(ps)

def smoke():
    results=[]
    for job in ['fast_demean','eegnet_raw']:
        v4.seed_all(42);m=build(job).cuda();initial=weights_hash(m)
        if job.startswith('fast'):assert initial==json.loads((OLD/'0-fold0.json').read_text())['initial_state_sha256']
        x=torch.randn(10,64,800 if job.startswith('fast') else 750,device='cuda');y=torch.arange(10,device='cuda')%5
        with torch.autocast('cuda',dtype=torch.bfloat16):a=m(x);loss=F.cross_entropy(a,y)
        assert a.shape==(10,5);loss.backward();assert all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters())
        results.append(dict(job=job,passed=True,parameters=sum(p.numel() for p in m.parameters()),initial_sha256=initial));del m;torch.cuda.empty_cache()
    a=np.random.default_rng(1).normal(size=(3,64,800)).astype(np.float32);v=inputs(a)
    assert np.allclose(v['mean_only'][:,:,:750]+v['demean'][:,:,:750],a[:,:,:750],atol=5e-7)
    assert np.max(np.abs(v['demean'][:,:,:750].mean(-1)))<1e-6
    atomic(ROOT/'smoke.json',dict(passed=True,results=results,decomposition=True))
    print('SMOKE_PASS',json.dumps(results),flush=True)

def train_fold(subject,fold,job,x,y,done,durations):
    dest=ROOT/'results'/job/f'{subject}-fold{fold}';dest.parent.mkdir(exist_ok=True,parents=True)
    if dest.with_suffix('.npz').exists():return json.loads(dest.with_suffix('.json').read_text())
    ref=np.load(OLD/f'{subject}-fold{fold}.npz');tr=ref['train_idx'].copy();te=ref['test_idx'].copy()
    assert not set(tr)&set(te) and np.array_equal(ref['y'],y[te]);ref.close()
    condition='demean' if job.endswith('demean') else 'raw';variants=inputs(x)
    if job.startswith('fast'):
        norm_mean=np.zeros((1,64,1),np.float32);norm_std=np.ones((1,64,1),np.float32);samples=800
    else:
        samples=750;source=variants[condition][tr,:,:samples]
        norm_mean=source.mean(axis=(0,2),keepdims=True);norm_std=source.std(axis=(0,2),keepdims=True).clip(1e-12)
    v4.seed_all(42+subject*5+fold);model=build(job).cuda();initial=weights_hash(model)
    if job.startswith('fast'):assert initial==json.loads((OLD/f'{subject}-fold{fold}.json').read_text())['initial_state_sha256'],'FAST initial weights differ'
    else:
        pair=ROOT/'results'/('eegnet_demean' if job=='eegnet_raw' else 'eegnet_raw')/f'{subject}-fold{fold}.json'
        if pair.exists():assert initial==json.loads(pair.read_text())['initial_state_sha256'],'EEGNet paired initial weights differ'
    transformed=((variants[condition][:,:,:samples]-norm_mean)/norm_std).astype(np.float32)
    xt=torch.from_numpy(transformed[tr]).cuda();yt=torch.from_numpy(y[tr]).cuda()
    opt=torch.optim.AdamW(model.parameters(),lr=.0005,weight_decay=.01);schedule=v4.cosine_scheduler(1,.1,200,1,warmup_epochs=10)
    trace=[];begin=time.time();torch.cuda.reset_peak_memory_stats()
    for epoch in range(200):
        model.train();opt.zero_grad(set_to_none=True)
        for group in opt.param_groups:group['lr']=.0005*float(schedule[epoch-1])
        with torch.autocast('cuda',dtype=torch.bfloat16):
            logits=model(xt);loss=F.cross_entropy(logits,yt)
        if not torch.isfinite(loss):raise RuntimeError('Nonfinite training loss')
        loss.backward()
        if not all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters()):raise RuntimeError('Nonfinite gradients')
        opt.step()
        if job.startswith('eegnet'):model.constrain()
        if epoch==0 or (epoch+1)%25==0:
            trace.append(dict(epoch=epoch+1,loss=float(loss.detach()),lr=float(opt.param_groups[0]['lr'])))
            update(state='training',job=job,subject=subject,fold=fold,epoch=epoch+1,fits_done=done,fits_total=225)
    model.eval();torch.set_float32_matmul_precision('highest');torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    evals={};probabilities={};trainprob=prediction(model,transformed[tr])
    for target,values in variants.items():
        xx=((values[te,:,:samples]-norm_mean)/norm_std).astype(np.float32);p=prediction(model,xx)
        probabilities[target]=p;evals[target]=metrics(y[te],p.argmax(1))
    seconds=time.time()-begin
    info=dict(subject=subject,fold=fold,job=job,training_condition=condition,epochs=200,seed=42+subject*5+fold,
              initial_state_sha256=initial,evaluation=evals,train_evaluation=metrics(y[tr],trainprob.argmax(1)),trace=trace,seconds=seconds,
              peak_cuda_allocated_bytes=torch.cuda.max_memory_allocated(),evaluation_precision='fp32_tf32_disabled',n_train=len(tr),n_test=len(te))
    torch.save(dict(state_dict=model.cpu().state_dict(),config=v4.config().to_dict() if job.startswith('fast') else dict(style='EEGNet8,2',channels=64,samples=750,classes=5,kernel=128,dropout=.5),
                    norm_mean=norm_mean,norm_std=norm_std,train_idx=tr,test_idx=te,job=job),dest.with_suffix('.pt'))
    atomic(dest.with_suffix('.json'),info)
    tmp=dest.with_suffix('.npz.tmp')
    with tmp.open('wb') as f:np.savez_compressed(f,y=y[te],train_idx=tr,test_idx=te,**{k+'_prob':v for k,v in probabilities.items()})
    tmp.replace(dest.with_suffix('.npz'))
    print('FOLD_DONE',job,subject,fold,round(seconds,2),'matched_test',evals[condition]['balanced_accuracy'],flush=True)
    del model,opt,xt,yt,transformed,variants;torch.cuda.empty_cache();return info

def summary():
    groups=[]
    for job in JOBS:
        for target in ['raw','demean','mean_only']:
            persons=[]
            for s in range(15):
                files=[ROOT/'results'/job/f'{s}-fold{f}.npz' for f in range(5)]
                if not all(p.exists() for p in files):continue
                yy=[];pp=[]
                for p in files:
                    with np.load(p) as z:yy.extend(z['y']);pp.extend(z[target+'_prob'].argmax(1))
                persons.append(dict(subject=s,**metrics(np.array(yy),np.array(pp))))
            if persons:groups.append(dict(job=job,test_input=target,n_subjects=len(persons),subjects=persons,mean_balanced_accuracy=float(np.mean([p['balanced_accuracy'] for p in persons]))))
    count=len(list((ROOT/'results').glob('*/*.npz')))
    atomic(ROOT/'gpu_summary.json',dict(complete=count==225,fits_done=count,fits_total=225,groups=groups,note='Exploratory single-seed development data; no test selection; no original FAST retraining'))

def main():
    ROOT.mkdir(exist_ok=True,parents=True);lock=(ROOT/'gpu.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');args=ap.parse_args()
    if args.smoke:smoke();return
    protocol=json.loads((ROOT/'protocol.json').read_text());assert sha(Path(__file__))==protocol['train_script_sha256']
    smoke();durations={j:[] for j in JOBS};done=0
    for subject in range(15):
        with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5') as h:x=h[f'{subject+1:02d}/X'][:];y=h[f'{subject+1:02d}/Y'][:].astype(int)
        for fold in range(5):
            for job in JOBS:
                row=train_fold(subject,fold,job,x,y,done,durations);durations[job].append(row['seconds']);done+=1
                measured={j:float(np.mean(v)) for j,v in durations.items() if v}
                eta=sum((75-len(durations[j]))*measured[j] for j in JOBS) if len(measured)==3 else None
                update(state='running',job=job,subject=subject,fold=fold,epoch=200,fits_done=done,fits_total=225,seconds_per_fit=measured,estimated_remaining_seconds=eta)
        summary()
    summary();update(state='complete',fits_done=225,fits_total=225,estimated_remaining_seconds=0)

if __name__=='__main__':
    try:main()
    except Exception as e:update(state='failed',error=str(e),traceback=traceback.format_exc());raise
