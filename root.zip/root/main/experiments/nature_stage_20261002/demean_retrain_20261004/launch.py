"""Freeze source/data/split provenance and launch two finite background jobs."""
from pathlib import Path
import datetime,hashlib,json,subprocess,os
ROOT=Path('/root/FAST/experiments/nature_stage_20261002/demean_retrain_20261004')
OLD=Path('/root/FAST/experiments/mechanism_20260927/results/full_ce_seed42')
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
    return h.hexdigest()
def main():
    assert json.loads((ROOT/'smoke.json').read_text())['passed']
    assert not (ROOT/'launch.json').exists(),'Already launched; inspect existing processes rather than duplicate'
    sources=['/root/FAST/FAST.py','/root/FAST/experiments/residual_20260925/run_metric_v4.py','/root/FAST/experiments/nature_stage_20261002/inner_models.py']
    split_hashes={p.name:sha(p) for p in sorted(OLD.glob('*-fold*.npz'))}
    assert len(split_hashes)==75
    protocol=dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),design='Exploratory same-development-fold input adaptation; results previously inspected',
      train_script_sha256=sha(ROOT/'train_controls.py'),probe_script_sha256=sha(ROOT/'light_probes.py'),protocol_markdown_sha256=sha(ROOT/'protocol.md'),
      sources={p:sha(p) for p in sources},data_sha256=sha('/root/FAST/Processed/BCIC2020Track3.h5'),old_prediction_files_sha256=split_hashes,
      gpu_fits_total=225,cpu_fits_total=150,subjects=15,folds=5,seed=42,epochs=200,no_original_fast_retraining=True,
      primary='FAST demean trained, demean tested vs existing raw trained, demean tested',evaluation='FP32 TF32 disabled; fixed final epoch; report all subjects and all matrix cells')
    (ROOT/'protocol.json').write_text(json.dumps(protocol,indent=2))
    jobs={}
    for name,script in [('gpu','train_controls.py'),('cpu','light_probes.py')]:
        with (ROOT/f'{name}.log').open('ab',buffering=0) as log:
            p=subprocess.Popen(['/root/venv_fast/bin/python','-u',str(ROOT/script)],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,cwd=str(ROOT))
        jobs[name]=dict(pid=p.pid,script=script,log=str(ROOT/f'{name}.log'))
    record=dict(launched_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),jobs=jobs,protocol_sha256=sha(ROOT/'protocol.json'))
    (ROOT/'launch.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
if __name__=='__main__':main()
