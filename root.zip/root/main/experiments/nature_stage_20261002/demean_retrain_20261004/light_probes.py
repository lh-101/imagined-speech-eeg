"""Fixed CPU probes using existing development folds; no parameter search."""
import os
os.environ['OMP_NUM_THREADS']='2';os.environ['OPENBLAS_NUM_THREADS']='2'
from pathlib import Path
import hashlib,json,time,warnings,traceback
import h5py,numpy as np
from scipy.signal import welch
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score,f1_score,confusion_matrix
ROOT=Path('/root/FAST/experiments/nature_stage_20261002/demean_retrain_20261004')
OLD=Path('/root/FAST/experiments/mechanism_20260927/results/full_ce_seed42')
START=time.time()
def save(p,d):
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(d,indent=2));tmp.replace(p)
def main():
    protocol=json.loads((ROOT/'protocol.json').read_text())
    assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==protocol['probe_script_sha256']
    rows=[];done=0
    for s in range(15):
        with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5') as h:
            x=h[f'{s+1:02d}/X'][:,:,:750];y=h[f'{s+1:02d}/Y'][:].astype(int)
        means=x.mean(-1);d=x-means[:,:,None]
        freq,power=welch(d,fs=256,nperseg=256,noverlap=128,axis=-1)
        bands=[(1,4),(4,8),(8,13),(13,30),(30,80),(80,128)]
        feats=np.stack([np.log(np.maximum(power[:,:,(freq>=a)&((freq<b) if b<128 else (freq<=b))].mean(-1),1e-30)) for a,b in bands],axis=-1).reshape(len(x),-1)
        for name,values in [('mean_logreg',means),('spectrum_logreg',feats)]:
            yy=[];pred=[];indices=[];train_scores=[];messages=[]
            for f in range(5):
                with np.load(OLD/f'{s}-fold{f}.npz') as z:
                    tr=z['train_idx'];te=z['test_idx'];assert np.array_equal(z['y'],y[te]) and not set(tr)&set(te)
                model=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=2000,random_state=42))
                with warnings.catch_warnings(record=True) as ws:
                    warnings.simplefilter('always');model.fit(values[tr],y[tr])
                messages.extend([str(w.message) for w in ws]);p=model.predict(values[te]);probs=model.predict_proba(values[te])
                folder=ROOT/'probes'/name;folder.mkdir(parents=True,exist_ok=True)
                np.savez_compressed(folder/f'{s}-fold{f}.npz',y=y[te],pred=p,prob=probs,train_idx=tr,test_idx=te)
                train_scores.append(float(balanced_accuracy_score(y[tr],model.predict(values[tr]))))
                yy.extend(y[te]);pred.extend(p);indices.extend(te);done+=1
                save(ROOT/'cpu_status.json',dict(state='running',pid=os.getpid(),fits_done=done,fits_total=150,subject=s,probe=name,fold=f,elapsed_seconds=time.time()-START))
            assert sorted(indices)==list(range(350))
            rows.append(dict(probe=name,subject=s,balanced_accuracy=float(balanced_accuracy_score(yy,pred)),macro_f1=float(f1_score(yy,pred,average='macro')),confusion=confusion_matrix(yy,pred,labels=range(5)).tolist(),train_balanced_accuracy=float(np.mean(train_scores)),warnings=messages))
            save(ROOT/'cpu_summary.json',dict(complete=False,rows=rows,fits_done=done,fits_total=150))
    groups=[]
    for name in ['mean_logreg','spectrum_logreg']:
        a=np.array([r['balanced_accuracy'] for r in rows if r['probe']==name]);rng=np.random.default_rng(20261004)
        ci=np.quantile(a[rng.integers(0,len(a),(10000,len(a)))].mean(1),[.025,.975])
        groups.append(dict(probe=name,n_subjects=15,mean_balanced_accuracy=float(a.mean()),descriptive_subject_bootstrap_ci=ci.tolist()))
    save(ROOT/'cpu_summary.json',dict(complete=True,rows=rows,groups=groups,fits_done=150,fits_total=150,elapsed_seconds=time.time()-START))
    save(ROOT/'cpu_status.json',dict(state='complete',pid=os.getpid(),fits_done=150,fits_total=150,elapsed_seconds=time.time()-START))
    print('CPU_COMPLETE',json.dumps(groups),flush=True)
if __name__=='__main__':
    try:main()
    except Exception as e:
        save(ROOT/'cpu_status.json',dict(state='failed',error=str(e),traceback=traceback.format_exc()));raise
