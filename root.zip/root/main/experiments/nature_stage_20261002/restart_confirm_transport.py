"""Transport-only restart before any new training. Preserve completed chunks."""
from pathlib import Path
import json,os,signal,time,subprocess
r=Path('/root/FAST/experiments/nature_stage_20261002');out=r/'multicue_confirm_20261003'
s=json.loads((out/'status.json').read_text());pid=s['pid']
assert s['state']=='waiting_for_download' and not s.get('completed_subjects'),'Do not interrupt an active training job'
assert not list(out.glob('sub-*/multicue_fast_20261003/results/*.npz')),'Training has already begun'
cmd=Path(f'/proc/{pid}/cmdline').read_bytes();assert b'confirm_queue.py' in cmd
try:
 probe=Path('/proc/14736/cmdline')
 if probe.exists() and b'confirm_transport_probe.py' in probe.read_bytes():os.kill(14736,signal.SIGTERM)
except ProcessLookupError:pass
os.killpg(os.getpgid(pid),signal.SIGTERM)
for _ in range(20):
 if not Path(f'/proc/{pid}').exists():break
 time.sleep(.1)
audit=dict(time=time.time(),old_pid=pid,change='128 persistent-session workers, grouped 4MiB requests; retain 1MiB chunk cache and all published checksum checks. Scientific protocol unchanged.',reason='64-worker sustained average about1.5MB/s; bounded probe showed other official region endpoints slower. Increase concurrency and measure instead of claiming a guaranteed2MB/s.',previous_status=s)
(out/f'transport_restart_{int(time.time())}.json').write_text(json.dumps(audit,indent=2))
(out/'transport_restart.json').write_text(json.dumps(audit,indent=2))
subprocess.run([str(r/'data_env/bin/python'),str(r/'launch_confirm.py')],check=True)
