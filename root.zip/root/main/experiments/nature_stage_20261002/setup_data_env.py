from pathlib import Path
import subprocess,sys,sysconfig,json
r=Path('/root/FAST/experiments/nature_stage_20261002');env=r/'data_env'
subprocess.run([sys.executable,'-m','venv',str(env)],check=True)
py=env/'bin/python'
site=Path(subprocess.check_output([str(py),'-c','import sysconfig; print(sysconfig.get_paths()["purelib"])'],text=True).strip())
(site/'existing_fast_runtime.pth').write_text('import sys; sys.path[:0] = '+repr([p for p in sys.path if p.endswith('site-packages')])+'\n')
subprocess.run([str(py),'-m','pip','install','mne==1.8.0','pooch==1.8.2','lazy-loader==0.4'],check=True)
subprocess.run([str(py),'-c','import mne,numpy,torch; print("DATA_ENV_OK",mne.__version__,numpy.__version__,torch.__version__)'],check=True)
