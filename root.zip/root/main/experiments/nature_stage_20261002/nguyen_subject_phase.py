"""LOSO cross-segment capability test; no held-subject fitting or calibration."""
from pathlib import Path
import os,json,time,fcntl
import numpy as np
from scipy.io import loadmat
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression,Ridge
import run_nguyen_external as old
from nguyen_spectral_study import power,metrics
R=old.ROOT;OUT=R/'nguyen_subject_phase_20261003';atomic=old.atomic
SEGMENTS=['segment0_2','segment3_5','posttrial_rest'];VIEWS=['eeg_absolute','eeg_relative','eog_relative','eeg_eog_residual'];N_PERM=50
def relative(x,n):
    z=x.reshape(len(x),3,n);return (z-z.mean(2,keepdims=True)).reshape(len(x),-1)
def load_features():
    data={}
    for s in range(1,7):
        p=OUT/f'features_sub{s:02d}.npz'
        if p.exists():
            with np.load(p) as f:data[s]={k:f[k] for k in f.files}
            continue
        with np.load(R/'nguyen_phase_20261003'/f'features_sub{s:02d}.npz') as f:
            d=dict(segment0_2=f['early'],segment3_5=f['late'],posttrial_rest=f['rest'],y=f['y'])
        raw=loadmat(old.DATA/'extracted'/f'sub-{s:02d}.mat');a=raw['eeg_data_wrt_task_rep_no_eog_256Hz_last_beep'];b=raw['eeg_data_wrt_task_rep_no_eog_256Hz_end_trial']
        assert a.shape==b.shape==(3,100)
        for name,variable,start in [('segment0_2',a,0),('segment3_5',a,768),('posttrial_rest',b,0)]:
            x=np.asarray([variable[c,j][[0,9,32,63],start:start+512] for c in range(3) for j in range(100)],dtype=np.float32)
            assert x.shape==(300,4,512);d['eog_'+name]=power(x)
        assert np.array_equal(d['y'],np.repeat(np.arange(3),100))
        np.savez_compressed(p,**d);data[s]=d;print('SUBJECT_PHASE_FEATURES',s,flush=True)
    return data
def inputs(data,held,source,target,view):
    ids=[s for s in range(1,7) if s!=held]
    x=np.concatenate([data[s][source] for s in ids]);z=data[held][target]
    eg=np.concatenate([data[s]['eog_'+source] for s in ids]);ez=data[held]['eog_'+target]
    if view=='eeg_relative':x=relative(x,60);z=relative(z,60)
    elif view=='eog_relative':x=relative(eg,4);z=relative(ez,4)
    elif view=='eeg_eog_residual':
        x=relative(x,60);z=relative(z,60);eg=relative(eg,4);ez=relative(ez,4)
        se=StandardScaler().fit(eg);sx=StandardScaler().fit(x);eg=se.transform(eg);ez=se.transform(ez);x=sx.transform(x);z=sx.transform(z)
        model=Ridge(alpha=10).fit(eg,x);x=x-model.predict(eg);z=z-model.predict(ez)
    else:assert view=='eeg_absolute'
    scaler=StandardScaler().fit(x);x=scaler.transform(x);z=scaler.transform(z)
    assert x.shape[0]==1500 and z.shape[0]==300 and np.isfinite(x).all() and np.isfinite(z).all()
    return x,z,ids
def fit(x,y):
    m=LogisticRegression(C=1,max_iter=2000);m.fit(x,y);return m
def summary():
    rows=[json.loads(p.read_text()) for p in (OUT/'fits').glob('*/*.json')];groups=[]
    for view in VIEWS:
        for source in SEGMENTS:
            for target in SEGMENTS:
                a=[r for r in rows if r['view']==view and r['source']==source and r['target']==target]
                groups.append(dict(view=view,source=source,target=target,n_subjects=len(a),subjects=[dict(subject=r['held_subject'],**r['evaluation']) for r in a],
                  accuracy=float(np.mean([r['evaluation']['accuracy'] for r in a])) if len(a)==6 else None,macro_f1=float(np.mean([r['evaluation']['macro_f1'] for r in a])) if len(a)==6 else None))
    atomic(OUT/'summary.json',dict(groups=groups,complete=len(rows)==216,primary='eeg_relative posttrial_rest->segment0_2; other matrix entries exploratory controls'))
def null_summary():
    files=sorted((OUT/'null').glob('sub*.npz'))
    if len(files)!=6:return
    arrays=[]
    for p in files:
        with np.load(p) as f:assert np.array_equal(f['views'],np.asarray(VIEWS));arrays.append(f['accuracy'])
    null=np.mean(arrays,axis=0);groups=json.loads((OUT/'summary.json').read_text())['groups'];rows=[]
    for i,view in enumerate(VIEWS):
        g=next(g for g in groups if g['view']==view and g['source']=='posttrial_rest' and g['target']=='segment0_2');obs=g['accuracy']
        vals=np.array([r['accuracy'] for r in g['subjects']]);rng=np.random.RandomState(88000+i);boot=vals[rng.randint(0,6,(5000,6))].mean(1)
        rows.append(dict(view=view,accuracy=obs,macro_f1=g['macro_f1'],conditional_subject_bootstrap_interval=np.quantile(boot,[.025,.975]).tolist(),null_mean=float(null[:,i].mean()),null_range=np.quantile(null[:,i],[.025,.975]).tolist(),
          exploratory_tail_fraction=(1+int((null[:,i]>=obs).sum()))/(N_PERM+1),max_over_views_tail_fraction=(1+int((null.max(1)>=obs).sum()))/(N_PERM+1)))
    atomic(OUT/'primary_endpoint.json',dict(rows=rows,n_permutations=N_PERM,
      limitations='Only six already-observed subjects. Bootstrap conditions on fitted overlapping LOSO training sets and omits model/data acquisition uncertainty. Labels exchangeable within frozen fold groups only as an unverified assumption. Not proof of language specificity or causal mechanism.'))
def main():
    OUT.mkdir(exist_ok=True)
    with (OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        protocol=dict(capability_hypothesis='A fixed spectral readout trained solely on post-trial rest from five people predicts commands from the first two seconds of last_beep signal in an unseen sixth person, without any target labels or target aggregate calibration.',
          primary='EEG within-trial band-wise spatially centered logpower; posttrial_rest source -> segment0_2 target; held-subject accuracy averaged over six LOSO folds.',
          subjects=6,segments=SEGMENTS,views=VIEWS,n_real_fits=216,n_permutations=N_PERM,n_null_fits=1200,
          classifier='LogisticRegression C1 max_iter2000. All scaler and EOG regression fits use five source subjects in source segment only; no target-feature statistics.',
          relative='For each individual trial/band subtract that trial mean logpower across channels, EEG60/EOG4. Does not fit anything on target subjects.',
          eog_adjustment='Train-only Ridge alpha10 EOG->relative EEG, subtract predicted source-trained association. At evaluation only target-segment same-trial EOG used, not target resting or labels.',
          timeline_caution='Original paper describes three T=1s imagery periods after last beep, followed by rest; released readme calls full5s last_beep imagery. Without raw events, segment3_5 cannot be asserted to be late imagery. Main endpoint uses first2s; exploratory matrix uses literal segment names.',
          permutation='Shuffle labels consistently within each archived fivefold group per subject, independently per subject, same permuted vector across phases/views/held-folds. Evaluate permuted target labels. Only primary rest->first2s direction rerun for all4views.',
          sources=['https://bpb-us-w2.wpmucdn.com/sites.udel.edu/dist/b/9405/files/2019/08/JNE18_Nguyen.pdf','https://zenodo.org/records/19502794'],
          limitations=['Extension designed after prior outcomes; this is a stronger holdout protocol on the same subjects, not a new independent cohort','Visual cues may remain; memory, cue and time effects remain alternatives','Phase transfer cannot alone establish a speech-specific neural mechanism','No raw event/run IDs; no invented temporal ordering','EOG exclusion/regression cannot eliminate all physiological artifacts','No online performance or Nature acceptance claim'],
          source_sha256=old.digest(Path(__file__)))
        path=OUT/'protocol.json'
        if path.exists():assert json.loads(path.read_text())==protocol
        else:atomic(path,protocol)
        started=time.time()
        try:
            atomic(OUT/'status.json',dict(state='running',phase='features',pid=os.getpid(),started=started,updated=time.time()))
            data=load_features()
            # Sanity: deterministic relative transform removes channel-uniform
            # offsets exactly to floating tolerance and uses no labels.
            test=np.random.RandomState(42).normal(size=(12,180));assert np.allclose(relative(test+3,60),relative(test,60))
            atomic(OUT/'smoke.json',dict(passed=True,relative_uniform_offset_invariant=True,source_subjects=5,target_subjects=1))
            primary_inputs={}
            for held in range(1,7):
                for view in VIEWS:
                    for source in SEGMENTS:
                        for target in SEGMENTS:
                            job=f'{view}__{source}__{target}';dest=OUT/'fits'/job;dest.mkdir(parents=True,exist_ok=True);name=f'sub{held:02d}'
                            x,z,ids=inputs(data,held,source,target,view);y=np.concatenate([data[s]['y'] for s in ids]);assert held not in ids
                            if source=='posttrial_rest' and target=='segment0_2':primary_inputs[(held,view)]=(x,z,ids)
                            if (dest/(name+'.json')).exists():continue
                            atomic(OUT/'status.json',dict(state='running',phase='real_tests',held_subject=held,job=job,pid=os.getpid(),started=started,updated=time.time()))
                            tick=time.time();m=fit(x,y);p=m.predict_proba(z)
                            np.savez_compressed(dest/(name+'.npz'),prob=p,y=data[held]['y'],train_subjects=ids,held_subject=held)
                            atomic(dest/(name+'.json'),dict(view=view,source=source,target=target,held_subject=held,train_subjects=ids,evaluation=metrics(data[held]['y'],p),seconds=time.time()-tick))
                summary();print('LOSO_PHASE_SUBJECT_DONE',held,flush=True)
            dest=OUT/'null';dest.mkdir(exist_ok=True)
            # Shared global repeat defines consistent subject-level labels for
            # all held-person fits, rather than incompatible per-fold shuffles.
            for held in range(1,7):
                file=dest/f'sub{held:02d}.npz'
                if file.exists():continue
                scores=[]
                for rep in range(N_PERM):
                    atomic(OUT/'status.json',dict(state='running',phase='permutation',held_subject=held,permutation=rep+1,pid=os.getpid(),started=started,updated=time.time()))
                    permuted={}
                    for s in range(1,7):
                        yy=data[s]['y'].copy();rng=np.random.RandomState(92000+rep*100+s)
                        splits=json.loads((old.OUT/f'splits_sub{s:02d}.json').read_text())['folds']
                        for split in splits:
                            ix=np.asarray(split['test']);yy[ix]=yy[ix][rng.permutation(len(ix))]
                        permuted[s]=yy
                    row=[]
                    for view in VIEWS:
                        x,z,ids=primary_inputs[(held,view)];y=np.concatenate([permuted[s] for s in ids]);m=fit(x,y)
                        row.append(float((m.predict(z)==permuted[held]).mean()))
                    scores.append(row)
                np.savez_compressed(file,accuracy=np.asarray(scores),views=np.asarray(VIEWS));print('LOSO_PHASE_NULL_DONE',held,flush=True)
            null_summary();atomic(OUT/'status.json',dict(state='complete',updated=time.time()))
        except Exception as e:atomic(OUT/'status.json',dict(state='failed',error=repr(e),updated=time.time()));raise
if __name__=='__main__':main()
