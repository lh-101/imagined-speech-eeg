"""Bounded time-origin correction and engineering/biological control probes.
Never selects a window or checkpoint using evaluation accuracy.
"""
from pathlib import Path
import os,sys,json,time,pickle,subprocess,hashlib,argparse
import numpy as np
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'validation_20261003'
PREP=ROOT/'inner_prepared_action_corrected'
def atomic(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(o,indent=2));t.replace(p)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def prepare():
    import mne
    import preprocess_inner as old
    # Retain the audited reader, geometry and trial metadata; change only the
    # event-relative window. The source remains unchanged on disk.
    src=(ROOT/'preprocess_inner.py').read_text()
    src=src.replace("DEST=ROOT/'inner_prepared'","DEST=ROOT/'inner_prepared_action_corrected'")
    src=src.replace('tmin=1.,tmax=3.5','tmin=.5,tmax=3.')
    src=src.replace('action_interval_s=[1.,3.5]','action_interval_s=[.5,3.]')
    src=src.replace('crop action [1,3.5)s','crop event-relative action [.5,3)s')
    src=src.replace('session-wise unsupervised ICA','inherited session-level processing; ICA application in this derivative version not independently established')
    atomic(OUT/'protocol.json',dict(window_event_relative=[.5,3.],legacy_window=[1.,3.5],
      trial_relative_action=[1.,3.5],event_anchor='Direction cue at trial 0.5 seconds; epoch event IDs 31..34',
      sources=['https://www.nature.com/articles/s41597-022-01147-2',
      'https://github.com/N-Nieto/Inner_Speech_Dataset/blob/main/Python_Processing/InnerSpeech_preprocessing.py',
      'https://github.com/N-Nieto/Inner_Speech_Dataset/blob/main/Python_Processing/lib/data_processing.py'],
      explanation='Author numpy time selection indexes from start of epoch (-0.5 event-relative); MNE crop indexes event-relative times. Old MNE [1,3.5) retained 0.5 seconds of relaxation.',
      seed=42,new_gpu_fits=60,synthetic_gpu_checks=2,epochs=200,
      evaluation='Same subjects, trial identities, source/held session splits and initialization as legacy replay. No test-based window/model selection.',
      cpu='Fixed log bandpower EEG and log-standard-deviation EXG probes, within and cross-session direction prediction for all three tasks; three-class task control; five train-label shuffles for inner within-session only.',
      limitations=['Post hoc diagnostic, not independent confirmatory experiment','Task condition is confounded with acquisition run/time','Direction cue could confound direction decoding','Synthetic positive controls verify engineering only','Five shuffles are a coarse diagnostic, not a significance test','Same-day sessions; inherited author preprocessing is not prospective causal validation'],
      source_hashes={p:sha(ROOT/p) for p in ['validation_stage.py','preprocess_inner.py','run_inner_study.py','inner_models.py','diagnostic_common.py']}))
    atomic(OUT/'corrected_preprocess_source.json',dict(source=src,sha256=hashlib.sha256(src.encode()).hexdigest()))
    if not (PREP/'prepare_status.json').exists() or json.loads((PREP/'prepare_status.json').read_text())['state']!='complete':
        env={'__name__':'corrected_preprocessing','__file__':str(ROOT/'validation_stage.py')}
        exec(compile(src,'corrected_preprocessing','exec'),env);env['main']()
    audit=[]
    for s in range(1,11):
        with np.load(ROOT/'inner_prepared'/f'sub-{s:02d}.npz') as f:a={k:f[k] for k in f.files}
        with np.load(PREP/f'sub-{s:02d}.npz') as f:b={k:f[k] for k in f.files}
        for k in ['y','session','original_trial','original_sample','emg_flagged']:assert np.array_equal(a[k],b[k]),k
        assert np.array_equal(a['X'][:,:,:512],b['X'][:,:,128:]),'Windows must overlap by exactly 512 samples'
        audit.append(dict(subject=s,n=len(a['y']),identities_match=True,overlap_exact=True))
    atomic(OUT/'alignment_audit.json',dict(passed=True,subjects=audit))
def cpu():
    import mne
    from diagnostic_common import bandpower
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import accuracy_score,balanced_accuracy_score
    def fit(x,y,tr,ev,shuffle=None):
        yy=y[tr].copy()
        if shuffle is not None:np.random.RandomState(shuffle).shuffle(yy)
        model=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=2000))
        model.fit(x[tr],yy);pred=model.predict(x[ev])
        return dict(accuracy=float(accuracy_score(y[ev],pred)),balanced_accuracy=float(balanced_accuracy_score(y[ev],pred)),n_train=len(tr),n_eval=len(ev))
    rng=np.random.RandomState(42);y=np.tile(np.arange(4),80);x=rng.normal(size=(320,20));x[np.arange(320),y]+=8
    tr=np.arange(240);ev=np.arange(240,320);positive=fit(x,y,tr,ev);assert positive['accuracy']>.95
    atomic(OUT/'synthetic_cpu.json',dict(passed=True,positive=positive,negative=fit(x,y,tr,ev,1234),note='Engineered independent noise plus known class signal; not biological evidence'))
    rows=[]
    for s in range(1,11):
        parts=[]
        for sess in range(1,4):
            folder=ROOT/'inner_data/ds003626/derivatives'/f'sub-{s:02d}'/f'ses-{sess:02d}'
            prefix=f'sub-{s:02d}_ses-{sess:02d}'
            with (folder/(prefix+'_events.dat')).open('rb') as f:events=np.asarray(pickle.load(f,encoding='latin1'),dtype=np.int64)
            eeg=mne.read_epochs(folder/(prefix+'_eeg-epo.fif'),preload=True,verbose='ERROR')
            exg=mne.read_epochs(folder/(prefix+'_exg-epo.fif'),preload=True,verbose='ERROR')
            assert np.array_equal(eeg.events[:,0],events[:,0]) and np.array_equal(eeg.events[:,2],events[:,1]+31)
            assert np.array_equal(eeg.events[:,0],exg.events[:,0]) and np.all(events[:,3]==sess)
            xx=eeg.crop(.5,3.,include_tmax=False).get_data(copy=True)*1e6
            zz=exg.crop(.5,3.,include_tmax=False).get_data(copy=True)*1e6
            assert xx.shape[1:]==(128,640) and zz.shape[1:]==(8,640) and np.isfinite(xx).all() and np.isfinite(zz).all()
            parts.append(dict(eeg=bandpower(xx),exg=np.log(np.maximum(zz[:,2:].std(-1),1e-6)),y=events[:,1],condition=events[:,2],session=events[:,3]))
        d={k:np.concatenate([p[k] for p in parts]) for k in parts[0]}
        for held in range(1,4):
            for cond in range(3):
                ix=np.flatnonzero((d['condition']==cond)&(d['session']==held));pool=[];ev=[]
                rng=np.random.RandomState(42+s*101+held*17)
                for c in range(4):
                    z=ix[d['y'][ix]==c].copy();rng.shuffle(z);n=len(z)//2;pool.extend(z[:n]);ev.extend(z[n:])
                pool=np.asarray(sorted(pool));ev=np.asarray(sorted(ev))
                source=np.flatnonzero((d['condition']==cond)&(d['session']!=held))
                if cond==1:
                    prior=json.loads((ROOT/'inner_results/fast/ce'/f'seed42_sub{s:02d}_ses{held}_base.json').read_text())['split']
                    ids=np.flatnonzero(d['condition']==1)
                    assert np.array_equal(ev,ids[prior['evaluation']]) and set(pool)==set(ids[prior['calibration_pool']])
                for feat in ['eeg','exg']:
                    for ctx,tr in [('within',pool),('cross_session',source)]:
                        rows.append(dict(subject=s,held_session=held,condition=cond,feature=feat,context=ctx,kind='direction',**fit(d[feat],d['y'],tr,ev)))
                    if cond==1:
                        for k in range(5):rows.append(dict(subject=s,held_session=held,condition=cond,feature=feat,context='within',kind='train_label_shuffle',shuffle=k,**fit(d[feat],d['y'],pool,ev,50000+s*101+held*17+k)))
            tr=np.flatnonzero(d['session']!=held);ev=np.flatnonzero(d['session']==held)
            for feat in ['eeg','exg']:rows.append(dict(subject=s,held_session=held,feature=feat,context='cross_session',kind='task_condition_nuisance_control',**fit(d[feat],d['condition'],tr,ev)))
        atomic(OUT/'cpu_results.json',dict(rows=rows,completed_subjects=s,complete=s==10))
        print('CONTROL_SUBJECT_DONE',s,len(rows),flush=True)
def gpu():
    import torch
    import run_inner_study as run
    from inner_models import build,seed_all
    torch.set_num_threads(4)
    run.PREP=PREP;run.OUT=OUT/'gpu'
    geometry=json.loads((PREP/'geometry.json').read_text())
    # Positive signal must generalize to freshly generated trials; no trial overlap.
    if not (OUT/'synthetic_gpu.json').exists():
        rng=np.random.RandomState(42);y=np.tile(np.arange(4),32)
        x=rng.normal(0,.3,(len(y),128,640)).astype(np.float32)
        t=np.arange(640)/256
        for c in range(4):x[y==c,c*32:(c+1)*32]+=np.sin(2*np.pi*(6+c*5)*t)[None,None,:].astype(np.float32)*3
        tr=np.arange(96);ev=np.arange(96,128);norm=run.normalization(x[tr]);x=(x-norm[0])/norm[1]
        checks=[]
        for arch in ['fast','eegnet']:
            seed_all(42);m=build(arch,geometry);m,timing=run.train(m,x[tr],y[tr],'ce',100,.0005)
            acc=float((run.predict(m,x[ev]).argmax(1)==y[ev]).mean());assert acc>=.9,(arch,acc)
            checks.append(dict(architecture=arch,accuracy=acc,seconds=timing['seconds']));del m;torch.cuda.empty_cache()
        atomic(OUT/'synthetic_gpu.json',dict(passed=True,checks=checks))
    started=time.time()
    for s in range(1,11):
        for held in range(1,4):
            for method in ['ce','loo']:
                atomic(OUT/'status.json',dict(state='running',phase='gpu',pid=os.getpid(),subject=s,held_session=held,method=method,started=started,updated=time.time()))
                run.base('fast',method,42,s,held,geometry)
                records=[json.loads(p.read_text()) for p in run.OUT.glob('fast/*/*_base.json')]
                groups=[]
                for meth in ['ce','loo']:
                    a=[r for r in records if r['method']==meth];subjects=[]
                    for subj in range(1,11):
                        q=[r for r in a if r['subject']==subj]
                        if len(q)==3:subjects.append(dict(subject=subj,accuracy=float(np.mean([r['evaluation']['accuracy'] for r in q])),common_accuracy=float(np.mean([r['common_evaluation']['accuracy'] for r in q]))))
                    groups.append(dict(method=meth,n_fits=len(a),subjects=subjects,mean_accuracy=float(np.mean([r['accuracy'] for r in subjects])) if subjects else None))
                atomic(OUT/'gpu_summary.json',dict(groups=groups,complete=len(records)==60))
def main():
    OUT.mkdir(exist_ok=True)
    import fcntl
    with (OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            atomic(OUT/'status.json',dict(state='running',phase='preparing',pid=os.getpid(),started=time.time()))
            prepare()
            atomic(OUT/'status.json',dict(state='running',phase='cpu_controls',pid=os.getpid(),started=time.time()))
            cpu();gpu()
            atomic(OUT/'status.json',dict(state='complete',updated=time.time()))
        except Exception as e:
            atomic(OUT/'status.json',dict(state='failed',error=repr(e),updated=time.time()));raise
if __name__=='__main__':main()
