from pathlib import Path
import argparse,fcntl,json,time
import numpy as np,torch
import run_inner_study as r
from diagnostic_common import ROOT,OUT,CONTEXTS,ARCHITECTURES,atomic,load_subject,fixed_split,summarize,sha

def eval_old(subject,session,data,geometry):
    y=data['y'];name=f'seed42_sub{subject:02d}_ses{session}'
    for method in ['ce','loo']:
        dest=OUT/'existing';dest.mkdir(parents=True,exist_ok=True)
        marker=dest/f'{name}_{method}.json'
        reused=OUT/'gpu'/f'sub{subject:02d}_ses{session}_fast_full_source.json'
        if marker.exists() and (method!='ce' or reused.exists()):continue
        original=ROOT/'inner_results/fast'/method
        checkpoint=torch.load(original/(name+'_base.pt'),map_location='cpu')
        split=checkpoint['split'];source=np.asarray(split['source']);held=np.asarray(split['held']);ev=np.asarray(split['evaluation'])
        norm=checkpoint['normalization'];x=((data['X']-norm[0])/norm[1]).astype(np.float32)
        r.seed_all(42+subject*101+session*17);model=r.build('fast',geometry).cuda();model.load_state_dict(checkpoint['state_dict'])
        ptrain=r.predict(model,x[source]);ptest=r.predict(model,x[held])
        with np.load(original/(name+'_base.npz')) as stored:
            assert np.array_equal(stored['indices'],held) and np.array_equal(stored['y'],y[held])
            diff=float(np.max(np.abs(ptest-stored['prob'])))
            assert np.allclose(ptest,stored['prob'],atol=1e-5,rtol=1e-4),f'Checkpoint predictions mismatch: {diff}'
        lookup={int(index):i for i,index in enumerate(held)};common=ptest[[lookup[int(index)] for index in ev]]
        row=dict(subject=subject,session=session,method=method,checkpoint=str(original/(name+'_base.pt')),max_cached_probability_difference=diff,
            train_n=len(source),evaluation_n=len(held),training=r.metrics(y[source],ptrain,data['emg_flagged'][source]),
            full_held_evaluation=r.metrics(y[held],ptest,data['emg_flagged'][held]),evaluation=r.metrics(y[ev],common,data['emg_flagged'][ev]))
        atomic(marker,row)
        if method=='ce':
            info=json.loads((original/(name+'_base.json')).read_text())
            row.update(architecture='fast',context='full_source',seed=42,train_idx=source.tolist(),evaluation_idx=ev.tolist(),
                training_reused=True,seconds=0,original_training_seconds=info['seconds'],initial_state_sha256=info['initial_state_sha256'])
            atomic(OUT/'gpu'/f'sub{subject:02d}_ses{session}_fast_full_source.json',row)
        del model;torch.cuda.empty_cache()

def fit(subject,session,architecture,context,data,geometry,tr,ev):
    dest=OUT/'gpu';path=dest/f'sub{subject:02d}_ses{session}_{architecture}_{context}.json'
    weights=path.with_suffix('.pt');pred=path.with_suffix('.npz')
    if path.exists():
        row=json.loads(path.read_text());assert row['train_idx']==tr.tolist() and row['evaluation_idx']==ev.tolist()
        assert weights.exists() and pred.exists();return
    y=data['y'];norm=r.normalization(data['X'][tr]);x=((data['X']-norm[0])/norm[1]).astype(np.float32)
    r.seed_all(42+subject*101+session*17);model=r.build(architecture,geometry);initial=r.state_hash(model)
    for other in CONTEXTS:
        previous=dest/f'sub{subject:02d}_ses{session}_{architecture}_{other}.json'
        if previous.exists():assert json.loads(previous.read_text())['initial_state_sha256']==initial
    model,timing=r.train(model,x[tr],y[tr],'ce',r.CFG['epochs'],r.CFG['lr'])
    testprob=r.predict(model,x[ev]);trainprob=r.predict(model,x[tr])
    row=dict(subject=subject,session=session,architecture=architecture,context=context,seed=42,training_reused=False,
        train_idx=tr.tolist(),evaluation_idx=ev.tolist(),train_n=len(tr),train_class_counts=np.bincount(y[tr],minlength=4).tolist(),
        initial_state_sha256=initial,training=r.metrics(y[tr],trainprob,data['emg_flagged'][tr]),
        evaluation=r.metrics(y[ev],testprob,data['emg_flagged'][ev]),**timing)
    tmp=weights.with_suffix('.pt.tmp');torch.save(dict(state_dict=model.cpu().state_dict(),normalization=norm,train_idx=tr,evaluation_idx=ev),tmp);tmp.replace(weights)
    tmp=pred.with_suffix('.npz.tmp')
    with tmp.open('wb') as f:np.savez(f,prob=testprob,y=y[ev],indices=ev,train_idx=tr)
    tmp.replace(pred);atomic(path,row)
    print('DIAGNOSTIC_GPU_DONE',architecture,context,subject,session,row['training']['accuracy'],row['evaluation']['accuracy'],timing['seconds'],flush=True)
    del model;torch.cuda.empty_cache()

def reports():
    rows=[json.loads(p.read_text()) for p in (OUT/'gpu').glob('sub*.json')]
    atomic(OUT/'gpu/summary.json',summarize(rows,['architecture','context']))
    existing=[json.loads(p.read_text()) for p in (OUT/'existing').glob('seed42_sub*.json')]
    if existing:atomic(OUT/'existing/summary.json',summarize(existing,['method']))
    return sum(not v.get('training_reused',False) for v in rows),len(rows)

def smoke():
    geometry=json.loads((r.PREP/'geometry.json').read_text());data=load_subject(1);train,ev=fixed_split(1,1,data)
    tr=train['within_session'];norm=r.normalization(data['X'][tr]);x=((data['X']-norm[0])/norm[1]).astype(np.float32)
    for arch in ARCHITECTURES:
        r.seed_all(42);model=r.build(arch,geometry)
        model,_=r.train(model,x[tr],data['y'][tr],'ce',2,r.CFG['lr'])
        prob=r.predict(model,x[ev]);assert prob.shape==(len(ev),4) and np.isfinite(prob).all()
        assert np.allclose(prob.sum(1),1,atol=1e-5)
        del model;torch.cuda.empty_cache()
    atomic(OUT/'gpu_smoke.json',dict(passed=True,checks=['finite real-data CE training for both encoders','held-out prediction shape/probabilities','source/target training disjoint from fixed evaluation']))
    print('DIAGNOSTIC_GPU_SMOKE_OK',flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');args=ap.parse_args();torch.set_num_threads(4)
    (OUT/'gpu').mkdir(parents=True,exist_ok=True);(OUT/'existing').mkdir(parents=True,exist_ok=True)
    if args.smoke:smoke();return
    assert json.loads((OUT/'gpu_smoke.json').read_text())['passed']
    protocol=json.loads((OUT/'protocol.json').read_text())
    for name,expected in protocol['source_hashes'].items():assert sha(ROOT/name)==expected,'Protocol source changed'
    geometry=json.loads((r.PREP/'geometry.json').read_text());started=time.time()
    with (OUT/'gpu/run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            for subject in range(1,11):
                data=load_subject(subject)
                for session in range(1,4):
                    train,ev=fixed_split(subject,session,data);eval_old(subject,session,data,geometry)
                    for arch in ARCHITECTURES:
                        for context in CONTEXTS:
                            if arch=='fast' and context=='full_source':continue
                            complete,cases=reports()
                            atomic(OUT/'gpu/status.json',dict(state='running',subject=subject,session=session,architecture=arch,context=context,
                                completed=complete,total=150,reused_cases=cases-complete,started=started,updated=time.time()))
                            fit(subject,session,arch,context,data,geometry,train[context],ev)
                    reports()
            complete,cases=reports();assert complete==150 and cases==180
            atomic(OUT/'gpu/status.json',dict(state='complete',completed=complete,total=150,reused_cases=30,started=started,updated=time.time()))
            print('DIAGNOSTIC_GPU_COMPLETE',flush=True)
        except Exception as e:
            atomic(OUT/'gpu/status.json',dict(state='failed',error=repr(e),updated=time.time()));raise

if __name__=='__main__':main()
