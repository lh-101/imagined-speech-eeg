"""Bounded official-host transfer diagnostic; no outcome or model access."""
from pathlib import Path
import json,time,requests,concurrent.futures
r=Path('/root/FAST/experiments/nature_stage_20261002/multicue_confirm_20261003')
meta=json.loads((r/'protocol.json').read_text())['cohort'][0]['files'][0]
tests=[]
for host in ['https://s3.amazonaws.com/openneuro.org/','https://s3.us-east-1.amazonaws.com/openneuro.org/']:
 url=host+'ds004306/'+meta['path'];start=time.time()
 def fetch(i):
  lo=i*4*1024**2;hi=lo+4*1024**2-1
  t=time.time()
  with requests.get(url,headers={'Range':f'bytes={lo}-{hi}'},timeout=(10,35)) as x:
   assert x.status_code==206 and x.headers['Content-Range']==f'bytes {lo}-{hi}/{meta["size"]}'
   assert len(x.content)==4*1024**2
  return dict(seconds=time.time()-t,bytes=4*1024**2)
 try:
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:rows=list(p.map(fetch,range(4)))
  elapsed=time.time()-start;tests.append(dict(url=url,workers=4,range_bytes=4*1024**2,elapsed_seconds=elapsed,bytes_per_second=sum(x['bytes'] for x in rows)/elapsed,rows=rows))
 except Exception as e:tests.append(dict(url=url,error=str(e),elapsed_seconds=time.time()-start))
(r/'transport_probe.json').write_text(json.dumps(dict(tests=tests,caveat='Concurrent with active queue; network contention and short duration preclude stable throughput estimate.'),indent=2))
print(json.dumps(tests,indent=2),flush=True)
