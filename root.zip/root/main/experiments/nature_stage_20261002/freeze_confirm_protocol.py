"""Freeze the unobserved cohort and published file hashes before downloading."""
from pathlib import Path
import hashlib,json,time,requests

ROOT=Path('/root/FAST/experiments/nature_stage_20261002')
OUT=ROOT/'multicue_confirm_20261003';OUT.mkdir(exist_ok=True)
base='https://api.github.com/repos/OpenNeuroDatasets/ds004306'
s=requests.Session()
def get(url):
 r=s.get(url,timeout=(15,45));r.raise_for_status();return r
commit=get(base+'/commits/main').json()['sha']
tree=get(base+'/git/trees/'+commit+'?recursive=1').json()
assert not tree.get('truncated')
paths=[r['path'] for r in tree['tree']]
import re
cohort=[]
for subject in ['03','08','010','012','013','014','016','017','019']:
 sessions=['03'] if subject in ['03','08'] else ['01']
 session=sessions[0];prefix=f'derivatives/preprocessed/sub-{subject}/ses-{session}/eeg/'
 files=sorted(p for p in paths if p.startswith(prefix) and p.endswith('.fif'))
 assert files,(subject,prefix)
 first=[p for p in files if not re.search(r'-\d+\.fif$',p)]
 assert len(first)==1,(subject,files)
 files=[first[0]]+[p for p in files if p!=first[0]]
 metas=[]
 for path in files:
  link=get(f'https://raw.githubusercontent.com/OpenNeuroDatasets/ds004306/{commit}/{path}').text
  m=re.search(r'SHA256E-s(\d+)--([a-f0-9]{64})',link);assert m,(path,link)
  metas.append(dict(path=path,filename=Path(path).name,size=int(m[1]),sha256=m[2],url='https://s3.amazonaws.com/openneuro.org/ds004306/'+path))
 cohort.append(dict(subject=subject,session=session,files=metas,total_bytes=sum(f['size'] for f in metas)))
protocol=dict(version=1,frozen_at_unix=time.time(),frozen_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
 study='Independent participant validation of a post-hoc cross-condition candidate',
 observation='Among already inspected sub-011,sub-015,sub-018: perception-text to imagination-image accuracy CE30.237%, additive36.383%, protected35.911%; all three participant gains positive.',
 discovery_subjects=['011','015','018'],cohort=cohort,repository_commit=commit,repository_tree_sha=tree['sha'],
 selection='All other released participants. Earliest available preprocessed session: session03 for sub03/sub08, session01 for others. No selection based on outcome, all failures/exclusions retained.',
 primary_source=dict(task='perception',modality='text',seconds=[0,2]),primary_target=dict(task='imagination',modality='image',seconds=[1,3]),
 primary_metric='Per-subject pooled out-of-fold balanced accuracy; subjects equally weighted',
 primary_contrasts=['additive minus CE','protected minus CE'],primary_seed=42,epochs=200,methods=['ce','additive','protected'],
 fits_per_subject=15,total_gpu_fits=135,source_only='Only perception-text is trained; original other-source matrices are not retrained. All six target conditions are saved as secondary boundaries, never used for selection.',
 architecture='Identical FAST and auxiliary hyperparameters to discovery; actual recorded EEG cap mapping and 512-sample input. Three 256-sample overlapping CNN windows.',
 normalization='Only perception-text training epochs used for channel mean/std. No target fitted transformation/calibration or checkpoint selection.',
 splitting='Same GroupKFold5 on consecutive groups of five paired perception/imagination trials per contiguous modality sequence. Groups and paired events never cross a fold; record-specific split persisted.',
 auxiliary='Analytic training kernel leave-one-out; gamma2 ridge.1 score4 weight.3; protected single-sided projection and norm cap.5; historical identical cosine schedule epoch-1',
 secondary_metrics=['ordinary accuracy','macroF1','class recalls','confusion','all six target-condition results','training performance','spectral logistic reference on identical split/windows'],
 statistics=dict(unit='participant, not fold/trial/seed',paired='Exact subject sign-flip test of mean balanced-accuracy difference (symmetry assumption); Holm over two contrasts; mean difference and descriptive subject-bootstrap95% CI.',
  absolute='9999 target-image label permutations independently within held paired acquisition groups, same permutations for all methods. Target labels never enter any fit, so target-only permutation leaves all source-fitted models exactly unchanged. This conditional test does not substitute for full training-label null or establish a biological mechanism.',
  absolute_family='Holm over CE/additive/protected mean balanced accuracy; report permutation coverage and mixed-label group counts.',
  exchangeability='Target labels assumed exchangeable within five-pair acquisition groups. Retains group class counts and paired target identity. Unknown temporal dependence remains. If no mixed-label groups, report unidentifiable null rather than p-value.',
  uncertainty='Bootstrap conditions on frozen training/folds/models; does not include data collection, preprocessing, or optimizer variability.'),
 spectral='Source-only StandardScaler + LogisticRegression C1 max_iter2000; 5 log-Welch bands1-4,4-8,8-13,13-30,30-45Hz; per-trial spatial centering; no tuning.',
 quality='Published SHA256 and size for every split FIF; audit complete pairs, full windows, EEG mapping, finite arrays, source training class coverage and fold isolation. Internal event errors halt that participant; dangling final perception removed with recorded reason only.',
 limitations=['Only remaining nine public participants, no guaranteed sufficient power','Same dataset/acquisition paradigm as discovery, not a new independent study','Full-recording author ICA remains transductive preprocessing','No EOG/EMG or matched interference controls, no language-specific or neural causal mechanism','Same three semantic categories, not novel words or general semantic comprehension','One seed; no cross-subject decoder, each participant trains own source model','Different available session numbers for two participants; report explicitly'],
 stopping='Run every fixed participant. No early stopping based on outcome; no replacements for failure. Technical resume allowed, log failures. Summarize completed fixed cohort only with missing participant disclosures.',
 storage='Keep historical results untouched; retain new prepared epochs/checkpoints/predictions and file hashes. Delete only verified transient chunk files; retain FIF if capacity permits. Fail safely below storage reserve.',
 registry_status='Local timestamped prespecified validation plan; not formally preregistered with a registry.',
 total_download_bytes=sum(r['total_bytes'] for r in cohort))
p=OUT/'protocol.json'
if p.exists():raise RuntimeError('Protocol already exists; do not silently replace a frozen plan')
p.write_text(json.dumps(protocol,indent=2))
(OUT/'repository_tree.json').write_text(json.dumps(tree))
print(json.dumps(dict(protocol_path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),subjects=[c['subject'] for c in cohort],total_files=sum(len(c['files']) for c in cohort),bytes=protocol['total_download_bytes'],cohort=[dict(subject=c['subject'],session=c['session'],bytes=c['total_bytes']) for c in cohort]),indent=2))
