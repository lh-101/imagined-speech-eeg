from pathlib import Path
import json,pickle
import numpy as np,mne
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'inner_data/ds003626/derivatives'
rows=[]
for s in range(1,11):
    for session in range(1,4):
        pre=f'sub-{s:02d}_ses-{session:02d}';folder=SRC/f'sub-{s:02d}'/f'ses-{session:02d}'
        eeg=mne.read_epochs(folder/(pre+'_eeg-epo.fif'),preload=False,verbose='ERROR')
        exg=mne.read_epochs(folder/(pre+'_exg-epo.fif'),preload=False,verbose='ERROR')
        with (folder/(pre+'_events.dat')).open('rb') as f:events=np.asarray(pickle.load(f,encoding='latin1'))
        with (folder/(pre+'_report.pkl')).open('rb') as f:report=pickle.load(f,encoding='latin1')
        row=dict(subject=s,session=session,n=len(eeg),sfreq=eeg.info['sfreq'],tmin=eeg.tmin,tmax=eeg.tmax,
            n_times=len(eeg.times),n_eeg=len(eeg.ch_names),n_exg=len(exg.ch_names),
            event_sample_match=bool(np.array_equal(eeg.events[:,0],events[:,0])),
            event_class_match=bool(np.array_equal(eeg.events[:,2],events[:,1]+31)),
            eeg_exg_times_match=bool(np.array_equal(eeg.times,exg.times)),baseline=eeg.baseline,
            report_keys=list(report))
        rows.append(row)
        if s==1 and session==1:
            print('FIRST_HEADER',json.dumps(row));print('FIRST_REPORT',repr(report));print('FIRST_EVENTS',eeg.events[:4].tolist(),events[:4].tolist())
assert len(rows)==30
(ROOT/'epoch_metadata_audit.json').write_text(json.dumps(rows,indent=2))
print('METADATA_SUMMARY',json.dumps(dict(n_files=len(rows),time_ranges=sorted({(r['tmin'],r['tmax'],r['n_times']) for r in rows}),
    sampling_rates=sorted({r['sfreq'] for r in rows}),all_samples_aligned=all(r['event_sample_match'] for r in rows),
    all_classes_aligned=all(r['event_class_match'] for r in rows),all_eeg_exg_times_aligned=all(r['eeg_exg_times_match'] for r in rows))))
