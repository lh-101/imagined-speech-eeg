from pathlib import Path
import fcntl,json,time,warnings
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,f1_score
from sklearn.exceptions import ConvergenceWarning
from diagnostic_common import ROOT,OUT,CONTEXTS,atomic,load_subject,fixed_split,features,summarize

def scores(y,prob):
    pred=prob.argmax(1)
    return dict(accuracy=float(accuracy_score(y,pred)),macro_f1=float(f1_score(y,pred,labels=[0,1,2,3],average='macro',zero_division=0)),n=len(y))

def main():
    dest=OUT/'cpu';dest.mkdir(parents=True,exist_ok=True)
    with (dest/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        started=time.time()
        try:
            for subject in range(1,11):
                data=load_subject(subject);y=data['y'];fs=features(data)
                for session in range(1,4):
                    train,ev=fixed_split(subject,session,data)
                    for name,f in fs.items():
                        for context in CONTEXTS:
                            path=dest/f'sub{subject:02d}_ses{session}_{context}_{name}.json'
                            if path.exists():continue
                            tr=train[context];start=time.time()
                            clf=make_pipeline(StandardScaler(),LogisticRegression(C=1.,max_iter=2000,solver='lbfgs',random_state=42))
                            with warnings.catch_warnings(record=True) as caught:
                                warnings.simplefilter('always',ConvergenceWarning);clf.fit(f[tr],y[tr])
                            assert np.array_equal(clf.classes_,np.arange(4))
                            testprob=clf.predict_proba(f[ev]);trainprob=clf.predict_proba(f[tr])
                            weights=path.with_suffix('.npz');tmp=weights.with_suffix('.npz.tmp')
                            with tmp.open('wb') as handle:
                                np.savez(handle,prob=testprob,y=y[ev],indices=ev,train_idx=tr,
                                    coef=clf[-1].coef_,intercept=clf[-1].intercept_,scaler_mean=clf[0].mean_,scaler_scale=clf[0].scale_)
                            tmp.replace(weights)
                            row=dict(subject=subject,session=session,context=context,feature=name,seed=42,train_idx=tr.tolist(),evaluation_idx=ev.tolist(),
                                train_n=len(tr),train_class_counts=np.bincount(y[tr],minlength=4).tolist(),training=scores(y[tr],trainprob),
                                evaluation=scores(y[ev],testprob),seconds=time.time()-start,
                                convergence_warnings=[str(w.message) for w in caught if issubclass(w.category,ConvergenceWarning)])
                            atomic(path,row)
                    rows=[json.loads(p.read_text()) for p in dest.glob('sub*.json')]
                    atomic(dest/'summary.json',summarize(rows,['context','feature']))
                    atomic(dest/'status.json',dict(state='running',subject=subject,session=session,completed=len(rows),total=630,started=started,updated=time.time()))
                    print('DIAGNOSTIC_CPU_SESSION_DONE',subject,session,len(rows),flush=True)
            atomic(dest/'status.json',dict(state='complete',completed=630,total=630,started=started,updated=time.time()))
        except Exception as e:
            atomic(dest/'status.json',dict(state='failed',error=repr(e),updated=time.time()));raise

if __name__=='__main__':main()
