from pathlib import Path
import json,pickle,time,subprocess
import numpy as np
ROOT=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text()) if p.exists() else {}
checks={}
for label,filename,token in [('core','core/core.pid',b'run_core_study.py'),('download','download.pid',b'prepare_inner_data.py'),('queue','queue.pid',b'stage_queue.py')]:
    pid=int((ROOT/filename).read_text());p=Path(f'/proc/{pid}/cmdline')
    checks[label]=dict(pid=pid,alive=p.exists() and token in p.read_bytes())
    assert checks[label]['alive'],f'{label} is not running'
events=[]
for p in sorted((ROOT/'inner_data/ds003626/derivatives').glob('sub-*/ses-*/*_events.dat')):
    with p.open('rb') as f:y=np.asarray(pickle.load(f,encoding='latin1'))
    mask=y[:,2]==1
    counts=np.bincount(y[mask,1],minlength=4)
    assert (counts>=2).all(),f'Cannot form calibration/evaluation split: {p}'
    events.append(dict(file=p.name,n_inner=int(mask.sum()),class_counts=counts.tolist(),session=int(y[0,3])))
assert len(events)==30
old=Path('/root/FAST/experiments/mechanism_20260927/results/full_ce_seed42/0-fold0.json')
new=ROOT/'core/results/full_ce_seed42/0-fold0.json'
checks['initialization_matches_historical']=read(old).get('initial_state_sha256')==read(new).get('initial_state_sha256')
assert checks['initialization_matches_historical']
plan=dict(started_at=time.time(),core_fits=1350,inner_base_fits=540,inner_calibration_fits=1080,signal_control_fits=450,
  total_training_fits=3420,core_methods=['CE','joint LOO','regional LOO','global LOO','joint self support','supervised contrastive'],
  core_seeds=[42,142,242],core_subjects=15,core_folds=5,
  external_dataset='OpenNeuro ds003626 official derivative snapshot',external_subjects=10,external_sessions=3,
  external_condition='Inner speech only (condition 1)',external_classes=['up','down','right','left'],
  external_interval_s=[1,3.5],external_eeg_channels=128,external_exg_channels=8,
  external_architectures=['adapted FAST','EEGNet-style'],external_methods=['CE','LOO','supervised contrastive'],external_seeds=[42,142,242],
  external_protocol='Leave one actual same-day session out. Separate fixed target evaluation set for calibration; nested .25/.5/1 fractions of remaining calibration pool; report actual counts, not assumed 5/10/20 per class.',
  calibration='CE and LOO only, both architectures, 50 fixed fine-tuning epochs using source and permitted target calibration trials; evaluation subset never used for fitting',
  signal_controls='All-head demean, all-head time means, common-across-electrodes trial time permutation; retrain CE and joint LOO, all 15 subjects, seed42 exploratory',
  cpu_controls='EEG and EXG mean/variance linear probes with training-only scaling; original BCI folds and real external session splits',
  queue_order=['Core six-arm controls','External 540 session-held-out fits','External 1080 calibration fits','BCI 450 signal-control fits'],
  claims='Pending experiments; no acceptance, neural mechanism, cross-day or online claim. No hyperparameter/model selection using new held-out outcomes.')
(ROOT/'planned_protocol.json').write_text(json.dumps(plan,indent=2))
result=dict(checks=checks,external_event_audit=events,n_inner_trials=sum(e['n_inner'] for e in events),
  core_status=read(ROOT/'core/status.json'),queue_status=read(ROOT/'queue_status.json'),download_status=read(ROOT/'inner_data/download_status.json'),
  core_math_checks=read(ROOT/'core/component_smoke.json'),external_math_checks=read(ROOT/'inner_smoke.json'),
  completed_core_folds=len(list((ROOT/'core/results').glob('full_*/*-fold*.npz'))),
  gpu=subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.used,utilization.gpu','--format=csv,noheader'],text=True).strip())
(ROOT/'startup_checks.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['external_event_audit']},indent=2))
