from pathlib import Path
import json,time,statistics
root=Path(__file__).resolve().parent/'multicue_fast_20261003'
s=json.loads((root/'status.json').read_text());rows=[json.loads(p.read_text()) for p in (root/'results').glob('*.json')]
print('State:',s['state'],'| completed:',s.get('fits_done',0),'/90','| elapsed (min):',round(s.get('elapsed_seconds',0)/60,1))
print('Current:',s.get('source_task'),s.get('modality'),s.get('method'),'fold',s.get('fold'),'epoch',s.get('epoch'))
med={m:statistics.median([r['seconds'] for r in rows if r['method']==m]) for m in ['ce','additive','protected'] if any(r['method']==m for r in rows)}
if med:
 base=med.get('ce',min(med.values()));rates={m:med.get(m,base*(1 if m=='ce' else 2)) for m in ['ce','additive','protected']}
 eta=sum((30-sum(r['method']==m for r in rows))*rates[m] for m in rates)
 print('Estimated remaining (min):',round(eta/60,1),'| approximate; unmeasured methods assumed 2x CE')
 print('Measured seconds/fit:',med)
if s['state']=='failed':print(s.get('error',s.get('pipeline_error')))
