from pathlib import Path
import json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
ready=ROOT/'inner_prepared/prepare_status.json'
if ready.exists() and json.loads(ready.read_text()).get('state')=='complete':
    print('PREPROCESS_ALREADY_COMPLETE');raise SystemExit(0)
for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:args=p.joinpath('cmdline').read_bytes().split(b'\0')
    except OSError:continue
    if any(a in [str(ROOT/'preprocess_inner.py').encode(),str(ROOT/'resume_preprocess.py').encode()] for a in args):
        raise RuntimeError(f'Preprocessing already running: {p.name}')
failure=ROOT/'inner_data_failure.json'
if failure.exists():failure.rename(ROOT/f'preprocess_failure_tmin_before_fix_{int(time.time())}.json')
with (ROOT/'preprocess_resume.log').open('a') as log:
    p=subprocess.Popen([sys.executable,'-u',str(ROOT/'resume_preprocess.py')],cwd='/root/FAST',stdin=subprocess.DEVNULL,
        stdout=log,stderr=subprocess.STDOUT,start_new_session=True,
        env=dict(os.environ,PYTHONUNBUFFERED='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
print('PREPROCESS_RESUME_LAUNCHED',p.pid)
