"""Move the resumed dataset to the empty data disk with full hash verification."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import time

ROOT=Path('/root/FAST/experiments/nature_stage_20261002')
DISK=Path('/root/autodl-tmp')
SRC=ROOT/'inner_data'
DST=DISK/'eeg_research/nature_stage_20261002/inner_data'

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
    return h.hexdigest()

def inventory(folder):
    return {str(p.relative_to(folder)):(p.stat().st_size,sha(p)) for p in folder.rglob('*') if p.is_file()}

assert ROOT.resolve()==ROOT and DISK.resolve()==DISK
assert DST.is_relative_to(DISK) and DST != DISK
assert shutil.disk_usage(DISK).free > 12*1024**3
record={'time':time.time(),'source':str(SRC),'destination':str(DST),'removed_cache_bytes':0}
if SRC.is_symlink():
    assert SRC.resolve()==DST
    record['already_moved']=True
else:
    assert SRC.is_dir() and SRC.resolve()==SRC and SRC.is_relative_to(ROOT)
    assert not DST.exists(),'Destination already exists: inspect before replacing'
    before=inventory(SRC)
    DST.parent.mkdir(parents=True,exist_ok=True)
    shutil.copytree(SRC,DST)
    after=inventory(DST)
    assert before==after,'Hash verification failed: source preserved'
    # Exact paths were checked above and every copied byte verified.
    shutil.rmtree(SRC)
    SRC.symlink_to(DST,target_is_directory=True)
    record.update(files_verified=len(before),bytes_moved=sum(v[0] for v in before.values()))

cache=Path('/root/.cache/pip')
if cache.is_dir():
    assert cache.resolve()==cache and cache.parent==Path('/root/.cache')
    record['removed_cache_bytes']=sum(p.stat().st_size for p in cache.rglob('*') if p.is_file())
    shutil.rmtree(cache)
for rel in ['queue_status.json','core/status.json','inner_data/download_status.json']:
    path=ROOT/rel
    if path.exists():
        previous=json.loads(path.read_text())
        record.setdefault('previous_statuses',{})[rel]=previous
        if previous.get('state') in ('running','downloading'):
            previous.update(state='paused',pause_reason='clone has no live process; staged priority plan',updated=time.time())
            path.write_text(json.dumps(previous,indent=2))
record['disks']={p:dict(zip(['total','used','free'],shutil.disk_usage(p))) for p in ['/root','/root/autodl-tmp']}
(ROOT/'storage_cleanup_20261003.json').write_text(json.dumps(record,indent=2))
print(json.dumps({k:v for k,v in record.items() if k!='previous_statuses'},indent=2))
