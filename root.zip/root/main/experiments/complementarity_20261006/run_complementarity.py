"""Bounded CPU evidence audit, not a new network or independent confirmation."""
import os
os.environ['OMP_NUM_THREADS']='2';os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['MKL_NUM_THREADS']='2'
from pathlib import Path
import json,time,hashlib,fcntl,itertools,warnings,traceback,argparse
import numpy as np,h5py
from scipy.signal import welch
from scipy.io import loadmat
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,balanced_accuracy_score,f1_score
from sklearn.model_selection import KFold,StratifiedKFold

OUT=Path('/root/FAST/experiments/complementarity_20261006')
OLD_PROBES=Path('/root/FAST/experiments/nature_stage_20261002/demean_retrain_20261004/probes')
NGUYEN=Path('/root/FAST/experiments/nature_stage_20261002/nguyen_external_20261003')
RAW=Path('/root/autodl-tmp/eeg_research/nguyen2017_short_words/extracted')
METHODS=['mean','spectrum','joint','equal_fusion']
CONDITIONS={'bci_existing_folds':list(range(15)),'bci_released_file_holdout':list(range(15)),'nguyen_imagery':list(range(1,7)),'nguyen_post_trial_rest':list(range(1,7))}
NEW_FITS=270;REUSED_FITS=180
START=time.time()

def save(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.tmp')
    t.write_text(json.dumps(x,indent=2));t.replace(p)

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
    return h.hexdigest()

def model():return make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=2000,random_state=42))

def features(x,kind):
    mean=x.mean(-1)
    dynamic=x-mean[:,:,None]
    # Nguyen preserves historical float32 input exactly. Welch itself removes
    # each segment's mean, so this non-DC view still excludes constant offsets.
    freq,power=welch(dynamic if kind=='bci' else x,fs=256,nperseg=256,noverlap=128,axis=-1)
    if kind=='bci':
        bands=[(1,4),(4,8),(8,13),(13,30),(30,80),(80,128)]
        spectral=np.stack([np.log(np.maximum(power[:,:,(freq>=a)&((freq<b) if b<128 else (freq<=b))].mean(-1),1e-30)) for a,b in bands],axis=-1).reshape(len(x),-1)
    else:
        # Preserve the already fixed published8-70Hz-data comparator definition.
        # Welch detrending makes non-DC bandpower independent of the trial mean.
        bands=[(8,13),(13,30),(30,70)]
        spectral=np.concatenate([np.log(np.maximum(power[:,:,(freq>=a)&(freq<b)].sum(-1),1e-12)) for a,b in bands],axis=1)
    assert np.isfinite(mean).all() and np.isfinite(spectral).all()
    return {'mean':mean,'spectrum':spectral,'joint':np.concatenate([mean,spectral],1)}

def metrics(y,p,nclasses):
    return {'accuracy':float(accuracy_score(y,p)),'balanced_accuracy':float(balanced_accuracy_score(y,p)),
      'macro_f1':float(f1_score(y,p,labels=np.arange(nclasses),average='macro',zero_division=0))}

def status(state,**kw):
    records=[]
    for p in OUT.glob('*/*/*fold*.json'):
        r=json.loads(p.read_text())
        if r['new_fit']:records.append(r)
    n=len(records);elapsed=time.time()-START
    save(OUT/'status.json',{'state':state,'pid':os.getpid(),'new_fits_done':n,'new_fits_total':270,'elapsed_seconds':elapsed,'estimated_remaining_seconds':elapsed*(270-n)/n if n else None,'updated':time.time(),**kw})

def filename(s,f):return f'{s}-fold{f}'

def run_fold(condition,s,f,values,y,tr,te,nclasses,existing=None):
    assert not set(tr)&set(te);probs={};provenance={}
    for method in ['mean','spectrum','joint']:
        dest=OUT/condition/method;dest.mkdir(parents=True,exist_ok=True);p=dest/(filename(s,f)+'.npz')
        if p.exists():
            with np.load(p) as z:
                assert np.array_equal(z['train_idx'],tr) and np.array_equal(z['test_idx'],te) and np.array_equal(z['y'],y[te])
                probs[method]=z['prob'].copy()
            continue
        if existing and method in existing:
            source=existing[method]
            with np.load(source) as z:
                tk='train_idx' if 'train_idx' in z else 'train';ek='test_idx' if 'test_idx' in z else 'test'
                assert np.array_equal(z[tk],tr) and np.array_equal(z[ek],te) and np.array_equal(z['y'],y[te])
                prob=z['prob'].copy();assert prob.shape==(len(te),nclasses)
            rec={'new_fit':False,'source':str(source),'source_sha256':sha(source),'seconds':0.,'warnings':[]}
        else:
            t=time.time();m=model()
            with warnings.catch_warnings(record=True) as ws:
                warnings.simplefilter('always');m.fit(values[method][tr],y[tr])
            assert np.array_equal(m.classes_,np.arange(nclasses))
            prob=m.predict_proba(values[method][te]);train_accuracy=float(accuracy_score(y[tr],m.predict(values[method][tr])))
            rec={'new_fit':True,'seconds':time.time()-t,'train_accuracy':train_accuracy,'warnings':[str(w.message) for w in ws],
              'training_only_scaler':True,'n_features':values[method].shape[1]}
            scaler=m.named_steps['standardscaler'];lr=m.named_steps['logisticregression']
            np.savez_compressed(dest/(filename(s,f)+'-weights.npz'),center=scaler.mean_,scale=scaler.scale_,coef=lr.coef_,intercept=lr.intercept_,classes=lr.classes_,train_idx=tr)
        assert np.isfinite(prob).all() and np.allclose(prob.sum(1),1)
        np.savez_compressed(p,prob=prob,pred=prob.argmax(1),y=y[te],train_idx=tr,test_idx=te)
        rec.update({'condition':condition,'subject':s,'fold':f,'method':method,'test_metrics':metrics(y[te],prob.argmax(1),nclasses)})
        save(dest/(filename(s,f)+'.json'),rec);probs[method]=prob;provenance[method]=rec
        print('PROBE_DONE',condition,s,f,method,rec['test_metrics'],flush=True);status('running',condition=condition,subject=s,fold=f+1,method=method)
    prob=.5*(probs['mean']+probs['spectrum']);dest=OUT/condition/'equal_fusion';dest.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(dest/(filename(s,f)+'.npz'),prob=prob,pred=prob.argmax(1),y=y[te],train_idx=tr,test_idx=te)
    save(dest/(filename(s,f)+'.json'),{'new_fit':False,'condition':condition,'subject':s,'fold':f,'method':'equal_fusion','weight_fixed':.5,'test_metrics':metrics(y[te],prob.argmax(1),nclasses)})

def summarize():
    result={'complete':True,'conditions':{},'limits':['Previously examined datasets and folds; exploratory, no independent confirmation','One fixed C=1 linear probe, no parameter search; failure does not exclude nonlinear complementarity','Oracle union only an upper bound; not realizable prediction or a method result','Post-trial rest follows imagery and can contain carryover; it is not a pretask negative control','Original release file holdout is not verified across-session/acquisition-block validation','Different preprocessing restricts frequency interpretation; Nguyen is already8-70Hz filtered']}
    for condition,participants in CONDITIONS.items():
        nclasses=5 if condition.startswith('bci') else 3;nfolds=1 if condition=='bci_released_file_holdout' else 5
        rows=[]
        for s in participants:
            if not all((OUT/condition/m/(filename(s,f)+'.npz')).exists() for m in METHODS for f in range(nfolds)):continue
            truth=[];pred={m:[] for m in METHODS};index=[]
            for f in range(nfolds):
                for mi,m in enumerate(METHODS):
                    with np.load(OUT/condition/m/(filename(s,f)+'.npz')) as z:
                        if mi==0:truth.extend(z['y']);index.extend(z['test_idx'])
                        pred[m].extend(z['pred'])
            assert len(set(index))==len(index)
            y=np.array(truth);pred={m:np.array(p) for m,p in pred.items()}
            row={'subject':s,'n_test_trials':len(y),'metrics':{m:metrics(y,p,nclasses) for m,p in pred.items()}}
            mc=pred['mean']==y;dc=pred['spectrum']==y
            row['error_overlap']={'dynamic_correct_mean_wrong':int((dc&~mc).sum()),'mean_correct_dynamic_wrong':int((mc&~dc).sum()),'both_correct':int((mc&dc).sum()),'both_wrong':int((~mc&~dc).sum()),'oracle_union_accuracy':float((mc|dc).mean())}
            row['delta_joint_minus_mean_pp']=100*(row['metrics']['joint']['accuracy']-row['metrics']['mean']['accuracy'])
            row['delta_joint_minus_spectrum_pp']=100*(row['metrics']['joint']['accuracy']-row['metrics']['spectrum']['accuracy'])
            rows.append(row)
        complete=len(rows)==len(participants);result['complete']&=complete
        group={'complete':complete,'n_subjects':len(rows),'total_subjects':len(participants),'subjects':rows}
        if rows:
            group['means']={m:{k:float(np.mean([r['metrics'][m][k] for r in rows])) for k in ['accuracy','balanced_accuracy','macro_f1']} for m in METHODS}
            group['mean_oracle_union_accuracy']=float(np.mean([r['error_overlap']['oracle_union_accuracy'] for r in rows]))
        if complete:
            comparisons={}
            for alternative in ['mean','spectrum']:
                d=100*np.array([r['metrics']['joint']['accuracy']-r['metrics'][alternative]['accuracy'] for r in rows]);rng=np.random.default_rng(20261006)
                ci=np.quantile(d[rng.integers(0,len(d),(50000,len(d)))].mean(1),[.025,.975])
                signs=np.array(list(itertools.product([-1,1],repeat=len(d))))
                comparisons['joint_minus_'+alternative]={'mean_pp':float(d.mean()),'bootstrap95_pp':ci.tolist(),'exact_signflip_p':float(np.mean(abs((signs*d).mean(1))>=abs(d.mean())-1e-12)),'positive_subjects':int((d>1e-10).sum()),'negative_subjects':int((d<-1e-10).sum())}
            group['descriptive_paired_comparisons']=comparisons
        result['conditions'][condition]=group
    save(OUT/'summary.json',result)

def protocol():
    return {'created_utc':'2026-10-06','new_cpu_fits':270,'reused_fits':180,'conditions':CONDITIONS,'methods':METHODS,
      'primary':'Within existing trial folds, fixed joint mean+spectrum probe versus each single-view probe, both datasets; descriptive incremental predictability not causal physiology.',
      'secondary':['Equal probability fusion, no tuned weight','Error overlap/oracle ceiling, not a deployable gain','BCI original300train to50validation release-file sensitivity','Nguyen paired trial-end rest using samefolds; not pre-task baseline'],
      'features':{'bci':'Model-visible first750samples;64means and384logWelch powers over1-4,4-8,8-13,13-30,30-80,80-128Hz; exact existing definitions','nguyen':'Imageryfirst1024samples;post-trialrest512samples;60nonEOGchannels;60means and180logbandpower8-13,13-30,30-70Hz, matching existing spectral comparator'},
      'fit':'Training-only StandardScaler + LogisticRegression C=1 max_iter2000 seed42; no tuning, test-feature fitting, best-fold/participant selection, repeated seeds or new deep training',
      'existing_references':'BCI mean and spectrum150savedprobes;Nguyen spectral30savedprobes. Preserve before choosing new architecture.',
      'interpretation_rules':['Joint versus both probes tests usefulness under this fixed linear model; differing errors alone is not usable complementarity','No neural-source inference from trialmeans or restdecoding','No fake recordingblocks from class-sorted indices','Stop after270fixedCPUfits regardless of effect; do not automatically start a new architecture'],
      'metadata_limits':'BCI released epochs and Nguyen cell arrays lack verified original chronological run/block IDs; release files and cell positions are not proof of session independence.',
      'source_sha256':sha(__file__)}

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    with (OUT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        p=protocol()
        if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==p
        else:save(OUT/'protocol.json',p)
        status('running')
        try:
            for s in range(15):
                with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5') as h:x=h[f'{s+1:02d}/X'][:,:,:750];y=h[f'{s+1:02d}/Y'][:].astype(int)
                values=features(x,'bci')
                for f,(tr,te) in enumerate(KFold(5,shuffle=False).split(x)):
                    existing={m:OLD_PROBES/(m+'_logreg')/(filename(s,f)+'.npz') for m in ['mean','spectrum']}
                    run_fold('bci_existing_folds',s,f,values,y,tr,te,5,existing)
                run_fold('bci_released_file_holdout',s,0,values,y,np.arange(300),np.arange(300,350),5)
                summarize();del x,values
            for s in range(1,7):
                with np.load(NGUYEN/f'sub-{s:02d}.npz') as z:x=z['X'];y=z['y'].astype(int)
                folds=list(StratifiedKFold(5,shuffle=True,random_state=42).split(x,y))
                rawpath=RAW/f'sub-{s:02d}.mat';raw=loadmat(rawpath)
                imag=raw['eeg_data_wrt_task_rep_no_eog_256Hz_last_beep'];rest=raw['eeg_data_wrt_task_rep_no_eog_256Hz_end_trial'];assert imag.shape==rest.shape==(3,100)
                keep=[i for i in range(64) if i not in [0,9,32,63]];rx=[]
                for c in range(3):
                    for j in range(100):
                        idx=c*100+j;assert y[idx]==c
                        assert np.array_equal(imag[c,j][keep,:1024].astype(np.float32),x[idx])
                        a=rest[c,j][keep,:].astype(np.float32);assert a.shape==(60,512);rx.append(a)
                rx=np.asarray(rx);assert np.isfinite(rx).all()
                save(OUT/'metadata'/f'nguyen_subject{s}.json',{'subject':s,'raw_sha256':sha(rawpath),'imagery_shape':list(x.shape),'post_trial_rest_shape':list(rx.shape),'paired_cell_order_verified':True,'channels_excluded_zero_based':[0,9,32,63],'time_run_block_metadata':'Not supplied in prepared cell arrays; cell order does not establish acquisition chronology'})
                for condition,signal in [('nguyen_imagery',x),('nguyen_post_trial_rest',rx)]:
                    values=features(signal,'nguyen')
                    for f,(tr,te) in enumerate(folds):
                        existing={'spectrum':NGUYEN/'results/spectral_logistic'/f'sub{s:02d}_fold{f}.npz'} if condition=='nguyen_imagery' else None
                        run_fold(condition,s,f,values,y,tr,te,3,existing)
                    summarize()
                del x,rx,values,raw
            summarize();status('complete')
            assert json.loads((OUT/'summary.json').read_text())['complete']
            assert json.loads((OUT/'status.json').read_text())['new_fits_done']==270
        except Exception as e:status('failed',error=repr(e),traceback=traceback.format_exc());raise

if __name__=='__main__':main()
