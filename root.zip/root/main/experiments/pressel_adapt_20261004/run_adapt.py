"""Bounded exploratory inner-validation auxiliary-weight adaptation.
All outer folds retain their historical test trials. Test labels never select
weights; earlier results have already been inspected, so this is not a fresh
independent confirmation and does not establish a new architecture.
"""
from pathlib import Path
import sys,os,json,time,hashlib,fcntl,argparse,shutil
import numpy as np,torch
from torch.nn import functional as F
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.metrics import accuracy_score,balanced_accuracy_score,f1_score
from transformers import PretrainedConfig
R=Path(__file__).resolve().parent
OLD=Path('/root/FAST/experiments/pressel_20261004')
STAGE=Path('/root/FAST/experiments/nature_stage_20261002')
sys.path[:0]=[str(STAGE),'/root/FAST']
import inner_models as im
import run_inner_study as base
WEIGHTS=(0.,.03,.1,.3)

def atomic(p,obj):
 p.parent.mkdir(parents=True,exist_ok=True);temp=p.with_suffix(p.suffix+'.tmp');temp.write_text(json.dumps(obj,indent=2));temp.replace(p)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
 return h.hexdigest()
def build():
 return im.FAST(PretrainedConfig(electrodes=['F3','F4','C3','C4','P3','P4'],zone_dict={'Frontal':['F3','F4'],'Central':['C3','C4'],'Parietal':['P3','P4']},dim_cnn=32,dim_token=32,seq_len=1024,window_len=256,slide_step=128,head='Conv4Layers',n_classes=6,num_layers=4,num_heads=8,dropout=.1))
def loo(q,y):
 k=im.kernel(q,q);a=k+.1*torch.eye(len(q),device=q.device,dtype=k.dtype)
 b=torch.cholesky_inverse(torch.linalg.cholesky(a));t=F.one_hot(y,6).to(k.dtype)
 return (t-(b@t)/b.diag()[:,None]).float()
im.loo=loo

def metrics(y,p):
 pred=p.argmax(-1);counts=np.bincount(pred,minlength=6)
 return dict(accuracy=float(accuracy_score(y,pred)),balanced_accuracy=float(balanced_accuracy_score(y,pred)),macro_f1=float(f1_score(y,pred,average='macro',labels=list(range(6)),zero_division=0)),predicted_classes=int((counts>0).sum()),dominant_class_fraction=float(counts.max()/counts.sum()),predicted_class_counts=counts.tolist())
def fit(x,y,indices,weight,seed,anchor_hash=None):
 im.seed_all(seed);model=build();initial=base.state_hash(model)
 if anchor_hash is not None:assert initial==anchor_hash,'Historical initialization mismatch'
 norm=base.normalization(x[indices]);xx=((x-norm[0])/norm[1]).astype(np.float32)
 im.CFG['aux_weight']=weight
 model,timing=base.train(model,xx[indices],y[indices],'ce' if weight==0 else 'loo',200,.0005)
 timing['initial_state_sha256']=initial
 return model,xx,norm,timing

def smoke():
 assert json.loads((OLD/'smoke.json').read_text())['passed']
 im.seed_all(9);q=F.normalize(torch.randn(12,16,device='cuda'),dim=1).requires_grad_();y=torch.arange(12,device='cuda')%6
 scores=loo(q,y)
 for i in range(12):
  mask=torch.arange(12,device='cuda')!=i;k=im.kernel(q[mask],q[mask])
  a=k+.1*torch.eye(11,device='cuda',dtype=k.dtype)
  expect=(im.kernel(q[i:i+1],q[mask])@torch.linalg.solve(a,F.one_hot(y[mask],6).double())).float()[0]
  assert torch.allclose(scores[i],expect,atol=1e-5)
 for w in WEIGHTS:
  im.seed_all(42+101);m=build().cuda()
  with torch.autocast('cuda',dtype=torch.bfloat16):
   logits,z=base.representation(m,torch.randn(12,6,1024,device='cuda'))
   main=F.cross_entropy(logits,y)
   extra=z.sum()*0 if w==0 else w*F.cross_entropy(4*loo(z,y),y)
  (main+extra).backward()
  assert torch.isfinite(main+extra) and all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters())
  del m;torch.cuda.empty_cache()
 # Audit all partitions and historical initializations before training.
 inner_sizes=[]
 for s in range(1,16):
  with np.load(OLD/'prepared'/f'sub-{s:02d}.npz') as d:yall=d['y'];trial=d['original_trial']
  splits=json.loads((OLD/f'splits_sub{s:02d}.json').read_text())['folds']
  for fi,split in enumerate(splits):
   tr=np.array(split['train']);te=np.array(split['test'])
   it,iv=next(StratifiedShuffleSplit(1,test_size=.2,random_state=20261004+s*101+fi*17).split(tr,yall[tr]))
   fitidx=tr[it];valididx=tr[iv]
   assert not set(fitidx)&set(valididx) and not set(tr)&set(te)
   assert set(fitidx)|set(valididx)==set(tr)
   assert set(yall[fitidx])==set(yall[valididx])==set(range(6))
   assert not set(trial[fitidx])&set(trial[valididx])
   for method in ('ce','loo'):
    p=OLD/'results'/method/f'sub{s:02d}_fold{fi}.json';assert p.exists()
   ce=json.loads((OLD/'results/ce'/f'sub{s:02d}_fold{fi}.json').read_text());lo=json.loads((OLD/'results/loo'/f'sub{s:02d}_fold{fi}.json').read_text())
   assert ce['initial_state_sha256']==lo['initial_state_sha256']
   inner_sizes.append(len(fitidx))
 im.seed_all(42+101);model=build();assert base.state_hash(model)==json.loads((OLD/'results/ce/sub01_fold0.json').read_text())['initial_state_sha256']
 atomic(R/'smoke.json',dict(passed=True,weights=list(WEIGHTS),partitions=75,finite_gradients_all_weights=True,inner_train_min=min(inner_sizes),historical_initialization_matched=True))
 print('ADAPT_SMOKE_PASS',flush=True)

def report():
 rows=[json.loads(p.read_text()) for p in (R/'outer').glob('*.json')];subjects=[]
 for s in range(1,16):
  sr=[r for r in rows if r['subject']==s]
  if len(sr)!=5:continue
  entry=dict(subject=s,selected_weights=[r['selected_weight'] for r in sorted(sr,key=lambda r:r['fold'])])
  for method in ('ce','fixed_loo','adapted'):
   entry[method]={k:float(np.mean([r['evaluation'][method][k] for r in sr])) for k in ('accuracy','balanced_accuracy','macro_f1','dominant_class_fraction','predicted_classes')}
  subjects.append(entry)
 counts={str(w):sum(r['selected_weight']==w for r in rows) for w in WEIGHTS}
 result=dict(complete=len(rows)==75,completed_outer_folds=len(rows),subjects=subjects,selected_weight_counts=counts)
 if subjects:result['means']={method:{k:float(np.mean([r[method][k] for r in subjects])) for k in ('accuracy','balanced_accuracy','macro_f1','dominant_class_fraction','predicted_classes')} for method in ('ce','fixed_loo','adapted')}
 if len(rows)==75:
  d=100*np.array([r['adapted']['balanced_accuracy']-r['ce']['balanced_accuracy'] for r in subjects])
  rng=np.random.default_rng(20261004);boot=d[rng.integers(0,15,(10000,15))].mean(1)
  signs=2*((np.arange(32768)[:,None]>>np.arange(15))&1)-1
  result['primary']=dict(endpoint='Adapted minus CE subject mean balanced accuracy',delta_pp=float(d.mean()),subject_bootstrap_95ci_pp=np.quantile(boot,[.025,.975]).tolist(),exact_two_sided_sign_flip_p=float((np.abs((signs*d).mean(1))>=abs(d.mean())-1e-12).mean()),positive_subjects=int((d>0).sum()),negative_subjects=int((d<0).sum()))
  result['note']='Exploratory adaptation after inspecting historical outcomes. Test labels not used for weight selection within this replay. Single seed, one inner holdout. Not independent confirmation; weight0 fallback allowed and reported; does not establish innovation or biological mechanism.'
 atomic(R/'summary.json',result)
 return result

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--smoke',action='store_true');parser.add_argument('--report',action='store_true');args=parser.parse_args()
 torch.set_num_threads(4)
 if args.smoke:smoke();return
 if args.report:print(json.dumps(report(),indent=2));return
 assert json.loads((R/'smoke.json').read_text())['passed']
 protocol=dict(dataset='Pressel-Coretto six imagined directional commands',subjects=list(range(1,16)),outer_folds=5,seed=42,weights=list(WEIGHTS),inner_validation_fraction=.2,inner_seed_rule='20261004+subject*101+fold*17',model_seed_rule='42+subject*101+fold*17',epochs=200,lr=.0005,kernel_gamma=2.,ridge=.1,score_scale=4.,primary='Subject mean balanced accuracy adapted minus matched historical CE',selection='Max inner validation balanced accuracy, then macroF1, then smallest auxiliary weight on exact ties',normalization='Inner candidate norms fitted on inner train only; outer refit norm on outer train only',new_inner_fits=300,max_new_outer_fits=75,cache_policy='Reuse historical outer CE for selected weight0 and historical fixed LOO for selected weight.3; otherwise refit only on outer train',source_hashes={str(p):sha(p) for p in [Path(__file__),STAGE/'inner_models.py',STAGE/'run_inner_study.py',Path('/root/FAST/FAST.py')]},original_protocol_sha256=sha(OLD/'protocol.json'),limitations=['Dataset results already inspected; exploratory adaptation','One inner holdout, one seed','Architecture, input and all other parameters fixed','Weight0 fallback is allowed; no forced positive result','Not proof of original fixed method external benefit','No performance-based early stopping'])
 p=R/'protocol.json'
 if p.exists():assert json.loads(p.read_text())==protocol
 else:atomic(p,protocol)
 for folder in ('inner','outer'): (R/folder).mkdir(exist_ok=True)
 started=time.time();status=dict(state='running',pid=os.getpid(),started=started,total_inner_fits=300,total_outer_folds=75)
 with (R/'run.lock').open('w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  try:
   for s in range(1,16):
    with np.load(OLD/'prepared'/f'sub-{s:02d}.npz') as d:x=d['X'];y=d['y'];trial=d['original_trial']
    folds=json.loads((OLD/f'splits_sub{s:02d}.json').read_text())['folds']
    for fi,split in enumerate(folds):
     name=f'sub{s:02d}_fold{fi}'
     outerfile=R/'outer'/(name+'.json')
     if outerfile.exists():continue
     tr=np.array(split['train']);te=np.array(split['test'])
     a,b=next(StratifiedShuffleSplit(1,test_size=.2,random_state=20261004+s*101+fi*17).split(tr,y[tr]));it=tr[a];iv=tr[b]
     assert not set(it)&set(iv) and not set(tr)&set(te)
     seed=42+s*101+fi*17;candidates=[]
     initial=None
     for weight in WEIGHTS:
      key=f'{name}_w{weight:g}';infofile=R/'inner'/(key+'.json')
      if infofile.exists():info=json.loads(infofile.read_text())
      else:
       status.update(phase='inner_selection',subject=s,fold=fi+1,weight=weight,updated=time.time());atomic(R/'status.json',status)
       model,xx,norm,timing=fit(x,y,it,weight,seed)
       probability=base.predict(model,xx[iv]);evaluation=metrics(y[iv],probability)
       info=dict(subject=s,fold=fi,weight=weight,train=it.tolist(),validation=iv.tolist(),evaluation=evaluation,**timing)
       np.savez_compressed(R/'inner'/(key+'.npz'),prob=probability,y=y[iv],train=it,validation=iv)
       atomic(infofile,info)
       print('INNER_DONE',s,fi,weight,evaluation,timing['seconds'],flush=True)
       del model;torch.cuda.empty_cache()
      assert info['train']==it.tolist() and info['validation']==iv.tolist()
      if initial is None:initial=info['initial_state_sha256']
      assert initial==info['initial_state_sha256']
      candidates.append(info)
     chosen=max(candidates,key=lambda v:(v['evaluation']['balanced_accuracy'],v['evaluation']['macro_f1'],-v['weight']))
     weight=chosen['weight'];status.update(phase='outer_refit',subject=s,fold=fi+1,weight=weight,updated=time.time());atomic(R/'status.json',status)
     evaluation={};olddata={}
     for method,folder in [('ce','ce'),('fixed_loo','loo')]:
      with np.load(OLD/'results'/folder/(name+'.npz')) as d:olddata[method]={k:d[k] for k in d.files}
      assert np.array_equal(olddata[method]['train'],tr) and np.array_equal(olddata[method]['test'],te)
      assert np.array_equal(olddata[method]['y'],y[te])
      evaluation[method]=metrics(y[te],olddata[method]['prob'])
     if weight in (0.,.3):
      cached='ce' if weight==0 else 'fixed_loo';probability=olddata[cached]['prob'];timing=dict(seconds=0,reused_historical=cached,initial_state_sha256=initial)
     else:
      model,xx,norm,timing=fit(x,y,tr,weight,seed,initial)
      probability=base.predict(model,xx[te]);timing['reused_historical']=None
      torch.save(dict(state_dict=model.cpu().state_dict(),normalization=norm,train=tr,test=te,selected_weight=weight),R/'outer'/(name+'.pt'))
      del model;torch.cuda.empty_cache()
     evaluation['adapted']=metrics(y[te],probability)
     np.savez_compressed(R/'outer'/(name+'.npz'),prob=probability,y=y[te],train=tr,test=te,original_trial=trial[te])
     atomic(outerfile,dict(subject=s,fold=fi,selected_weight=weight,selection='Inner BA then macroF1 then lower weight',inner_candidates=candidates,inner_train=it.tolist(),inner_validation=iv.tolist(),outer_train=tr.tolist(),outer_test=te.tolist(),evaluation=evaluation,**timing))
     report();print('OUTER_DONE',s,fi,weight,evaluation,flush=True)
   status.update(state='complete',phase='complete');report()
  except Exception as e:status.update(state='failed',error=repr(e));raise
  finally:status['updated']=time.time();atomic(R/'status.json',status)
if __name__=='__main__':main()
