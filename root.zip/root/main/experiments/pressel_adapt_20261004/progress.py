from pathlib import Path
import json,numpy as np
R=Path(__file__).resolve().parent
status=R/'status.json'
if status.exists():print(json.dumps(json.loads(status.read_text()),indent=2))
inner=[json.loads(p.read_text()) for p in (R/'inner').glob('*.json')]
outer=[json.loads(p.read_text()) for p in (R/'outer').glob('*.json')]
times=[r['seconds'] for r in inner]
print(json.dumps(dict(inner_fits_completed=len(inner),inner_fits_total=300,outer_folds_completed=len(outer),outer_folds_total=75,mean_inner_seconds=None if not times else float(np.mean(times)),estimated_inner_remaining_seconds=None if not times else (300-len(inner))*float(np.mean(times)),outer_new_fits=sum(r.get('reused_historical') is None for r in outer),selected_weights={str(w):sum(r['selected_weight']==w for r in outer) for w in (0.,.03,.1,.3)}),indent=2))
if (R/'summary.json').exists():
 d=json.loads((R/'summary.json').read_text());d.pop('subjects',None);print(json.dumps(d,indent=2))
