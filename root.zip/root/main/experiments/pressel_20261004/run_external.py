"""Fixed external replay: Spanish directional imagined words, all15 subjects."""
from pathlib import Path
import os,sys,json,time,hashlib,concurrent.futures,threading,zipfile,fcntl,shutil
import requests,numpy as np
R=Path(__file__).resolve().parent
DATA=Path('/root/autodl-tmp/eeg_research/pressel2016')
STAGE=Path('/root/FAST/experiments/nature_stage_20261002')
RECORD='19502780'
START=time.time();LOCK=threading.Lock();BYTES={}

def atomic(p,obj):
 p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(obj,indent=2));q.replace(p)
def digest(p,kind='sha256'):
 h=hashlib.new(kind)
 with p.open('rb') as f:
  for block in iter(lambda:f.read(4*1024**2),b''):h.update(block)
 return h.hexdigest()
def download():
 DATA.mkdir(parents=True,exist_ok=True)
 response=requests.get(f'https://zenodo.org/api/records/{RECORD}',timeout=30);response.raise_for_status();record=response.json()
 atomic(R/'repository_record.json',record)
 files={f['key']:f for f in record['files']}
 selected=[files[f'S{s:02d}.zip'] for s in range(1,16)]+[files['README.md']]
 assert shutil.disk_usage(DATA).free>sum(f['size'] for f in selected)*3+1024**3,'Insufficient disk space'
 total=sum(f['size'] for f in selected)
 def worker(info):
  dest=DATA/info['key'];temp=dest.with_suffix(dest.suffix+'.part');size=info['size'];md5=info['checksum'].split(':')[1]
  if dest.exists() and dest.stat().st_size==size and digest(dest,'md5')==md5:
   with LOCK:BYTES[info['key']]=size
   return dest
  for attempt in range(5):
   try:
    offset=temp.stat().st_size if temp.exists() else 0
    if offset>size:raise RuntimeError('Part size exceeds expected file')
    if offset<size:
     headers={'Range':f'bytes={offset}-'} if offset else {}
     with requests.get(info['links']['self'],headers=headers,stream=True,timeout=(20,90)) as response:
      response.raise_for_status()
      if offset and response.status_code==200:offset=0
      elif offset:
       assert response.status_code==206 and response.headers.get('Content-Range','').startswith(f'bytes {offset}-')
      with temp.open('ab' if offset else 'wb') as out:
       for chunk in response.iter_content(1024**2):
        out.write(chunk);offset+=len(chunk)
        with LOCK:
         BYTES[info['key']]=offset
         atomic(R/'download_status.json',dict(state='downloading',bytes=sum(BYTES.values()),total=total,seconds=time.time()-START,average_MBps=sum(BYTES.values())/max(time.time()-START,1)/1e6,files=BYTES))
    assert temp.stat().st_size==size
    assert digest(temp,'md5')==md5,'Checksum mismatch'
    temp.replace(dest)
    print('DOWNLOAD_DONE',info['key'],size,flush=True);return dest
   except Exception:
    if attempt==4:raise
    time.sleep(min(2*(attempt+1),8))
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(worker,selected))
 atomic(R/'download_status.json',dict(state='complete',bytes=total,total=total,seconds=time.time()-START,verified_md5=True))
 return files

def prepare(files):
 from scipy.io import loadmat
 from scipy.signal import resample_poly
 prepared=R/'prepared';prepared.mkdir(exist_ok=True);audit=[]
 for s in range(1,16):
  zip_path=DATA/f'S{s:02d}.zip'
  with zipfile.ZipFile(zip_path) as z:
   assert z.testzip() is None
   members=[i for i in z.infolist() if i.filename.endswith('.mat')];assert len(members)==1
   dest=DATA/f'sub-{s:02d}_eeg.mat'
   if not dest.exists() or dest.stat().st_size!=members[0].file_size:
    with z.open(members[0]) as source,dest.open('wb') as out:shutil.copyfileobj(source,out,4*1024**2)
  try:matrix=loadmat(dest)['EEG']
  except NotImplementedError:
   import h5py
   with h5py.File(dest,'r') as h:matrix=np.asarray(h['EEG']).T
  assert matrix.ndim==2 and matrix.shape[1]==24579,matrix.shape
  labels=matrix[:,-3:].astype(np.int64)
  mask=(labels[:,0]==1)&(labels[:,2]==1)&(labels[:,1]>=6)&(labels[:,1]<=11)
  indices=np.flatnonzero(mask);y=labels[mask,1]-6
  assert set(y)==set(range(6)) and np.bincount(y,minlength=6).min()>=5
  raw=matrix[mask,:24576].reshape(-1,6,4096)
  x=resample_poly(raw,1,4,axis=-1).astype(np.float32)
  assert x.shape==(len(y),6,1024) and np.isfinite(x).all()
  np.savez_compressed(prepared/f'sub-{s:02d}.npz',X=x,y=y,original_trial=indices)
  audit.append(dict(subject=s,original_shape=list(matrix.shape),n_clean_directional_trials=len(y),class_counts=np.bincount(y,minlength=6).tolist(),imagined_only=True,artifact_policy='Released flag1 only',zip_md5=digest(zip_path,'md5'),mat_sha256=digest(dest)))
  print('PREPARED',s,len(y),np.bincount(y,minlength=6).tolist(),flush=True)
 atomic(R/'data_audit.json',dict(subjects=audit,channels=['F3','F4','C3','C4','P3','P4'],label_map=['arriba','abajo','adelante','atras','derecha','izquierda'],fs_original=1024,fs_model=256,window='Full4s of released imagined interval; 1024 model samples',trial_unit='One complete released trial; no overlapping fragments',readme=(DATA/'README.md').read_text()))

def train():
 sys.path[:0]=[str(STAGE),'/root/FAST']
 import torch
 from torch.nn import functional as F
 from transformers import PretrainedConfig
 from sklearn.model_selection import StratifiedKFold
 from sklearn.metrics import accuracy_score,balanced_accuracy_score,f1_score
 from sklearn.pipeline import make_pipeline
 from sklearn.preprocessing import StandardScaler
 from sklearn.linear_model import LogisticRegression
 from scipy.signal import welch
 import inner_models as im
 import run_inner_study as base
 torch.set_num_threads(4)
 def build():
  return im.FAST(PretrainedConfig(electrodes=['F3','F4','C3','C4','P3','P4'],zone_dict={'Frontal':['F3','F4'],'Central':['C3','C4'],'Parietal':['P3','P4']},dim_cnn=32,dim_token=32,seq_len=1024,window_len=256,slide_step=128,head='Conv4Layers',n_classes=6,num_layers=4,num_heads=8,dropout=.1))
 def loo(q,y):
  k=im.kernel(q,q);a=k+.1*torch.eye(len(q),device=q.device,dtype=k.dtype)
  b=torch.cholesky_inverse(torch.linalg.cholesky(a));target=F.one_hot(y,6).to(k.dtype)
  return (target-(b@target)/b.diag()[:,None]).float()
 im.loo=loo
 def metrics(y,p):
  pred=p.argmax(-1);return dict(accuracy=float(accuracy_score(y,pred)),balanced_accuracy=float(balanced_accuracy_score(y,pred)),macro_f1=float(f1_score(y,pred,average='macro',labels=list(range(6)),zero_division=0)))
 def summarize():
  groups=[]
  for method in ('ce','loo','spectral_logistic'):
   rows=[json.loads(p.read_text()) for p in (R/'results'/method).glob('*.json')];subjects=[]
   for subject in range(1,16):
    sr=[r for r in rows if r['subject']==subject]
    if len(sr)==5:subjects.append(dict(subject=subject,**{k:float(np.mean([r['evaluation'][k] for r in sr])) for k in ('accuracy','balanced_accuracy','macro_f1')}))
   groups.append(dict(method=method,n_fits=len(rows),subjects=subjects,means={k:float(np.mean([r[k] for r in subjects])) for k in ('accuracy','balanced_accuracy','macro_f1')} if subjects else {}))
  atomic(R/'summary.json',dict(groups=groups,complete=all(g['n_fits']==75 for g in groups)))
  if all(g['n_fits']==75 for g in groups):
   ce={r['subject']:r for r in groups[0]['subjects']};lo={r['subject']:r for r in groups[1]['subjects']}
   d=100*np.array([lo[s]['balanced_accuracy']-ce[s]['balanced_accuracy'] for s in range(1,16)])
   rng=np.random.default_rng(20261004);boot=d[rng.integers(0,15,(10000,15))].mean(1)
   signs=2*((np.arange(32768)[:,None]>>np.arange(15))&1)-1
   atomic(R/'paired_analysis.json',dict(complete=True,primary='subject mean balanced accuracy LOO minus CE',delta_pp=float(d.mean()),subject_bootstrap_95ci_pp=np.quantile(boot,[.025,.975]).tolist(),exact_two_sided_sign_flip_p=float((np.abs((signs*d).mean(1))>=abs(d.mean())-1e-12).mean()),positive_subjects=int((d>0).sum()),negative_subjects=int((d<0).sum()),seed=42,n_subjects=15,groups=groups,note='Dataset and task fixed before observing model results; no positive-result stopping. Single seed; no cross-subject or zero-shot transfer claim. All earlier external findings retained.'))
 # Fixed-embedding analytic LOO and self-label exclusion checks.
 im.seed_all(9);q=F.normalize(torch.randn(12,16,device='cuda'),dim=1).requires_grad_();y=torch.arange(12,device='cuda')%6
 actual=loo(q,y)
 for i in range(12):
  mask=torch.arange(12,device='cuda')!=i
  k=im.kernel(q[mask],q[mask]);a=k+.1*torch.eye(11,device='cuda',dtype=k.dtype)
  expected=(im.kernel(q[i:i+1],q[mask])@torch.linalg.solve(a,F.one_hot(y[mask],6).double())).float()[0]
  assert torch.allclose(actual[i],expected,atol=1e-5)
 changed=y.clone();changed[0]=(changed[0]+1)%6
 assert torch.allclose(actual[0],loo(q,changed)[0],atol=1e-5)
 m=build().cuda().eval();x=torch.randn(12,6,1024,device='cuda')
 logits,z=base.representation(m,x);assert logits.shape==(12,6)
 assert torch.allclose(logits,m(x),atol=1e-6)
 (F.cross_entropy(logits,y)+im.auxiliary(z,y,'loo')).backward()
 assert all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters())
 atomic(R/'smoke.json',dict(passed=True,checks=['LOO scores equal explicit refits','No direct self-label in fixed-embedding score','Six-channel FAST forward agreement','Finite gradients']))
 del m;torch.cuda.empty_cache()
 for subject in range(1,16):
  with np.load(R/'prepared'/f'sub-{subject:02d}.npz') as data:x=data['X'];y=data['y'];trial=data['original_trial']
  folds=list(StratifiedKFold(5,shuffle=True,random_state=42).split(x,y))
  atomic(R/f'splits_sub{subject:02d}.json',dict(folds=[dict(train=tr.tolist(),test=te.tolist()) for tr,te in folds]))
  f,p=welch(x,fs=256,nperseg=256,noverlap=128,axis=-1)
  features=np.concatenate([np.log(np.maximum(p[...,(f>=a)&(f<b)].sum(-1),1e-12)) for a,b in [(2,4),(4,8),(8,13),(13,30),(30,45)]],axis=1)
  for fold,(tr,te) in enumerate(folds):
   assert not set(trial[tr])&set(trial[te])
   norm=base.normalization(x[tr]);xx=((x-norm[0])/norm[1]).astype(np.float32)
   for method in ('ce','loo','spectral_logistic'):
    dest=R/'results'/method;dest.mkdir(parents=True,exist_ok=True);name=f'sub{subject:02d}_fold{fold}'
    if (dest/(name+'.json')).exists():continue
    atomic(R/'status.json',dict(state='running',phase='training',pid=os.getpid(),subject=subject,fold=fold+1,method=method,started=START,updated=time.time(),new_gpu_fits=150))
    if method=='spectral_logistic':
     start=time.time();model=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=2000));model.fit(features[tr],y[tr]);prob=model.predict_proba(features[te]);timing=dict(seconds=time.time()-start)
    else:
     im.seed_all(42+subject*101+fold*17);model=build();initial=base.state_hash(model)
     if method=='loo':assert initial==json.loads((R/'results/ce'/(name+'.json')).read_text())['initial_state_sha256']
     model,timing=base.train(model,xx[tr],y[tr],method,200,.0005);prob=base.predict(model,xx[te]);timing['initial_state_sha256']=initial
     torch.save(dict(state_dict=model.cpu().state_dict(),normalization=norm,train=tr,test=te,method=method),dest/(name+'.pt'))
     del model;torch.cuda.empty_cache()
    np.savez_compressed(dest/(name+'.npz'),prob=prob,y=y[te],train=tr,test=te,original_trial=trial[te])
    atomic(dest/(name+'.json'),dict(subject=subject,fold=fold,method=method,evaluation=metrics(y[te],prob),**timing))
    summarize();print('FOLD_DONE',method,subject,fold,metrics(y[te],prob),timing['seconds'],flush=True)

def main():
 R.mkdir(exist_ok=True)
 with (R/'run.lock').open('w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  protocol=dict(dataset='Pressel-Coretto Spanish imagined speech',record=RECORD,subjects=list(range(1,16)),task='Six directional commands codes6-11; imagined modality1; clean artifact flag1',seed=42,folds=5,epochs=200,new_gpu_fits=150,new_cpu_fits=75,primary='Subject mean balanced accuracy LOO minus matched CE',window='Full released4s; resample1024 to256Hz; no overlapping trial fragments',architecture='Same FAST operators; input geometry changes to three pairs F3/F4,C3/C4,P3/P4; output6classes',auxiliary='Original joint normalized region/CLS representation and fixed LOO; ridge.1 gamma2 weight.3 score4',lr=.0005,split='Stratified full-trial5fold, random_state42; same folds and initialization for both arms; training-only channel normalization',source_hashes={str(p):digest(p) for p in [Path(__file__),STAGE/'inner_models.py',STAGE/'run_inner_study.py',Path('/root/FAST/FAST.py')]},selection_reason='Independent word-level imagined-speech task and affordable complete15subject data, chosen before performance was observed',limitations=['One seed','Released artifact labels used for both arms','No full run/time identifiers; trial folds cannot exclude all slow drift','Six-electrode adaptation is not identical dense-cap geometry','No zero-shot or cross-subject claim','No stop based on accuracy; retain all previous external outcomes'])
  p=R/'protocol.json'
  if p.exists():assert json.loads(p.read_text())==protocol
  else:atomic(p,protocol)
  try:
   atomic(R/'status.json',dict(state='running',phase='download',pid=os.getpid(),started=START))
   files=download();atomic(R/'status.json',dict(state='running',phase='preparation',pid=os.getpid(),started=START))
   prepare(files);train();atomic(R/'status.json',dict(state='complete',phase='complete',updated=time.time()))
  except Exception as e:
   atomic(R/'status.json',dict(state='failed',error=repr(e),updated=time.time()));raise
if __name__=='__main__':main()
