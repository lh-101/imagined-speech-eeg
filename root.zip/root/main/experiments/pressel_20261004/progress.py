from pathlib import Path
import json,numpy as np
R=Path(__file__).resolve().parent
for name in ('status.json','download_status.json'):
 p=R/name
 if p.exists():
  d=json.loads(p.read_text());d.pop('files',None)
  if name=='download_status.json':d['percent']=round(100*d['bytes']/d['total'],1)
  print(name,json.dumps(d,indent=2))
rows=[json.loads(p.read_text()) for method in ('ce','loo') for p in (R/'results'/method).glob('*.json')]
if rows:
 t=float(np.mean([r['seconds'] for r in rows]));print(json.dumps(dict(completed_gpu_fits=len(rows),total_gpu_fits=150,percent=round(100*len(rows)/150,1),seconds_per_fit=t,estimated_training_remaining_seconds=(150-len(rows))*t),indent=2))
if (R/'paired_analysis.json').exists():
 d=json.loads((R/'paired_analysis.json').read_text());d.pop('groups',None);print(json.dumps(d,indent=2))
