from pathlib import Path
import json,numpy as np
R=Path('/root/FAST/experiments/pressel_20261004')
rows=[]
for s in range(1,16):
 with np.load(R/'prepared'/f'sub-{s:02d}.npz') as d:y=d['y'];trial=d['original_trial']
 row={'subject':s,'class_counts':np.bincount(y,minlength=6).tolist(),'methods':{}}
 ref=[]
 for method in ('ce','loo','spectral_logistic'):
  targets=[];pred=[];indices=[];trace=[]
  for fold in range(5):
   p=R/'results'/method/f'sub{s:02d}_fold{fold}.npz'
   with np.load(p) as d:
    assert np.array_equal(d['y'],y[d['test']]);assert np.array_equal(d['original_trial'],trial[d['test']]);assert not set(d['train'])&set(d['test'])
    if method=='ce':ref.append((d['train'].copy(),d['test'].copy()))
    else:
     assert np.array_equal(d['train'],ref[fold][0]);assert np.array_equal(d['test'],ref[fold][1])
    indices.extend(d['test'].tolist());targets.extend(d['y'].tolist());pred.extend(d['prob'].argmax(1).tolist())
   info=json.loads(p.with_suffix('.json').read_text())
   if 'trace' in info:trace.append(info['trace'][-1])
  assert len(set(indices))==len(y)==len(indices)
  counts=np.bincount(pred,minlength=6)
  row['methods'][method]={'predicted_class_counts':counts.tolist(),'predicted_classes':int((counts>0).sum()),'dominant_class_fraction':float(counts.max()/counts.sum()),'last_main_loss_mean':float(np.mean([t['main_loss'] for t in trace])) if trace else None,'last_aux_loss_mean':float(np.mean([t['aux_loss'] for t in trace])) if trace else None}
 rows.append(row)
summary={m:{'mean_dominant_class_fraction':float(np.mean([r['methods'][m]['dominant_class_fraction'] for r in rows])),'subjects_with_one_predicted_class':sum(r['methods'][m]['predicted_classes']==1 for r in rows),'mean_predicted_classes':float(np.mean([r['methods'][m]['predicted_classes'] for r in rows])),'mean_last_main_loss':None if m=='spectral_logistic' else float(np.mean([r['methods'][m]['last_main_loss_mean'] for r in rows]))} for m in ('ce','loo','spectral_logistic')}
result={'paired_prediction_alignment_passed':True,'all_subjects_full_trial_coverage_passed':True,'summary':summary,'subjects':rows,'note':'Saved predictions/trace audit only; does not identify causal explanation.'}
(R/'prediction_audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='subjects'},indent=2))
