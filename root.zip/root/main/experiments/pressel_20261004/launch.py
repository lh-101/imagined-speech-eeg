from pathlib import Path
import subprocess,sys,os,json
R=Path(__file__).resolve().parent
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:args=(p/'cmdline').read_bytes().split(b'\0')
 except OSError:continue
 if str(R/'run_external.py').encode() in args:raise RuntimeError('Already running')
with (R/'pipeline.log').open('a') as log:
 proc=subprocess.Popen([sys.executable,'-u',str(R/'run_external.py')],cwd='/root/FAST',stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,PYTHONUNBUFFERED='1',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4'))
(R/'pid').write_text(str(proc.pid))
print(json.dumps(dict(launched=True,pid=proc.pid,subjects=15,new_gpu_fits=150,download_then_audit_then_train=True)))
