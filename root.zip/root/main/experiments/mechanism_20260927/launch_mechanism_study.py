import os
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parent
pidfile=root/'pid'
if pidfile.exists():
    pid=int(pidfile.read_text())
    try:
        cmd=Path(f'/proc/{pid}/cmdline').read_bytes()
    except FileNotFoundError:cmd=b''
    if b'run_mechanism_study.py' in cmd:
        raise RuntimeError(f'Already running pid {pid}')
assert (root/'smoke.json').exists(), 'Run smoke checks first'
with (root/'train.log').open('a') as f:
    p=subprocess.Popen([sys.executable,'-u',str(root/'run_mechanism_study.py')],
                       cwd='/root/FAST',stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,
                       start_new_session=True,env=dict(os.environ,PYTHONUNBUFFERED='1',OMP_NUM_THREADS='8',OPENBLAS_NUM_THREADS='8'))
pidfile.write_text(str(p.pid))
print('MECHANISM_STUDY_LAUNCHED',p.pid,str(root/'train.log'))
