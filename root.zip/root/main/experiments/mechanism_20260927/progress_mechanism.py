"""Read-only live progress display. Ctrl+C stops this display, not training."""
import json
import os
from pathlib import Path
import statistics
import time

ROOT=Path(__file__).resolve().parent

def duration(s):
    s=max(0,int(s));h,s=divmod(s,3600);m,s=divmod(s,60)
    return f'{h:02d}:{m:02d}:{s:02d}'

def read(p):
    try:return json.loads(p.read_text())
    except (OSError,ValueError):return {}

def show():
    status=read(ROOT/'status.json'); manifest=read(ROOT/'manifest.json')
    jobs=manifest.get('jobs',[]);total=len(jobs)*75
    done=0;times={};remaining={};current_done=False
    current=status.get('job',{})
    current_name=f"{current.get('condition')}_{current.get('method')}_seed{current.get('seed')}"
    for job in jobs:
        name=f"{job['condition']}_{job['method']}_seed{job['seed']}"
        directory=ROOT/'results'/name
        n=0
        for p in directory.glob('*-fold*.npz'):
            d=read(p.with_suffix('.json'))
            if not d:continue
            n+=1
            times.setdefault(job['method'],[]).append(d['seconds'])
            if name==current_name and d['subject']==status.get('subject') and d['fold']==status.get('fold'):
                current_done=True
        done+=n
        remaining[job['method']]=remaining.get(job['method'],0)+75-n
    # Historical estimate for methods not completed yet; replaced by measured medians.
    estimates={'ce':22.,'protected':45.,'additive':45.}
    for method,values in times.items():estimates[method]=statistics.median(values)
    now=time.time();elapsed=now-status.get('started',now)
    left=sum(n*estimates[m] for m,n in remaining.items())
    if status.get('state')=='running' and not current_done and current:
        left-=min(max(0,now-status.get('updated',now)),estimates[current['method']])
    left=max(0,left)
    state=status.get('state','waiting')
    if state=='complete':left=0
    pid=status.get('pid')
    alive=bool(pid and Path(f'/proc/{pid}').exists())
    print('\033[2J\033[H',end='')
    print('FAST mechanism study | refresh every 5s | Ctrl+C exits display only')
    print('='*75)
    print(f'State: {state} | process {pid}: {"present" if alive else "absent"}')
    print(f'Overall: {done}/{total} folds ({100*done/max(total,1):.1f}%)')
    print(f"Job: {status.get('job_index',0)+1}/{len(jobs)}  {current_name}")
    print(f"Subject: {status.get('subject',0)+1}/15 | fold: {status.get('fold',0)+1}/5")
    print(f'Elapsed: {duration(elapsed)}')
    if state=='running' and alive:
        print(f'Estimated remaining: {duration(left)} (rough range {duration(.8*left)} - {duration(1.3*left)})')
        print(f'Estimated total: {duration(elapsed+left)}')
        print('Estimated finish (SERVER timezone): '+time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(now+left)))
    elif state=='complete':print('All scheduled jobs completed.')
    else:print('ETA unavailable: training is stopped or failed. Check train.log.')
    print('Seconds/fold: '+', '.join(f'{m}={v:.1f}'+(' measured' if times.get(m) else ' initial estimate') for m,v in estimates.items()))
    print('ETA is approximate; the range is a heuristic, not a confidence interval.')
    print('-'*75)
    try:
        with (ROOT/'train.log').open('rb') as f:
            f.seek(0,os.SEEK_END);size=f.tell();f.seek(max(0,size-10000))
            lines=f.read().decode('utf-8',errors='replace').splitlines()
        for line in lines[-5:]:print(line)
    except OSError:print('Waiting for train.log')
    if status.get('error'):print('ERROR:',status['error'])

if __name__=='__main__':
    import sys
    try:
        while True:
            show()
            if '--once' in sys.argv:break
            time.sleep(5)
    except KeyboardInterrupt:print('\nDisplay closed; training was not stopped.')
