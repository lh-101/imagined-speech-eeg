"""CPU metadata and prediction association audit. No physiological attribution."""
import json
from pathlib import Path
import h5py
import numpy as np
from scipy.io import loadmat

ROOT=Path(__file__).resolve().parent
P=Path('/root/FAST')
records=[]; associations=[]
with h5py.File(P/'Processed/BCIC2020Track3.h5','r') as h:
    for s in range(15):
        X=h[f'{s+1:02d}/X'][:];Y=h[f'{s+1:02d}/Y'][:]
        offset=0
        for folder,key in [('Training set','epo_train'),('Validation set','epo_validation')]:
            p=P/'BCIC2020Track3'/folder/f'Data_Sample{s+1:02d}.mat'
            d=loadmat(p,simplify_cells=True)
            e=d[key];t=np.asarray(e['t']);raw=np.transpose(e['x'],(2,1,0)).astype(np.float32)
            labels=e['y'].argmax(0);n=len(raw)
            match=bool(np.array_equal(np.pad(raw,((0,0),(0,0),(0,5)),mode='edge'),X[offset:offset+n]))
            assert match and np.array_equal(labels,Y[offset:offset+n])
            records.append(dict(subject=s,set=folder,top_fields=[k for k in d if not k.startswith('__')],
                                epoch_fields=list(e),fs=float(e['fs']),t_first=float(t[0]),t_last=float(t[-1]),
                                n_timepoints=len(t),n_trials=n,raw_h5_exact_match=match,
                                event_fields=[k for k in e if any(z in k.lower() for z in ['event','trigger','cue','marker'])]))
            offset+=n
            del raw,d,e
        assert offset==350
        old=np.loadtxt(P/f'Results/FAST/{s}-Tune.csv',delimiter=',',dtype=int)
        v=np.load(P/f'experiments/residual_20260925/metric_v4/{s}-predictions.npz')
        a=np.load(P/f'Results/LEAK/{s}-leak.npz')
        assert np.array_equal(Y,v['y']) and np.array_equal(Y,a['y']) and np.array_equal(Y,old[:,1])
        wrong=old[:,0]!=Y;recovered=wrong&(v['pred']==Y);unrecovered=wrong&(v['pred']!=Y)
        for name in ['base_all','base_high40','base_low40']:
            correct=a[name]==Y
            associations.append(dict(subject=s,probe=name,n_recovered=int(recovered.sum()),n_unrecovered=int(unrecovered.sum()),
                                     correct_recovered=int((correct&recovered).sum()),correct_unrecovered=int((correct&unrecovered).sum()),
                                     recovered_probe_accuracy=float(correct[recovered].mean()) if recovered.any() else None,
                                     unrecovered_probe_accuracy=float(correct[unrecovered].mean()) if unrecovered.any() else None))
        print('AUDITED_SUBJECT',s,flush=True)
r=dict(metadata=records,associations=associations,
       note='Association conditional on old-baseline error only. No causal attribution; no proof of artefact or neural origin. Shared subject/class difficulty may confound.',
       event_conclusion='Epoch field inventory alone does not establish cue alignment or group IDs; no physiology inferred from negative timestamps.')
(ROOT/'data_audit.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
print('AUDIT_COMPLETE',len(records),flush=True)
