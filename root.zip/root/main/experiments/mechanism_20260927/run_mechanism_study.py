"""Frozen exploratory mechanism study. Does not modify historical V4 outputs."""
import argparse
import fcntl
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import time

PROJECT = Path('/root/FAST')
OLD = PROJECT/'experiments/residual_20260925'
sys.path[:0] = [str(PROJECT), str(OLD)]
import h5py
import numpy as np
import torch
from torch.nn import functional as F
from sklearn.model_selection import KFold
from sklearn.metrics import f1_score
import run_metric_v4 as v4

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'results'
MASKS = {'full': None, 'remove_pre': (0,128), 'remove_late': (622,750)}
JOBS = [dict(method=m, condition='full', seed=s)
        for s in (42,142,242) for m in ('ce','protected','additive')]
JOBS += [dict(method=m, condition=c, seed=42)
         for c in ('remove_pre','remove_late') for m in ('ce','protected')]

def atomic_json(path, obj):
    temp = path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding='utf-8')
    temp.replace(path)

def sha(path):
    h = hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()

def state_hash(model):
    h = hashlib.sha256()
    for k,t in model.state_dict().items():
        h.update(k.encode()); h.update(t.detach().cpu().numpy().tobytes())
    return h.hexdigest()

def job_name(job):
    return f"{job['condition']}_{job['method']}_seed{job['seed']}"

def mask_input(x, condition):
    z=x.copy()
    if MASKS[condition] is not None:
        a,b=MASKS[condition]; z[...,a:b]=0
    return z

def manifest():
    deps = [Path(__file__), OLD/'run_metric_v4.py', OLD/'run_residual.py',
            OLD/'fast_residual.py', PROJECT/'FAST.py',
            PROJECT/'BCIC2020Track3_train.py', PROJECT/'BCIC2020Track3_preprocess.py']
    return dict(version=1, jobs=JOBS, cfg=v4.CFG, masks=MASKS,
                source_hashes={str(p):sha(p) for p in deps},
                data_sha256=sha(PROJECT/'Processed/BCIC2020Track3.h5'),
                packages={p:importlib.metadata.version(p) for p in
                          ['torch','numpy','scipy','scikit-learn','lightning','transformers','h5py','einops']},
                primary_endpoint='subject-mean main-head accuracy; same-loop protected minus CE',
                secondary_endpoints=['fixed fused head','kernel head','macro F1','training diagnostics'],
                note='Previously explored outer folds. Not independent confirmation. No performance-based early stop. Temporal conditions are seed-42 sensitivity analyses only.',
                learning_rate='Historical schedule[epoch-1] intentionally preserved in every arm',
                temporal_control='Equal 128 samples; mirror coverage in effective input [0,750). Not proof of neural/artefact source.')

def train_fold(x,y,tr,te,job,s,fi,dest):
    v4.seed_all(job['seed']+s*5+fi)
    model=v4.FAST(v4.config()).cuda()
    initial_hash=state_hash(model)
    params=list(model.parameters())
    opt=torch.optim.AdamW(params,lr=v4.CFG['lr'])
    xt=torch.from_numpy(x[tr]).cuda(); yt=torch.from_numpy(y[tr]).cuda()
    schedule=v4.cosine_scheduler(1,.1,200,1,warmup_epochs=10)
    start=time.time(); trace=[]; conflicts=0
    torch.cuda.reset_peak_memory_stats()
    for epoch in range(200):
        model.train(); opt.zero_grad(set_to_none=True)
        lr=v4.CFG['lr']*float(schedule[epoch-1])
        for group in opt.param_groups: group['lr']=lr
        with torch.autocast('cuda',dtype=torch.bfloat16):
            logits,q=v4.representation(model,xt)
            main_loss=F.cross_entropy(logits,yt)
        aux_loss=None; cosine=None; ratio=None; scale=None
        if job['method']=='ce':
            main_loss.backward()
        else:
            _,loo=v4.ridge_fit(q,yt)
            aux_loss=v4.CFG['aux_weight']*F.cross_entropy(v4.CFG['score_scale']*loo,yt)
            gm=torch.autograd.grad(main_loss,params,retain_graph=True,allow_unused=True)
            ga=torch.autograd.grad(aux_loss,params,allow_unused=True)
            ma=[torch.zeros_like(p) if g is None else g for g,p in zip(gm,params)]
            au=[torch.zeros_like(p) if g is None else g for g,p in zip(ga,params)]
            dot=sum((a.float()*b.float()).sum() for a,b in zip(ma,au))
            mm=sum(a.float().square().sum() for a in ma)
            aa=sum(a.float().square().sum() for a in au)
            cosine=float((dot/(mm*aa).sqrt().clamp_min(1e-20)).detach())
            ratio=float((aa.sqrt()/mm.sqrt().clamp_min(1e-20)).detach())
            conflicts+=int(float(dot)<0)
            if job['method']=='protected':
                _,scale=v4.protect(gm,ga,params)
            else:
                for p,a,b in zip(params,ma,au): p.grad=(a+b).detach()
                scale=1.0
        if not torch.isfinite(main_loss) or (aux_loss is not None and not torch.isfinite(aux_loss)):
            raise RuntimeError('Nonfinite loss')
        if not all(p.grad is None or torch.isfinite(p.grad).all() for p in params):
            raise RuntimeError('Nonfinite gradients')
        opt.step()
        row=dict(epoch=epoch+1,lr=lr,main_loss=float(main_loss.detach()),
                 aux_loss=None if aux_loss is None else float(aux_loss.detach()),
                 gradient_cosine=cosine,aux_main_norm_ratio=ratio,aux_scale=scale)
        trace.append(row)
        if epoch==0 or (epoch+1)%50==0:
            print('TRAIN',job_name(job),s,fi,json.dumps(row),flush=True)
    model.eval()
    with torch.no_grad():
        train_main,support=v4.representation(model,xt)
        alpha,loo_eval=v4.ridge_fit(support,yt)
        test_main,query=v4.representation(model,torch.from_numpy(x[te]).cuda())
        scores=(v4.kernel(query,support)@alpha).float()
        fused=v4.corrected(test_main,scores)
        prob=fused.softmax(-1).cpu().numpy()
        primary_prob=test_main.softmax(-1).cpu().numpy()
        primary_pred=test_main.argmax(-1).cpu().numpy()
        kernel_pred=scores.argmax(-1).cpu().numpy()
        train_acc=float((train_main.argmax(-1)==yt).float().mean())
        loo_train_acc=float((loo_eval.argmax(-1)==yt).float().mean())
    info=dict(job=job,subject=s,fold=fi,initial_state_sha256=initial_hash,
              main_accuracy=float((primary_pred==y[te]).mean()),
              fused_accuracy=float((prob.argmax(-1)==y[te]).mean()),
              kernel_accuracy=float((kernel_pred==y[te]).mean()),
              main_train_accuracy=train_acc,loo_train_accuracy=loo_train_acc,
              conflicts=conflicts,trace=trace,seconds=time.time()-start,
              peak_cuda_allocated_bytes=torch.cuda.max_memory_allocated())
    # Check that corresponding arms start with identical weights.
    for method in ('ce','protected','additive'):
        other=OUT/job_name(dict(job,method=method))/f'{s}-fold{fi}.json'
        if other.exists():
            assert json.loads(other.read_text())['initial_state_sha256']==initial_hash
    weights=dest/f'{s}-fold{fi}.pt'
    temp=weights.with_suffix('.pt.tmp')
    torch.save(dict(state_dict=model.cpu().state_dict(),support=support.cpu(),alpha=alpha.cpu(),
                    train_idx=tr,test_idx=te,job=job,config=v4.config().to_dict()),temp)
    temp.replace(weights)
    atomic_json(dest/f'{s}-fold{fi}.json',info)
    target=dest/f'{s}-fold{fi}.npz'; tmp=target.with_suffix('.npz.tmp')
    with tmp.open('wb') as f:
        np.savez(f,prob=prob,primary_prob=primary_prob,primary_pred=primary_pred,
                 kernel_pred=kernel_pred,train_idx=tr,test_idx=te,y=y[te])
    tmp.replace(target)  # Last-written completion marker.
    print('FOLD_DONE',job_name(job),s,fi,info['main_accuracy'],info['seconds'],flush=True)

def subject(job,s,dest,status):
    with h5py.File(PROJECT/'Processed/BCIC2020Track3.h5','r') as h:
        x=h[f'{s+1:02d}/X'][:]; y=h[f'{s+1:02d}/Y'][:].astype(np.int64)
    x=mask_input(x,job['condition'])
    pred=np.full(350,-1); main=pred.copy(); kern=pred.copy(); fold=pred.copy()
    for fi,(tr,te) in enumerate(KFold(5,shuffle=False).split(x)):
        status.update(subject=s,fold=fi,updated=time.time())
        atomic_json(ROOT/'status.json',status)
        p=dest/f'{s}-fold{fi}.npz'
        if not p.exists(): train_fold(x,y,tr,te,job,s,fi,dest)
        with np.load(p) as d:
            assert np.array_equal(d['train_idx'],tr) and np.array_equal(d['test_idx'],te)
            assert np.array_equal(d['y'],y[te])
            pred[te]=d['prob'].argmax(-1);main[te]=d['primary_pred'];kern[te]=d['kernel_pred'];fold[te]=fi
    assert np.all(fold>=0)
    p=dest/f'{s}-predictions.npz';tmp=p.with_suffix('.npz.tmp')
    with tmp.open('wb') as f: np.savez(f,pred=pred,primary_pred=main,kernel_pred=kern,y=y,fold=fold)
    tmp.replace(p)

def report():
    result=[]
    for job in JOBS:
        dest=OUT/job_name(job); rows=[]
        for s in range(15):
            p=dest/f'{s}-predictions.npz'
            if not p.exists(): continue
            with np.load(p) as d:
                rows.append(dict(subject=s,main=float((d['primary_pred']==d['y']).mean()),
                                 fused=float((d['pred']==d['y']).mean()),
                                 kernel=float((d['kernel_pred']==d['y']).mean()),
                                 main_macro_f1=float(f1_score(d['y'],d['primary_pred'],average='macro'))))
        result.append(dict(job=job,n_subjects=len(rows),complete=len(rows)==15,subjects=rows,
                           means={k:float(np.mean([r[k] for r in rows])) for k in
                                  ['main','fused','kernel','main_macro_f1']} if rows else {}))
    atomic_json(ROOT/'summary.json',dict(runs=result,complete=all(r['complete'] for r in result)))

def smoke():
    v4.smoke()
    v4.seed_all(7)
    # Algebraic derivative check at full FP32 precision; training retains the
    # historical medium setting via seed_all in every fold.
    torch.set_float32_matmul_precision('highest')
    m=v4.FAST(v4.config()).cuda().eval()
    x=torch.randn(10,64,800,device='cuda');y=torch.arange(10,device='cuda')%5
    assert torch.equal(m(x),v4.representation(m,x)[0])
    # Direct-add gradients agree with derivative of the scalar summed objective.
    logits,q=v4.representation(m,x)
    lm=F.cross_entropy(logits,y);la=.3*F.cross_entropy(4*v4.ridge_fit(q,y)[1],y)
    params=list(m.parameters())
    gm=torch.autograd.grad(lm,params,retain_graph=True,allow_unused=True)
    ga=torch.autograd.grad(la,params,retain_graph=True,allow_unused=True)
    both=torch.autograd.grad(lm+la,params,allow_unused=True)
    for p,a,b,c in zip(params,gm,ga,both):
        z=torch.zeros_like(p);a=z if a is None else a;b=z if b is None else b;c=z if c is None else c
        assert torch.allclose(a+b,c,atol=1e-5,rtol=1e-3)
    arr=np.ones((2,64,800),np.float32)
    assert np.all(arr==1)
    coverage=np.zeros(800,int)
    for st in range(0,501,125): coverage[st:st+250]+=1
    assert np.array_equal(coverage[:128],coverage[622:750][::-1])
    for cond in ['remove_pre','remove_late']:
        z=mask_input(arr,cond);assert np.sum(z[0,0]==0)==128 and np.all(arr==1)
    atomic_json(ROOT/'smoke.json',dict(passed=True,time=time.time(),checks=[
        'historical LOO formula and protected gradients','main forward exactly equals FAST',
        'direct-add gradients match summed loss','128-sample masks with mirrored window coverage']))
    print('MECHANISM_SMOKE_OK',flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');ap.add_argument('--report',action='store_true')
    args=ap.parse_args();torch.set_num_threads(8)
    if args.smoke:smoke();return
    if args.report:report();return
    OUT.mkdir(exist_ok=True)
    with (ROOT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        m=manifest();mp=ROOT/'manifest.json'
        if mp.exists(): assert json.loads(mp.read_text())==json.loads(json.dumps(m)), 'Manifest changed; use a new directory'
        else: atomic_json(mp,m)
        status=dict(state='running',pid=os.getpid(),started=time.time(),completed_jobs=[],total_jobs=len(JOBS))
        try:
            for i,job in enumerate(JOBS):
                status.update(job_index=i,job=job,subject=0,fold=0)
                dest=OUT/job_name(job);dest.mkdir(exist_ok=True)
                for s in range(15):subject(job,s,dest,status);report()
                status['completed_jobs'].append(job_name(job))
                atomic_json(ROOT/'status.json',status)
            status['state']='complete';report()
        except Exception as e:
            status.update(state='failed',error=repr(e));raise
        finally:
            status['updated']=time.time();atomic_json(ROOT/'status.json',status)

if __name__=='__main__':main()
