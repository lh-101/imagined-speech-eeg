from pathlib import Path
import os,sys,json,subprocess,time
ROOT=Path(__file__).resolve().parent
assert json.loads((ROOT/'smoke.json').read_text())['passed']
for folder in Path('/proc').iterdir():
 if not folder.name.isdigit():continue
 try:cmd=(folder/'cmdline').read_bytes()
 except OSError:continue
 if str(ROOT/'run_control.py').encode() in cmd:raise RuntimeError('Control already running')
with (ROOT/'train.log').open('a') as log:
 p=subprocess.Popen([sys.executable,'-u',str(ROOT/'run_control.py')],cwd='/root/FAST',stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,PYTHONUNBUFFERED='1',OMP_NUM_THREADS='8',OPENBLAS_NUM_THREADS='8'))
(ROOT/'pid').write_text(str(p.pid))
print(json.dumps(dict(launched=True,pid=p.pid,folds=75,log=str(ROOT/'train.log'))))
