from pathlib import Path
import json,time,numpy as np
ROOT=Path(__file__).resolve().parent
BASE=Path('/root/FAST/experiments/mechanism_20260927/results')
status=json.loads((ROOT/'status.json').read_text())
files=list((ROOT/'results').glob('*/*-fold*.npz'))
seconds=[]
for p in (ROOT/'results').glob('*/*-fold*.json'):
 seconds.append(json.loads(p.read_text())['seconds'])
print(json.dumps(dict(state=status['state'],completed_folds=len(files),total_folds=225,percent=round(100*len(files)/225,1),current=status.get('job'),subject=status.get('subject'),fold=status.get('fold'),elapsed_seconds=time.time()-status['started'],estimated_remaining_seconds=None if not seconds else (225-len(files))*float(np.mean(seconds)),measured_seconds_per_fold=None if not seconds else float(np.mean(seconds))),indent=2))
if len(files)!=225:raise SystemExit(0)
rows=[]
for s in range(15):
 means={k:[] for k in ('ce','loo','self')}
 for seed in (42,142,242):
  pred={k:[] for k in means};targets=[]
  for fold in range(5):
   paths={'ce':BASE/f'full_ce_seed{seed}'/f'{s}-fold{fold}.npz','loo':BASE/f'full_additive_seed{seed}'/f'{s}-fold{fold}.npz','self':ROOT/'results'/f'self_support_additive_seed{seed}'/f'{s}-fold{fold}.npz'}
   data={k:np.load(p) for k,p in paths.items()}
   for k in means:
    assert np.array_equal(data[k]['y'],data['ce']['y'])
    assert np.array_equal(data[k]['train_idx'],data['ce']['train_idx'])
    assert np.array_equal(data[k]['test_idx'],data['ce']['test_idx'])
    pred[k].extend(data[k]['primary_pred'].tolist())
   targets.extend(data['ce']['y'].tolist())
  for k in means:means[k].append(float((np.array(pred[k])==targets).mean()))
 rows.append(dict(subject=s,**{k:float(np.mean(v)) for k,v in means.items()},per_seed=means))
d=100*np.array([r['loo']-r['self'] for r in rows])
rng=np.random.default_rng(20261004)
boot=d[rng.integers(0,15,(10000,15))].mean(1)
signs=2*((np.arange(2**15)[:,None]>>np.arange(15))&1)-1
p=float((np.abs((signs*d).mean(1))>=abs(d.mean())-1e-12).mean())
result=dict(complete=True,n_subjects=15,seeds=[42,142,242],means_percent={k:100*float(np.mean([r[k] for r in rows])) for k in ('ce','loo','self')},primary_loo_minus_self_pp=float(d.mean()),subject_bootstrap_95ci_pp=np.quantile(boot,[.025,.975]).tolist(),exact_two_sided_subject_sign_flip_p=p,positive_subjects=int((d>0).sum()),negative_subjects=int((d<0).sum()),subjects=rows,note='Exploratory fixed-hyperparameter component comparison on previously examined folds. Subject-level unit; seed means not independent subjects. Does not prove universal necessity or exclude all alternative auxiliary objectives.')
(ROOT/'paired_analysis.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
