"""Frozen self-support kernel control; reuse historical CE and LOO-Add anchors."""
from pathlib import Path
import importlib.util,sys,json,os,time,argparse
import torch
BASE=Path('/root/FAST/experiments/mechanism_20260927')
spec=importlib.util.spec_from_file_location('mechanism',BASE/'run_mechanism_study.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
ROOT=Path(__file__).resolve().parent
m.ROOT=ROOT;m.OUT=ROOT/'results'
m.JOBS=[dict(method='additive',condition='self_support',seed=s) for s in (42,142,242)]
m.MASKS={'self_support':None}
original_representation=m.v4.representation
original_ridge=m.v4.ridge_fit

def self_support(q,y):
 k=m.v4.kernel(q,q)
 chol=torch.linalg.cholesky(k+m.v4.CFG['ridge']*torch.eye(len(q),device=q.device,dtype=k.dtype))
 target=m.F.one_hot(y,5).to(k.dtype)
 alpha=torch.cholesky_solve(target,chol)
 return alpha,(k@alpha).float()
m.v4.ridge_fit=self_support
original_manifest=m.manifest

def manifest():
 r=original_manifest()
 r['source_hashes'][str(Path(__file__))]=m.sha(Path(__file__))
 r['source_hashes'][str(BASE/'run_mechanism_study.py')]=m.sha(BASE/'run_mechanism_study.py')
 r['primary_endpoint']='subject mean main-head accuracy: historical LOO-Add minus self-support kernel control, paired by subject and seed'
 r['note']='All 15 subjects, five historical folds, seeds42/142/242. All historical anchors reused. Same joint representation/ridge/gamma/score_scale/aux_weight/optimizer/precision/initial weights; only in-sample kernel scores replace LOO scores. No performance-based selection or early stop. Previously explored data; exploratory component evidence.'
 r['secondary_endpoints']=['macro F1','self-support training accuracy (base loo_train_accuracy field is renamed after completion)']
 r.pop('temporal_control',None)
 r['historical_manifest_sha256']=m.sha(BASE/'manifest.json')
 return r
m.manifest=manifest
original_train=m.train_fold

def train(x,y,tr,te,job,s,fi,dest):
 anchor=BASE/'results'/f"full_additive_seed{job['seed']}"/f'{s}-fold{fi}.json'
 assert anchor.exists(),f'Missing historical anchor {anchor}'
 m.v4.seed_all(job['seed']+s*5+fi)
 model=m.v4.FAST(m.v4.config()).cuda()
 assert m.state_hash(model)==json.loads(anchor.read_text())['initial_state_sha256'],'Initialization mismatch'
 del model
 original_train(x,y,tr,te,job,s,fi,dest)
 info_path=dest/f'{s}-fold{fi}.json'
 info=json.loads(info_path.read_text())
 assert info['initial_state_sha256']==json.loads(anchor.read_text())['initial_state_sha256']
 info['self_support_train_accuracy']=info.pop('loo_train_accuracy')
 info['control']='self-support kernel supervision; unchanged joint representation'
 m.atomic_json(info_path,info)
m.train_fold=train

def smoke():
 torch.set_num_threads(8)
 torch.manual_seed(104)
 q=m.F.normalize(torch.randn(12,16,device='cuda'),dim=-1).requires_grad_()
 y=torch.arange(12,device='cuda')%5
 alpha,scores=self_support(q,y)
 a=m.v4.kernel(q,q)+.1*torch.eye(12,device='cuda',dtype=torch.float64)
 target=m.F.one_hot(y,5).double()
 assert torch.allclose(a@alpha,target,atol=1e-8,rtol=1e-8)
 oldalpha,loo=original_ridge(q,y)
 assert torch.allclose(alpha,oldalpha,atol=1e-8,rtol=1e-8)
 assert not torch.allclose(scores,loo)
 loss=.3*m.F.cross_entropy(4*scores,y)
 g=torch.autograd.grad(loss,q)[0]
 assert torch.isfinite(g).all() and g.norm()>0
 # Check full-sized historical one-fold initialization and finite forward gradients.
 import h5py,numpy as np
 with h5py.File('/root/FAST/Processed/BCIC2020Track3.h5','r') as h:
  x=h['01/X'][:];yy=h['01/Y'][:].astype(np.int64)
 tr,te=next(m.KFold(5,shuffle=False).split(x))
 m.v4.seed_all(42)
 model=m.v4.FAST(m.v4.config()).cuda()
 anchor=json.loads((BASE/'results/full_additive_seed42/0-fold0.json').read_text())
 assert m.state_hash(model)==anchor['initial_state_sha256']
 model.train()
 with torch.autocast('cuda',dtype=torch.bfloat16):
  logits,q=m.v4.representation(model,torch.from_numpy(x[tr]).cuda())
  main=m.F.cross_entropy(logits,torch.from_numpy(yy[tr]).cuda())
 _,scores=self_support(q,torch.from_numpy(yy[tr]).cuda())
 loss=main+.3*m.F.cross_entropy(4*scores,torch.from_numpy(yy[tr]).cuda())
 loss.backward()
 assert all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters())
 assert sum(p.grad.float().square().sum().item() for p in model.parameters() if p.grad is not None)>0
 # Anchor availability is mandatory before launching any jobs.
 for seed in (42,142,242):
  for subject in range(15):
   for fold in range(5):
    for method in ('ce','additive'):
     assert (BASE/'results'/f'full_{method}_seed{seed}'/f'{subject}-fold{fold}.npz').exists()
 m.atomic_json(ROOT/'smoke.json',dict(passed=True,initialization_matched=True,anchors=450,finite_full_fold_backward=True,time=time.time()))
 print('NECESSITY_SMOKE_PASS',flush=True)

if __name__=='__main__':
 if '--smoke' in sys.argv:smoke()
 else:m.main()
