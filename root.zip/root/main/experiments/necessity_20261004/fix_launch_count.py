from pathlib import Path
R=Path('/root/FAST/experiments/necessity_20261004')
p=R/'launch.py';text=p.read_text(encoding='utf-8-sig');p.write_text(text.replace('folds=225','folds=75'))
