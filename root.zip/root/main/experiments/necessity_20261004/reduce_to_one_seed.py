from pathlib import Path
import json,os,signal,time,subprocess,sys
R=Path('/root/FAST/experiments/necessity_20261004')
pid=int((R/'pid').read_text())
proc=Path('/proc')/str(pid)/'cmdline'
if proc.exists():
 args=proc.read_bytes().split(b'\0')
 assert str(R/'run_control.py').encode() in args,'PID does not belong to experiment'
 os.kill(pid,signal.SIGTERM)
 for _ in range(50):
  if not proc.exists() or not proc.read_bytes():break
  time.sleep(.1)
 else:raise RuntimeError('Process did not stop; no files changed')
assert not list((R/'results').glob('self_support_additive_seed142/*-fold*.npz'))
assert not list((R/'results').glob('self_support_additive_seed242/*-fold*.npz'))
stamp=str(int(time.time()))
source=R/'run_control.py';old=source.read_text(encoding='utf-8-sig')
(R/f'run_control_before_single_seed_{stamp}.py').write_text(old)
new=old.replace("m.JOBS=[dict(method='additive',condition='self_support',seed=s) for s in (42,142,242)]","m.JOBS=[dict(method='additive',condition='self_support',seed=s) for s in (42,)]")
assert old!=new
source.write_text(new)
progress=R/'progress_and_analyze.py';old=progress.read_text(encoding='utf-8-sig')
(R/f'progress_before_single_seed_{stamp}.py').write_text(old)
new=old.replace('total_folds=225','total_folds=75').replace('100*len(files)/225','100*len(files)/75').replace('(225-len(files))','(75-len(files))').replace('len(files)!=225','len(files)!=75').replace('for seed in (42,142,242):','for seed in (42,):').replace('seeds=[42,142,242]','seeds=[42]').replace('Subject-level unit; seed means not independent subjects.','Single fixed seed; no claim of robustness across initializations.')
progress.write_text(new)
for name in ('manifest.json','status.json'):
 p=R/name
 if p.exists():p.rename(R/f'{p.stem}_before_single_seed_{stamp}.json')
(R/'scope_amendment.json').write_text(json.dumps(dict(time=time.time(),reason='User requested single seed to reduce runtime; decision based on budget, not outcome',original_seeds=[42,142,242],retained_seeds=[42],planned_new_folds=75,completed_folds_preserved=len(list((R/'results').glob('*/*-fold*.npz'))),stopped_pid=pid,partial_in_progress_fold_will_restart=True,note='Original protocol and code archived; historical multi-seed results are not overwritten. Only seed42 historical anchors used for this component comparison.'),indent=2))
ret=subprocess.run([sys.executable,str(R/'launch.py')],check=True)
