"""Exploratory full-map routing diagnostic; synthetic data, CPU only.

This is not an implementation of official mHC/oHC and establishes no novelty.
See 路由诊断协议.md for fixed measurement and interpretation boundaries.
"""
import argparse
import copy
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import time
import traceback

os.environ['CUDA_VISIBLE_DEVICES'] = ''
import torch
from torch import nn
from torch.nn import functional as F

ROOT = Path(__file__).resolve().parent
ARCHES = ['residual_mlp', 'small_transformer']
TASKS = ['smooth_teacher', 'content_selection']
ARMS = ['dynamic', 'static', 'weak', 'router_spectral', 'all_linear_spectral']
DEPTHS = [4, 8, 16]
WIDTH = 16
STEPS = 200
SEED = 20261006
TOTAL = len(ARCHES)*len(TASKS)*len(ARMS)*len(DEPTHS)
STOP = False


def atomic_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(obj, indent=2, allow_nan=False), encoding='utf8')
    temp.replace(path)


def state_hash(model):
    h = hashlib.sha256()
    for name, value in model.state_dict().items():
        h.update(name.encode()); h.update(value.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()


class Linear(nn.Linear):
    def __init__(self, *args, cap=None):
        super().__init__(*args)
        self.cap = cap

    def forward(self, x):
        w = self.weight
        if self.cap is not None:
            # Exact matrix norm of the actual effective weight, not an unverified
            # finite power-iteration estimate. Bias is unchanged.
            sigma = torch.linalg.vector_norm(w) if w.shape[0] == 1 else torch.linalg.matrix_norm(w, ord=2)
            w = w / (sigma/self.cap).clamp_min(1.0)
        return F.linear(x, w, self.bias)


def rotate(h, theta):
    c, s = theta.cos().unsqueeze(-1), theta.sin().unsqueeze(-1)
    a, b = h[..., 0, :], h[..., 1, :]
    return torch.stack((c*a-s*b, s*a+c*b), dim=-2)


class Router(nn.Module):
    def __init__(self, arm):
        super().__init__()
        self.arm = arm
        self.head = Linear(WIDTH, 1, cap=.25 if arm in ['router_spectral', 'all_linear_spectral'] else None)
        nn.init.zeros_(self.head.bias)

    def angle(self, h):
        context = F.layer_norm(h, (WIDTH,)).mean(dim=-2)
        if self.arm == 'static':
            context = context*0.0
        theta = self.head(context).squeeze(-1).tanh()
        return theta*.25 if self.arm == 'weak' else theta

    def forward(self, h, frozen=None):
        theta = self.angle(h) if frozen is None else frozen
        return rotate(h, theta), theta


class Block(nn.Module):
    def __init__(self, arch, arm, depth):
        super().__init__()
        cap = 1.0 if arm == 'all_linear_spectral' else None
        self.arch, self.step = arch, 1/math.sqrt(2*depth)
        self.router = Router(arm)
        self.ln_ff = nn.LayerNorm(WIDTH)
        self.ff1, self.ff2 = Linear(WIDTH, 32, cap=cap), Linear(32, WIDTH, cap=cap)
        if arch == 'small_transformer':
            self.ln_att = nn.LayerNorm(WIDTH)
            self.qkv = Linear(WIDTH, 3*WIDTH, cap=cap)
            self.att_out = Linear(WIDTH, WIDTH, cap=cap)

    def attention(self, z):
        b, tokens, streams, d = z.shape
        z = z.permute(0, 2, 1, 3).reshape(b*streams, tokens, d)
        q, k, v = self.qkv(z).reshape(b*streams, tokens, 3, 2, d//2).unbind(2)
        q, k, v = (a.transpose(1, 2) for a in (q, k, v))
        a = (q @ k.transpose(-2, -1) / math.sqrt(d//2)).softmax(-1)
        z = (a @ v).transpose(1, 2).reshape(b*streams, tokens, d)
        return self.att_out(z).reshape(b, streams, tokens, d).permute(0, 2, 1, 3)

    def forward(self, h, frozen=None):
        h, theta = self.router(h, frozen)
        if self.arch == 'small_transformer':
            h = h + self.step*self.attention(self.ln_att(h))
        h = h + self.step*self.ff2(F.gelu(self.ff1(self.ln_ff(h))))
        return h, theta


class Model(nn.Module):
    def __init__(self, arch, arm, depth):
        super().__init__()
        self.arch, self.arm = arch, arm
        cap = 1.0 if arm == 'all_linear_spectral' else None
        self.embed = Linear(35 if arch == 'residual_mlp' else 7, 2*WIDTH, cap=cap)
        self.blocks = nn.ModuleList(Block(arch, arm, depth) for _ in range(depth))
        self.final_ln = nn.LayerNorm(2*WIDTH)
        self.head = Linear(2*WIDTH, 2, cap=cap)

    def forward(self, x, frozen=None, capture=False):
        if self.arch == 'residual_mlp':
            h = self.embed(x.flatten(1)).reshape(len(x), 2, WIDTH)
        else:
            h = self.embed(x).reshape(len(x), 5, 2, WIDTH)
        angles, incoming = [], []
        for i, block in enumerate(self.blocks):
            if capture:
                incoming.append(h)
            h, theta = block(h, None if frozen is None else frozen[i])
            angles.append(theta)
        pooled = h if self.arch == 'residual_mlp' else h.mean(dim=1)
        out = self.head(self.final_ln(pooled.flatten(1)))
        return out, h, angles, incoming


def make_data(task):
    g = torch.Generator().manual_seed(SEED + (100 if task == TASKS[0] else 200))
    if task == 'smooth_teacher':
        tw1 = torch.randn(35, 32, generator=g)/math.sqrt(35)
        tw2 = torch.randn(32, 2, generator=g)/math.sqrt(32)
        def oracle(x):
            return (x.flatten(1) @ tw1).tanh() @ tw2
        def sample(n):
            x = torch.randn(n, 5, 7, generator=g)*.5
            return x, oracle(x)
        indices = torch.arange(35)
    else:
        def oracle(x):
            match = (x[:, 1:, :4]*x[:, :1, :4]).sum(-1)
            return (match.unsqueeze(-1)*x[:, 1:, 4:6]).sum(1)
        def sample(n):
            x = torch.zeros(n, 5, 7)
            keys = torch.rand(n, 4, generator=g).argsort(1)
            x[:, 1:, :4] = F.one_hot(keys, num_classes=4).float()
            query = torch.randint(0, 4, (n,), generator=g)
            x[:, 0, :4] = F.one_hot(query, num_classes=4).float()
            x[:, 0, 6] = 1
            x[:, 1:, 4:6] = torch.rand(n, 4, 2, generator=g)*2-1
            return x, oracle(x)
        indices = torch.tensor([7*t+j for t in range(1, 5) for j in [4, 5]])
    train, val, test = sample(512), sample(256), sample(512)
    noise = torch.zeros_like(test[0]).flatten(1)
    noise[:, indices] = torch.randn(512, len(indices), generator=g)*.01
    nx = test[0]+noise.reshape_as(test[0])
    noisy = nx, oracle(nx)
    return dict(train=train, val=val, test=test, noisy=noisy, indices=indices,
                hashes={name: hashlib.sha256(x.numpy().tobytes()+y.numpy().tobytes()).hexdigest()
                        for name, (x, y) in [('train', train), ('validation', val), ('test', test), ('noisy_test', noisy)]})


def norm2(j):
    return float(torch.linalg.matrix_norm(j, ord=2))


def local_router_probe(router, state):
    # Per-token route depends only on the two current streams for that token.
    z = state.reshape(-1, 2, WIDTH)[0].clone().detach()
    theta = router.angle(z.unsqueeze(0)).detach()
    def fn(t):
        return router(t.reshape(1, 2, WIDTH))[0].flatten()
    jac = torch.autograd.functional.jacobian(fn, z.flatten(), vectorize=True, strategy='forward-mode')
    rotated = rotate(z.unsqueeze(0), theta)
    c, s = theta.cos().item(), theta.sin().item()
    matrix = torch.tensor([[c, -s], [s, c]], dtype=torch.float64)
    return {'conditional_matrix_norm':norm2(matrix), 'full_local_map_norm':norm2(jac),
            'orthogonality_error':float((matrix.T @ matrix-torch.eye(2, dtype=torch.float64)).abs().max()),
            'relative_state_norm_error':float((rotated.norm()-z.norm()).abs()/(z.norm()+1e-12))}


def diagnostics(model, data, finite_difference=False):
    m = copy.deepcopy(model).double().eval()
    indices = data['indices']
    records = []
    for sample in [0, 17, 42]:
        base = data['val'][0][sample:sample+1].double()
        with torch.no_grad():
            out, h, cache, incoming = m(base, capture=True)
        cache = [a.detach().clone() for a in cache]
        size = h.numel()
        def fn(z, frozen):
            delta = torch.zeros(35, dtype=torch.float64).scatter(0, indices, z)
            prediction, state, _, _ = m(base+delta.reshape(1, 5, 7), cache if frozen else None)
            return torch.cat((state.flatten(), prediction.flatten()))
        z = torch.zeros(len(indices), dtype=torch.float64)
        jf = torch.autograd.functional.jacobian(lambda t:fn(t, False), z, vectorize=True, strategy='forward-mode')
        jc = torch.autograd.functional.jacobian(lambda t:fn(t, True), z, vectorize=True, strategy='forward-mode')
        assert torch.isfinite(jf).all() and torch.isfinite(jc).all()
        r = {'sample':sample, 'input_coordinates':len(indices)}
        for part, a, b in [('hidden', jf[:size], jc[:size]), ('prediction', jf[size:], jc[size:])]:
            full, frozen, diff = norm2(a), norm2(b), norm2(a-b)
            r[part] = {'full_norm':full, 'cached_route_norm':frozen, 'feedback_difference_norm':diff,
                       'norm_ratio':full/max(frozen, 1e-12), 'feedback_relative':diff/max(frozen, 1e-12)}
        if sample == 0:
            r['local_router_first'] = local_router_probe(m.blocks[0].router, incoming[0])
            r['local_router_last'] = local_router_probe(m.blocks[-1].router, incoming[-1])
        # Independently check the numerical derivative on both mappings.
        if sample == 0 or finite_difference:
            direction = torch.linspace(-1, 1, len(z), dtype=torch.float64)
            direction = direction/direction.norm()
            errors = {}
            for frozen, jac in [(False, jf), (True, jc)]:
                eps = 1e-5
                with torch.no_grad():
                    fd = (fn(z+eps*direction, frozen)-fn(z-eps*direction, frozen))/(2*eps)
                error = float((fd-jac @ direction).norm()/(fd.norm()+1e-12))
                assert error < 3e-4, ('Jacobian finite-difference mismatch', model.arch, model.arm, error)
                errors['cached' if frozen else 'full'] = error
            r['finite_difference_relative_error'] = errors
        records.append(r)
    return records


def mse(model, pair):
    model.eval()
    with torch.no_grad():
        value = F.mse_loss(model(pair[0])[0], pair[1]).item()
    assert math.isfinite(value)
    return value


def key(arch, task, depth, arm):
    return f'{arch}__{task}__d{depth}__{arm}'


def build(arch, arm, depth):
    torch.manual_seed(SEED + 10*depth + ARCHES.index(arch))
    return Model(arch, arm, depth)


def protocol():
    p = {'created':time.time(), 'device':'cpu', 'threads':2, 'torch':torch.__version__,
         'architectures':ARCHES, 'tasks':TASKS, 'arms':ARMS, 'depths':DEPTHS,
         'steps':STEPS, 'batch':64, 'lr':.002, 'weight_decay':.0001, 'width':WIDTH,
         'seed':SEED, 'total_fits':TOTAL, 'diagnostics_at_steps':[0, STEPS],
         'probe_validation_indices':[0,17,42], 'data_sha256':{t:make_data(t)['hashes'] for t in TASKS},
         'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'protocol_sha256':hashlib.sha256((ROOT/'路由诊断协议.md').read_bytes()).hexdigest(),
         'limitations':'Exploratory single-seed simplified networks, not official mHC/oHC. Static has lower effective routing capacity. No novelty certification or proof of harmful feedback.'}
    path = ROOT/'protocol.json'
    if path.exists():
        old = json.loads(path.read_text())
        for field in ['script_sha256', 'protocol_sha256', 'data_sha256', 'steps', 'seed']:
            assert old[field] == p[field], ('Existing incompatible protocol', field)
        return old
    atomic_json(path, p)
    return p


def train_case(arch, task, depth, arm, steps=STEPS, save_result=True):
    case = key(arch, task, depth, arm)
    target = ROOT/'results'/(case+'.json')
    if save_result and target.exists():
        return json.loads(target.read_text())
    start = time.time()
    data = make_data(task)
    model = build(arch, arm, depth)
    initial_hash = state_hash(model)
    initial_diag = diagnostics(model, data)
    curve = [{'step':0, 'train_mse':mse(model, data['train']), 'validation_mse':mse(model, data['val'])}]
    opt = torch.optim.AdamW(model.parameters(), lr=.002, weight_decay=.0001)
    batches = torch.Generator().manual_seed(SEED+777)
    training_started = time.time()
    for step in range(1, steps+1):
        if STOP:
            raise InterruptedError('Explicit stop requested; completed cases retained')
        model.train()
        ids = torch.randint(0, 512, (64,), generator=batches)
        opt.zero_grad(set_to_none=True)
        loss = F.mse_loss(model(data['train'][0][ids])[0], data['train'][1][ids])
        assert torch.isfinite(loss)
        loss.backward()
        assert all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters())
        opt.step()
        if step % 50 == 0 or step == steps:
            row = {'step':step, 'train_mse':mse(model, data['train']), 'validation_mse':mse(model, data['val'])}
            curve.append(row)
            print('TRAIN',case,json.dumps(row),flush=True)
    training_seconds = time.time()-training_started
    final_diag = diagnostics(model, data)
    result = {'case':case, 'arch':arch, 'task':task, 'depth':depth, 'arm':arm, 'steps':steps,
              'initial_state_sha256':initial_hash, 'final_state_sha256':state_hash(model),
              'total_parameters':sum(p.numel() for p in model.parameters()),
              'effective_router_parameters':depth*(1 if arm=='static' else WIDTH+1),
              'training_seconds':training_seconds, 'seconds':time.time()-start,
              'curve':curve, 'test_mse':mse(model, data['test']), 'noisy_test_mse':mse(model, data['noisy']),
              'constant_predictor_test_mse':float(F.mse_loss(data['train'][1].mean(0).expand_as(data['test'][1]),data['test'][1])),
              'initial_diagnostics':initial_diag, 'final_diagnostics':final_diag,
              'finite':True, 'data_sha256':data['hashes']}
    if save_result:
        target.parent.mkdir(exist_ok=True)
        cp = target.with_suffix('.pt')
        tmp = cp.with_suffix('.pt.tmp')
        torch.save({'model':model.state_dict(),'configuration':{'arch':arch,'arm':arm,'depth':depth}, 'seed':SEED},tmp)
        tmp.replace(cp)
        atomic_json(target,result)
    print('CASE_DONE',case,json.dumps({'test_mse':result['test_mse'],'seconds':result['seconds']}),flush=True)
    return result


def summarize():
    rows = [json.loads(p.read_text()) for p in sorted((ROOT/'results').glob('*.json'))]
    table, comparisons = [], []
    for r in rows:
        probes = r['final_diagnostics']
        mean = lambda part, field:sum(v[part][field] for v in probes)/len(probes)
        table.append({k:r[k] for k in ['case','arch','task','depth','arm','test_mse','noisy_test_mse','total_parameters','effective_router_parameters','seconds']} | {
            'hidden_norm_ratio':mean('hidden','norm_ratio'), 'prediction_norm_ratio':mean('prediction','norm_ratio'),
            'hidden_feedback_relative':mean('hidden','feedback_relative'), 'prediction_feedback_relative':mean('prediction','feedback_relative')})
    by = {r['case']:r for r in rows}
    for arch in ARCHES:
        for task in TASKS:
            for depth in DEPTHS:
                group = [by.get(key(arch,task,depth,a)) for a in ARMS]
                if not all(group):continue
                assert len({r['initial_state_sha256'] for r in group})==1
                assert len({json.dumps(r['data_sha256'],sort_keys=True) for r in group})==1
                dynamic = group[0]
                comparisons.append({'arch':arch,'task':task,'depth':depth,
                    'dynamic_test_mse':dynamic['test_mse'],
                    'control_minus_dynamic_mse':{r['arm']:r['test_mse']-dynamic['test_mse'] for r in group[1:]},
                    'paired_initial_parameters_and_data':True})
    summary = {'complete':len(rows)==TOTAL,'completed_cases':len(rows),'total_cases':TOTAL,'table':table,'paired_groups':comparisons,
               'interpretation':'Descriptive exploratory results only; feedback is not automatically harmful; no foundational novelty is established.'}
    atomic_json(ROOT/'summary.json',summary)
    if len(rows)==TOTAL:
        lines = ['# 路由诊断已完成：描述性结果','',
                 '全部60个预设条件保留。简化网络、单种子筛查，不能据此认定新原理成立或官方多流模型存在故障。',
                 '下表均方误差越低越好；比值为完整预测Jacobian范数/缓存路由预测Jacobian范数，三个验证样本平均。',
                 '反馈差异是导数测量，不能代替性能因果证据。固定路由实际自由度较小。','',
                 '|骨干|任务|深度|条件|测试MSE|扰动后MSE|预测导数范数比|隐藏反馈相对值|',
                 '|---|---|---:|---|---:|---:|---:|---:|']
        for r in table:
            lines.append(f"|{r['arch']}|{r['task']}|{r['depth']}|{r['arm']}|{r['test_mse']:.5f}|{r['noisy_test_mse']:.5f}|{r['prediction_norm_ratio']:.3f}|{r['hidden_feedback_relative']:.3f}|")
        lines += ['', '判读需同时检查学习曲线、普通约束对照和两类任务，不取单一最优条件下结论。当前报告只提供测量，不将相减导数归因为有害机制。', '',
                  '流程来源：Kassis et al. (2026), Scientific Agent Skills, https://doi.org/10.48550/arXiv.2609.00065 。']
        (ROOT/'diagnostic_conclusion.md').write_text('\n'.join(lines),encoding='utf8')
    return summary


def smoke():
    protocol()
    records=[]
    for arch in ARCHES:
        hashes=[]
        for arm in ARMS:
            result=train_case(arch,'content_selection',4,arm,steps=2,save_result=False)
            hashes.append(result['initial_state_sha256'])
            if arm=='static':
                for when in ['initial_diagnostics','final_diagnostics']:
                    assert all(v['hidden']['feedback_relative']<1e-10 and v['prediction']['feedback_relative']<1e-10 for v in result[when])
            for v in result['final_diagnostics']:
                if 'local_router_first' in v:
                    for field in ['local_router_first','local_router_last']:
                        assert v[field]['orthogonality_error']<1e-10
                        assert v[field]['relative_state_norm_error']<1e-10
            records.append({'arch':arch,'arm':arm,'seconds':result['seconds'],'finite':True})
        assert len(set(hashes))==1
    # Check the known rotation counterexample independently of learned networks.
    x=torch.tensor([1.,0.],dtype=torch.float64)
    def toy(v):
        t=v[1]
        return torch.stack((t.cos()*v[0]-t.sin()*v[1],t.sin()*v[0]+t.cos()*v[1]))
    j=torch.autograd.functional.jacobian(toy,x)
    assert torch.allclose(j,torch.diag(torch.tensor([1.,2.],dtype=torch.float64)))
    # A bounded runtime benchmark at deepest configuration, not used to tune scores.
    deep=build('small_transformer','dynamic',16)
    data=make_data('smooth_teacher')
    opt=torch.optim.AdamW(deep.parameters(),lr=.002)
    start=time.time()
    for _ in range(10):
        opt.zero_grad(set_to_none=True)
        F.mse_loss(deep(data['train'][0][:64])[0],data['train'][1][:64]).backward();opt.step()
    deep_seconds_per_step=(time.time()-start)/10
    dstart=time.time();diagnostics(deep,data);deep_diag_seconds=time.time()-dstart
    estimate=(deep_seconds_per_step*STEPS+deep_diag_seconds*2)*TOTAL
    atomic_json(ROOT/'smoke.json',{'passed':True,'checks':records,'static_feedback_zero':True,
        'finite_difference_checked':True,'orthogonality_norm_preservation_checked':True,
        'toy_jacobian_correct':True,'paired_initial_hashes_checked':True,
        'deepest_seconds_per_step':deep_seconds_per_step,'deepest_diagnostics_seconds':deep_diag_seconds,
        'conservative_runtime_estimate_minutes':estimate/60,'device':'cpu','GPU_used':False})
    print('SMOKE_OK',json.dumps({'passed':True,'estimated_minutes':estimate/60,'deepest_seconds_per_step':deep_seconds_per_step}),flush=True)


def get_status():
    path=ROOT/'status.json'
    if not path.exists():return {'state':'not_started'}
    s=json.loads(path.read_text())
    s['process_present']=Path('/proc',str(s.get('pid'))).exists()
    done=[json.loads(p.read_text()) for p in (ROOT/'results').glob('*.json')]
    s['completed_cases']=len(done);s['total_cases']=TOTAL;s['percent']=round(100*len(done)/TOTAL,1)
    s['elapsed_minutes']=(time.time()-s['started'])/60
    by_arch={arch:[r['seconds'] for r in done if r['arch']==arch] for arch in ARCHES}
    default=json.loads((ROOT/'smoke.json').read_text())['conservative_runtime_estimate_minutes']*60/TOTAL
    remaining=0
    for arch in ARCHES:
        observed=by_arch[arch]
        seconds=sum(observed)/len(observed) if observed else default
        remaining+=(TOTAL//2-len(observed))*seconds
    s['estimated_remaining_minutes']=remaining/60
    s['heuristic_range_minutes']=[remaining/60*.6,remaining/60*1.8]
    s['device']='cpu'
    s['ETA_limits']='Approximate timing only; initial shallow cases may underestimate deeper cases.'
    if s.get('state')!='running':s['estimated_remaining_minutes']=0 if s['state']=='complete' else None
    return s


def run():
    protocol()
    assert json.loads((ROOT/'smoke.json').read_text())['passed']
    tasks=[(a,t,d,r) for d in DEPTHS for t in TASKS for a in ARCHES for r in ARMS]
    # Predetermined deep timing cases first; all cases retained regardless of score.
    first=[('residual_mlp','smooth_teacher',16,'dynamic'),('small_transformer','smooth_teacher',16,'dynamic')]
    tasks=first+[t for t in tasks if t not in first]
    status={'state':'running','pid':os.getpid(),'started':time.time(),'total_cases':TOTAL,'device':'cpu'}
    with (ROOT/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            for arch,task,depth,arm in tasks:
                status.update(current={'arch':arch,'task':task,'depth':depth,'arm':arm},updated=time.time(),completed_cases=len(list((ROOT/'results').glob('*.json'))))
                atomic_json(ROOT/'status.json',status)
                train_case(arch,task,depth,arm)
                summarize()
            result=summarize();assert result['complete']
            status.update(state='complete',completed_cases=TOTAL)
        except InterruptedError as e:
            status.update(state='stopped',error=str(e));print('STOPPED',str(e),flush=True)
        except BaseException as e:
            status.update(state='failed',error=repr(e));traceback.print_exc();raise
        finally:
            status.update(updated=time.time(),completed_cases=len(list((ROOT/'results').glob('*.json'))))
            atomic_json(ROOT/'status.json',status)


def stop_handler(signum, frame):
    global STOP
    STOP=True


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');ap.add_argument('--status',action='store_true');ap.add_argument('--watch',action='store_true');args=ap.parse_args()
    torch.set_num_threads(2);torch.set_num_interop_threads(1)
    signal.signal(signal.SIGTERM,stop_handler)
    if args.smoke:smoke()
    elif args.status or args.watch:
        while True:
            print(json.dumps(get_status(),indent=2),flush=True)
            if not args.watch:break
            time.sleep(5)
    else:run()
