"""
Single-channel leave-one-out importance probe for FAST on BCIC2020 Track 3.

WHY THIS REPLACES THE ZONE PROBE. The zone probe (zone_probe.py) found that
cross-subject importance maps ARE consistent (mean pairwise r = 0.3441 vs a
permutation null of 0.0000 +- 0.0264; split-half reliability 0.8062). But it could
not be interpreted, because the size-matched random control turned out to be BIASED:
the size-weighted average excess over the paper's 8 zones was -0.0477 where a
linear damage model forces exactly 0. Neighbouring electrodes carry overlapping
information, so a spatially contiguous group of k channels is MORE redundant, and
therefore LESS harmful, than k scattered channels -- and because that redundancy is
a fixed function of electrode geometry it is IDENTICAL for every subject, which
inflates cross-subject correlation and split-half reliability all by itself.

Single-channel leave-one-out removes that whole class of confound:
  - every condition has size 1, so there is no size effect to correct for;
  - a single channel has no contiguity, so there is no redundancy handicap;
  - 64 values give far more power for a consistency test than 8 zone values;
  - it produces a channel-level map (a usable paper figure) instead of 8 blocks;
  - any grouping -- including the paper's bilateral zones, or hemispheres -- can be
    formed POST HOC without re-running anything.

THE QUESTION IT ANSWERS is not "was the author wrong". It is: does a SPATIAL
STRUCTURE SHARED ACROSS SUBJECTS exist?
  consistent across subjects -> H1, a universal spatial prior with an individual
                               code underneath it (the positive claim)
  inconsistent              -> H2, and see [[fast-paper-strategy]] for why that
                               outcome is much harder to publish.

PROTOCOL: the released one, unchanged -- KFold(5, shuffle=False) over the subject's
own 350 trials, full batch 280, 200 epochs, bf16-mixed, seed_all(42) called ONCE
before the fold loop exactly as Finetune() does. All 5 folds are trained so the
profile rests on 350 held-out trials rather than 70.

Conditions per fold: `none`, `ALL` (all 64 deranged, the validity anchor -- must
collapse to chance or nothing here means anything), and 64 single-channel
derangements. 66 forward passes per fold, ~25 min for all 15 subjects on a 3080 Ti.

OUTPUT: Results/CP/<s>-chan.npz with
    base       (350,)      bool, baseline correctness
    all_ok     (350,)      bool, all-64-deranged correctness (anchor)
    ch_correct (64, 350)   bool, correctness with channel c deranged
    fold_of    (350,)      int, which KFold the trial came from
    ch_name    (64,)       str
and Results/CP/folds.npz holding the fold index arrays.
"""

import os
import sys
import logging
import numpy as np
import torch

sys.path.insert(0, "/root/FAST")
os.chdir("/root/FAST")

logging.getLogger("pytorch_lightning").setLevel(logging.WARNING)
logging.getLogger("lightning").setLevel(logging.WARNING)

import lightning as pl
from torch.utils.data import DataLoader
from transformers import PretrainedConfig
from sklearn.model_selection import KFold

from BCIC2020Track3_train import EEG_Encoder_Module, BasicDataset, seed_all, load_standardized_h5
from BCIC2020Track3_preprocess import Electrodes, Zones

RUN = "Results/CP"
MAX_EPOCHS = 200
N_CH = len(Electrodes)


def build_config():
    return PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1,
    )


def derangement(n, seed):
    """A permutation of range(n) with no fixed point.

    A plain torch.randperm leaves ~1 fixed point in 70, and a fixed point means that
    trial keeps its OWN signal, so the perturbation leaks. Repair by rotating values
    among the fixed positions; if there is exactly one fixed point it must first
    borrow a second position, because rotating a 1-element set is a no-op (that bug
    cost a run once -- see [[fast-zone-probe-results]]).
    """
    g = torch.Generator().manual_seed(seed)
    p = torch.randperm(n, generator=g)
    ar = torch.arange(n)
    for _ in range(200):
        fx = (p == ar).nonzero().flatten()
        if fx.numel() == 0:
            return p
        if fx.numel() == 1:
            i = int(fx[0])
            j = int(torch.randint(0, n, (1,), generator=g))
            if j == i:
                j = (i + 1) % n
            fx = torch.tensor([i, j], dtype=torch.long)
        p[fx] = p[fx].clone().roll(1)
    raise RuntimeError("could not build a derangement for n=%d" % n)


def predict(model, x):
    model.eval()
    model.cuda()           # Lightning leaves params on CPU after fit(); the released
    with torch.no_grad():  # inference_on_loader() calls .cuda() for the same reason
        return torch.argmax(model(x.cuda()), dim=1).cpu()


def train_fold(config, x_train, y_train):
    loader = DataLoader(BasicDataset(x_train, y_train), batch_size=len(x_train),
                        shuffle=True, num_workers=0, pin_memory=True)
    model = EEG_Encoder_Module(config, MAX_EPOCHS, len(loader))
    trainer = pl.Trainer(strategy="auto", accelerator="gpu", devices=[0],
                         max_epochs=MAX_EPOCHS, callbacks=[],
                         enable_progress_bar=False, enable_checkpointing=False,
                         precision="bf16-mixed", logger=False)
    trainer.fit(model, train_dataloaders=loader)
    return model.model


def probe_subject(s, X, Y, config):
    seed_all(42)                      # once, before the fold loop, as Finetune() does
    n_t = 350
    base = np.zeros(n_t, dtype=bool)
    all_ok = np.zeros(n_t, dtype=bool)
    ch_ok = np.zeros((N_CH, n_t), dtype=bool)
    fold_of = np.full(n_t, -1, dtype=int)

    for fi, (tr, te) in enumerate(KFold(n_splits=5, shuffle=False).split(X[s])):
        x_te = torch.from_numpy(X[s][te])
        y_te = Y[s][te]
        fold_of[te] = fi
        model = train_fold(config, X[s][tr], Y[s][tr])

        base[te] = (predict(model, x_te).numpy() == y_te)

        p_all = derangement(len(te), 9000 + fi)
        xa = x_te.clone()
        xa[:, :, :] = x_te[p_all][:, :, :]
        all_ok[te] = (predict(model, xa).numpy() == y_te)

        for c in range(N_CH):
            p = derangement(len(te), 500000 + 1000 * c + fi)
            xp = x_te.clone()
            xp[:, c, :] = x_te[p][:, c, :]
            ch_ok[c, te] = (predict(model, xp).numpy() == y_te)

        print("  [subj %02d fold %d] base=%.4f  ALL-deranged=%.4f  ch-drop min=%.4f max=%.4f"
              % (s, fi, base[te].mean(), all_ok[te].mean(),
                 (base[te].mean() - ch_ok[:, te].mean(axis=1)).min(),
                 (base[te].mean() - ch_ok[:, te].mean(axis=1)).max()), flush=True)
        del model
        torch.cuda.empty_cache()

    return base, all_ok, ch_ok, fold_of


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--subjects", type=str, default="0-14")
    a = ap.parse_args()
    todo = []
    for part in a.subjects.split(","):
        if "-" in part:
            lo, hi = [int(v) for v in part.split("-")]
            todo += list(range(lo, hi + 1))
        else:
            todo.append(int(part))

    os.makedirs(RUN, exist_ok=True)
    config = build_config()

    print("channels: %d, first/last: %s / %s" % (N_CH, Electrodes[0], Electrodes[-1]), flush=True)
    X, Y = load_standardized_h5("Processed/BCIC2020Track3.h5")
    print("probe subjects: %s" % todo, flush=True)

    for s in todo:
        f = "%s/%d-chan.npz" % (RUN, s)
        if os.path.exists(f):
            print("skip subject %02d (exists)" % s, flush=True)
            continue
        base, all_ok, ch_ok, fold_of = probe_subject(s, X, Y, config)
        np.savez(f, base=base, all_ok=all_ok, ch_correct=ch_ok,
                 fold_of=fold_of, ch_name=np.array(Electrodes))
        d = base.mean() - ch_ok.mean(axis=1)
        order = np.argsort(-d)
        print("[subject %02d] baseline=%.4f anchor=%.4f | top5 channels by damage: %s"
              % (s, base.mean(), all_ok.mean(),
                 ", ".join("%s(%.3f)" % (Electrodes[c], d[c]) for c in order[:5])), flush=True)
    print("CP_DONE", flush=True)
