"""
Leakage / shortcut audit for BCI Competition 2020 Track 3 (BCIC2020-3).

MIRRORS Tates, Matran-Fernandez, Halder & Daly (IEEE MetroXRAINE 2026), who report on
THIS dataset that (a) a classifier trained on the imagery window keeps working in the
post-imagery resting window, (b) the effect is concentrated above 40 Hz at peripheral
electrodes, and (c) a single channel and a single frequency band suffice to decode.
Their reading: published accuracies here are driven by a task-correlated artefact
(EMG and/or trial-order leakage), not by inner speech.

WHY THIS RUNS BEFORE ANY FURTHER MODELLING. Every architecture arm we have tried is
judged against a number (0.5779 released / 0.5949 probe harness) whose MEANING is not
established. If the label is recoverable from a task-free segment, or from one
electrode in one band, then a better model improves the artefact, not the science --
and a "+10 points" result is not a result.

THE THREE QUESTIONS, all on the same 350 trials per subject and the same
KFold(5, shuffle=False) split every other probe in this repo uses, so the numbers are
directly comparable to the stored baselines.

  1. single (channel, band)   log band power of ONE electrode in ONE band, LDA.
                              Above chance => a focal, spatially concentrated
                              artefact. Inner speech is a distributed
                              fronto-temporal network, so one electrode should be
                              nearly useless if the signal is cortical.
  2. below vs above 40 Hz     where the class information lives. Above 40 Hz at
                              peripheral channels is EMG, not cortex.
  3. THE PRE-CUE BASELINE     BCIC2020Track3_preprocess reads epo.t, whose first
                              sample is t = -500 ms, so samples 0..127 are the
                              500 ms BEFORE the trial starts -- task-free by
                              construction, no new data needed. All three tests are
                              re-run on that segment alone. Anything above chance
                              there cannot be inner speech.

TIMING NOTE. Two different fs values appear in this repo: the raw .mat says fs = 256
(epo.fs), and csp_probe.py / amplitude_control.py hardcode FS = 200. This file reads
fs from the .mat header semantics (256) -- 800 samples spanning t = -500..2601.6 ms,
which is 3.90625 ms per sample = 256 Hz. A wrong fs shifts every band edge, so it is
asserted against the sample count rather than trusted.

CONTROLS. A shuffled-label arm (train-fold labels permuted with a fold-local
RandomState, test labels untouched) gives the floor, and the per-fold majority-class
rate is stored alongside, so "above chance" means the majority rate and never a
nominal 0.20.

Read-only, CPU only. Nothing here trains the transformer, so it costs minutes, not
GPU hours:
    /root/venv_fast/bin/python -u leak_probe.py --subjects 0-14
"""

import argparse
import os
import sys

import h5py
import numpy as np
from scipy.signal import butter, sosfiltfilt
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.model_selection import KFold

H5 = "Processed/BCIC2020Track3.h5"
RUN = "Results/LEAK"

FS = 256.0
# The pre-cue baseline: epo.t[0] == -500 ms, so 0.5 s at 256 Hz = 128 samples.
BASE_SLICE = (0, 128)
FULL_SLICE = (0, 800)

BANDS = {
    "delta":  (1.0,   4.0),
    "theta":  (4.0,   8.0),
    "alpha":  (8.0,  13.0),
    "beta":   (13.0, 30.0),
    "gamma":  (30.0, 70.0),
    "hgamma": (70.0, 127.0),
}
# The headline split. Tates' <40 Hz "clinical baseline" condition is the low side; the
# high side is where they locate the artefact, and where our own band profile peaks
# (hgamma 0.3549 / gamma 0.3522 -- see fast-architecture-diagnosis).
SPLIT = {
    "low40":  (1.0, 40.0),
    "high40": (40.0, 127.0),
}


def band_power(X, lo, hi, fs=FS):
    """X (trials, ch, T) -> log mean power in [lo, hi], one value per (trial, ch).

    Filter then variance, rather than a Welch PSD: with T as short as 128 samples a
    periodogram gives a 2 Hz bin width, and band power by filtering is both more
    robust at that length and the standard definition in this literature.
    """
    hi = min(hi, fs / 2 - 1.0)
    sos = butter(4, [lo / (fs / 2), hi / (fs / 2)], btype="band", output="sos")
    F = sosfiltfilt(sos, X.astype(np.float64), axis=-1,
                    padlen=min(30, X.shape[-1] - 1))
    return np.log(np.mean(F ** 2, axis=-1) + 1e-12)          # (trials, ch)


def cv_acc(F, Y, seed=42, shuffle=False):
    """5-fold sequential CV with LDA. Returns (correct(350) bool, mean chance rate).

    Same split as every other probe: KFold(5, shuffle=False) over the subject's own
    350 trials, so this is the per-subject regime, and the chance level is the
    per-fold MAJORITY-CLASS rate rather than 0.20.
    """
    correct = np.zeros(len(Y), dtype=bool)
    chance = []
    for tr, te in KFold(n_splits=5, shuffle=False).split(F):
        y_tr = Y[tr]
        if shuffle:
            # Fold-local, and NOT from the global RNG: this arm has to differ from
            # the real one only in the labels.
            rs = np.random.RandomState(seed * 1000 + len(chance))
            y_tr = y_tr[rs.permutation(len(y_tr))]
        clf = LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
        clf.fit(F[tr], y_tr)
        correct[te] = clf.predict(F[te]) == Y[te]
        _, cnt = np.unique(Y[te], return_counts=True)
        chance.append(cnt.max() / len(te))
    return correct, float(np.mean(chance))


def stack_bands(X, names):
    """(trials, ch, n_band) log band power."""
    return np.stack([band_power(X, *BANDS[b]) for b in names], axis=-1)


def sweep(F, Y, n_ch, n_band, tag):
    """The full grid for one segment: all-features, per-band, per-channel, per-cell.

    F is (trials, ch, band). Every row of the returned dict is measured on the same
    folds, so cells are comparable to each other and to the stored baselines.
    """
    out = {}
    out["all"], out["chance"] = cv_acc(F.reshape(len(Y), -1), Y)
    out["shuf"], _ = cv_acc(F.reshape(len(Y), -1), Y, shuffle=True)
    out["band_all"] = np.array([cv_acc(F[:, :, bi], Y)[0].mean()
                                for bi in range(n_band)])
    out["ch_all"] = np.array([cv_acc(F[:, ci, :], Y)[0].mean()
                              for ci in range(n_ch)])
    cell = np.zeros((n_ch, n_band))
    for ci in range(n_ch):
        for bi in range(n_band):
            cell[ci, bi] = cv_acc(F[:, ci, bi][:, None], Y)[0].mean()
    out["cell"] = cell
    print("  [%s] all %.4f | shuf %.4f | chance %.4f" %
          (tag, out["all"].mean(), out["shuf"].mean(), out["chance"]), flush=True)
    print("       best single (ch,band) %.4f | best single channel %.4f | "
          "best single band %.4f" %
          (cell.max(), out["ch_all"].max(), out["band_all"].max()), flush=True)
    return out


def run_subject(sid, h5path=H5):
    with h5py.File(h5path, "r") as f:
        X = f[sid]["X"][:].astype(np.float64)      # (350, 64, 800)
        Y = f[sid]["Y"][:].astype(int)
    n_ch = X.shape[1]
    names = list(BANDS)

    print("[subj %s] X %s  Y classes %s" % (sid, X.shape, np.bincount(Y)), flush=True)

    # ---- full imagery epoch ----
    res = {}
    F = stack_bands(X[:, :, FULL_SLICE[0]:FULL_SLICE[1]], names)
    full = sweep(F, Y, n_ch, len(names), "full-epoch")
    res["full_all"] = full["all"]
    res["full_shuf"] = full["shuf"]
    res["full_chance"] = full["chance"]
    res["full_band_all"] = full["band_all"]
    res["full_ch_all"] = full["ch_all"]
    res["full_cell"] = full["cell"]

    # the 40 Hz split, all channels
    for k, (lo, hi) in SPLIT.items():
        Fk = band_power(X[:, :, FULL_SLICE[0]:FULL_SLICE[1]], lo, hi)
        c, ch_ = cv_acc(Fk.reshape(len(Y), -1), Y)
        res["full_%s" % k] = c
        res["full_%s_chance" % k] = ch_
        print("       %s (all 64ch) %.4f" % (k, c.mean()), flush=True)

    # ---- THE PRE-CUE BASELINE SEGMENT ----
    Xb = X[:, :, BASE_SLICE[0]:BASE_SLICE[1]]
    Fb = stack_bands(Xb, names)
    base = sweep(Fb, Y, n_ch, len(names), "pre-cue-baseline")
    res["base_all"] = base["all"]
    res["base_shuf"] = base["shuf"]
    res["base_chance"] = base["chance"]
    res["base_band_all"] = base["band_all"]
    res["base_ch_all"] = base["ch_all"]
    res["base_cell"] = base["cell"]

    for k, (lo, hi) in SPLIT.items():
        Fk = band_power(Xb, lo, hi)
        c, ch_ = cv_acc(Fk.reshape(len(Y), -1), Y)
        res["base_%s" % k] = c
        res["base_%s_chance" % k] = ch_
        print("       baseline %s (all 64ch) %.4f" % (k, c.mean()), flush=True)

    res["y"] = Y
    res["ch_names"] = np.array(
        [c for c in __import__("BCIC2020Track3_preprocess").Electrodes])
    res["band_names"] = np.array(names)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--subjects", type=str, default="0-14")
    ap.add_argument("--out", type=str, default=RUN)
    a = ap.parse_args()

    lo, hi = (int(v) for v in a.subjects.split("-"))
    todo = list(range(lo, hi + 1))
    os.makedirs(a.out, exist_ok=True)

    for s in todo:
        sid = "%02d" % (s + 1)
        f = "%s/%d-leak.npz" % (a.out, s)
        if os.path.exists(f):
            print("  skip subject %02d (exists)" % s, flush=True)
            continue
        np.savez(f, **run_subject(sid))
        print("  [saved %s]" % f, flush=True)

    # ---- summary ----
    cell_full, cell_base = [], []
    accs = {"full_all": [], "full_shuf": [], "base_all": [], "base_shuf": [],
            "full_low40": [], "full_high40": [],
            "base_low40": [], "base_high40": []}
    bestc_full, bestc_base = [], []
    for s in todo:
        f = "%s/%d-leak.npz" % (a.out, s)
        if not os.path.exists(f):
            continue
        d = np.load(f, allow_pickle=True)
        for k in accs:
            accs[k].append(d[k].mean())
        cell_full.append(d["full_cell"])
        cell_base.append(d["base_cell"])
        bestc_full.append(d["full_cell"].max())
        bestc_base.append(d["base_cell"].max())

    if not accs["full_all"]:
        print("nothing ran")
        return
    print("")
    print("=" * 72)
    print("LEAKAGE AUDIT -- n=%d subjects, chance 0.20, per-subject 5-fold"
          % len(accs["full_all"]))
    print("=" * 72)
    for k in ("full_all", "full_shuf", "full_low40", "full_high40",
              "base_all", "base_shuf", "base_low40", "base_high40"):
        v = np.array(accs[k])
        print("  %-12s mean %.4f  sd %.4f" % (k, v.mean(), v.std(ddof=1)))
    print("  best single (ch,band):  full epoch %.4f | pre-cue baseline %.4f"
          % (np.mean(bestc_full), np.mean(bestc_base)))
    cf = np.mean(cell_full, axis=0)
    bi = np.unravel_index(np.argmax(cf), cf.shape)
    names = np.load("%s/0-leak.npz" % a.out, allow_pickle=True)["band_names"]
    chn = np.load("%s/0-leak.npz" % a.out, allow_pickle=True)["ch_names"]
    print("  argmax cell (mean map): channel %s band %s -> %.4f"
          % (chn[bi[0]], names[bi[1]], cf[bi]))
    print("LEAK_DONE", flush=True)


if __name__ == "__main__":
    main()
