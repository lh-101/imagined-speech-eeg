"""Where in the scalp is the pre-cue decodable information? Reads Results/LEAK, recomputes
nothing.

The leakage audit left one thing unexplained: Tates et al. report that a SINGLE channel in
a SINGLE band suffices to decode BCIC2020-3, while our run found the mean best single cell
at 0.2107, BELOW chance 0.2560. If the effect is focal, it should show up as a few
channels far above the rest in the per-channel accuracy map. If it is distributed, the map
is flat and the mean is unremarkable.

The map also discriminates the two candidate mechanisms:
  - visual evoked response to the word cue  -> occipital / parietal (O, Oz, PO, Pz)
  - EMG from speech or neck muscles         -> peripheral temporal / frontal (T7/T8,
                                               FT, TP, F7/F8, Fp)
They live in different places, so the group breakdown is a real test, not decoration.

base_cell / full_cell are (subjects, 64 channels, 6 bands) accuracies, already on disk.

    /root/venv_fast/bin/python -u analyze_leak.py
"""

import glob
import os

import numpy as np

RUN = "Results/LEAK"
CHANCE = 0.2560          # the per-fold majority-class rate, NOT 0.20


def load(key):
    files = sorted(glob.glob("%s/*-leak.npz" % RUN),
                   key=lambda p: int(os.path.basename(p).split("-")[0]))
    if not files:
        raise SystemExit("no %s/*-leak.npz -- run leak_probe.py first" % RUN)
    arr = np.stack([np.load(f, allow_pickle=True)[key] for f in files])
    return arr, files


def group_of(name):
    """Coarse 10-20 grouping. Order matters: AF/FC/FT/TP/CP/PO must be tested before the
    bare F/C/T/P prefixes, or AF7 becomes 'frontal' by accident of a single letter."""
    n = name.strip().upper().rstrip("0123456789Z")
    n = name.strip().upper()
    for pre, g in (("AFP", "frontal"), ("AF", "frontal"), ("FTP", "temporal"),
                   ("FT", "temporal"), ("FCP", "frontal"),
                   ("FC", "frontal"), ("TP", "temporal"), ("CP", "parietal"),
                   ("PO", "parietal"), ("TPP", "temporal"), ("PP", "parietal")):
        if n.startswith(pre):
            return g
    if n.startswith("OZ") or n.startswith("IZ") or n.startswith("O"):
        return "occipital"
    if n.startswith("P"):
        return "parietal"
    if n.startswith("C"):
        return "central"
    if n.startswith("T"):
        return "temporal"
    if n.startswith("F"):
        return "frontal"
    return "other"


def main():
    base, files = load("base_cell")
    full, _ = load("full_cell")
    d0 = np.load(files[0], allow_pickle=True)
    bands = list(d0["band_names"])
    names = list(d0["ch_names"])
    n_s = base.shape[0]
    print("subjects %d | channels %d | bands %s" % (n_s, len(names), bands))
    print("chance = %.4f\n" % CHANCE)

    # ---- is it focal or distributed? ----
    for tag, cell in (("pre-cue baseline", base), ("full epoch", full)):
        m = cell.mean(axis=0)                       # (64, 6) mean over subjects
        ch = m.max(axis=1)                          # (64,)   best band per channel
        srt = np.sort(ch)[::-1]
        # A focal effect has a long right tail; a distributed one is flat. Compare the top
        # channel to the median channel rather than to chance, so the number is about
        # SHAPE and not about the overall level.
        print("== %s ==" % tag)
        print("  best single cell (mean map)  %.4f  %s / %s"
              % (m.max(), names[np.unravel_index(m.argmax(), m.shape)[0]],
                 bands[np.unravel_index(m.argmax(), m.shape)[1]]))
        print("  mean of per-subject best cell %.4f" % cell.max(axis=(1, 2)).mean())
        print("  channel map: max %.4f  p90 %.4f  median %.4f  min %.4f"
              % (srt[0], np.percentile(ch, 90), np.median(ch), srt[-1]))
        print("  top-5 / median ratio: %.2fx   (focal >> 1.5, distributed ~1.1)"
              % (srt[:5].mean() / np.median(ch)))
        print("  channels above chance: %d/%d (max band)"
              % (int((ch > CHANCE).sum()), len(names)))
        top = np.argsort(-ch)[:10]
        print("  top-10: " + ", ".join("%s %.3f" % (names[i], ch[i]) for i in top))

        # ---- group breakdown ----
        groups = {}
        for i, nm in enumerate(names):
            groups.setdefault(group_of(nm), []).append(i)
        print("  by region (max band, mean over its channels):")
        for g, idx in sorted(groups.items(), key=lambda kv: -ch[kv[1]].mean()):
            print("    %-10s n=%2d  %.4f  %s" % (g, len(idx), ch[idx].mean(),
                                                 "+" if ch[idx].mean() > CHANCE else "-"))
        print("  %s\n" % ("-" * 64))

    # ---- per-band, pooled over channels: where does the >40 Hz claim live spatially? ----
    print("per-band mean accuracy, pooled over all 64 channels:")
    print("  %-10s %-10s %-10s %s" % ("band", "pre-cue", "full", "delta"))
    for bi, b in enumerate(bands):
        mb, mf = base[:, :, bi].mean(), full[:, :, bi].mean()
        print("  %-10s %-10.4f %-10.4f %+.4f" % (b, mb, mf, mb - mf))

    # ---- is the pre-cue map the SAME map as the full-epoch map? ----
    # If the two use the same electrodes, one generator explains both and the pre-cue
    # segment is a window onto the same process, not an independent curiosity.
    rs = [np.corrcoef(base[s].max(axis=1), full[s].max(axis=1))[0, 1] for s in range(n_s)]
    rs = np.array(rs)
    print("\ncorrelation of the 64-channel accuracy map, pre-cue vs full epoch:")
    print("  per subject:", " ".join("%+.2f" % r for r in rs))
    print("  mean r %+.3f  (%d/%d positive)" % (rs.mean(), int((rs > 0).sum()), n_s))

    # ---- per-subject argmax channel: is there one canonical bad electrode? ----
    arg = base.max(axis=2).argmax(axis=1)
    print("\nper-subject argmax channel (pre-cue, best band):")
    print("  " + " ".join(names[i] for i in arg))
    vals, cnts = np.unique(arg, return_counts=True)
    print("  repeated: " + (", ".join("%s x%d" % (names[v], c)
                                      for v, c in zip(vals, cnts) if c > 1) or "none"))
    print("ANALYZE_LEAK_DONE", flush=True)


if __name__ == "__main__":
    main()
