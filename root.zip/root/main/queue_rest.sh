#!/bin/bash
# riemann + the three augmentation screens, run SERIALLY and gated on the GPU actually
# being free.
#
# WHY THIS REPLACES THE MARKER-GATED QUEUES. The marker design failed in a way worth
# recording: queue_spatial.sh ran its arm, the arm hit an OOM against a long-running
# spatial process and died in ~50 s, and the script then wrote QUEUE_SPATIAL_DONE anyway.
# Every downstream gate opened on a marker written by a run that never trained a thing, so
# riemann and aug each crashed the same way and each wrote their own success marker. Three
# arms were "completed" in 13 minutes and not one npz was produced. A marker that cannot
# distinguish "finished" from "died instantly" is worse than no marker, because it cascades.
#
# So the gate is now the resource itself, not a proxy for it:
#   * no `zone_attn_probe` process alive, AND
#   * the GPU holds < 500 MiB.
# and a step that produces no new .npz ABORTS the chain instead of passing a marker on.
#
# Order and rationale:
#   riemann 0-4   the one built-but-never-run arm. Signal-processing representation
#                 (per-zone log-Euclidean spatial covariance) fed INTO the model.
#   aug cdrop     channel dropout 0.1 alone -- the minimal, most targeted augmentation.
#   aug light     shift 125 ms + gain 10% + dropout 0.1 + noise 5%
#   aug full      the same, doubled
# Subjects 0-4 only: a screen. The other arms settle by subject 5, and at n=5 the
# resolvable difference is ~0.03 -- enough to kill or promote a preset, not enough to
# report a win. Anything that survives extends to 5-14 before it is quoted.
cd /root/FAST || exit 1
P=/root/venv_fast/bin/python
LOG=/root/FAST/rest.log

gpu_mib() { nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits | head -1; }

wait_free() {
  local n=0
  while pgrep -f zone_attn_probe >/dev/null 2>&1 || [ "$(gpu_mib)" -gt 500 ]; do
    n=$((n+1))
    [ $((n % 20)) -eq 0 ] && echo "  ...waiting for GPU ($(gpu_mib) MiB, $(pgrep -cf zone_attn_probe) trainers)" >> "$LOG"
    sleep 30
  done
}

n_npz() { ls /root/FAST/Results/ZA/*"$1"*.npz 2>/dev/null | wc -l; }

run_arm() {
  local label="$1" tag="$2"; shift 2
  wait_free
  local before after
  before=$(n_npz "$tag")
  echo "=== $label START $(date +%H:%M:%S)  (gpu $(gpu_mib) MiB, ${before} npz already) ===" >> "$LOG"
  $P -u zone_attn_probe.py "$@" >> "$LOG" 2>&1
  local rc=$?
  after=$(n_npz "$tag")
  echo "=== $label END $(date +%H:%M:%S)  rc=$rc  npz ${before} -> ${after} ===" >> "$LOG"
  if [ "$after" -le "$before" ]; then
    echo "=== $label PRODUCED NO NEW RESULTS -- aborting the chain rather than cascading ===" >> "$LOG"
    echo "=== (the arm's own output is above this line; nothing was written to $LOG) ===" >> "$LOG"
    exit 1
  fi
}

run_arm "riemann-0-4"   "riemann-h8-ex"  --variant riemann --harness exact --subjects 0-4
run_arm "aug-cdrop-0-4" "augcdrop"       --variant base --harness exact --aug cdrop --subjects 0-4
run_arm "aug-light-0-4" "auglight"       --variant base --harness exact --aug light --subjects 0-4
run_arm "aug-full-0-4"  "augfull"        --variant base --harness exact --aug full  --subjects 0-4

echo QUEUE_REST_DONE >> "$LOG"
