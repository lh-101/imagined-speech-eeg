"""
Amplitude control for the single-channel importance map.

THE PROBLEM. channel_probe.py found a 64-channel damage profile that is
cross-subject consistent (r = +0.2932, permutation p < 0.0005, split-half 0.7402).
But upstream preprocessing (BCIC2020Track3_preprocess.proc_one) does NO
normalization whatsoever -- it transposes, casts to float32, and edge-pads 795->800
samples. The function is named load_standardized_h5 but it only loads. So raw
per-channel amplitude differences survive into the model's input.

The observed map is ordered almost exactly like a scalp amplitude map:
    top     AF7 .086  AF8 .080  F8 .080  Fp1 .076  TP10 .075  F7 .074  Fp2 .073  Oz .069
    bottom  F2 .010   P2 .010   P4 .014  Pz .014   Fz .015   CP1 .018  P3 .018
Frontopolar = EOG and drift; temporal = EMG; Oz = the strongest alpha in EEG;
midline centro-parietal = the smallest amplitudes on the scalp. That is a
damning coincidence and it has to be tested, not argued about.

WHAT THIS SCRIPT DOES
  1. per-channel scale: std over time and trials, plus band powers (delta/theta/
     alpha/beta/gamma) from the same trials the probe used.
  2. within-subject r between the damage profile and log-amplitude (64 points per
     subject, so 15 independent correlations -- the powerful version of the test).
  3. the between-subject version, mean map vs mean amplitude.
  4. THE DECISIVE ONE: regress damage on log-amplitude per subject, take the
     RESIDUAL map, and re-run the cross-subject consistency test on it. If the
     consistency survives residualization there is structure beyond amplitude; if
     it collapses to zero the map was an amplitude map and the "universal spatial
     prior" claim has to be withdrawn.

Read-only.
"""

import os
import numpy as np
import h5py

H5 = "Processed/BCIC2020Track3.h5"
CP = "Results/CP/summary.npz"
FS = 250.0
BANDS = {"delta": (0.5, 4), "theta": (4, 8), "alpha": (8, 13),
         "beta": (13, 30), "gamma": (30, 70)}


def band_power(X, fs=FS):
    """X: (trials, ch, time). Returns dict band -> (ch,) mean power.

    Drop the 5 edge-padded samples: proc_one pads 795->800 by copying sample 794,
    so the tail is a constant, not signal.
    """
    n = X.shape[2] - 5
    x = X[:, :, :n].astype(np.float64)
    x = x - x.mean(axis=2, keepdims=True)          # remove per-trial DC
    P = np.abs(np.fft.rfft(x, axis=2)) ** 2
    f = np.fft.rfftfreq(n, 1.0 / fs)
    out = {}
    for b, (lo, hi) in BANDS.items():
        m = (f >= lo) & (f < hi)
        out[b] = P[:, :, m].mean(axis=(0, 2))
    out["total"] = P[:, :, (f >= 0.5) & (f < 70)].mean(axis=(0, 2))
    return out


def mean_pair_r(Z):
    Zc = Z - Z.mean(axis=1, keepdims=True)
    sd = Zc.std(axis=1, keepdims=True)
    sd[sd == 0] = 1e-12
    Zs = Zc / sd
    C = (Zs @ Zs.T) / Z.shape[1]
    iu = np.triu_indices(Z.shape[0], 1)
    return float(C[iu].mean())


def perm_p(Z, n=2000, seed=0):
    rng = np.random.RandomState(seed)
    obs = mean_pair_r(Z)
    null = np.array([mean_pair_r(np.array([rng.permutation(r) for r in Z]))
                     for _ in range(n)])
    return obs, float((null >= obs).mean()), null


def zscore_rows(D):
    return (D - D.mean(axis=1, keepdims=True)) / D.std(axis=1, keepdims=True)


def main():
    d = np.load(CP)
    D, names, subs_used = d["D"], [str(x) for x in d["names"]], d["subjects"]
    print("damage matrix from %s: %s, subjects %s" % (CP, D.shape, subs_used.tolist()))
    print("")

    amp, bands = [], {b: [] for b in list(BANDS) + ["total"]}
    with h5py.File(H5, "r") as f:
        keys = sorted(f.keys())
        for k in keys:
            X = f[k]["X"][()]                      # (350, 64, 800)
            amp.append(X.std(axis=(0, 2)))
            bp = band_power(X)
            for b in bands:
                bands[b].append(bp[b])
            print("  %s X=%s  per-channel std: min %.3f median %.3f max %.3f"
                  % (k, X.shape, X.std(axis=(0, 2)).min(),
                     np.median(X.std(axis=(0, 2))), X.std(axis=(0, 2)).max()))
            del X
    amp = np.array(amp)
    for b in bands:
        bands[b] = np.array(bands[b])
    print("")

    if amp.shape[0] != D.shape[0]:
        print("!! subject count mismatch: h5 has %d, damage has %d" % (amp.shape[0], D.shape[0]))
        return

    logamp = np.log10(amp)

    print("=== 1. PER-CHANNEL AMPLITUDE vs DAMAGE (across the 64 channels) ===")
    print("  within-subject Pearson r, computed per subject then averaged:")
    r_amp = []
    r_bands = {b: [] for b in bands}
    for s in range(D.shape[0]):
        r_amp.append(np.corrcoef(D[s], logamp[s])[0, 1])
        for b in bands:
            r_bands[b].append(np.corrcoef(D[s], np.log10(bands[b][s]))[0, 1])
    r_amp = np.array(r_amp)
    print("    damage vs log10(std)     : mean r = %+.4f   sd %.4f   positive in %d/%d subjects"
          % (r_amp.mean(), r_amp.std(), int((r_amp > 0).sum()), len(r_amp)))
    for b in bands:
        rb = np.array(r_bands[b])
        print("    damage vs log10(%s%-5s) : mean r = %+.4f   sd %.4f   positive in %d/%d"
              % (b, ")", rb.mean(), rb.std(), int((rb > 0).sum()), len(rb)))

    print("")
    print("=== 2. THE TWO MAPS SIDE BY SIDE (sorted by damage) ===")
    mu_d = D.mean(axis=0)
    mu_a = logamp.mean(axis=0)
    o = np.argsort(-mu_d)
    print("  %-5s %9s %10s %10s" % ("ch", "damage", "log10 std", "delta pow"))
    for c in o[:12]:
        print("  %-5s %9.4f %10.4f %10.3f"
              % (names[c], mu_d[c], mu_a[c], np.log10(bands["delta"].mean(axis=0)[c])))
    print("  ...")
    for c in o[-8:]:
        print("  %-5s %9.4f %10.4f %10.3f"
              % (names[c], mu_d[c], mu_a[c], np.log10(bands["delta"].mean(axis=0)[c])))

    print("")
    print("=== 3. CAN THE MAP BE PREDICTED FROM AMPLITUDE ALONE? ===")
    print("  (regress the subject-mean damage map on the subject-mean log-amplitude;")
    print("   a high R^2 means the 64-channel ordering is an amplitude ordering)")
    A = np.c_[np.ones(64), mu_a]
    coef, *_ = np.linalg.lstsq(A, mu_d, rcond=None)
    pred = A @ coef
    ss_res = ((mu_d - pred) ** 2).sum()
    ss_tot = ((mu_d - mu_d.mean()) ** 2).sum()
    print("  R^2 = %.4f   slope = %.4f   intercept = %.4f"
          % (1 - ss_res / ss_tot, coef[1], coef[0]))

    print("")
    print("=== 4. DECISIVE: DOES CROSS-SUBJECT CONSISTENCY SURVIVE RESIDUALIZATION? ===")
    obs_raw, p_raw, null_raw = perm_p(D)
    print("  raw damage map          : r = %+.4f  permutation p = %.4f  (null sd %.4f)"
          % (obs_raw, p_raw, null_raw.std()))
    R = np.empty_like(D)
    for s in range(D.shape[0]):
        As = np.c_[np.ones(64), logamp[s]]
        c, *_ = np.linalg.lstsq(As, D[s], rcond=None)
        R[s] = D[s] - As @ c                    # damage with the amplitude trend removed
    obs_res, p_res, null_res = perm_p(R)
    print("  amplitude residualized  : r = %+.4f  permutation p = %.4f  (null sd %.4f)"
          % (obs_res, p_res, null_res.std()))
    print("")
    keep = 100.0 * obs_res / obs_raw if obs_raw > 0 else float("nan")
    print("  -> %.0f%% of the cross-subject consistency survives removing amplitude." % keep)
    if p_res >= 0.01:
        print("  -> CONSISTENCY COLLAPSES. The map was an amplitude map. The spatial-prior")
        print("     claim cannot be made from this probe; report that plainly.")
    elif keep < 50:
        print("  -> consistency is mostly amplitude; the residual is too small to carry")
        print("     the claim on its own.")
    else:
        print("  -> consistency SURVIVES. There is spatial structure beyond channel scale.")

    np.savez("Results/CP/amplitude.npz", amp=amp, logamp=logamp,
             **{("band_" + b): bands[b] for b in bands},
             R=R, D=D, names=np.array(names))
    print("")
    print("  wrote Results/CP/amplitude.npz")


if __name__ == "__main__":
    main()
