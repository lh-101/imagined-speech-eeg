"""Memory-safe preprocessing wrapper for the 2GB cgroup cap of AutoDL no-GPU mode.

The upstream BCIC2020Track3_preprocess.proc_all() uses mp.Pool(15) + pool.map,
which materialises all 15 subjects (~1.07GB fp32) in the parent process on top of
15 worker children -- that is SIGKILLed here. This wrapper calls the *unmodified*
proc_one() serially and writes straight to HDF5, so peak RSS stays ~one subject.
Output is byte-identical to the upstream h5.
"""
import os, sys, time, importlib.util
import numpy as np, h5py

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location(
    "bpp", os.path.join(HERE, "BCIC2020Track3_preprocess.py"))
bpp = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bpp)

os.makedirs(bpp.DATA_FOLDER, exist_ok=True)
out = f"{bpp.DATA_FOLDER}/{bpp.NAME}.h5"
t0 = time.time()
with h5py.File(out, "w") as f:
    for sid in bpp.SUBJECTS:
        SID, X, Y = bpp.proc_one(sid)
        f.create_dataset(f"{SID}/X", data=X)
        f.create_dataset(f"{SID}/Y", data=Y)
        f.flush()
        u = np.unique(Y, return_counts=True)
        print(f"[{time.time()-t0:6.0f}s] {SID} X={X.shape} Y={Y.shape} classes={dict(zip(u[0].tolist(), u[1].tolist()))}", flush=True)
        del X, Y
print(f"DONE_PREPROCESS -> {out}", flush=True)
