"""
HOW MUCH CLASS INFORMATION DOES FAST STRUCTURALLY THROW AWAY?

THE ARGUMENT THIS TESTS. FAST's zone encoder is
    cnn1 (1,5) -> cnn2 (C,1) -> cnn3 (1,5,pad2) -> cnn4 (1,5,pad2) -> gelu
    mean over the 246 remaining time samples
The temporal receptive field of that stack is 5+4+4 = 13 samples = 52 ms at 250 Hz.
The pooling that follows averages a full second. So:

    theta   4-8   Hz, period 125-250 ms -> 2.4-4.8 periods fit inside the RECEPTIVE
                                           FIELD ALONE: the conv cannot see it
    mu/alpha 8-13 Hz, period  77-125 ms -> cannot see it either
    and the 1 s mean then averages 2-8 full periods of these bands to ~zero

The bands the imagined-speech literature reports as most discriminative (theta
tracking the syllable rate, mu/beta sensorimotor desynchronisation) are therefore
not merely under-weighted by FAST, they are arithmetically unavailable to it.

NONE OF THIS MATTERS IF THE INFORMATION ISN'T THERE. So measure it directly: take
log band power as features and ask a plain linear classifier how much of the class
label it recovers. This is weeks cheaper than rebuilding the model, and it decides
whether a spectral branch has anything to add.

WHAT IS AND IS NOT BEING COMPARED. This is a PROBE, not a head-to-head. A logistic
regression on hand-built features and FAST's 191k-parameter transformer are not the
same protocol family, and the number below must not be reported as "we beat FAST".
Its only job here is to bound the headroom: if band power linearly recovers far more
than 0.5779, the missing representation is worth building; if it lands at 0.5779,
band power is not the gap and the spectral-branch plan should be dropped.

FEATURE SETS
  raw_moments  per-channel mean and std over the epoch. Minimal raw-domain control.
  bp           log band power, 64 channels x 6 bands.  The headroom question.
  bp_zone      bp plus the same bands averaged within each of the 8 FAST zones --
               i.e. does FAST's own spatial grouping add anything on top of bp.
  bp_time      log band power in 5 consecutive 1 s windows x 64 ch x 6 bands.
               Time-resolved, i.e. what a spectral TOKENIZER would actually feed
               the transformer. Closest to the proposed architecture.
  cov_tangent  per-band covariance + tangent-space projection (the Riemannian
               baseline). Included because it is the method the BCI literature
               actually uses to beat deep nets at this sample size, so it is the
               honest bar for "we built something better".

Contrast is INVERTED (band power is a power, so higher = more) and every band is
log10'd, which is the standard normalisation for EEG spectra.

Controls: shuffled labels (must fall to chance 0.20) and the same KFold(5,
shuffle=False) split as the released protocol so fold boundaries line up.

CPU only, no training. Run: python spectral_probe.py
"""

import os
import sys
import numpy as np
from scipy.signal import welch
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import KFold

H5 = "Processed/BCIC2020Track3.h5"
OUT = "Results/SPEC"
FS = 250.0
N_PAD = 5                       # proc_one edge-pads 795 -> 800; the tail is a constant
BANDS = [("delta", 1, 4), ("theta", 4, 8), ("alpha", 8, 13),
         ("beta", 13, 30), ("gamma", 30, 70), ("hgamma", 70, 100)]
N_WIN = 5                       # matches FAST's 5 tokens
SEED = 42


def band_power(x, nperseg=250):
    """x: (trials, ch, T) -> (trials, ch, n_bands) mean power in each band.

    Welch with a 1 s Hann segment: 1 Hz bins, which resolves every band of interest
    including delta vs theta. nperseg=250 at 250 Hz means 3 segments per epoch with
    noverlap=125, so the estimate averages 3 periodograms -- enough to be stable
    without smoothing away band edges.
    """
    # The time-windowed feature set feeds this 159-sample windows, which is shorter
    # than the 250-sample segment. Clamp instead of letting scipy emit a UserWarning
    # per call, and halve the overlap so the shorter segment still averages >= 2
    # periodograms.
    nperseg = min(nperseg, x.shape[-1])
    f, P = welch(x, fs=FS, nperseg=nperseg, noverlap=nperseg // 2,
                 window="hann", axis=-1, detrend="constant")
    out = np.empty(x.shape[:2] + (len(BANDS),), dtype=np.float64)
    for b, (_, lo, hi) in enumerate(BANDS):
        m = (f >= lo) & (f < hi)
        if not m.any():
            raise RuntimeError("band %s has no bins (fmax %.1f)" % (BANDS[b][0], f[-1]))
        out[:, :, b] = P[:, :, m].mean(axis=-1)
    return out


def features(x, zone_idx):
    """All four feature sets for one subject's trials. x: (n, ch, T)."""
    x = x[:, :, : x.shape[2] - N_PAD]
    f = {}

    mu = x.mean(axis=2)
    sd = x.std(axis=2)
    f["raw_moments"] = np.c_[mu, sd]

    bp = np.log10(band_power(x) + 1e-12)                    # (n, ch, band)
    f["bp"] = bp.reshape(bp.shape[0], -1)

    zs = [bp[:, idx, :].mean(axis=1) for idx in zone_idx]   # (n, band) per zone
    f["bp_zone"] = np.c_[f["bp"], np.concatenate(zs, axis=1)]

    T = x.shape[2]
    edges = np.linspace(0, T, N_WIN + 1).astype(int)
    wins = [np.log10(band_power(x[:, :, a:b]) + 1e-12) for a, b in zip(edges[:-1], edges[1:])]
    f["bp_time"] = np.concatenate([w.reshape(w.shape[0], -1) for w in wins], axis=1)

    f["cov_tangent"] = cov_tangent(x)
    return f


def cov_tangent(x):
    """Per-band covariance: x (n, ch, T) -> (n, n_bands, ch, ch).

    The reference point for the tangent projection is NOT built here -- it is fit on
    the training fold only, in cv_cov(). Building it from all trials of a subject
    would leak test trials into the projection.
    """
    ch = x.shape[1]
    feats = []
    for b, (_, lo, hi) in enumerate(BANDS):
        # time-domain band-pass via FFT masking, then plain covariance
        Xf = np.fft.rfft(x, axis=-1)
        ff = np.fft.rfftfreq(x.shape[-1], 1.0 / FS)
        Xf = Xf * ((ff >= lo) & (ff < hi))
        xb = np.fft.irfft(Xf, n=x.shape[-1], axis=-1)
        C = np.einsum('nct,ndt->ncd', xb, xb) / xb.shape[-1]      # (n, ch, ch)
        C = C + 1e-6 * np.eye(ch) * np.trace(C, axis1=1, axis2=2)[:, None, None] / ch
        feats.append(C)
    return np.stack(feats, axis=1)                                # (n, nb, ch, ch)


def spd_mean(Cs):
    """Mean of (n, ch, ch) SPD matrices via the log-Euclidean approximation.

    Deliberately does NOT accept (n, n_bands, ch, ch): cov_tangent returns that, and
    averaging a band's covariances together with every other band's is a silent
    wrong answer, so make the caller slice the band out.
    """
    assert Cs.ndim == 3, "spd_mean wants (n, ch, ch), got %s" % (Cs.shape,)
    ev, V = np.linalg.eigh(Cs.mean(axis=0))
    ev = np.clip(ev, 1e-10, None)
    return (V * ev) @ V.T


def tangent(Cs, ref):
    """Log-Euclidean tangent projection of (n, ch, ch) covariances at ref."""
    ev, V = np.linalg.eigh(ref)
    ev = np.clip(ev, 1e-10, None)
    W = (V / np.sqrt(ev)) @ V.T                     # whitening ref -> I
    S = W @ Cs @ W.T
    ev2, V2 = np.linalg.eigh(S)
    # scale the COLUMNS of V2: V2[..., :, i] is the i-th eigenvector, so the (n, ch)
    # eigenvalue vector must be broadcast along the last axis, not the middle one.
    L = (V2 * np.log(np.clip(ev2, 1e-10, None))[:, None, :]) @ np.transpose(V2, (0, 2, 1))
    iu = np.triu_indices(Cs.shape[1])
    return L[:, iu[0], iu[1]]


def make_clf():
    return make_pipeline(StandardScaler(),
                         LogisticRegression(C=0.1, max_iter=2000, n_jobs=-1))


def cv(F, y, zones=None):
    """5-fold, the released KFold(5, shuffle=False) split. Returns per-fold accuracy."""
    accs = []
    for tr, te in KFold(n_splits=5, shuffle=False).split(F):
        clf = make_clf()
        clf.fit(F[tr], y[tr])
        accs.append(float((clf.predict(F[te]) == y[te]).mean()))
    return float(np.mean(accs))


def cv_cov(Cs, y):
    """cov_tangent needs the reference point fit on the training fold only, and one
    reference per band -- the bands are different SPD manifolds and sharing a single
    reference across them would be meaningless."""
    accs = []
    for tr, te in KFold(n_splits=5, shuffle=False).split(Cs):
        Xtr = np.concatenate([tangent(Cs[tr][:, b], spd_mean(Cs[tr][:, b]))
                              for b in range(Cs.shape[1])], axis=1)
        Xte = np.concatenate([tangent(Cs[te][:, b], spd_mean(Cs[tr][:, b]))
                              for b in range(Cs.shape[1])], axis=1)
        clf = make_clf()
        clf.fit(Xtr, y[tr])
        accs.append(float((clf.predict(Xte) == y[te]).mean()))
    return float(np.mean(accs))


def main():
    import h5py                              # lazy: keeps the numerics locally testable
    os.makedirs(OUT, exist_ok=True)
    sys.path.insert(0, "/root/FAST")
    from BCIC2020Track3_preprocess import Electrodes, Zones
    idx = {e: i for i, e in enumerate(Electrodes)}
    zone_idx = [np.array([idx[c] for c in ch]) for ch in Zones.values()]
    print("bands:", ", ".join("%s %g-%g" % b for b in BANDS))
    print("zones:", {k: len(v) for k, v in Zones.items()})
    print("folds: KFold(5, shuffle=False), as released")
    print("")

    names = ["raw_moments", "bp", "bp_zone", "bp_time", "cov_tangent", "SHUFFLE_ctrl"]
    res = {k: [] for k in names}
    with h5py.File(H5, "r") as f:
        for key in sorted(f.keys()):
            X = f[key]["X"][()].astype(np.float64)
            Y = f[key]["Y"][()]
            if Y.ndim > 1:
                Y = Y.argmax(1)
            fset = features(X, zone_idx)
            row = {}
            for k in ["raw_moments", "bp", "bp_zone", "bp_time"]:
                row[k] = cv(fset[k], Y)
            row["cov_tangent"] = cv_cov(fset["cov_tangent"], Y)
            rng = np.random.RandomState(SEED)
            row["SHUFFLE_ctrl"] = cv(fset["bp"], rng.permutation(Y))
            for k in names:
                res[k].append(row[k])
            print("  %s  " % key + "  ".join("%s %.4f" % (k, row[k]) for k in names),
                  flush=True)
            del X
            np.savez("%s/%s.npz" % (OUT, key), **row)

    print("")
    print("=== MEAN OVER SUBJECTS (chance 0.2000, FAST released 0.5779) ===")
    for k in names:
        v = np.array(res[k])
        print("  %-12s mean %.4f  sd %.4f  min %.4f  max %.4f"
              % (k, v.mean(), v.std(), v.min(), v.max()))
    np.savez("%s/summary.npz" % OUT, **{k: np.array(v) for k, v in res.items()})

    bp = np.array(res["bp"])
    bpt = np.array(res["bp_time"])
    cov = np.array(res["cov_tangent"])
    print("")
    print("  bp        beats 0.5779 in %d/15 subjects" % int((bp > 0.5779).sum()))
    print("  bp_time   beats 0.5779 in %d/15 subjects" % int((bpt > 0.5779).sum()))
    print("  cov_tang  beats 0.5779 in %d/15 subjects" % int((cov > 0.5779).sum()))
    print("")
    print("  paired vs 0.5779 (one-sample t on the per-subject difference):")
    for k, v in [("bp", bp), ("bp_time", bpt), ("cov_tangent", cov)]:
        d = v - 0.5779
        se = d.std(ddof=1) / np.sqrt(len(d))
        print("    %-12s mean diff %+.4f  se %.4f  t=%.2f  (n=15)"
              % (k, d.mean(), se, d.mean() / se if se > 0 else float("nan")))
    print("SPEC_DONE")


if __name__ == "__main__":
    main()
