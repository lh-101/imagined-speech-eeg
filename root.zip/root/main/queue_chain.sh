#!/bin/bash
# Wait for the lr sweep to finish, then run the next batch. Started as a separate process
# rather than appended to queue_lr.sh because bash reads a running script incrementally and
# rewriting one under a live interpreter can make it execute garbage.
cd /root/FAST || exit 1
P=/root/venv_fast/bin/python

# --- wait for the lr sweep, or for it to die ---
for i in $(seq 1 400); do
    grep -q QUEUE_LR_DONE lr_sweep.log 2>/dev/null && break
    alive=0
    for d in /proc/[0-9]*; do
        [ "$(cat "$d/comm" 2>/dev/null)" = "python" ] && alive=1
    done
    if [ "$alive" -eq 0 ]; then
        echo "=== lr sweep stopped without QUEUE_LR_DONE; starting next batch anyway ==="
        break
    fi
    sleep 30
done
echo "=== next batch START $(date +%H:%M:%S) ==="

# Full 15 subjects, not a screen. w1std is the arm with a mechanism behind it (whole-epoch
# mean+std is the strongest hand-built representation measured on this data and the
# released front end can only compute the mean); w1 is the ablation that says what the
# 5-window tokenisation was worth; riemann is the spatial-second-order branch. All at the
# released 5e-4 so they are comparable with every arm already on disk.
$P -u zone_attn_probe.py --variant w1std
echo "=== w1std END $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant w1
echo "=== w1 END $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant riemann
echo "=== riemann END $(date +%H:%M:%S) ==="
echo QUEUE_CHAIN_DONE
