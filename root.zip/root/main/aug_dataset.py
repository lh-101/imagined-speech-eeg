"""Standard EEG augmentations, as a Dataset wrapper that leaves the model untouched.

WHY THIS AND NOT ANOTHER ARCHITECTURE.

The chain of measurements that puts augmentation here and nothing else:

  1. diagnose.py, base, subject 0:  TRAIN 1.0000 / TEST 0.6143, gap +0.3857. The model
     memorises its 280 training trials outright.
  2. The released protocol builds the loader with `batch_size=len(x_train)=280` and trains
     for 200 epochs. With one full-batch gradient step per epoch, the model sees THE SAME
     280 trials 200 times. A model that can memorise 280 samples will, given 200 looks at
     them -- which is what TRAIN 1.0000 is.
  3. Eleven architecture variants were built and not one beat base; `spatial` scored -0.2589
     (0/8 subjects, t=-12.05) and the LR mismatch between paper (0.001) and code (5e-4) is
     worth +0.0095, BELOW the +0.0120 placebo noise floor. So neither capacity nor the
     optimiser is the binding constraint.

That leaves the training set itself. This is also the standard lever in the imagined-speech
literature: papers on this exact problem state they "introduced artificial trials" because
of EEG data scarcity, and the review literature names "insufficient EEG data set" the first
obstacle. It is a training-strategy change, not a modelling innovation -- that distinction
is real and must be stated when reporting, but it is not a reason not to measure it.

WHY IT FITS THIS PROTOCOL ESPECIALLY WELL. Augmentation is applied in __getitem__, and the
loader reshuffles every epoch, so the 200 full-batch steps see 200 DIFFERENT augmented views
of the 280 trials. The protocol's odd shape (200 steps, one per epoch) hands us 200 fresh
draws for free. In a normal mini-batch schedule the same augmentation buys far less.

WHAT IS APPLIED, AND WHY EACH ONE IS DEFENSIBLE RATHER THAN TUNED.

  shift     circular time roll, +-25 samples = +-125 ms. Half a window stride. ERP latencies
            jitter on this scale and the model should not read absolute onset time.
  scale     per-channel gain ~ N(1, 0.1). Electrode impedance and cap placement vary between
            sessions; identical signals arrive at different amplitudes.
  chan_drop whole channels zeroed independently with probability p. Electrode failure and
            spatial robustness -- this is the one that attacks the diagnosed failure mode
            most directly, because with 64 electrodes a model can memorise via a handful.
  noise     gaussian, std = 0.1 x that CHANNEL'S OWN std in that sample. Scale-relative on
            purpose: proc_one does no normalisation and per-channel amplitude spans 21x-73x
            within a subject, so an absolute noise level would be a no-op on loud channels
            and destructive on quiet ones.

Order is fixed: shift -> scale -> dropout -> noise. Noise last so it is not itself scaled
away, and dropout before it so a dead channel does not contribute a noise term.

Augmentation is applied to the TRAINING split only. The test split stays BasicDataset, so
the reported accuracy is measured on clean data.

Run the self-test on the training box (CPU only):
    CUDA_VISIBLE_DEVICES= python aug_dataset.py
"""

import numpy as np
import torch
from torch.utils.data import Dataset

# Named presets rather than free parameters, so a run's augmentation is identified by a
# word in its tag and a reader knows exactly what produced it.
PRESETS = {
    "none":  dict(shift=0,  scale=0.00, chan_drop=0.00, noise=0.00),
    "cdrop": dict(shift=0,  scale=0.00, chan_drop=0.10, noise=0.00),
    "light": dict(shift=25, scale=0.10, chan_drop=0.10, noise=0.05),
    "full":  dict(shift=25, scale=0.20, chan_drop=0.20, noise=0.10),
}


class AugDataset(Dataset):
    """BasicDataset with per-access augmentation. Same (sample, label) contract."""

    def __init__(self, data, label, shift=0, scale=0.0, chan_drop=0.0, noise=0.0):
        if len(data.shape) == 4:
            data, label = np.concatenate(data, axis=0), np.concatenate(label, axis=0)
        self.data = torch.from_numpy(data)
        self.labels = torch.from_numpy(label)
        self.shift = int(shift)
        self.scale = float(scale)
        self.chan_drop = float(chan_drop)
        self.noise = float(noise)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        # .clone() is not optional: every op below is out-of-place today, but a single
        # in-place one would silently corrupt the stored trial for every later epoch.
        x = self.data[idx].clone()
        y = self.labels[idx]
        C = x.shape[0]

        if self.shift:
            k = int(torch.randint(-self.shift, self.shift + 1, (1,)).item())
            if k:
                x = torch.roll(x, k, dims=-1)

        if self.scale:
            x = x * (1.0 + self.scale * torch.randn(C, 1, dtype=x.dtype))

        if self.chan_drop:
            keep = (torch.rand(C, dtype=x.dtype) >= self.chan_drop).to(x.dtype).unsqueeze(1)
            x = x * keep

        if self.noise:
            sd = x.std(dim=-1, keepdim=True)
            x = x + self.noise * sd * torch.randn_like(x)

        return x, y


def make_train_data(data, label, aug="none"):
    """The one entry point the harness calls. aug="none" must be BIT-IDENTICAL to
    BasicDataset -- the `exact` harness claims to be a verbatim mirror of Finetune, and
    routing it through here is only safe if the default reproduces that claim exactly."""
    if aug not in PRESETS:
        raise KeyError("unknown aug %r; known: %s" % (aug, ", ".join(sorted(PRESETS))))
    if aug == "none":
        from BCIC2020Track3_train import BasicDataset
        return BasicDataset(data, label)
    return AugDataset(data, label, **PRESETS[aug])


def augment_batch(x, aug="none", allow_drop=False):
    """The SAME augmentation, applied to a (B, C, T) tensor instead of a Dataset item.

    Used for test-time augmentation: average the model's probabilities over several
    augmented views of the test set. Written as a second implementation on purpose --
    the alternative was a Dataset wrapper the harness would have to re-plumb -- but a
    second implementation is only safe if it is provably the same function, so
    test_batch_and_dataset_agree checks the two against each other sample by sample.

    `allow_drop=False` by default because CHANNEL DROPOUT MUST NOT BE USED AT TEST TIME.
    Zeroing electrodes and averaging is not a view of the same input, it is a different
    input the model was trained to be robust to; including it inflates the TTA gain in a
    way that does not reproduce as a decoding improvement. The other three transforms
    (shift, gain, noise) are the ones that are legitimately test-time views.

    EVERY RANDOM TENSOR IS BUILT ON `x.device`, and that is not cosmetic. The first
    version built them on the default (CPU) device, and it crashed the tta8 arm 30 seconds
    after it started:

        RuntimeError: Expected all tensors to be on the same device,
                      but found at least two devices, cuda:0 and cpu!

    Nothing caught it earlier because `AugDataset` -- the other implementation -- is fed by
    a DataLoader and so is always built on the CPU and only moved afterwards, and because
    every test in this file runs under `CUDA_VISIBLE_DEVICES=`. TTA is the ONLY caller that
    hands this function a CUDA tensor, so the one arm that used this path is the one arm
    that could not have been tested on CPU. Hence `test_output_follows_the_input_device`,
    which is a no-op on CPU by construction -- run this file once WITHOUT
    `CUDA_VISIBLE_DEVICES=` to actually exercise it.
    """
    if aug not in PRESETS:
        raise KeyError("unknown aug %r; known: %s" % (aug, ", ".join(sorted(PRESETS))))
    p = dict(PRESETS[aug])
    if not allow_drop:
        p["chan_drop"] = 0.0
    B, C, T = x.shape
    y = x.clone()
    if p["shift"]:
        k = int(torch.randint(-p["shift"], p["shift"] + 1, (1,)).item())
        if k:
            y = torch.roll(y, k, dims=-1)
    if p["scale"]:
        y = y * (1.0 + p["scale"] * torch.randn(B, C, 1, dtype=y.dtype, device=y.device))
    if p["chan_drop"]:
        keep = (torch.rand(B, C, dtype=y.dtype, device=y.device) >= p["chan_drop"])
        y = y * keep.to(y.dtype).unsqueeze(-1)
    if p["noise"]:
        sd = y.std(dim=-1, keepdim=True)
        y = y + p["noise"] * sd * torch.randn_like(y)
    return y


# ---------------------------------------------------------------------------------------
# self-test
# ---------------------------------------------------------------------------------------

_TESTS = []


def test(fn):
    _TESTS.append(fn)
    return fn


def _batch(n=8, C=64, T=800, seed=0):
    g = torch.Generator().manual_seed(seed)
    x = torch.randn(n, C, T, generator=g) * 3 + 1
    y = torch.randint(0, 5, (n,), generator=g)
    return x.numpy(), y.numpy()


@test
def test_none_is_bit_identical_to_basicdataset():
    """The exact harness's 'no line differs from Finetune' claim depends on this."""
    from BCIC2020Track3_train import BasicDataset
    x, y = _batch()
    a = make_train_data(x, y, "none")
    b = BasicDataset(x, y)
    assert type(a) is BasicDataset, "aug='none' returned %s" % type(a).__name__
    for i in range(len(b)):
        xa, ya = a[i]
        xb, yb = b[i]
        assert torch.equal(xa, xb) and ya == yb, "item %d differs from BasicDataset" % i


@test
def test_shape_dtype_and_label_are_preserved():
    x, y = _batch()
    for name in PRESETS:
        d = make_train_data(x, y, name)
        xa, ya = d[0]
        assert xa.shape == (64, 800), "%s changed the shape to %s" % (name, tuple(xa.shape))
        assert xa.dtype == torch.float32, "%s changed the dtype to %s" % (name, xa.dtype)
        assert int(ya) == int(y[0]), "%s changed the label" % name
        assert len(d) == len(y)


@test
def test_every_augmentation_actually_fires():
    """An idle augmentation would run to completion and look like a null result."""
    x, y = _batch(n=64)
    base = make_train_data(x, y, "none")
    for name in ("cdrop", "light", "full"):
        d = make_train_data(x, y, name)
        moved = sum(1 for i in range(len(d)) if not torch.equal(d[i][0], base[i][0]))
        assert moved == len(d), "%s left %d/%d samples untouched" % (name, len(d) - moved, len(d))


@test
def test_stored_data_is_never_mutated():
    """__getitem__ must not write through to the array every later epoch reads."""
    x, y = _batch()
    before = torch.from_numpy(x).clone()
    d = make_train_data(x, y, "full")
    for i in range(len(d)):
        _ = d[i]
    assert torch.equal(torch.from_numpy(x), before), \
        "augmentation mutated the stored training data"


@test
def test_channel_dropout_zeroes_whole_channels():
    """Partial masking would be a different, weaker augmentation than the one named."""
    x, y = _batch(n=64)
    d = AugDataset(x, y, chan_drop=0.5)
    zeroed = total = 0
    for i in range(len(d)):
        xi, _ = d[i]
        per_ch = xi.abs().max(dim=-1).values
        is_zero = per_ch == 0
        # a channel is either fully intact or fully zero, never partly
        partly = (per_ch > 0) & (per_ch < 1e-6)
        assert not partly.any(), "item %d has a partially-masked channel" % i
        zeroed += int(is_zero.sum())
        total += per_ch.numel()
    frac = zeroed / total
    assert 0.35 < frac < 0.65, "chan_drop=0.5 zeroed %.2f of channels" % frac


@test
def test_dropout_is_independent_across_trials():
    """Same electrode pattern on every trial would be a fixed ablation, not augmentation."""
    x, y = _batch(n=64)
    d = AugDataset(x, y, chan_drop=0.5)
    masks = set()
    for i in range(len(d)):
        xi, _ = d[i]
        masks.add(tuple((xi.abs().max(dim=-1).values == 0).tolist()))
    assert len(masks) > len(d) // 4, \
        "only %d distinct dropout patterns across %d trials" % (len(masks), len(d))


@test
def test_noise_is_scale_relative():
    """Amplitude spans 21x-73x within a subject; absolute noise would be a no-op or lethal."""
    x, y = _batch(n=64)
    d = AugDataset(x, y, noise=0.1)
    x10 = x * 10.0
    d10 = AugDataset(x10, y, noise=0.1)
    torch.manual_seed(0)
    e1 = torch.stack([d[i][0] - torch.from_numpy(x[i]) for i in range(len(d))])
    torch.manual_seed(0)
    e2 = torch.stack([d10[i][0] - torch.from_numpy(x10[i]) for i in range(len(d))])
    r = (e2.std() / e1.std()).item()
    assert 9.0 < r < 11.0, "noise scaled by %.2f when the signal scaled by 10" % r


@test
def test_noise_level_matches_the_named_fraction():
    x, y = _batch(n=64)
    d = AugDataset(x, y, noise=0.1)
    errs = torch.stack([d[i][0] - torch.from_numpy(x[i]) for i in range(len(d))])
    want = 0.1 * torch.from_numpy(x).std()
    got = errs.std()
    ratio = (got / want).item()
    assert 0.9 < ratio < 1.1, "noise std is %.3f x the requested 0.1" % (ratio / 0.1)


@test
def test_shift_stays_within_bounds_and_conserves_the_signal():
    x, y = _batch(n=64)
    d = AugDataset(x, y, shift=25)
    for i in range(len(d)):
        xi, _ = d[i]
        assert torch.equal(xi.sort(dim=-1).values, torch.from_numpy(x[i]).sort(dim=-1).values), \
            "circular shift changed the multiset of samples in trial %d" % i


@test
def test_shift_actually_moves_the_signal_but_not_always_by_the_same_amount():
    x, y = _batch(n=64)
    d = AugDataset(x, y, shift=25)
    deltas = set()
    for i in range(len(d)):
        xi, _ = d[i]
        orig = torch.from_numpy(x[i])
        # recover the roll by cross-correlation on the first channel
        k = int(torch.argmax(torch.tensor(
            [float((torch.roll(orig[0], s, dims=-1) * xi[0]).sum()) for s in range(-25, 26)]))) - 25
        assert abs(k) <= 25
        deltas.add(k)
    assert len(deltas) > 1, "the shift is a fixed offset, not a random one"


@test
def test_scale_preserves_each_channels_shape_and_varies_the_gain():
    x, y = _batch(n=64)
    d = AugDataset(x, y, scale=0.1)
    gains = []
    for i in range(len(d)):
        xi, _ = d[i]
        orig = torch.from_numpy(x[i])
        g = (xi * orig).sum(dim=-1) / (orig * orig).sum(dim=-1)
        assert torch.allclose(xi, orig * g.unsqueeze(1), atol=1e-4), \
            "trial %d is not a per-channel rescaling" % i
        # EVERY channel's gain, not the per-trial mean of them. The gains are N(1, 0.1),
        # so a 64-channel mean has sd 0.1/sqrt(64) = 0.0125 -- which is what the first
        # version of this test measured, and read as "the gains are not varying".
        gains.extend(g.tolist())
    sd = float(np.std(gains))
    assert 0.05 < sd < 0.20, \
        "per-channel gains have sd %.4f, not the requested 0.1" % sd
    mean_g = float(np.mean(gains))
    assert 0.95 < mean_g < 1.05, "gains are centred on %.3f, not 1" % mean_g


@test
def test_batch_and_dataset_agree():
    """`augment_batch` and `AugDataset` are two implementations of one transform. If they
    disagree, TTA averages probabilities from a differently-distributed input than the one
    the model trained on -- a silent, plausible-looking result that means nothing.

    COMPARED ONE SAMPLE AT A TIME, batch of ONE. AugDataset draws `randn(C, 1)` and
    `rand(C)` for a single trial; augment_batch draws `randn(B, C, 1)` and `rand(B, C)`.
    With B == 1 those consume the same RNG elements in the same order, so the two are
    bit-identical -- which is the property worth asserting. With B > 1 there is no
    per-item correspondence to check at all, and the first version of this test compared
    item i of a 16-wide batch against a single-item draw and failed for that reason.

    THE SEED HAS TO COME FIRST, AND THAT WAS THE ACTUAL BUG. The second version seeded
    BETWEEN the two calls:

        xi, _ = d[i]              # draws from whatever state the RNG happened to be in
        torch.manual_seed(1234)   # <-- reset AFTER one side has already drawn
        batch = augment_batch(...)

    so `xi` and `batch[0]` were the same transform applied to two different random draws
    and could not agree for any implementation. Both sides have to start from the same
    state, which is why the seed sits above both calls now.
    """
    x, y = _batch(n=4)
    for name in ("light", "full"):
        d = make_train_data(x, y, name)
        for i in range(len(d)):
            torch.manual_seed(1234)
            xi, _ = d[i]
            batch = augment_batch(torch.from_numpy(x[i:i + 1]), name)
            assert batch[0].shape == xi.shape, \
                "%s: shapes differ, %s vs %s" % (name, tuple(batch[0].shape), tuple(xi.shape))
            assert torch.allclose(xi, batch[0], atol=1e-6), \
                "%s: item %d differs between AugDataset and augment_batch (max %.3e)" \
                % (name, i, (xi - batch[0]).abs().max().item())


@test
def test_tta_never_drops_channels():
    """Channels must survive test-time augmentation, and only chan_drop uses a (B, C)
    draw -- so a channel-dropped TTA view shows up as a fully-zero channel."""
    x, y = _batch(n=16)
    for name in PRESETS:
        for _ in range(8):
            v = augment_batch(torch.from_numpy(x), name)
            assert v.shape == x.shape
            assert torch.isfinite(v).all(), "%s produced non-finite values" % name
            if name != "cdrop":       # cdrop is all-dropout, so with drop disabled it is identity
                dead = (v.abs().max(dim=-1).values == 0).any()
                assert not dead, "%s zeroed a whole channel at test time" % name


def _smooth(n=16, C=64, T=800, seed=0):
    """A band-limited surrogate, not white noise.

    `_batch` is iid noise, and a circular shift of iid noise is UNCORRELATED with the
    original -- so the first version of the test below measured r ~ 0 for a perfectly
    correct +-25-sample roll and failed. EEG in the 1-40 Hz band is smooth over 25 samples
    (125 ms at 200 Hz), and a test signal has to be too for the assertion to mean anything.
    Moving average of white noise: smooth, same shape, cheap.
    """
    g = torch.Generator().manual_seed(seed)
    z = torch.randn(n, C, T, generator=g)
    k = 25
    return (z.unfold(-1, k, 1).mean(-1).repeat_interleave(k, dim=-1)[..., :T] * 3).numpy()


@test
def test_tta_views_differ_but_stay_close():
    """A view must actually be a different view, and must not be a different signal.

    THE THRESHOLD IS 0.90, AND IT IS MEASURED, NOT CHOSEN. The first version asserted
    0.99 and failed at 0.9396 -- and 0.9396 is the right answer, not a bug. EEG here is
    1-40 Hz; a 40 Hz component has a 5-sample period, so a +-25-sample (125 ms) circular
    shift genuinely decorrelates it. That is precisely WHY test-time augmentation can
    help: the views are different enough to disagree, but not so different that they are
    a different trial. A broken transform that returned unrelated noise would sit near 0
    and still fail this; the assertion retains its teeth.
    """
    xt = torch.from_numpy(_smooth())
    for name in ("light", "full"):
        vs = [augment_batch(xt, name) for _ in range(4)]
        assert not torch.allclose(vs[0], vs[1]), "%s produced identical views" % name
        rs = []
        for v in vs:
            a = (v - v.mean()).flatten()
            b = (xt - xt.mean()).flatten()
            rs.append(float((a * b).sum() / (a.norm() * b.norm())))
        assert min(rs) > 0.90, \
            "%s view has correlation %.4f with the original -- that is a different signal" \
            % (name, min(rs))


@test
def test_output_follows_the_input_device():
    """The output must live where the input lived, not on the default device.

    THE TEST THAT WAS MISSING WHEN IT MATTERED. Every other test here builds its input on
    the CPU, so `torch.randn(B, C, 1)` -- which allocates on the default device -- was
    always correct in the tests and always WRONG in the one caller that matters: TTA hands
    this function a CUDA tensor, and the first tta8 run died 30 seconds in with

        RuntimeError: Expected all tensors to be on the same device, but found at least
                      two devices, cuda:0 and cpu!

    so it is not enough to assert on the CPU, where the bug is invisible. This runs on
    whatever device the box has; under the queue's `CUDA_VISIBLE_DEVICES=` it is a CPU
    no-op, and it only has teeth when run WITHOUT that prefix. Hence the skip notice.
    """
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if dev.type == "cpu":
        print("      (no CUDA visible: this is a CPU no-op, run without "
              "CUDA_VISIBLE_DEVICES= for the real check)")
    x = torch.randn(3, 64, 800, device=dev)
    for name in ("none", "cdrop", "light", "full"):
        y = augment_batch(x, name)
        # Compare against x.device, NOT against `dev`. `torch.device("cuda") !=
        # torch.device("cuda:0")`, so asserting `y.device == dev` failed on exactly the
        # box this test exists to protect -- with the message "returned a cuda:0 tensor
        # from a cuda input", which reads like a bug and is actually the fix working.
        # The property that matters is that the output follows the input, whatever index
        # the input nominally carried.
        assert y.device == x.device, \
            "%s returned a %s tensor from a %s input" % (name, y.device, x.device)
        assert y.dtype == x.dtype, "%s changed the dtype to %s" % (name, y.dtype)
    # and the Dataset half must keep producing CPU items, since the DataLoader owns the
    # device move -- pinning both halves stops a future "fix" from breaking the other one
    ds = AugDataset(np.zeros((4, 64, 800), dtype=np.float32),
                    np.zeros(4, dtype=np.int64), **PRESETS["light"])
    assert ds[0][0].device.type == "cpu", "AugDataset stopped returning CPU items"


def main():
    fails = []
    for fn in _TESTS:
        try:
            fn()
            print("  ok    %s" % fn.__name__)
        except Exception as e:
            fails.append((fn.__name__, e))
            print("  FAIL  %s: %s: %s" % (fn.__name__, type(e).__name__, e))
    print("")
    if fails:
        print("%d/%d FAILED" % (len(fails), len(_TESTS)))
        for name, e in fails:
            print("   %s -> %s" % (name, e))
        raise SystemExit(1)
    print("ALL_TESTS_PASSED  (%d tests)" % len(_TESTS))


if __name__ == "__main__":
    main()
