#!/bin/bash
# Runs the `riemann` arm after the spatial arm finishes, serially, on an idle GPU --
# same reason as queue_spatial.sh: --harness exact is only reproducible with exclusive
# GPU access, because a second process changes the free memory visible at
# model-construction time and that is the state that made folds 1-4 diverge.
#
# `riemann` is the one arm that was BUILT and never run. It is gated here on test_riemann.py
# passing (15 tests: logm against an independent power series, no leakage across zones,
# autocast immunity around eigh, finite backward through eigh, the parameter census).
# spatial v1 is the precedent for running an untested arm: it scored -0.26 for two hours
# before anyone learned why.
#
# SCREEN FIRST: subjects 0-4 only. The other arms settle by subject 5, and 5 subjects is
# ~2.2 h against 6.6 h for the full set. If the paired difference is not negative beyond the
# placebo noise floor (+0.0120), extend to 5-14; if it is, the negative record is complete
# and the GPU goes back to something else.
cd /root/FAST || exit 1
P=/root/venv_fast/bin/python
LOG=/root/FAST/arms.log

for _ in $(seq 1 480); do
  grep -q QUEUE_SPATIAL_DONE "$LOG" 2>/dev/null && break
  sleep 30
done
if ! grep -q QUEUE_SPATIAL_DONE "$LOG" 2>/dev/null; then
  echo "=== riemann SKIPPED: spatial queue never reported done ===" >> "$LOG"
  exit 1
fi

echo "=== riemann START $(date +%H:%M:%S) ===" >> "$LOG"
$P -u zone_attn_probe.py --variant riemann --harness exact --subjects 0-4 >> "$LOG" 2>&1
echo "=== riemann END $(date +%H:%M:%S) ===" >> "$LOG"
echo QUEUE_RIEMANN_DONE >> "$LOG"
