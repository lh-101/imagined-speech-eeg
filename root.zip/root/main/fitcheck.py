"""Can the model fit its OWN training set? TRAIN vs TEST for one fold, for one variant.

diagnose.py answered this for `base`: TRAIN 1.0000 / TEST 0.6143, gap +0.3857. It cannot
answer it for a variant, because its build_config() takes no variant argument. That matters,
because the two failure modes want OPPOSITE fixes and the variants sit on both sides:

  overfitting  (train >> test)            the model fits; the problem is what it does with the
                                          fit, and capacity is not the lever
  underfitting (train ~= test, both low)  it cannot fit at all -- a capacity/optimisation
                                          failure, and re-arranging the spatial mixing cannot
                                          fix it

`spatial` scored -0.2589 (0/8 subjects, t=-12.05) against the released baseline, and fixing
the space/time ordering changed nothing (-0.2566 before, -0.2589 after). So the cause is
something both versions share: the shared temporal encoder, attention across electrodes, the
per-electrode position embedding, zone mean-pooling, and a head cut from 148,992 parameters to
25,184. This measurement says which of those stories is true, and therefore whether the arm is
worth repairing or abandoning.

Run on the training box, WITH THE GPU IDLE (it is a training run, bf16, same as the protocol):
    python fitcheck.py --variant spatial --subject 0
    python fitcheck.py --variant base    --subject 0     # control, reproduces diagnose.py
"""

import argparse
import logging
import os
import sys

import numpy as np
import torch
from sklearn.model_selection import KFold
from torch.utils.data import DataLoader

sys.path.insert(0, "/root/FAST")
os.chdir("/root/FAST")
logging.getLogger("pytorch_lightning").setLevel(logging.WARNING)
logging.getLogger("lightning").setLevel(logging.WARNING)

import pytorch_lightning as pl
from BCIC2020Track3_train import BasicDataset, load_standardized_h5, seed_all
from zone_attn_probe import build_config, make_encoder


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--variant", required=True)
    ap.add_argument("--subject", type=int, default=0)
    ap.add_argument("--fold", type=int, default=0)
    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--heads", type=int, default=8)
    ap.add_argument("--device", default="gpu")
    a = ap.parse_args()

    X, Y = load_standardized_h5("Processed/BCIC2020Track3.h5")
    s = a.subject
    _tr, _te = list(KFold(n_splits=5, shuffle=False).split(X[s]))[a.fold]
    x_tr, y_tr, x_te, y_te = X[s][_tr], Y[s][_tr], X[s][_te], Y[s][_te]

    seed_all(42)
    config = build_config(a.variant, a.heads)
    train_loader = DataLoader(BasicDataset(x_tr, y_tr), batch_size=len(x_tr),
                              shuffle=True, num_workers=0, pin_memory=True)
    model = make_encoder(config, a.epochs, len(train_loader))
    n_par = sum(p.numel() for p in model.model.parameters())

    dev = "cuda" if a.device == "gpu" else "cpu"
    accel = "gpu" if dev == "cuda" else "cpu"
    trainer = pl.Trainer(strategy="auto", accelerator=accel,
                         devices=[0] if accel == "gpu" else 1,
                         max_epochs=a.epochs, callbacks=[],
                         enable_progress_bar=False, enable_checkpointing=False,
                         precision="bf16-mixed" if accel == "gpu" else "32-true", logger=False)
    trainer.fit(model, train_dataloaders=train_loader)

    m = model.model
    m.eval()
    m.to(dev)

    def acc(x, y):
        with torch.no_grad():
            pred = torch.argmax(m(torch.from_numpy(x).float().to(dev)), dim=1).cpu().numpy()
        return float((pred == y).mean())

    tr_acc, te_acc = acc(x_tr, y_tr), acc(x_te, y_te)
    gap = tr_acc - te_acc
    print("variant %-10s subject %d fold %d epochs %d params %d device %s"
          % (a.variant, s, a.fold, a.epochs, n_par, dev))
    print("  TRAIN %.4f   TEST %.4f   gap %+.4f   (chance 0.2000)" % (tr_acc, te_acc, gap))
    # 0.15 is not a tuned threshold: `base` measured a gap of +0.3857 and anything a model
    # cannot fit would sit near 0. The two regimes are far apart and nothing lives between.
    print("  reading: %s" % ("OVERFITTING -- it fits; capacity is not the lever"
                             if gap > 0.15 else
                             "UNDERFITTING -- it cannot fit its own training set"))
    print("FITCHECK_DONE")


if __name__ == "__main__":
    main()
