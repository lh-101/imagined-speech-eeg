import sys, torch
sys.path.insert(0, "/root/FAST")
from transformers import PretrainedConfig
from FAST import FAST
from BCIC2020Track3_preprocess import Electrodes, Zones, SUBJECTS, CLASSES

sfreq = 250
config = PretrainedConfig(
    electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
    seq_len=800, window_len=sfreq, slide_step=sfreq // 2, head="Conv4Layers",
    n_classes=5, num_layers=4, num_heads=8, dropout=0.1)
m = FAST(config)
print("params     :", f"{sum(p.numel() for p in m.parameters()):,}")
print("electrodes :", len(Electrodes), "| zones:", len(Zones),
      "| zone channel sum:", sum(len(v) for v in Zones.values()))
print("uncovered  :", sorted(set(Electrodes) - set(c for v in Zones.values() for c in v)))
print("n_tokens   :", m.n_tokens, "(seq_len=800, window=250, step=125)")
print("classes    :", CLASSES)
x = torch.randn(2, len(Electrodes), 800)
y = m(x)
print("forward out:", tuple(y.shape), "-> OK")
print("SMOKE_TEST_PASSED")
