#!/bin/bash
# Runs the `spatial` arm after queue_arms.sh finishes, on an otherwise idle GPU and serially,
# for the reason given in queue_arms.sh: a second process changes the free memory visible at
# model-construction time, which is exactly the state that made folds 1-4 diverge in the first
# place. --harness exact is only reproducible with exclusive GPU access.
#
# Gated on the spatial arm's own test suite having passed (ALL_TESTS_PASSED): one shared
# temporal encoder over all 64 electrodes, one AttentionBlock over the 64 electrode tokens,
# then mean-pool within each anatomical zone back to the released (b, 8, 32) contract.
# 63,813 params vs base 191,781 (-67%); head 148,992 -> 21,024 (-86%); tokens still 6.
cd /root/FAST || exit 1
P=/root/venv_fast/bin/python
LOG=/root/FAST/arms.log

for _ in $(seq 1 240); do
  grep -q QUEUE_ARMS_DONE "$LOG" 2>/dev/null && break
  sleep 30
done
if ! grep -q QUEUE_ARMS_DONE "$LOG" 2>/dev/null; then
  echo "=== spatial SKIPPED: queue never reported done ===" >> "$LOG"
  exit 1
fi

echo "=== spatial START $(date +%H:%M:%S) ===" >> "$LOG"
$P -u zone_attn_probe.py --variant spatial --harness exact --subjects 0-14 >> "$LOG" 2>&1
echo "=== spatial END $(date +%H:%M:%S) ===" >> "$LOG"
echo QUEUE_SPATIAL_DONE >> "$LOG"
