"""
Baseline diagnostic: is FAST on BCIC2020 UNDER-fitting or OVER-fitting?

Why this decides everything. The two failure modes want opposite fixes:
    overfitting  (train >> test) -> augmentation, regularization, dropout,
                                    channel dropout, mixup, weight decay
    underfitting (train ~= test, both low) -> more epochs, higher capacity,
                                    higher LR, less regularization, more tokens
Changing the wrong one wastes hours and can make things worse. So measure first.

Also reports the effective learning-rate trajectory actually applied. The released
configure_optimizers builds
    cosine_scheduler(1, 0.1, 200, niter_per_ep=1, warmup_epochs=10)
i.e. a 200-entry schedule (one entry per epoch, because full-batch training gives
niter_per_ep == 1), then LambdaLR multiplies the base lr of 5e-4 by that entry. This
print confirms the ramp actually reaches its peak and where.

Run:  python diagnose.py --subjects 0-2
"""

import os
import sys
import logging
import numpy as np
import torch

sys.path.insert(0, "/root/FAST")
os.chdir("/root/FAST")
logging.getLogger("pytorch_lightning").setLevel(logging.WARNING)
logging.getLogger("lightning").setLevel(logging.WARNING)

import lightning as pl
from torch.utils.data import DataLoader
from transformers import PretrainedConfig
from sklearn.model_selection import KFold

from BCIC2020Track3_train import (
    EEG_Encoder_Module, BasicDataset, seed_all, load_standardized_h5,
    cosine_scheduler,
)
from BCIC2020Track3_preprocess import Electrodes, Zones

MAX_EPOCHS = 200
LR = 0.0005


def build_config():
    return PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1,
    )


def predict(model, x):
    model.eval()
    model.cuda()
    with torch.no_grad():
        return torch.argmax(model(x.cuda()), dim=1).cpu()


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--subjects", type=str, default="0-2")
    ap.add_argument("--epochs", type=int, default=MAX_EPOCHS)
    a = ap.parse_args()
    todo = []
    for part in a.subjects.split(","):
        if "-" in part:
            lo, hi = [int(v) for v in part.split("-")]
            todo += list(range(lo, hi + 1))
        else:
            todo.append(int(part))

    sched = cosine_scheduler(1, 0.1, a.epochs, 1, warmup_epochs=10)
    lr = LR * sched
    print("LR trajectory actually applied (base lr %.4g x schedule):" % LR)
    print("  step   1-%3d (warmup): %s" % (10, " ".join("%.2e" % v for v in lr[:10])))
    print("  step  11- 15         : %s" % " ".join("%.2e" % v for v in lr[10:15]))
    print("  peak lr %.3e at step %d | final lr %.3e | total steps %d"
          % (lr.max(), int(np.argmax(lr)) + 1, lr[-1], len(lr)))
    print("")

    config = build_config()
    X, Y = load_standardized_h5("Processed/BCIC2020Track3.h5")

    rows = []
    for s in todo:
        seed_all(42)
        for fi, (tr, te) in enumerate(KFold(n_splits=5, shuffle=False).split(X[s])):
            x_tr, y_tr = X[s][tr], Y[s][tr]
            x_te, y_te = X[s][te], Y[s][te]
            loader = DataLoader(BasicDataset(x_tr, y_tr), batch_size=len(x_tr),
                                shuffle=True, num_workers=0, pin_memory=True)
            model = EEG_Encoder_Module(config, a.epochs, len(loader))
            trainer = pl.Trainer(strategy="auto", accelerator="gpu", devices=[0],
                                 max_epochs=a.epochs, callbacks=[],
                                 enable_progress_bar=False, enable_checkpointing=False,
                                 precision="bf16-mixed", logger=False)
            trainer.fit(model, train_dataloaders=loader)

            m = model.model
            tr_acc = (predict(m, torch.from_numpy(x_tr)).numpy() == y_tr).mean()
            te_acc = (predict(m, torch.from_numpy(x_te)).numpy() == y_te).mean()
            rows.append((s, fi, tr_acc, te_acc))
            print("  [subj %02d fold %d] TRAIN %.4f   TEST %.4f   gap %+.4f"
                  % (s, fi, tr_acc, te_acc, tr_acc - te_acc), flush=True)
            del model, trainer
            torch.cuda.empty_cache()

    arr = np.array([[r[2], r[3]] for r in rows])
    print("")
    print("=== SUMMARY over %d fold-runs ===" % len(rows))
    print("  mean TRAIN acc = %.4f" % arr[:, 0].mean())
    print("  mean TEST  acc = %.4f   (released full baseline 0.5779)" % arr[:, 1].mean())
    print("  mean gap       = %+.4f" % (arr[:, 0] - arr[:, 1]).mean())
    print("")
    if arr[:, 0].mean() > 0.95:
        print("  -> OVERFITTING. Train is near-perfect while test sits at 0.58.")
        print("     Fixes that should work: augmentation, dropout, weight decay,")
        print("     channel dropout, mixup, input normalization.")
    elif arr[:, 0].mean() - arr[:, 1].mean() < 0.10:
        print("  -> UNDERFITTING. Train is barely above test.")
        print("     Fixes that should work: more epochs, higher lr, more capacity.")
    else:
        print("  -> MIXED. Both regularisation AND more training may help.")
    print("DIAG_DONE")


if __name__ == "__main__":
    main()
