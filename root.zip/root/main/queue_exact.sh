#!/bin/bash
# Under --harness exact, which is Finetune's fold body verbatim. Verified on subject 0:
# 0.5714 0.5286 0.6714 0.5429 0.6714, identical to the stored released CSV.
#
# RUN SERIALLY AND WITH THE GPU OTHERWISE IDLE. The whole reason folds 1-4 diverged is
# that the live allocation set at model-construction time changes kernel selection. A second
# process on the GPU, or two arms at once, changes free memory and destroys that property.
# Do not co-schedule anything with this queue.
cd /root/FAST || exit 1
P=/root/venv_fast/bin/python

run () {  # run <variant> [extra args]
  local v=$1; shift
  echo "=== $v START $(date +%H:%M:%S) ==="
  $P -u zone_attn_probe.py --variant "$v" --harness exact --subjects 0-14 "$@"
  echo "=== $v END $(date +%H:%M:%S) ==="
}

# 1. The true baseline through the probe. Must land on 0.5779. If it does not, nothing
#    below it is interpretable and the queue should be stopped.
run base

# 2. The paper's own head. Conv4Layers runs cnn1..cnn4 with NO activation between them and
#    one gelu at the end, so the affine identity holds to 1.097e-06 and 77.7% of the
#    parameters buy a single linear map. The author's own unused HeadConv_Paper_Version
#    applies gelu(norm(.)) after each of its four blocks. +0 parameters.
run nl

# 3. Whole-epoch pooling with mean AND std. Best hand-built feature was whole-epoch
#    mean+std (0.4149); time-resolved power is measurably worse (-0.131).
run w1std

# 4. Capacity-reduction control: share the temporal convs across zones, -38% params.
#    diagnose.py says TRAIN 1.0000 / TEST 0.6143, so capacity is the liability.
run sharedtemp

# 5. THE CONTROL. Byte-identical architecture to base, one extra torch.randn(1) before
#    construction. Any gap between this and base is a gap the released protocol itself
#    produces from a change that is not an architecture change.
run placebo

echo QUEUE_EXACT_DONE
