#!/bin/bash
# ONE queue in priority order. Replaces queue_lr.sh / queue_chain.sh / queue_pri.sh.
#
# Rewritten rather than appended to for two reasons. (1) bash reads a running script
# incrementally, so editing a live one can execute garbage -- a separate waiter script was
# the old workaround, but that forced the new arms to the BACK of the queue. (2) A
# statistics review changed what deserves to run first: the follow-on arms that make the
# existing verdict trustworthy now outrank the new candidate architectures, because if the
# schedule confound is real then every candidate has to be re-measured under a matched
# budget anyway.
#
# Everything here resumes: the runner skips any subject whose .npz already exists. So
# re-running this file, or interrupting it, is safe and loses at most the subject in flight.
cd /root/FAST || exit 1
P=/root/venv_fast/bin/python

# --- 1. THE VERDICT (~36 min, 10 new subjects each) ----------------------------------
# Pre-registered rule, fixed before these numbers exist: positive DiD with |t| >= 2 means
# the released schedule charges architecture variants a mismatch fee and every comparison
# must be matched-budget; otherwise the variant is genuinely worse and the move is
# structural. analyze_lr.py section 3 applies the rule.
echo "=== base lr=1e-3 to n=15 START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant base --lr 1e-3 --subjects 0-14
echo "=== base lr=1e-3 END $(date +%H:%M:%S) ==="

echo "=== zoneattn lr=1e-3 to n=15 START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant zoneattn --lr 1e-3 --subjects 0-14
echo "=== zoneattn lr=1e-3 END $(date +%H:%M:%S) ==="

# --- 2. MAKE THE VERDICT TRUSTWORTHY (~81 min) ---------------------------------------
# Three lr levels let the arch x lr interaction be fitted as a per-subject slope in
# log10(lr) instead of a single two-point DiD. That is ~2.3x more precise (it uses all
# three cells) and it is the cheapest power available: it needs no new code, only these
# arms at 15 subjects rather than 5. Ranked above the candidate architectures on purpose.
echo "=== base lr=2e-4 to n=15 START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant base --lr 2e-4 --subjects 0-14
echo "=== base lr=2e-4 END $(date +%H:%M:%S) ==="

echo "=== zoneattn lr=2e-4 to n=15 START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant zoneattn --lr 2e-4 --subjects 0-14
echo "=== zoneattn lr=2e-4 END $(date +%H:%M:%S) ==="

# The released arm is at 14/15; the matched-budget design compares best-of-two schedules
# per architecture, so it needs all 15.
echo "=== zoneattn released to n=15 START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant zoneattn --subjects 0-14
echo "=== zoneattn released END $(date +%H:%M:%S) ==="

# THE UNDER-TRAINING CONTROL, and the reason it is worth 54 min. With exactly 1 gradient
# step per epoch, "lr" is also "distance travelled", so the DiD cannot tell "zoneattn pays
# a mismatch fee" from "zoneattn simply needs more optimisation". A 400-step arm is only
# interpretable if BOTH architectures get one -- a one-armed control can say "zoneattn
# improved with more steps" but not whether the improvement survives base's own.
echo "=== base 400 steps START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant base --epochs 400 --subjects 0-14
echo "=== base 400 steps END $(date +%H:%M:%S) ==="

echo "=== zoneattn 400 steps START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant zoneattn --epochs 400 --subjects 0-14
echo "=== zoneattn 400 steps END $(date +%H:%M:%S) ==="

# --- 3. THE CANDIDATE ARCHITECTURES (~84 min) ---------------------------------------
# Run LAST of the three groups, not first: their numbers are only interpretable once we
# know whether the schedule confound is real. If it is, each of these needs a second arm
# at its own lr before any claim is made about it, and that decision is made by section 3.
# w1std carries the mechanism (whole-epoch mean+std is the best hand-built representation
# measured and the released front end can only compute the mean); w1 prices what the
# 5-window tokenisation was worth; riemann is the spatial second-order branch.
echo "=== w1std START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant w1std
echo "=== w1std END $(date +%H:%M:%S) ==="

echo "=== riemann START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant riemann
echo "=== riemann END $(date +%H:%M:%S) ==="

echo "=== w1 START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant w1
echo "=== w1 END $(date +%H:%M:%S) ==="

echo QUEUE_ALL_DONE
