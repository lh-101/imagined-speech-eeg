#!/bin/bash
# Run a list of variants sequentially, waiting for a free GPU slot before each.
#
# The box holds two concurrent probe processes; a third exceeds the 12 GB of the card.
# Each arm is ~25 minutes for all 15 subjects, and zone_attn_probe.py skips any subject
# whose .npz already exists, so this is safe to re-run after an interruption.
#
cd /root/FAST || exit 1

# ONE ARM AT A TIME, deliberately. The card is at 100% either way, and splitting it does
# not split the work evenly -- measured on this box, base alone ran 1.6 min/subject while
# two concurrent arms ran 4.6 min/subject each, i.e. 2.3 min/subject of aggregate
# throughput. Serial is therefore ~44% FASTER in total, and it also puts the first
# interpretable result on the table in ~25 minutes instead of waiting for two arms.
# Order the arguments best-first so the most promising arm reports first.
for v in "$@"; do
    echo "=== $v START $(date +%H:%M:%S) ==="
    /root/venv_fast/bin/python -u zone_attn_probe.py --variant "$v" --tag "$v-h8"
    echo "=== $v END $(date +%H:%M:%S) ==="
done
echo QUEUE_DONE
