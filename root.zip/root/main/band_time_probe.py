"""
IS THE MISSING INFORMATION SPECTRAL, OR TEMPORAL?

WHY. Two structural defects in FAST are established, not argued:

  (a) No spatial attention. Space is flattened and squeezed by one Linear(256->32)
      before the transformer runs. See fast_zones.py -- being tested separately.
  (b) The zone encoder's temporal receptive field is 13 samples = 52 ms, and what
      follows it is `einops.reduce(x, 'B F 1 T -> B F', 'mean')`, a plain average
      over the 1 s window. Anything that oscillates faster than about 4 Hz does not
      survive that average, and nothing below about 20 Hz fits inside the 52 ms
      receptive field to begin with.

spectral_probe.py already killed one version of the fix: STATIC whole-epoch log band
power gets 0.3623 against FAST's 0.5779 (t = -14.3, 0/15 subjects), and the Riemannian
tangent-space baseline gets 0.4015 (t = -10.7). So "add a frequency branch" is not
the answer on its own.

That result does NOT settle defect (b), because a whole-epoch band power is itself an
average -- it throws away exactly the temporal dynamics that the 1 s mean pooling is
suspected of destroying. This script separates the two:

    std over the WHOLE epoch   vs   std in each of 5 / 10 SUB-windows

std within a short window is the signal's amplitude envelope over that window: the
quantity the 1 s mean pooling discards. If sub-window std recovers substantially more
class information than whole-epoch std, the loss is TEMPORAL and the fix belongs in
the tokenisation (finer time resolution), not in a frequency branch. If it does not,
mean pooling is not the problem and the temporal-tokenisation plan should be dropped.

The same split is run per band, so the spectral and temporal axes are measured
independently: does a band only pay off once it is allowed to vary over time?

HONESTY ABOUT THE C GRID. Feature dimension ranges from 64 to 3,840 against only 280
training trials, so a single fixed C would understate the high-dimensional sets. Both
the best-C accuracy over a small fixed grid and the accuracy at the reference C=0.1
are reported side by side. The best-C column is an UPPER BOUND and is selected on the
same folds it is scored on, so it is a headroom estimate, never a result to quote.
The C=0.1 column is the comparable one.

CPU only. Run: python band_time_probe.py
"""

import os
import sys
import numpy as np

from spectral_probe import band_power, N_PAD
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import KFold

H5 = "Processed/BCIC2020Track3.h5"
OUT = "Results/BT"
BANDS = ["delta", "theta", "alpha", "beta", "gamma", "hgamma"]
C_GRID = [0.003, 0.01, 0.03, 0.1, 0.3]
C_REF = 0.1
REF_FAST = 0.5779


def acc(F, y, C):
    a = []
    for tr, te in KFold(n_splits=5, shuffle=False).split(F):
        clf = make_pipeline(StandardScaler(),
                            LogisticRegression(C=C, max_iter=3000, n_jobs=-1))
        clf.fit(F[tr], y[tr])
        a.append(float((clf.predict(F[te]) == y[te]).mean()))
    return float(np.mean(a))


def eval_set(F, y):
    """Returns (best-C accuracy, its C, accuracy at the reference C)."""
    best, bestC = -1.0, None
    for C in C_GRID:
        v = acc(F, y, C)
        if v > best:
            best, bestC = v, C
    return best, bestC, acc(F, y, C_REF)


def sub_windows(T, k):
    """k contiguous (start, stop) spans covering T. Named s/e, NOT a/b: the caller
    also loops over band names and a stray `b` would be silent."""
    e = np.linspace(0, T, k + 1).astype(int)
    return list(zip(e[:-1], e[1:]))


def main():
    import h5py
    os.makedirs(OUT, exist_ok=True)
    print("reference: released FAST 0.5779, chance 0.2000, n=280 train per fold")
    print("C grid %s, reference C=%.3g" % (C_GRID, C_REF))
    print("")

    names = (["mom_epoch", "std_time5", "std_time10"]
             + ["bp_%s_epoch" % b for b in BANDS]
             + ["bp_%s_time5" % b for b in BANDS]
             + ["bp_all_time5"])
    res = {k: [] for k in names}

    with h5py.File(H5, "r") as f:
        for key in sorted(f.keys()):
            X = f[key]["X"][()].astype(np.float64)
            Y = f[key]["Y"][()]
            if Y.ndim > 1:
                Y = Y.argmax(1)
            T = X.shape[2] - N_PAD
            x = X[:, :, :T]

            bp = np.log10(band_power(x) + 1e-12)                  # (n, ch, 6)
            row = {}
            row["mom_epoch"] = np.c_[x.mean(axis=2), x.std(axis=2)]
            for k, nm in [(5, "std_time5"), (10, "std_time10")]:
                row[nm] = np.concatenate([x[:, :, s:e].std(axis=2)
                                          for s, e in sub_windows(T, k)], axis=1)
            for bi, band in enumerate(BANDS):
                row["bp_%s_epoch" % band] = bp[:, :, bi]
                row["bp_%s_time5" % band] = np.concatenate(
                    [np.log10(band_power(x[:, :, s:e])[:, :, bi] + 1e-12)
                     for s, e in sub_windows(T, 5)], axis=1)
            w5 = [np.log10(band_power(x[:, :, s:e]) + 1e-12)
                  for s, e in sub_windows(T, 5)]
            row["bp_all_time5"] = np.concatenate(
                [w.reshape(w.shape[0], -1) for w in w5], axis=1)

            for k in names:
                best, bc, ref = eval_set(row[k], Y)
                res[k].append((best, bc, ref, row[k].shape[1]))
            s = "  ".join("%s %.3f" % (k, res[k][-1][2])
                          for k in ["mom_epoch", "std_time5", "std_time10"])
            print("  %s %s" % (key, s), flush=True)
            del X

    print("")
    print("=== MEAN OVER 15 SUBJECTS ===")
    print("  %-18s %6s %8s %7s %8s" % ("feature set", "dim", "bestC", "atC", "ref C=0.1"))
    arr = {}
    for k in names:
        v = np.array([[r[0], r[2]] for r in res[k]])
        arr[k] = v
        dim = res[k][0][3]
        bcs = [r[1] for r in res[k]]
        print("  %-18s %6d %8.4f %7.2g %8.4f"
              % (k, dim, v[:, 0].mean(), np.median(bcs), v[:, 1].mean()))

    def pair(k):
        d = arr[k][:, 1] - REF_FAST
        se = d.std(ddof=1) / np.sqrt(len(d))
        return d.mean(), se, d.mean() / se

    print("")
    print("=== THE DECIDING COMPARISONS (paired t over 15 subjects, vs FAST 0.5779) ===")
    for k in ["mom_epoch", "std_time5", "std_time10"]:
        m, se, t = pair(k)
        print("  %-12s mean %.4f  diff %+.4f (se %.4f)  t=%+.2f" % (k, arr[k][:, 1].mean(), m, se, t))

    print("")
    print("  TEMPORAL: does sub-window std beat whole-epoch moments? (paired across subjects)")
    for k in ["std_time5", "std_time10"]:
        d = arr[k][:, 1] - arr["mom_epoch"][:, 1]
        se = d.std(ddof=1) / np.sqrt(len(d))
        print("    %-11s - mom_epoch = %+.4f (se %.4f) t=%+.2f  %s"
              % (k, d.mean(), se, d.mean() / se,
                 "positive in %d/15" % int((d > 0).sum())))

    print("")
    print("  SPECTRAL: does time resolution help WITHIN each band?")
    for b in BANDS:
        d = arr["bp_%s_time5" % b][:, 1] - arr["bp_%s_epoch" % b][:, 1]
        se = d.std(ddof=1) / np.sqrt(len(d))
        print("    %-8s time5 - epoch = %+.4f (se %.4f) t=%+.2f"
              % (b, d.mean(), se, d.mean() / se))

    print("")
    print("  best single band at whole-epoch resolution:")
    for b in BANDS:
        print("    %-8s %.4f" % (b, arr["bp_%s_epoch" % b][:, 1].mean()))

    np.savez("%s/summary.npz" % OUT, **{k: arr[k] for k in names},
             names=np.array(names))
    print("BT_DONE")


if __name__ == "__main__":
    main()
