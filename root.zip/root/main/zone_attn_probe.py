"""
Controlled ablation of the tokenisation change in fast_zones.FAST_ZoneAttn.

THE REFERENCE THIS HARNESS WAS COMPARED AGAINST DOES NOT REPRODUCE, and finding that out is
why the harness argument exists. base through this harness scores 0.5949; the released
BCIC2020Track3_train.py Finetune scored 0.5779 on this same box (Results/FAST/SUMMARY.txt:
`python -u BCIC2020Track3_train.py --gpu 0 --folds 0-15`, torch 2.1.2+cu118, RTX 4080
SUPER). Same model, same seed, same data. The two agree trial for trial on FOLD 0 -- 70/70
on subjects 0, 1 and 2 -- and disagree on folds 1-4 (46-61/70). So data, split, seeding and
fold-0 training are identical and the whole gap is state carried between folds.

The first explanation for that (torch.cuda.empty_cache() between folds, which Finetune does
not call) is REFUTED: --harness released drops exactly that line and leaves subject 00 at
0.6657 and subject 01 at 0.5771, bit-identical to legacy, 2/2. What is left is the two
structural differences --harness exact restores: Finetune builds the test DataLoader before
the model, and never frees the previous fold's model. Both change which GPU allocations are
live at construction time, hence possibly the cuBLAS/cuDNN workspace choice and the bf16
rounding path, hence the model, 200 steps later. Fold 0 is the first model built either way,
with the same free memory, which is why it is the fold that agrees.

The consequence is not bookkeeping. A variant arm has a different model shape, so it
consumes RNG differently and lands on a DIFFERENT stream after fold 0, against a reference
that itself does not reproduce. Arm-level comparisons therefore carry an offset that has
nothing to do with architecture -- of the same order as most of the penalties previously
reported from this table. Use --harness pinned for any comparison between arms, and re-read
the old table as exploratory only.

What IS safe: any contrast between two arms that share an architecture, a subject and a
stream -- i.e. the difference-in-differences in analyze_lr.py, where the offset cancels
exactly.

Other than the harness, everything here matches the released protocol -- seed_all once
before the fold loop, KFold(5, shuffle=False), full-batch training so one gradient step
per epoch, 200 epochs, AdamW lr 5e-4 under the same cosine LambdaLR, bf16-mixed.

Variants
  base       the released model, run through this harness. Not taken from the
             existing results on disk, so the comparison is paired on code path as
             well as on subject.
  zoneattn   identical except that the (window x zone) features become 40 content
             tokens addressed by a factorised position code, instead of being
             flattened and squeezed through one Linear(256->32) before attention.

  --heads    overrides config.num_heads for either variant. The released value is 8,
             which with dim_token=32 gives head_dim=4. Exposed because the zoneattn
             token set is 41 rather than 6 and the right head count may differ, but
             any change to it must be reported as a SEPARATE row, never folded into
             the tokenisation result.

Writes Results/ZA/<subj>-<tag>.npz with per-trial correctness and the fold index, so
the analysis can pair the variants trial by trial rather than only on the mean.
"""

import os
import sys
import types
import argparse
import logging
import numpy as np
import torch
import torch.optim as optim

sys.path.insert(0, "/root/FAST")
os.chdir("/root/FAST")
logging.getLogger("pytorch_lightning").setLevel(logging.WARNING)
logging.getLogger("lightning").setLevel(logging.WARNING)

import lightning as pl
from torch.utils.data import DataLoader
from transformers import PretrainedConfig
from sklearn.model_selection import KFold

from BCIC2020Track3_train import (
    EEG_Encoder_Module, BasicDataset, seed_all, load_standardized_h5,
    inference_on_loader,
)
import BCIC2020Track3_train as train_mod
from BCIC2020Track3_preprocess import Electrodes, Zones
import fast_zones
from aug_dataset import PRESETS, make_train_data, augment_batch
from BCIC2020Track3_train import cosine_scheduler

RUN = "Results/ZA"
MAX_EPOCHS = 200


def _configure_optimizers_override(self):
    """configure_optimizers with the run's lr / warmup instead of the released constants.

    THE POINT OF THIS. The released protocol fixes lr = 5e-4 over 200 steps with a
    10-step warmup, and -- because batch_size is the whole training fold -- exactly ONE
    gradient step per epoch. That schedule was co-tuned with the released architecture by
    its authors. Running an architecture variant under it measures the variant's ability
    to work under SOMEONE ELSE'S schedule, which is not the same question as whether the
    variant is better.

    Nothing about the schedule's SHAPE is changed: same cosine_scheduler(1, 0.1, ...)
    multiplier list, same LambdaLR driven by global_step. Only the base learning rate and
    the warmup length move, so a run at a different lr is the same recipe at a different
    step size and the two are directly comparable.
    """
    lr = self._lr_override if self._lr_override is not None else 0.0005
    warmup = self._warmup_override if self._warmup_override is not None else 10
    self.cosine_lr_list = cosine_scheduler(1, 0.1, self._max_epochs, self._niter_per_ep,
                                           warmup_epochs=warmup)
    self.optimizer = optim.AdamW(self.parameters(), lr=lr)
    self.scheduler = optim.lr_scheduler.LambdaLR(
        self.optimizer, lambda epoch: self.cosine_lr_list[self.global_step - 1])
    return [self.optimizer], [{'scheduler': self.scheduler, 'interval': 'step'}]


def build_config(variant, heads):
    return PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=heads, dropout=0.1, variant=variant,
    )


def make_encoder(config, max_epochs, niter_per_ep, lr=None, warmup=None):
    """Build EEG_Encoder_Module with this variant's model class.

    EEG_Encoder_Module.__init__ runs `self.model = Tower(config)`, where Tower is a
    module-level global bound to FAST at import time. Patching that global for the
    duration of the constructor makes the model get built EXACTLY ONCE, through the
    same line of code as the released path and as channel_probe.py.

    Subclassing and reassigning `self.model` afterwards is the obvious-looking
    alternative and it is WRONG: it constructs a FAST first and throws it away, which
    draws a second set of values from the global torch RNG. seed_all(42) is called
    once before the fold loop, so every model after that point is initialised from a
    different RNG state than the released protocol would use. Verified concretely --
    that version gave a base mean of 0.635 over the first four subjects against the
    released 0.5779, i.e. it was a different model, not a better one.
    """
    orig = train_mod.Tower
    train_mod.Tower = fast_zones.build
    try:
        module = EEG_Encoder_Module(config, max_epochs, niter_per_ep)
    finally:
        train_mod.Tower = orig

    # The override is attached to the INSTANCE, not to the class. Lightning calls
    # configure_optimizers at fit time, long after this function returns, so a class-level
    # patch restored in a `finally` would be gone by then and the run would silently use
    # the released lr -- i.e. every lr arm would be a duplicate of the 5e-4 arm and the
    # whole experiment would report that the schedule does not matter.
    module._lr_override = lr
    module._warmup_override = warmup
    module._max_epochs = max_epochs
    module._niter_per_ep = niter_per_ep
    module.configure_optimizers = types.MethodType(_configure_optimizers_override, module)
    return module


def predict(model, x):
    model.eval()
    model.cuda()
    with torch.no_grad():
        return torch.argmax(model(x.cuda()), dim=1).cpu()


def predict_tta(model, x, n, aug):
    """Average softmax over n augmented views of the test set, then argmax.

    Probabilities, not logits: the views are of the same trial, so the mean must be taken
    where the outputs are already comparable distributions. Averaging logits answers a
    different question (it is not a vote) and would silently weight an over-confident view
    more than a cautious one.

    TTA CANNOT BE APPLIED TO AN EXISTING RUN. `enable_checkpointing=False` in both the
    released Finetune and this harness, so no fold's weights survive the fold loop -- there
    is nothing on disk to re-evaluate. A TTA arm is a full training run.
    """
    model.eval()
    model.cuda()
    x = torch.from_numpy(x).float().cuda()
    acc = None
    with torch.no_grad():
        for i in range(n):
            xi = x if i == 0 else augment_batch(x, aug)
            p = torch.softmax(model(xi).float(), dim=1)
            acc = p if acc is None else acc + p
    return torch.argmax(acc, dim=1).cpu().numpy()


def run_subject(s, X, Y, config, lr=None, warmup=None, epochs=None,
                seed=42, harness="legacy", aug="none", tta=1, tta_aug=None,
                shuffle_labels=False):
    """Train every fold for one subject.

    harness picks how much of the released fold loop the probe reproduces. base through
    the legacy harness scores 0.5949 while the released Finetune scores 0.5779 for the
    same model, same seed, same data -- and the two are BIT-IDENTICAL on fold 0, verified
    trial by trial against Results/FAST/<s>-Tune.csv (70/70 trials on subjects 0, 1 and 2).
    Every bit of the gap is in folds 1-4. The mechanism is therefore state that carries
    from one fold to the next, and it is NOT torch.cuda.empty_cache(): dropping it
    (--harness released) leaves subject 00 at 0.6657 and subject 01 at 0.5771, i.e.
    bit-identical to legacy, 2/2. What remains are the two structural differences in
    --harness exact below.

      legacy   (default) the historical probe behaviour, so every file already on
               disk stays reproducible: predict() on a tensor, del model/trainer, then
               torch.cuda.empty_cache() between folds.
      released legacy minus the empty_cache.
      pinned   released plus a re-seed at the top of every fold. This is the only mode
               in which arms are comparable: an arm's model shape changes how many RNG
               draws construction and dropout consume, so after fold 0 every arm is on a
               different stream and carries a different offset. Measured size of that
               offset: folds 1-4 differ by sd 0.041 per subject between two harnesses,
               i.e. ~0.011 on a 15-subject mean -- the same order as most of the
               arm-vs-base penalties being reported.
      exact    a verbatim mirror of Finetune's fold body. The released loop builds
               BasicDataset(x_test) and the test DataLoader BEFORE the model, never frees
               the previous fold's model, and evaluates through inference_on_loader.
               The first two change which GPU allocations are live when the next model is
               constructed; cuBLAS/cuDNN workspace choice can depend on free memory, so
               the bf16 rounding path differs, and 200 steps at lr 5e-4 amplifies a
               rounding difference into a different model. Fold 0 is unaffected because
               it is the first model built either way, with the same free memory -- which
               is exactly the observed pattern.
    """
    epochs = MAX_EPOCHS if epochs is None else epochs

    if harness == "exact":
        # Deliberately a separate body rather than more branches below. The whole point is
        # that no line of this differs from Finetune; the only additions are the bookkeeping
        # needed to return per-trial correctness instead of writing a CSV, and the lr/warmup
        # override, which reproduces Finetune's own configure_optimizers when both are None.
        seed_all(seed)
        correct = np.zeros(350, dtype=bool)
        fold_of = np.full(350, -1, dtype=int)
        for fi, (_train_idx, _test_idx) in enumerate(
                KFold(n_splits=5, shuffle=False).split(X[s])):
            x_train, y_train = X[s][_train_idx], Y[s][_train_idx]
            x_test, y_test = X[s][_test_idx], Y[s][_test_idx]

            if shuffle_labels:
                # Permute the TRAINING labels only. Two things this must NOT do:
                #   * touch y_test -- the accuracy is still scored against the truth, or
                #     the control would be measuring its own permutation;
                #   * use the global RNG -- seed_all(seed) ran once above and every draw
                #     after it is part of the released stream, so consuming from it here
                #     would shift the initialisation of every fold and make this control
                #     incomparable to base for a reason that has nothing to do with labels.
                # A fold-local RandomState keyed on the seed keeps it reproducible and
                # keeps fold fi's permutation independent of every other fold's.
                _rs = np.random.RandomState(seed * 1000 + fi)
                y_train = y_train[_rs.permutation(len(y_train))]

            # `aug="none"` returns BasicDataset itself, so with the default this line is
            # bit-identical to Finetune's. The test split below is NEVER augmented: the
            # reported accuracy must be measured on clean data.
            train_data = make_train_data(x_train, y_train, aug)
            train_loader = DataLoader(train_data, batch_size=len(x_train), shuffle=True,
                                      num_workers=0, pin_memory=True)
            test_data = BasicDataset(x_test, y_test)
            test_loader = DataLoader(test_data, batch_size=len(x_test), shuffle=False,
                                     num_workers=0, pin_memory=True)

            model = make_encoder(config, epochs, len(train_loader), lr=lr, warmup=warmup)
            trainer = pl.Trainer(strategy="auto", accelerator="gpu", devices=[0],
                                 max_epochs=epochs, callbacks=[],
                                 enable_progress_bar=False, enable_checkpointing=False,
                                 precision="bf16-mixed", logger=False)
            trainer.fit(model, train_dataloaders=train_loader)

            # Test data is used only once. With tta == 1 this is Finetune's own call,
            # unchanged; the TTA path replaces it only when explicitly asked for.
            if tta > 1:
                pred = predict_tta(model.model, x_test, tta, tta_aug)
                real = y_test
            else:
                pred, real = inference_on_loader(model.model, test_loader)
            correct[_test_idx] = pred == real
            fold_of[_test_idx] = fi
            print("    [subj %02d fold %d] acc %.4f" % (s, fi, correct[_test_idx].mean()),
                  flush=True)
            if shuffle_labels:
                # The control only means something if the model still FITS. If shuffled
                # labels dropped TRAIN to chance, "test == chance" would just be an
                # undertrained model, not evidence about the labels. 191k parameters over
                # 280 trials says it should memorise anything; this checks that it did.
                tr_pred, _ = inference_on_loader(model.model, train_loader)
                tr_acc = float((tr_pred == y_train).mean())
                print("      [shuf subj %02d fold %d] TRAIN acc on the SHUFFLED labels "
                      "%.4f  (must stay near 1.0 or the control is void)"
                      % (s, fi, tr_acc), flush=True)
            # No del, no empty_cache: the next fold's model must be constructed while this
            # fold's model and trainer are still alive, as in Finetune.
        return correct, fold_of

    seed_all(seed)                            # once, before the fold loop, as Finetune()
    correct = np.zeros(350, dtype=bool)
    fold_of = np.full(350, -1, dtype=int)
    for fi, (tr, te) in enumerate(KFold(n_splits=5, shuffle=False).split(X[s])):
        if harness == "pinned":
            seed_all(seed)                    # pin every fold to the same RNG state
        x_tr, y_tr = X[s][tr], Y[s][tr]
        loader = DataLoader(make_train_data(x_tr, y_tr, aug), batch_size=len(x_tr),
                            shuffle=True, num_workers=0, pin_memory=True)
        model = make_encoder(config, epochs, len(loader), lr=lr, warmup=warmup)
        trainer = pl.Trainer(strategy="auto", accelerator="gpu", devices=[0],
                             max_epochs=epochs, callbacks=[],
                             enable_progress_bar=False, enable_checkpointing=False,
                             precision="bf16-mixed", logger=False)
        trainer.fit(model, train_dataloaders=loader)
        correct[te] = (predict(model.model, torch.from_numpy(X[s][te])).numpy() == Y[s][te])
        fold_of[te] = fi
        print("    [subj %02d fold %d] acc %.4f" % (s, fi, correct[te].mean()), flush=True)
        del model, trainer
        if harness == "legacy":
            # Absent from the released Finetune. It canonicalizes allocator state, which
            # can change kernel selection and hence the bf16 rounding path; over the 200
            # steps that follow, that is worth about +0.02 on a subject. Kept as the
            # default only so that already-written results reproduce.
            torch.cuda.empty_cache()
    return correct, fold_of


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--subjects", type=str, default="0-14")
    ap.add_argument("--variant", type=str, default=None,
                    help="REQUIRED (except with --report-only / --verify-base). There "
                         "is deliberately no default: the old default was 'zoneattn', "
                         "so any invocation that forgot the flag silently trained the "
                         "wrong model and wrote it under the requested tag.")
    ap.add_argument("--harness", type=str, default="legacy",
                    choices=("legacy", "released", "pinned", "exact"),
                    help="legacy = the historical probe behaviour (predict() on a tensor, "
                         "del model/trainer, empty_cache between folds); released = drop "
                         "the empty_cache (measured: a no-op, 2/2 bit-identical to legacy); "
                         "pinned = released + re-seed every fold, the only mode in which "
                         "arms are comparable; exact = a verbatim mirror of Finetune's fold "
                         "body. Non-legacy modes go into the tag.")
    ap.add_argument("--seed", type=int, default=42,
                    help="seed for seed_all; non-default values go into the tag")
    ap.add_argument("--heads", type=int, default=8)
    ap.add_argument("--aug", type=str, default="none", choices=sorted(PRESETS),
                    help="training-set augmentation preset (see aug_dataset.py). Applied "
                         "in __getitem__, so the 200 epochs see 200 different views of the "
                         "280 trials. 'none' is bit-identical to BasicDataset, so it does "
                         "not perturb the exact harness. Non-default values go into the tag.")
    ap.add_argument("--tag", type=str, default=None)
    ap.add_argument("--tta", type=int, default=1,
                    help="average softmax over this many augmented views of the test set. "
                         "1 = off, and reproduces Finetune's own inference call exactly. "
                         "Requires a FULL training run: no checkpoints are kept, so there "
                         "is nothing on disk to re-evaluate.")
    ap.add_argument("--tta-aug", type=str, default=None, choices=sorted(PRESETS),
                    help="which augmentation to build the test-time views from. Defaults "
                         "to --aug when that is set, else 'light'. Channel dropout is "
                         "forced off at test time either way -- see aug_dataset.")
    ap.add_argument("--shuffle-labels", action="store_true",
                    help="SHUFFLED-LABEL CONTROL. Permute the TRAINING labels within each "
                         "fold, independently per fold, and train exactly as ever. The "
                         "test labels are left untouched, so accuracy is still measured "
                         "against the truth. This is the one experiment that tests the "
                         "premise every architecture arm silently assumed -- that part of "
                         "the ~0.61 is signal learned from the labels. The model has "
                         "enough capacity to reach TRAIN 1.0 on random labels (191k "
                         "parameters, 280 trials), so: TEST ~= the fold's majority-class "
                         "rate means the accuracy was label-driven; TEST above it means "
                         "the accuracy comes from structure shared between train and "
                         "test trials that has nothing to do with the labels.")
    ap.add_argument("--lr", type=float, default=None,
                    help="override the released 5e-4 base lr (same schedule shape)")
    ap.add_argument("--warmup", type=int, default=None,
                    help="override the released 10-step warmup")
    ap.add_argument("--epochs", type=int, default=None,
                    help="override the released 200 steps; with batch == training fold "
                         "there is exactly one gradient step per epoch, so this is the "
                         "step count and not just the epoch count")
    ap.add_argument("--report-only", action="store_true",
                    help="print the parameter counts and exit, no training")
    ap.add_argument("--verify-base", type=int, default=None, metavar="SUBJ",
                    help="run base on this subject, diff per-trial correctness against "
                         "Results/CP/<subj>-chan.npz, and exit without writing results")
    a = ap.parse_args()

    if a.verify_base is not None:
        # The flag must test what its name says. It used to inherit the --variant
        # default, so it built zoneattn and diffed that against the released-model
        # baseline -- it could never have passed, and the harness it claimed to verify
        # was never actually verified by it.
        a.variant = "base"
    if a.shuffle_labels and a.harness != "exact":
        # The permutation lives in the `exact` fold body only. In legacy/pinned/released
        # it would be accepted and silently ignored, producing a normal-looking base run
        # filed under a "-shuf" tag -- i.e. a control that reports the thing it was
        # supposed to test as if the test had been run. Refuse instead.
        ap.error("--shuffle-labels is only implemented for --harness exact; running it "
                 "elsewhere would silently train on the true labels and file the result "
                 "as a control")
    if a.variant is None and not a.report_only:
        ap.error("--variant is required (no default: a wrong default is silent, a "
                 "missing argument is not)")

    # The lr, warmup, epochs, seed and harness go INTO the default tag. Without this, a
    # non-default run could land in a default-named file and be read as the released
    # number. `legacy` and seed 42 add nothing, so every file already on disk keeps its
    # name; the newer harnesses cannot collide with them.
    tag = a.tag
    if tag is None:
        tag = "%s-h%d" % (a.variant, a.heads)
        if a.lr is not None:
            tag += "-lr%g" % a.lr
        if a.warmup is not None:
            tag += "-wu%d" % a.warmup
        if a.epochs is not None:
            tag += "-ep%d" % a.epochs
        if a.aug != "none":
            tag += "-aug%s" % a.aug
        if a.tta != 1:
            tag += "-tta%d" % a.tta
        if a.shuffle_labels:
            # A control that can land in a default-named file is a control that can be
            # read as a real result. It gets its own name.
            tag += "-shuf"
        if a.seed != 42:
            tag += "-s%d" % a.seed
        if a.harness == "released":
            tag += "-rel"
        elif a.harness == "pinned":
            tag += "-pin"
        elif a.harness == "exact":
            tag += "-ex"
    # Which transform the test-time views are built from. Defaulting to the TRAINING
    # augmentation is deliberate: a view distribution the model never saw during training
    # is not a view of the same input, it is a distribution shift, and averaging over it
    # measures robustness to that shift rather than the trial's own label.
    tta_aug = a.tta_aug if a.tta_aug is not None else (a.aug if a.aug != "none" else "light")
    if a.tta > 1 and tta_aug == "none":
        ap.error("--tta needs an augmentation to build views from; --tta-aug none is a no-op")
    config = build_config(a.variant, a.heads)

    print("=== parameter accounting (%s, heads=%d) ===" % (a.variant, a.heads))
    rep = fast_zones.param_report(build_config(a.variant, a.heads))
    for v in fast_zones.VARIANTS:
        r = rep[v]
        print("  %-9s total %7d | head %7d | transformer %6d | input_layer %5d | "
              "pos %4d | tokens %d"
              % (v, r["total"], r["head"], r["transformer"], r["input_layer"],
                 r["pos"], r["n_tokens"]))
    for v in fast_zones.VARIANTS:
        print("  delta %-9s vs base: %+d" % (v, rep[v]["total"] - rep["base"]["total"]))
    print("")
    if a.report_only:
        return

    todo = []
    for part in a.subjects.split(","):
        if "-" in part:
            lo, hi = [int(v) for v in part.split("-")]
            todo += list(range(lo, hi + 1))
        else:
            todo.append(int(part))

    os.makedirs(RUN, exist_ok=True)
    X, Y = load_standardized_h5("Processed/BCIC2020Track3.h5")

    if a.verify_base is not None:
        if a.aug != "none":
            # verify-base exists to prove base through this harness is bit-identical to the
            # stored reference. With augmentation the comparison is meaningless, and a
            # silent failure here would be read as "the harness broke".
            ap.error("--verify-base cannot be combined with --aug")
        s = a.verify_base
        ref_f = "Results/CP/%d-chan.npz" % s
        if not os.path.exists(ref_f):
            print("no reference at %s -- cannot verify" % ref_f)
            return
        print("verifying base against %s (must be the released model exactly)" % ref_f)
        ref = np.load(ref_f)["base"]
        correct, _ = run_subject(s, X, Y, config, seed=a.seed, harness=a.harness)
        same = int((correct == ref).sum())
        print("")
        print("  per-trial agreement with channel_probe: %d/350" % same)
        print("  harness acc %.4f   channel_probe acc %.4f   diff %+.4f"
              % (correct.mean(), ref.mean(), correct.mean() - ref.mean()))
        if same == 350:
            print("  VERIFIED: base through this harness is bit-identical to the "
                  "established baseline, so a variant difference is the variant")
        else:
            bad = np.where(correct != ref)[0]
            print("  MISMATCH on %d trials, first: %s" % (len(bad), bad[:20].tolist()))
            print("  the harness is NOT the released one; do not interpret any "
                  "variant comparison until this is zero")
        return

    print("variant=%s heads=%d tag=%s subjects=%s lr=%s warmup=%s epochs=%s "
          "seed=%d harness=%s"
          % (a.variant, a.heads, tag, todo,
             a.lr if a.lr is not None else "5e-4 (released)",
             a.warmup if a.warmup is not None else "10 (released)",
             a.epochs if a.epochs is not None else "200 (released)",
             a.seed, a.harness), flush=True)

    for s in todo:
        f = "%s/%d-%s.npz" % (RUN, s, tag)
        if os.path.exists(f):
            d = np.load(f)
            print("  skip subject %02d (exists, acc %.4f)" % (s, d["correct"].mean()), flush=True)
            continue
        correct, fold_of = run_subject(s, X, Y, config, lr=a.lr, warmup=a.warmup,
                                       epochs=a.epochs, seed=a.seed, harness=a.harness,
                                       aug=a.aug, tta=a.tta, tta_aug=tta_aug,
                                       shuffle_labels=a.shuffle_labels)
        # The chance level this arm should be read against, computed from the same
        # sequential 5-fold split the arm used. Accuracy is compared to the MAJORITY-CLASS
        # rate of each test fold, not to 0.20: if a fold's labels are unbalanced, a model
        # that ignores its input entirely scores the majority rate, and 0.20 would make
        # that look like signal. Saved with the arm so the number cannot be lost and
        # recomputed differently later.
        _ch = []
        for _tr, _te in KFold(n_splits=5, shuffle=False).split(X[s]):
            _, _cnt = np.unique(Y[s][_te], return_counts=True)
            _ch.append(_cnt.max() / len(_te))
        np.savez(f, correct=correct, fold_of=fold_of, chance=float(np.mean(_ch)))
        print("  [%s subject %02d] acc = %.4f" % (tag, s, correct.mean()), flush=True)

    accs = []
    for s in range(15):
        f = "%s/%d-%s.npz" % (RUN, s, tag)
        if os.path.exists(f):
            accs.append(np.load(f)["correct"].mean())
    if accs:
        print("")
        print("=== %s : mean %.4f  sd %.4f  n=%d  (released base 0.5779) ==="
              % (tag, np.mean(accs), np.std(accs, ddof=1), len(accs)), flush=True)
    print("ZA_DONE", flush=True)


if __name__ == "__main__":
    main()
