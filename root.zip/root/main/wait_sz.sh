#!/bin/bash
# Wait for the zone-attention arm to finish, then run the soft-zone arm, so the GPU
# is never idle between them. The pattern is assembled at runtime from a variable so
# this script's own command line cannot match pgrep -f and deadlock the wait.
PAT='zone_attn_probe.py --variant zone'
while pgrep -f "$PAT" > /dev/null; do sleep 30; done
sleep 10
cd /root/FAST
exec /root/venv_fast/bin/python -u zone_attn_probe.py --variant softzone --tag softzone-h8
