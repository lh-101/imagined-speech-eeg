#!/bin/bash
# Improved arms only. The baseline is NOT rerun: the released number already exists as
# Results/FAST/<s>-Tune.csv (our own run of the authors' script, reproduced byte-for-byte
# this session -- same md5), and --harness exact was verified on subject 0 to reproduce that
# CSV's folds exactly (0.5971/0.5400/0.6086 on subjects 0/1/2). So arms are now compared
# directly against the stored released CSVs, per subject.
#
# RUN SERIALLY AND WITH THE GPU OTHERWISE IDLE. The reason folds 1-4 diverged in the first
# place is that the live allocation set at model-construction time changes kernel selection.
# A second process on the GPU changes free memory and destroys that property.
cd /root/FAST || exit 1
P=/root/venv_fast/bin/python

run () {  # run <variant>
  local v=$1
  echo "=== $v START $(date +%H:%M:%S) ==="
  $P -u zone_attn_probe.py --variant "$v" --harness exact --subjects 0-14
  echo "=== $v END $(date +%H:%M:%S) ==="
}

# The paper's own head. Conv4Layers runs cnn1..cnn4 with NO activation between them and one
# gelu at the end, so the affine identity holds to 1.097e-06 and 77.7% of the parameters buy
# a single linear map. The author's own unused HeadConv_Paper_Version applies gelu(norm(.))
# after each of its four blocks. +0 parameters.
run nl

# Whole-epoch pooling with mean AND std. Best hand-built feature was whole-epoch mean+std
# (0.4149); time-resolved power is measurably worse (-0.131).
run w1std

# Capacity-reduction control: share the temporal convs across zones, -38% params.
# diagnose.py says TRAIN 1.0000 / TEST 0.6143, so capacity is the liability.
run sharedtemp

# THE CONTROL. Byte-identical architecture to base, one extra torch.randn(1) before
# construction. Any gap between this and base is a gap the released protocol itself produces
# from a change that is not an architecture change.
run placebo

echo QUEUE_ARMS_DONE
