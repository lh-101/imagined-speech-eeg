import os, sys, time, subprocess, urllib.request
BASE = "/root/FAST"
JOBS = [('https://osf.io/download/tyzc9/', 'BCIC2020Track3/Training set/Data_Sample07.mat', 116467551), ('https://osf.io/download/us96c/', 'BCIC2020Track3/Training set/Data_Sample01.mat', 116176013), ('https://osf.io/download/3txuf/', 'BCIC2020Track3/Training set/Data_Sample05.mat', 115687760), ('https://osf.io/download/682y9/', 'BCIC2020Track3/Training set/Data_Sample04.mat', 115620338), ('https://osf.io/download/m6wbu/', 'BCIC2020Track3/Training set/Data_Sample14.mat', 116038957), ('https://osf.io/download/yeh24/', 'BCIC2020Track3/Training set/Data_Sample02.mat', 115939776), ('https://osf.io/download/xc7pz/', 'BCIC2020Track3/Training set/Data_Sample11.mat', 115293005), ('https://osf.io/download/qcbv9/', 'BCIC2020Track3/Training set/Data_Sample03.mat', 116089687), ('https://osf.io/download/tpz6n/', 'BCIC2020Track3/Training set/Data_Sample12.mat', 115882577), ('https://osf.io/download/8md2p/', 'BCIC2020Track3/Training set/Data_Sample13.mat', 115968068), ('https://osf.io/download/mywcq/', 'BCIC2020Track3/Training set/Data_Sample08.mat', 115910190), ('https://osf.io/download/q9tbf/', 'BCIC2020Track3/Training set/Data_Sample06.mat', 116391545), ('https://osf.io/download/sng2u/', 'BCIC2020Track3/Training set/Data_Sample10.mat', 116092803), ('https://osf.io/download/we3u7/', 'BCIC2020Track3/Training set/Data_Sample09.mat', 116831189), ('https://osf.io/download/q2ndy/', 'BCIC2020Track3/Training set/Data_Sample15.mat', 116186085), ('https://osf.io/download/f5c9n/', 'BCIC2020Track3/Validation set/Data_Sample02.mat', 19336185), ('https://osf.io/download/qprs3/', 'BCIC2020Track3/Validation set/Data_Sample05.mat', 19287795), ('https://osf.io/download/ax5v6/', 'BCIC2020Track3/Validation set/Data_Sample04.mat', 19285086), ('https://osf.io/download/2zh87/', 'BCIC2020Track3/Validation set/Data_Sample15.mat', 19374892), ('https://osf.io/download/jpcem/', 'BCIC2020Track3/Validation set/Data_Sample08.mat', 19309665), ('https://osf.io/download/tnh2g/', 'BCIC2020Track3/Validation set/Data_Sample10.mat', 19344780), ('https://osf.io/download/y9edh/', 'BCIC2020Track3/Validation set/Data_Sample13.mat', 19353718), ('https://osf.io/download/ep7sw/', 'BCIC2020Track3/Validation set/Data_Sample06.mat', 19385407), ('https://osf.io/download/dqrfu/', 'BCIC2020Track3/Validation set/Data_Sample01.mat', 19369307), ('https://osf.io/download/fcj8y/', 'BCIC2020Track3/Validation set/Data_Sample09.mat', 19469828), ('https://osf.io/download/wqm3k/', 'BCIC2020Track3/Validation set/Data_Sample12.mat', 19325954), ('https://osf.io/download/ga5r2/', 'BCIC2020Track3/Validation set/Data_Sample07.mat', 19402261), ('https://osf.io/download/w46s7/', 'BCIC2020Track3/Validation set/Data_Sample11.mat', 19231887), ('https://osf.io/download/w9gh4/', 'BCIC2020Track3/Validation set/Data_Sample14.mat', 19377724), ('https://osf.io/download/vyjth/', 'BCIC2020Track3/Validation set/Data_Sample03.mat', 19352775)]
os.chdir(BASE)
def log(m): print(m, flush=True)

def dl(url, out, want):
    for attempt in range(8):
        try:
            pos = os.path.getsize(out) if os.path.exists(out) else 0
            if pos == want: return True
            if pos > want:
                log("    oversized " + str(pos) + " > " + str(want) + ", restarting file")
                os.remove(out); pos = 0
            req = urllib.request.Request(url)
            if pos: req.add_header("Range", "bytes=" + str(pos) + "-")
            with urllib.request.urlopen(req, timeout=120) as r, open(out, "ab" if pos else "wb") as fh:
                while True:
                    ch = r.read(1 << 20)
                    if not ch: break
                    fh.write(ch)
            if os.path.getsize(out) == want: return True
        except Exception as ex:
            log("    retry" + str(attempt) + ": " + type(ex).__name__ + " " + str(ex)); time.sleep(5)
    return False

log("=== STEP 1: wait for dl_osf.py to exit ===")
t0 = time.time()
while subprocess.run(["pgrep","-f","dl_osf.py"], capture_output=True).returncode == 0:
    if time.time() - t0 > 7200: log("TIMEOUT waiting"); sys.exit(2)
    time.sleep(20)
log("dl_osf.py gone after " + str(int(time.time()-t0)) + "s")
time.sleep(5)

log("")
log("=== STEP 2: verify + repair ===")
bad = []
for url, rel, want in JOBS:
    out = os.path.join(BASE, rel)
    got = os.path.getsize(out) if os.path.exists(out) else 0
    if got == want: continue
    log("  REPAIR " + rel + "  " + str(round(got/1e6,1)) + " -> " + str(round(want/1e6,1)) + " MB")
    if dl(url, out, want): log("    fixed " + rel)
    else: bad.append(rel); log("    FAILED " + rel)

log("")
log("=== STEP 3: full verification ===")
allok = True
for url, rel, want in JOBS:
    out = os.path.join(BASE, rel)
    got = os.path.getsize(out) if os.path.exists(out) else 0
    ok = (got == want); allok = allok and ok
    log("  " + ("OK  " if ok else "BAD ") + rel.ljust(44) + " " + str(round(got/1e6,1)).rjust(8) + " / " + str(round(want/1e6,1)).rjust(8) + " MB")
if not allok:
    log(""); log("ABORT: size mismatches remain: " + str(bad)); sys.exit(3)

log("")
log("=== STEP 4: preprocessing ===")
r = subprocess.run(["/root/venv_fast/bin/python","-u","preprocess_safe.py"], cwd=BASE, capture_output=True, text=True)
log(r.stdout)
if r.returncode != 0:
    log("PREPROCESS FAILED rc=" + str(r.returncode)); log(r.stderr[-3000:]); sys.exit(4)

h5 = os.path.join(BASE, "Processed/BCIC2020Track3.h5")
log("h5 size: " + str(round(os.path.getsize(h5)/1e6,1)) + " MB")
log("")
log("ALL_DONE_OK")
