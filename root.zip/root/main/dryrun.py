import sys, os, warnings
os.chdir("/root/FAST"); sys.path.insert(0, "/root/FAST")
print("--- 1. transformers.PretrainedConfig actually works? ---")
from transformers import PretrainedConfig
import BCIC2020Track3_preprocess as bp
cfg = PretrainedConfig(electrodes=bp.Electrodes, zone_dict=bp.Zones, dim_cnn=32, dim_token=32,
                       seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
                       n_classes=5, num_layers=4, num_heads=8, dropout=0.1)
print("   config built OK; n_classes =", cfg.n_classes, "| zone keys =", len(cfg.zone_dict))
print("   access works:", cfg.electrodes[0], cfg.head, cfg.seq_len)

print()
print("--- 2. every import in BCIC2020Track3_train.py resolves ---")
import importlib
for m in ["torch","torch.optim","torch.utils.data","torch.nn","torchmetrics","logging","h5py",
          "einops","sklearn.model_selection","transformers","lightning","utils","FAST",
          "BCIC2020Track3_preprocess"]:
    importlib.import_module(m)
print("   all imports OK")
from utils import green, yellow
print("   utils.green/yellow OK")

print()
print("--- 3. model forward with the REAL training config ---")
import torch, numpy as np
from FAST import FAST
torch.manual_seed(0)
m = FAST(cfg)
n = sum(p.numel() for p in m.parameters())
print("   params:", n)
print("   n_tokens:", m.n_tokens)
x = torch.randn(4, 64, 800)
with torch.no_grad():
    out = m(x)
print("   forward:", tuple(x.shape), "->", tuple(out.shape))
assert out.shape == (4, 5)
print("   PASS model forward")

print()
print("--- 4. loss + backward (gradient path intact) ---")
m2 = FAST(cfg)
opt = torch.optim.AdamW(m2.parameters(), lr=5e-4)
y = torch.randint(0, 5, (4,))
loss = torch.nn.CrossEntropyLoss()(m2(x), y)
loss.backward()
g = sum(1 for p in m2.parameters() if p.grad is not None and p.grad.abs().sum() > 0)
print("   loss=%.4f  params_with_nonzero_grad=%d/%d" % (loss.item(), g, n))
assert g > 0
print("   PASS backward")

print()
print("--- 5. the exact /root/FAST/smoke_test.py that passed before ---")
