"""
Ground-truth tests for the nonlinear zone-encoder variants. Run on the remote (needs torch).

The load-bearing test is `test_released_encoder_is_affine`. The claim under test is that
the released Conv4Layers is a LINEAR operator followed by a single GELU, because its four
convolutions have no activation between them and an affine composition is affine. That is
a claim about a specific released file, so it is checked numerically against that file
rather than argued from reading it.

An affine map g satisfies g(x1 + x2) = g(x1) + g(x2) - g(0) exactly. A map with a
nonlinearity between the layers does not. So the same identity is applied to both
encoders and the two outcomes are expected to differ -- that is what makes it a test
rather than a tautology.

Also checks shapes, parameter counts, and that build() wires each variant to the encoder
it claims to, since a silent fallback to the base encoder would make every variant row
a copy of the base row.
"""

import math

import torch
import torch.nn as nn

import fast_zones
from FAST import FAST, Conv4Layers
from fast_zones import Conv4LayersNL, Conv4LayersNLNorm, _register
from BCIC2020Track3_preprocess import Electrodes, Zones

ATOL = 1e-6


def _pre_gelu(enc, x):
    """The tensor the class's OWN forward feeds to its final F.gelu -- captured with a
    forward hook on cnn4 so this measures the released code path rather than a
    reimplementation of it. Reimplementing the chain would make the test circular: it
    would prove something about the copy, not about FAST.py."""
    store = {}
    h = enc.cnn4.register_forward_hook(lambda m, i, o: store.__setitem__("y", o))
    try:
        with torch.no_grad():
            enc(x)
    finally:
        h.remove()
    return store["y"]


def _affine_residual(g, x1, x2):
    """max |g(x1+x2) - g(x1) - g(x2) + g(0)| -- zero for an affine map.

    g(0) has to be a tensor, not the Python scalar 0: einops rearranges its argument
    and raises on an int rather than broadcasting.
    """
    zero = torch.zeros_like(x1)
    with torch.no_grad():
        return (g(x1 + x2) - g(x1) - g(x2) + g(zero)).abs().max().item()


def test_released_encoder_is_affine():
    """The released Conv4Layers' pre-gelu conv stack is affine; the NL variant's is not.

    Significance: if the released stack is affine then depth 4 buys it a larger
    receptive field and NO extra representational power, so 77.7% of the model's
    parameters are spent on a single linear operator. The NL variant breaks that
    identity, which is what makes it a different function class and not a reparam.
    """
    torch.manual_seed(0)
    ch, T, B = 9, 300, 4
    x1 = torch.randn(B, ch, T) * 3.0
    x2 = torch.randn(B, ch, T) * 3.0

    base = Conv4Layers(ch, dim=16).eval()
    nl = Conv4LayersNL(ch, dim=16).eval()

    r_base = _affine_residual(lambda x: _pre_gelu(base, x), x1, x2)
    r_nl = _affine_residual(lambda x: _pre_gelu(nl, x), x1, x2)

    # base: the identity holds to float noise, so depth adds receptive field only
    assert r_base < 1e-4, "released conv stack is NOT affine (residual %.3e)" % r_base
    # nl: the convolutions are separated by GELU, so the identity must break
    assert r_nl > 1e-2, "NL conv stack looks affine too (residual %.3e)" % r_nl
    print("  released conv stack affine residual %.3e  (linear, as claimed)" % r_base)
    print("  NL conv stack       affine residual %.3e  (nonlinear)" % r_nl)
    print("test_released_encoder_is_affine OK")


def test_nl_forward_shape_and_finiteness():
    torch.manual_seed(0)
    x = torch.randn(4, 9, 300)
    for cls in (Conv4LayersNL, Conv4LayersNLNorm):
        enc = cls(9, dim=32).eval()
        y = enc(x)
        assert y.shape == (4, 32), (cls.__name__, y.shape)
        assert torch.isfinite(y).all(), cls.__name__
        # mean-pooled over T, so the output must not scale with T
        y2 = enc(torch.randn(4, 9, 300))
        assert y2.shape == (4, 32)
    print("test_nl_forward_shape_and_finiteness OK")


def test_nl_is_not_the_identity_of_base():
    """A variant that silently aliased the base encoder would make every result row a
    copy of the base row. Same weights, different forward => different output."""
    torch.manual_seed(0)
    x = torch.randn(2, 7, 200)
    base = Conv4Layers(7, dim=32).eval()
    nl = Conv4LayersNL(7, dim=32).eval()
    nl.load_state_dict(base.state_dict())          # identical weights
    with torch.no_grad():
        assert not torch.allclose(base(x), nl(x), atol=1e-5), \
            "NL variant produced identical output to base under identical weights"
    print("test_nl_is_not_the_identity_of_base OK")


def test_build_wires_the_right_class():
    """build() must resolve each variant to the encoder it names, and the four
    non-zoneattn variants must share the base tokenisation."""
    from transformers import PretrainedConfig
    _register()
    for variant, want in (("base", "Conv4Layers"), ("nl", "Conv4LayersNL"),
                          ("nlnorm", "Conv4LayersNLNorm")):
        cfg = PretrainedConfig(
            electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
            seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
            n_classes=5, num_layers=4, num_heads=8, dropout=0.1, variant=variant,
        )
        m = fast_zones.build(cfg)
        got = [type(e).__name__ for e in m.head.encoders.values()]
        assert set(got) == {want}, (variant, set(got), want)
        # the tokeniser is untouched for these, so 6 tokens not 41
        assert m.n_tokens == 5, (variant, m.n_tokens)
        print("  %-8s -> %-18s zones=%d tokens=%d params=%d"
              % (variant, want, len(got), m.n_tokens + 1,
                 sum(p.numel() for p in m.parameters())))
    print("test_build_wires_the_right_class OK")


def test_shared_conv_really_is_shared():
    """The three temporal convs must be ONE set of parameters, not eight copies that
    happen to look alike. If sharing silently failed the variant would still train, and
    would just be the base model with a confusing name."""
    from transformers import PretrainedConfig
    _register()
    cfg = PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1, variant="sharedtemp",
    )
    m = fast_zones.build(cfg)
    encs = list(m.head.encoders.values())
    assert len(encs) == 8

    # identity, not equality: the same nn.Conv2d object on all eight encoders
    for name in ("cnn1", "cnn3", "cnn4"):
        objs = [getattr(e, name) for e in encs]
        assert all(o is objs[0] for o in objs), "%s is not a single shared object" % name
    # cnn2 must stay per-zone
    assert len({id(e.cnn2) for e in encs}) == 8, "cnn2 should be per-zone"

    # and the optimizer-visible parameter count must reflect the sharing, i.e. the
    # deduplication nn.Module does by identity
    n_conv = sum(p.numel() for n, p in m.named_parameters()
                 if n.endswith(("cnn1.weight", "cnn1.bias", "cnn3.weight", "cnn4.weight")))
    assert n_conv == 192 + 5120 + 5120, n_conv
    total = sum(p.numel() for p in m.parameters())
    assert total == 118757, "sharedtemp total is %d, expected 118757" % total
    print("  shared temporal convs: %d params once (vs 83456 duplicated), total %d (-38%%)"
          % (n_conv, total))
    print("test_shared_conv_really_is_shared OK")


def test_shared_convs_are_reset_between_builds():
    """build() must clear the class-level cache. Four folds of a subject are trained in
    ONE process, so a leaked cache would start fold 2 from fold 1's trained temporal
    filters -- silent, and it would make the arm meaningless rather than crash."""
    from transformers import PretrainedConfig
    _register()
    cfg = lambda: PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1, variant="sharedtemp",
    )
    m1 = fast_zones.build(cfg())
    w1 = m1.head.encoders["Central"].cnn3.weight.detach().clone()
    m2 = fast_zones.build(cfg())
    w2 = m2.head.encoders["Central"].cnn3.weight.detach()
    assert not torch.allclose(w1, w2), (
        "two builds produced identical shared conv weights -- the class-level cache "
        "leaked across builds and fold 2 would inherit fold 1's trained filters"
    )
    assert m1.head.encoders["Central"].cnn3 is not m2.head.encoders["Central"].cnn3
    print("  two builds -> independent shared convs (no cache leak)")
    print("test_shared_convs_are_reset_between_builds OK")


def test_bank_is_actually_band_structured():
    """The load-bearing claim of Conv4LayersBank is that its filters are band-pass with
    log-spaced centre frequencies, not merely longer. Read the centre frequency off each
    kernel's own spectrum and compare against the design frequencies."""
    from fast_zones import Conv4LayersBank
    dim = 32
    enc = Conv4LayersBank(9, dim=dim)
    w = enc.cnn1.weight.detach().double()[:, 0, 0, :]          # (dim, N_TAPS)
    n = w.shape[1]
    assert n == Conv4LayersBank.N_TAPS, n

    # zero-mean and unit-L2, so a filter measures a band and not a band plus the offset
    assert w.mean(dim=1).abs().max() < 1e-5, "bank filters are not zero-mean"
    assert (w.norm(dim=1) - 1.0).abs().max() < 1e-5, "bank filters are not unit-norm"

    # peak of the interpolated spectrum vs the designed centre frequency
    nfft = 4096
    spec = torch.fft.rfft(w, n=nfft, dim=1).abs()
    freqs = torch.fft.rfftfreq(nfft, d=1.0 / Conv4LayersBank.FS)
    peak = freqs[spec.argmax(dim=1)]
    want = torch.exp(torch.linspace(math.log(Conv4LayersBank.F_LO),
                                    math.log(Conv4LayersBank.F_HI), dim,
                                    dtype=torch.float64))
    err = (peak - want).abs()
    assert err.max() < 3.0, ("filter %d peaks at %.1f Hz but was designed for %.1f Hz"
                            % (int(err.argmax()), peak[int(err.argmax())],
                               want[int(err.argmax())]))
    # and the bank must actually span the range, not cluster
    assert peak.min() < 4.0 and peak.max() > 35.0, (peak.min().item(), peak.max().item())
    # strictly increasing centre frequency across the bank
    assert (peak[1:] > peak[:-1] - 0.5).all(), "centre frequencies are not ordered"
    print("  bank spans %.1f-%.1f Hz over %d filters, max design error %.2f Hz"
          % (peak.min(), peak.max(), dim, err.max()))
    print("test_bank_is_actually_band_structured OK")


def test_bank_receptive_field_exceeds_the_released_one():
    """The point of the change: the released encoder sees 52 ms and cannot represent
    theta (period 125-250 ms) or alpha (77-125 ms). Assert the bank's receptive field
    actually covers a full theta cycle, so the claim is checked and not just asserted."""
    from fast_zones import Conv4LayersBank
    fs = Conv4LayersBank.FS
    released = 13                                   # cnn1 5-1 + cnn3 5-1 + cnn4 5-1
    bank = Conv4LayersBank.N_TAPS + 4 + 4           # bank + cnn3 + cnn4
    assert bank / fs >= 0.5, bank
    # a theta cycle at 4 Hz is 62.5 samples; the released field is 13
    theta_period = fs / 4.0
    assert released < theta_period, "released field already covers a theta cycle"
    assert bank > theta_period, "bank does not even cover one theta cycle"
    print("  receptive field %.0f ms -> %.0f ms (a 4 Hz theta cycle is %.0f ms); "
          "released field %.0f ms could not contain one"
          % (1000.0 * released / fs, 1000.0 * bank / fs,
             1000.0 * theta_period / fs, 1000.0 * released / fs))
    print("test_bank_receptive_field_exceeds_the_released_one OK")


def test_bankfrozen_freezes():
    from transformers import PretrainedConfig
    _register()
    cfg = lambda v: PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1, variant=v,
    )
    m_bank = fast_zones.build(cfg("bank"))
    m_froz = fast_zones.build(cfg("bankfrozen"))
    assert all(e.cnn1.weight.requires_grad for e in m_bank.head.encoders.values())
    assert not any(e.cnn1.weight.requires_grad for e in m_froz.head.encoders.values())
    n_free = sum(p.numel() for p in m_bank.parameters() if p.requires_grad)
    n_froz = sum(p.numel() for p in m_froz.parameters() if p.requires_grad)
    # 8 zones x (32*125 + 32) bank params must drop out of the trainable set
    assert n_free - n_froz == 8 * (32 * 125 + 32), (n_free, n_froz)
    # the architectures are otherwise the same size
    assert (sum(p.numel() for p in m_bank.parameters())
            == sum(p.numel() for p in m_froz.parameters()))
    print("  bank %d trainable -> bankfrozen %d trainable (same %d total)"
          % (n_free, n_froz, sum(p.numel() for p in m_bank.parameters())))
    print("test_bankfrozen_freezes OK")


def test_riemann_logm_matches_the_power_series():
    """The log-covariance must be an actual matrix logarithm, checked independently.

    Every other test of this branch would pass for a wrong logm as long as it were
    consistent, so the formula is checked against a computation that shares no code with
    it: for a symmetric N with small norm, log(I + N) = N - N^2/2 + N^3/3 - N^4/4 + ...
    Four terms leave O(||N||^5) ~ 2e-8 of truncation error, so agreement to 1e-7 is a real
    constraint and not a restatement -- while a formula that dropped the N^2/2 term, the
    plausible way to get this wrong, would miss by ~1e-3.

    Also checks the two properties that make it usable: logm(C) is symmetric, and its
    eigenvalues are log of C's -- i.e. it is a spectral function, so it cannot be
    distorting the eigenstructure while coincidentally matching the series.
    """
    from fast_zones import RiemannBranch

    torch.manual_seed(0)
    B, n = 8, 6
    N = torch.randn(B, n, n, dtype=torch.float64)
    N = (N + N.transpose(1, 2)) / 2 * 1e-2                   # symmetric, small norm
    C = torch.eye(n, dtype=torch.float64).expand(B, n, n) + N

    L = RiemannBranch.logm(C).double()
    N2 = N @ N
    series = N - N2 / 2 + N2 @ N / 3 - N2 @ N2 / 4          # log(I+N) to O(||N||^5)
    err = (L - series).abs().max().item()
    assert err < 1e-7, "logm disagrees with the power series by %.3e" % err
    assert (L - L.transpose(1, 2)).abs().max() < 1e-12, "logm(C) is not symmetric"

    ev_logm = torch.linalg.eigvalsh(L)
    ev_log = torch.linalg.eigvalsh(C).log()
    assert (ev_logm - ev_log).abs().max() < 1e-9, "logm is not a spectral function"

    # and the released-style failure mode: a covariance with a near-zero eigenvalue makes
    # eigh's gradients singular. The eps clamp is what stops that, so assert it holds.
    Cs = C.clone()
    Cs[:, 0, 0] = 0.0
    assert torch.isfinite(RiemannBranch.logm(Cs, eps=1e-12)).all()
    print("  logm vs power series: max err %.3e (independent computation)" % err)
    print("test_riemann_logm_matches_the_power_series OK")


def test_riemann_descriptor_is_amplitude_scale_equivariant():
    """The descriptor must not be a re-encoding of amplitude.

    proc_one does no normalisation and per-channel amplitude spans 21x-73x within a
    subject, so a covariance that reported raw scale would have subjects separated by
    their units. log(a^2 C) = log(C) + 2 log(a) I, so scaling the input by a must leave
    every OFF-DIAGONAL entry of log(C) alone and shift every diagonal entry by exactly
    2 log a. That is a sharp invariant: it pins the ridge (which must scale with the
    signal, not sit at an absolute constant) and it pins that the log is applied to the
    covariance and not to something that merely looks like it.
    """
    from fast_zones import RiemannBranch

    torch.manual_seed(0)
    br = RiemannBranch(["a", "b", "c"], {"Z": ["a", "b", "c"]}, out_dim=1)
    x = torch.randn(4, 3, 200)

    d1 = br.log_cov_triu(x)[0].double()
    a = 3.0
    d2 = br.log_cov_triu(a * x)[0].double()

    # triu_indices(3, 3) -> [(0,0), (0,1), (0,2), (1,1), (1,2), (2,2)]
    diag = torch.tensor([0, 3, 5])
    off = torch.tensor([1, 2, 4])
    doff = (d2[:, off] - d1[:, off]).abs().max().item()
    ddiag = ((d2[:, diag] - d1[:, diag]) - 2.0 * math.log(a)).abs().max().item()
    assert doff < 1e-4, "off-diagonal log-covariance changed with amplitude: %.3e" % doff
    assert ddiag < 1e-4, "diagonal shift is not 2*log(a): %.3e" % ddiag
    print("  scaling input x%d moves off-diagonals by %.1e and diagonals by "
          "2*log(%g) to %.1e" % (a, doff, a, ddiag))
    print("test_riemann_descriptor_is_amplitude_scale_equivariant OK")


def test_riemann_branch_is_wired_into_the_output():
    """The branch must reach the logits, not sit on the side computing nothing.

    Zeroing the readout is the direct test: if the covariance path is connected, the
    model's output must change. A branch that was silently dropped -- wrong shape that
    broadcast, a rearrange that put it in the wrong slot, a forward that never called it
    -- would leave the logits identical here, which is exactly the failure this catches.
    """
    from transformers import PretrainedConfig
    from fast_zones import FAST_Riemann

    _register()
    torch.manual_seed(0)
    cfg = PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1, variant="riemann",
    )
    m = fast_zones.build(cfg)
    assert isinstance(m, FAST_Riemann)
    x = torch.randn(2, 64, 800)

    m.eval()
    with torch.no_grad():
        before = m(x)
        for p in m.riemann.projs.parameters():
            p.zero_()
        after = m(x)
    assert not torch.allclose(before, after, atol=1e-6), \
        "zeroing the covariance readout did not change the output: the branch is dead"
    print("  zeroing the covariance readout moves the logits by %.3e"
          % (before - after).abs().max().item())
    print("test_riemann_branch_is_wired_into_the_output OK")


def test_riemann_changes_only_the_input_width():
    """The transformer must be untouched, and the added capacity must be small.

    Two claims are checked rather than asserted. (1) n_tokens is still 5, so the branch
    did not smuggle in a tokenisation change -- the same 6 tokens attend as in base, and
    the whole comparison stays about the input vector. (2) The parameter delta is exactly
    8 zone readouts of 8 dims each plus the widened input layer, i.e. +4,736 on a 191,781
    baseline (+2.5%). Stated numerically because "it is only a small increase" is the
    kind of claim that quietly stops being true.

    The transformer and pos_embedding counts are compared against a fresh base build, so
    a stray parameter added anywhere in the shared path fails the test too.
    """
    from transformers import PretrainedConfig
    _register()

    def cfg(v):
        return PretrainedConfig(
            electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
            seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
            n_classes=5, num_layers=4, num_heads=8, dropout=0.1, variant=v,
        )

    b = fast_zones.build(cfg("base"))
    r = fast_zones.build(cfg("riemann"))

    assert r.n_tokens == 5, r.n_tokens
    n_riemann = sum(p.numel() for p in r.riemann.parameters())
    n_input = sum(p.numel() for p in r.input_layer.parameters())
    total = sum(p.numel() for p in r.parameters())
    assert n_riemann == 2688, n_riemann
    assert n_input == 10272, n_input
    assert total == 196517, total
    assert total - sum(p.numel() for p in b.parameters()) == 4736

    # everything downstream of the input vector is bit-for-bit the same size. cls_token
    # and pos_embedding are bare Parameters rather than submodules, so both cases have to
    # be handled -- a test that silently compared zero to zero would pass for any change.
    for name in ("transformer", "cls_token", "pos_embedding", "last_layer"):
        counts = []
        for m in (b, r):
            obj = getattr(m, name)
            ps = [obj] if isinstance(obj, nn.Parameter) else list(obj.parameters())
            counts.append(sum(p.numel() for p in ps))
        assert counts[0] == counts[1] and counts[0] > 0, (name, counts)
    print("  riemann total %d (+%d vs base, +%.1f%%): readout %d, input %d; "
          "transformer and pos unchanged"
          % (total, 4736, 100.0 * 4736 / 191781, n_riemann, n_input))
    print("test_riemann_changes_only_the_input_width OK")


def test_w1_is_really_one_window():
    """w1 must actually unfold ONE window, and must not have mutated the caller's config.

    Two silent failure modes, both of which would leave the arm running as plain base
    under the w1 label and reporting that "removing the temporal tokenisation changed
    nothing":
      * config is deep-copied inside FAST_WholeEpoch and FAST keeps `self.config`, so if
        the copy were replaced by a restore-after-construction, forward_head would read
        window_len=250 off the restored config and unfold 5 windows again;
      * the caller's config must come back untouched, because the runner reuses one config
        object across variants and a leaked window_len would corrupt the next one.
    Both are asserted directly on the config the model will read during training.
    """
    from transformers import PretrainedConfig
    _register()
    cfg = PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1, variant="w1",
    )
    m = fast_zones.build(cfg)

    # the model must read the WIDE window every call, not just at construction
    assert m.config.window_len == 800, m.config.window_len
    assert m.config.slide_step == 800, m.config.slide_step
    assert m.n_tokens == 1, m.n_tokens
    assert m.pos_embedding.shape[1] == 2, m.pos_embedding.shape
    assert m.cls_token.shape[1] == 1

    # and the caller's config is untouched, so a later variant in the same process is safe
    assert cfg.window_len == 250 and cfg.slide_step == 125, (cfg.window_len, cfg.slide_step)

    m.eval()
    with torch.no_grad():
        out = m(torch.randn(3, 64, 800))
    assert out.shape == (3, 5), out.shape
    # Pure subtraction: no layer changes size. The only parameter difference is
    # pos_embedding, which is one vector per token, so it drops 192 -> 64 with 6 -> 2
    # tokens. Asserted as a number rather than as "<=" so that a real architectural change
    # slipping into this variant cannot hide inside the token-count saving.
    n_pos = m.pos_embedding.numel()
    assert n_pos == 2 * 32, n_pos
    assert sum(p.numel() for p in m.parameters()) == 191781 - 192 + 64
    print("  w1: n_tokens=1 (%d tokens), window_len=%d, params %d = base - %d pos; "
          "caller config unmutated"
          % (m.pos_embedding.shape[1], m.config.window_len,
             sum(p.numel() for p in m.parameters()), 192 - 64))
    print("test_w1_is_really_one_window OK")


def test_w1std_pooling_is_exactly_mean_plus_std():
    """The mean half must reproduce the released encoder EXACTLY, and the second half must
    be the std of the same post-gelu map.

    Checking the first half against Conv4Layers under identical weights is the strong test:
    it proves the change is a strict extension of the released encoder rather than a
    reimplementation of it that happens to be close. If the conv chain, the gelu placement
    or the pool axis had drifted, the mean half would not match the released output
    element for element.

    The second half is checked against the tensor the encoder's OWN cnn4 produced, read
    back with a forward hook -- so it tests the pooling code rather than a copy of it.
    """
    from fast_zones import Conv4LayersMeanStd
    from FAST import Conv4Layers
    import torch.nn.functional as F

    torch.manual_seed(0)
    x = torch.randn(4, 9, 800)
    base = Conv4Layers(9, dim=32).eval()
    ms = Conv4LayersMeanStd(9, dim=32).eval()
    ms.load_state_dict(base.state_dict())              # identical weights

    store = {}
    h = ms.cnn4.register_forward_hook(lambda mod, i, o: store.__setitem__("y", o))
    try:
        with torch.no_grad():
            out = ms(x)
            ref = base(x)
    finally:
        h.remove()

    assert out.shape == (4, 64), out.shape
    # half 1 is the released encoder, bit for bit
    assert torch.allclose(out[:, :32], ref, atol=1e-6), \
        "the mean half does not reproduce Conv4Layers (max diff %.3e)" \
        % (out[:, :32] - ref).abs().max().item()
    # half 2 is the std of the encoder's own post-gelu map
    y = F.gelu(store["y"]).squeeze(2)                  # (B, F, T)
    want = y.std(dim=2, unbiased=False)
    assert torch.allclose(out[:, 32:], want, atol=1e-6), \
        "the std half is not the std of the post-gelu map (max diff %.3e)" \
        % (out[:, 32:] - want).abs().max().item()
    # and it is not a constant, i.e. the std branch carries window-dependent information
    assert want.std(dim=0).min() > 0, "a std channel is constant across the batch"
    print("  mean half == released Conv4Layers exactly; std half == std of the same "
          "post-gelu map (max diff %.1e)"
          % (out[:, 32:] - want).abs().max().item())
    print("test_w1std_pooling_is_exactly_mean_plus_std OK")


def test_w1std_widths_and_total():
    from transformers import PretrainedConfig
    from fast_zones import FAST_WholeEpochMeanStd
    _register()
    cfg = PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1, variant="w1std",
    )
    m = fast_zones.build(cfg)
    assert isinstance(m, FAST_WholeEpochMeanStd)
    assert m.n_tokens == 1 and m.config.window_len == 800
    n_in = sum(p.numel() for p in m.input_layer.parameters())
    total = sum(p.numel() for p in m.parameters())
    assert n_in == 512 * 32 + 32, n_in
    # base 191,781 - 128 (pos_embedding 192 -> 64 with 6 -> 2 tokens) + 8,192 (input_layer
    # 256->32 becomes 512->32)
    assert total == 199845, total
    m.eval()
    with torch.no_grad():
        assert m(torch.randn(2, 64, 800)).shape == (2, 5)
    print("  w1std: one window, 2 tokens, input_layer 512->32 (%d), total %d (+%d vs base)"
          % (n_in, total, total - 191781))
    print("test_w1std_widths_and_total OK")


def test_new_variants_train_end_to_end():
    """Every parameter must be IN the graph: forward, backward, finite non-None grads.

    The forward tests above cannot catch a branch that computes the right numbers and is
    then detached -- the outputs would look identical and the arm would train as whatever
    the rest of the model does without it, silently, for 200 steps. `grad is None` is the
    precise signature of a parameter that never entered the graph, so it is asserted
    directly for every variant whose forward does something unusual (an autocast-disabled
    fp32 block, a std reduction, a deep-copied config).

    Also asserts the grads are finite, because the riemann branch goes through eigh, whose
    backward is the standard place for a NaN to appear, and because bf16-mixed is what the
    real runner uses.
    """
    from transformers import PretrainedConfig
    _register()
    torch.manual_seed(0)

    for variant in ("w1", "w1std", "riemann"):
        cfg = PretrainedConfig(
            electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
            seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
            n_classes=5, num_layers=4, num_heads=8, dropout=0.1, variant=variant,
        )
        m = fast_zones.build(cfg)
        m.train()
        x = torch.randn(6, 64, 800)
        y = torch.randint(0, 5, (6,))
        loss = torch.nn.CrossEntropyLoss()(m(x), y)
        loss.backward()

        missing = [n for n, p in m.named_parameters() if p.grad is None]
        assert not missing, "%s: %d params never entered the graph, e.g. %s" \
            % (variant, len(missing), missing[:5])
        bad = [n for n, p in m.named_parameters()
               if not torch.isfinite(p.grad).all()]
        assert not bad, "%s: non-finite grad on %s" % (variant, bad[:5])
        n_zero = sum(1 for _, p in m.named_parameters() if p.grad.abs().max() == 0)
        assert n_zero <= 1, "%s: %d params have identically zero grad" % (variant, n_zero)
        n = sum(p.numel() for p in m.parameters())
        print("  %-8s loss %.4f, all %d params have finite grads (%d with zero grad)"
              % (variant, loss.item(), len(list(m.named_parameters())), n_zero))
    print("test_new_variants_train_end_to_end OK")


def main():
    for fn in (test_released_encoder_is_affine, test_nl_forward_shape_and_finiteness,
               test_nl_is_not_the_identity_of_base, test_build_wires_the_right_class,
               test_shared_conv_really_is_shared,
               test_shared_convs_are_reset_between_builds,
               test_bank_is_actually_band_structured,
               test_bank_receptive_field_exceeds_the_released_one,
               test_bankfrozen_freezes,
               test_riemann_logm_matches_the_power_series,
               test_riemann_descriptor_is_amplitude_scale_equivariant,
               test_riemann_branch_is_wired_into_the_output,
               test_riemann_changes_only_the_input_width,
               test_w1_is_really_one_window,
               test_w1std_pooling_is_exactly_mean_plus_std,
               test_w1std_widths_and_total,
               test_new_variants_train_end_to_end):
        fn()
    print("ALL_TESTS_PASSED")


if __name__ == "__main__":
    main()
