import os, time, urllib.request, concurrent.futures, threading
JOBS = [('https://osf.io/download/tyzc9/', 'BCIC2020Track3/Training set/Data_Sample07.mat', 116467551), ('https://osf.io/download/us96c/', 'BCIC2020Track3/Training set/Data_Sample01.mat', 116176013), ('https://osf.io/download/3txuf/', 'BCIC2020Track3/Training set/Data_Sample05.mat', 115687760), ('https://osf.io/download/682y9/', 'BCIC2020Track3/Training set/Data_Sample04.mat', 115620338), ('https://osf.io/download/m6wbu/', 'BCIC2020Track3/Training set/Data_Sample14.mat', 116038957), ('https://osf.io/download/yeh24/', 'BCIC2020Track3/Training set/Data_Sample02.mat', 115939776), ('https://osf.io/download/xc7pz/', 'BCIC2020Track3/Training set/Data_Sample11.mat', 115293005), ('https://osf.io/download/qcbv9/', 'BCIC2020Track3/Training set/Data_Sample03.mat', 116089687), ('https://osf.io/download/tpz6n/', 'BCIC2020Track3/Training set/Data_Sample12.mat', 115882577), ('https://osf.io/download/8md2p/', 'BCIC2020Track3/Training set/Data_Sample13.mat', 115968068), ('https://osf.io/download/mywcq/', 'BCIC2020Track3/Training set/Data_Sample08.mat', 115910190), ('https://osf.io/download/q9tbf/', 'BCIC2020Track3/Training set/Data_Sample06.mat', 116391545), ('https://osf.io/download/sng2u/', 'BCIC2020Track3/Training set/Data_Sample10.mat', 116092803), ('https://osf.io/download/we3u7/', 'BCIC2020Track3/Training set/Data_Sample09.mat', 116831189), ('https://osf.io/download/q2ndy/', 'BCIC2020Track3/Training set/Data_Sample15.mat', 116186085), ('https://osf.io/download/f5c9n/', 'BCIC2020Track3/Validation set/Data_Sample02.mat', 19336185), ('https://osf.io/download/qprs3/', 'BCIC2020Track3/Validation set/Data_Sample05.mat', 19287795), ('https://osf.io/download/ax5v6/', 'BCIC2020Track3/Validation set/Data_Sample04.mat', 19285086), ('https://osf.io/download/2zh87/', 'BCIC2020Track3/Validation set/Data_Sample15.mat', 19374892), ('https://osf.io/download/jpcem/', 'BCIC2020Track3/Validation set/Data_Sample08.mat', 19309665), ('https://osf.io/download/tnh2g/', 'BCIC2020Track3/Validation set/Data_Sample10.mat', 19344780), ('https://osf.io/download/y9edh/', 'BCIC2020Track3/Validation set/Data_Sample13.mat', 19353718), ('https://osf.io/download/ep7sw/', 'BCIC2020Track3/Validation set/Data_Sample06.mat', 19385407), ('https://osf.io/download/dqrfu/', 'BCIC2020Track3/Validation set/Data_Sample01.mat', 19369307), ('https://osf.io/download/fcj8y/', 'BCIC2020Track3/Validation set/Data_Sample09.mat', 19469828), ('https://osf.io/download/wqm3k/', 'BCIC2020Track3/Validation set/Data_Sample12.mat', 19325954), ('https://osf.io/download/ga5r2/', 'BCIC2020Track3/Validation set/Data_Sample07.mat', 19402261), ('https://osf.io/download/w46s7/', 'BCIC2020Track3/Validation set/Data_Sample11.mat', 19231887), ('https://osf.io/download/w9gh4/', 'BCIC2020Track3/Validation set/Data_Sample14.mat', 19377724), ('https://osf.io/download/vyjth/', 'BCIC2020Track3/Validation set/Data_Sample03.mat', 19352775)]
BASE = "/root/FAST"
N = 4
lock = threading.Lock(); done = [0]; bad = []
def one(job):
    url, rel, want = job
    out = os.path.join(BASE, rel)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    for attempt in range(5):
        try:
            pos = os.path.getsize(out) if os.path.exists(out) else 0
            if want and pos == want:
                with lock: done[0]+=1
                print(f"[{done[0]}/{len(JOBS)}] cached {rel}", flush=True); return
            req = urllib.request.Request(url)
            if pos: req.add_header("Range", f"bytes={pos}-")
            with urllib.request.urlopen(req, timeout=90) as r, open(out, "ab" if pos else "wb") as fh:
                while True:
                    c = r.read(1 << 20)
                    if not c: break
                    fh.write(c)
            got = os.path.getsize(out)
            if want and got != want:
                print(f"WARN size {rel} got={got} want={want}", flush=True)
            with lock: done[0]+=1
            print(f"[{done[0]}/{len(JOBS)}] {rel} {got/1e6:.1f}MB", flush=True); return
        except Exception as ex:
            print(f"retry{attempt} {rel}: {type(ex).__name__} {ex}", flush=True); time.sleep(3)
    with lock: bad.append(rel)
    print(f"FAILED {rel}", flush=True)
start = time.time()
with concurrent.futures.ThreadPoolExecutor(N) as ex:
    list(ex.map(one, JOBS))
print(f"DONE_DOWNLOAD {time.time()-start:.0f}s bad={bad}", flush=True)
