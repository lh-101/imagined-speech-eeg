#!/bin/bash
# The full improvement queue, serial, resource-gated.
#
# TWO GATE BUGS ARE FIXED HERE, BOTH MINE, BOTH WORTH RECORDING.
#
# 1. The first generation gated on a "DONE" marker. A run that died instantly still wrote
#    its marker, so every downstream gate opened on a marker written by a run that never
#    trained anything -- three arms "completed" in 13 minutes with zero npz between them.
#    A marker that cannot tell "finished" from "died" is worse than no marker, because it
#    cascades.
# 2. The second generation gated on `pgrep -f zone_attn_probe`. That pattern matches the
#    FULL command line, and every monitoring command run over SSH contains the literal
#    string "zone_attn_probe" -- so the queue counted the shell that was asking it whether
#    it could start, concluded a trainer was running, and deadlocked forever with the GPU
#    at 0 MiB. Hence the anchored pattern below: it matches the trainer's own argv and
#    nothing that merely mentions the trainer.
#
# So: the gate is the resource itself, checked in a way that cannot see its own reflection.
cd /root/FAST || exit 1
P=/root/venv_fast/bin/python
LOG=/root/FAST/arms.log

gpu_mib() { nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits | head -1; }
trainers() { pgrep -f "venv_fast/bin/python -u zone_attn_probe" 2>/dev/null | wc -l; }

wait_free() {
  local n=0
  while [ "$(trainers)" -gt 0 ] || [ "$(gpu_mib)" -gt 500 ]; do
    n=$((n+1))
    [ $((n % 20)) -eq 0 ] && echo "  ...waiting ($(gpu_mib) MiB, $(trainers) trainers)" >> "$LOG"
    sleep 30
  done
}

n_npz() { ls /root/FAST/Results/ZA/*"$1"*.npz 2>/dev/null | wc -l; }

run_arm() {
  local label="$1" pat="$2"; shift 2
  wait_free
  local before after rc
  before=$(n_npz "$pat")
  echo "=== $label START $(date +%H:%M:%S)  (gpu $(gpu_mib) MiB, ${before} npz)" >> "$LOG"
  $P -u zone_attn_probe.py "$@" >> "$LOG" 2>&1
  rc=$?
  after=$(n_npz "$pat")
  echo "=== $label END $(date +%H:%M:%S)  rc=$rc  npz ${before} -> ${after} ===" >> "$LOG"
  if [ "$after" -le "$before" ]; then
    echo "=== $label PRODUCED NO NEW RESULTS -- aborting rather than cascading ===" >> "$LOG"
    exit 1
  fi
}

# 1. riemann: the signal-processing representation fed INTO the model. Built, tested
#    (15/15 in test_riemann.py), never run.
run_arm "riemann-0-4" "riemann-h8-ex" --variant riemann --harness exact --subjects 0-4

# 2-4. Augmentation screens. Attacks the diagnosed bottleneck: TRAIN 1.0000 on 280 trials
#    that the loader re-shows unchanged for 200 full-batch steps.
run_arm "aug-cdrop-0-4" "base-h8-augcdrop-ex" --variant base --harness exact --aug cdrop --subjects 0-4
run_arm "aug-light-0-4" "base-h8-auglight-ex" --variant base --harness exact --aug light --subjects 0-4
run_arm "aug-full-0-4"  "base-h8-augfull-ex"  --variant base --harness exact --aug full  --subjects 0-4

# 5. softzone: a learnable soft channel->zone assignment, i.e. the user's "adaptive weight
#    per electrode inside each region" -- and the model's learned assignment is readable as
#    a data-driven functional parcellation. Built, never run. Gated on its own test suite,
#    because spatial v1 is the precedent for running an untested arm.
if CUDA_VISIBLE_DEVICES= $P test_softzone.py 2>&1 | grep -q ALL_TESTS_PASSED; then
  run_arm "softzone-0-4" "softzone-h8-ex" --variant softzone --harness exact --subjects 0-4
else
  echo "=== softzone SKIPPED: test_softzone.py did not pass ===" >> "$LOG"
fi

# 6. TTA alone, so its effect is attributable without training augmentation in the way.
run_arm "tta8-0-14" "base-h8-tta8-ex" --variant base --harness exact --tta 8 --subjects 0-14

echo QUEUE_FINAL_DONE >> "$LOG"
