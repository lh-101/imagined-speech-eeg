"""Re-verify the ONE fact the whole leakage conclusion rests on: what wall-clock time is
h5 sample 0?

Reads the raw .mat epoched struct (NOT the h5, NOT the preprocessing source) and prints
epo.t, epo.fs, and every other field, so the -500 ms claim is measured rather than
inherited from a comment. If t[0] is anything but ~-500 ms, samples 0..127 are NOT a
task-free pre-cue segment and leak_probe.py's "baseline" rows need re-labelling.

    /root/venv_fast/bin/python -u check_t.py
"""
import glob
import os

import numpy as np
import scipy.io as sio

CANDIDATES = [
    "/root/FAST/BCIC2020Track3/Training set/Data_Sample01.mat",
    "/root/FAST/BCIC2020Track3/Validation set/Data_Sample01.mat",
]

found = [c for c in CANDIDATES if os.path.exists(c)]
if not found:
    found = sorted(glob.glob("/root/**/Data_Sample*.mat", recursive=True))[:4]
print("files:", found, flush=True)
if not found:
    raise SystemExit("no .mat found -- cannot verify")

f = found[0]
d = sio.loadmat(f, struct_as_record=False, squeeze_me=True)
print("top-level keys:", [k for k in d if not k.startswith("__")], flush=True)

epo_keys = [k for k in d if not k.startswith("__") and k.lower().startswith("epo")]
print("epoch-struct keys:", epo_keys, flush=True)

for key in epo_keys:
    e = d[key]
    print("\n=== %s : %s ===" % (key, type(e).__name__), flush=True)
    fields = [a for a in dir(e) if not a.startswith("_")]
    print("fields:", fields, flush=True)
    for a in fields:
        try:
            v = np.asarray(getattr(e, a))
        except Exception as exc:            # noqa: BLE001
            print("  %-14s <unreadable: %s>" % (a, exc), flush=True)
            continue
        if v.dtype.kind in "fiu" and v.size <= 8:
            print("  %-14s shape %-14s %s" % (a, v.shape, v.ravel()), flush=True)
        elif v.dtype.kind in "fiu" and a in ("t", "times", "time"):
            print("  %-14s shape %-14s first3 %s last3 %s"
                  % (a, v.shape, np.ravel(v)[:3], np.ravel(v)[-3:]), flush=True)
        else:
            print("  %-14s shape %-14s dtype %s" % (a, v.shape, v.dtype), flush=True)

    if hasattr(e, "x"):
        x = np.asarray(e.x)
        print("\n  epo.x shape", x.shape, flush=True)
        print("  epo.x dtype", x.dtype, "min %.4g max %.4g" % (x.min(), x.max()), flush=True)

# The decisive arithmetic: sample index -> milliseconds, from the file itself.
for key in epo_keys:
    if not hasattr(d[key], "t"):
        continue
    t = np.asarray(d[key].t).ravel()
    fs = getattr(d[key], "fs", None)
    print("\n--- TIMING (%s) ---" % key, flush=True)
    print("t[0] = %.4f ms" % t[0], flush=True)
    print("t[-1] = %.4f ms" % t[-1], flush=True)
    print("n samples = %d" % len(t), flush=True)
    print("fs field = %s" % fs, flush=True)
    dt = np.median(np.diff(t))
    print("median dt = %.6f ms  -> implied fs = %.3f Hz" % (dt, 1000.0 / dt), flush=True)
    # n samples ending at t[-1] starting at t[0]
    print("span = %.1f ms = %.4f s" % (t[-1] - t[0], (t[-1] - t[0]) / 1000.0), flush=True)
    # What is sample 128? sample 0?
    print("sample 0   -> %.3f ms" % t[0], flush=True)
    print("sample 127 -> %.3f ms" % t[127], flush=True)
    print("sample 128 -> %.3f ms" % t[128], flush=True)
    print("\nVERDICT: samples 0..127 span %.1f ms to %.1f ms relative to t=0"
          % (t[0], t[127]), flush=True)
    if t[0] < -100:
        print("  -> PRE-CUE / task-free segment CONFIRMED", flush=True)
    else:
        print("  -> NOT pre-cue. leak_probe.py's 'baseline' rows are MISLABELLED.",
              flush=True)
print("CHECK_T_DONE", flush=True)
