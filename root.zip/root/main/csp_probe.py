"""Filter-bank CSP + LDA, on the SAME folds and the SAME data as everything else.

WHY THIS IS NOT REDUNDANT WITH ANYTHING ALREADY MEASURED.

The measured negatives so far are: whole-epoch per-channel moments (`mom_epoch`, 0.4149),
per-band covariance in the tangent space (`cov_tangent`, 0.4015), band power (`bp`, 0.3623).
All three are SPATIALLY UNCORRECTED -- they describe one electrode at a time (moments,
power) or the covariance's geometry without a supervised choice of direction (tangent).
CSP is the one classic method missing from that list, and it is the one that is
SUPERVISED: it chooses the spatial directions that maximise the variance ratio between
classes, which is a different object from anything the moments or the covariance give.

It is also the standard "did you try the simple thing" baseline in this literature, and
the released model's own cnn2 is a LEARNED spatial filter (Conv2d(32, 32, (n_ch, 1))), so
the comparison "supervised linear spatial filter + linear classifier vs the whole
transformer" is a real one to have in hand.

PROTOCOL. Identical to every other arm: KFold(5, shuffle=False) on the same 350 trials per
subject, same subject list, accuracy per fold, compared PAIRED against the stored released
CSV. Filter-bank CSP is fitted INSIDE each fold on the training split only -- fitting the
spatial filters on the full subject would leak the test trials into the projection, which
is the single most common way a CSP number comes out too high.

Runs on CPU. Deliberately: the GPU has a training queue on it and this needs none.
    python csp_probe.py --subjects 0-14
"""

import argparse
import os
import sys

import numpy as np
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.model_selection import KFold

sys.path.insert(0, "/root/FAST")
os.chdir("/root/FAST")

FS = 200.0
# Same band family the released preprocessing passes (1-40 Hz), split into the classic
# overlapping sub-bands. 4 Hz width with 2 Hz step is the standard filter-bank CSP setting
# for a 40 Hz ceiling; 8 bands from 2-40 Hz.
BANDS = [(lo, lo + 4) for lo in range(2, 36, 2)]
N_COMP = 4          # CSP components kept per band, per class-direction; 4 is the usual


def load_subject(s):
    import h5py
    with h5py.File("Processed/BCIC2020Track3.h5", "r") as f:
        keys = sorted(f.keys(), key=lambda k: int(k) if k.isdigit() else k)
        return f[keys[s]]["X"][()], f[keys[s]]["Y"][()]


def butter_bandpass(x, lo, hi, fs=FS, order=4):
    """Zero-phase Butterworth along the time axis. x: (..., T)."""
    from scipy.signal import butter, filtfilt
    b, a = butter(order, [lo / (fs / 2), hi / (fs / 2)], btype="band")
    return filtfilt(b, a, x, axis=-1)


def csp_filters(x, y, n_comp=N_COMP):
    """Supervised spatial filters: top n_comp eigenvectors of C1 / (C1 + C2), per class.

    One-vs-rest, averaged over classes, which is the standard multiclass extension. Returns
    a list of (n_ch, n_comp) projection matrices, one per class.
    """
    n_classes = int(y.max()) + 1
    ch = x.shape[1]
    projs = []
    for c in range(n_classes):
        pos = x[y == c]
        neg = x[y != c]
        Cp = np.mean([np.cov(t) for t in pos], axis=0)
        Cn = np.mean([np.cov(t) for t in neg], axis=0)
        Cp += 1e-6 * np.trace(Cp) / ch * np.eye(ch)
        Cn += 1e-6 * np.trace(Cn) / ch * np.eye(ch)
        ev, V = np.linalg.eigh(np.linalg.solve(Cn, Cp))
        order = np.argsort(ev)[::-1]
        W = V[:, order[:n_comp]]
        projs.append(W / np.linalg.norm(W, axis=0, keepdims=True))
    return projs


def band_features(x_tr, y_tr, x_te):
    """Filter-bank CSP features: log-variance of each band's CSP components, both splits."""
    ftr, fte = [], []
    for lo, hi in BANDS:
        z_tr = butter_bandpass(x_tr, lo, hi)
        z_te = butter_bandpass(x_te, lo, hi)
        for W in csp_filters(z_tr, y_tr):
            ftr.append(np.log(np.var(np.einsum('bct,ck->bkt', z_tr, W), axis=-1) + 1e-12))
            fte.append(np.log(np.var(np.einsum('bct,ck->bkt', z_te, W), axis=-1) + 1e-12))
    return np.concatenate(ftr, axis=1), np.concatenate(fte, axis=1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--subjects", type=str, default="0-14")
    ap.add_argument("--out", type=str, default="Results/ZA/csp.npz")
    a = ap.parse_args()

    todo = []
    for part in a.subjects.split(","):
        if "-" in part:
            lo, hi = [int(v) for v in part.split("-")]
            todo += list(range(lo, hi + 1))
        else:
            todo.append(int(part))

    accs = {}
    for s in todo:
        X, Y = load_subject(s)
        correct = np.zeros(len(Y), dtype=bool)
        fold_of = np.full(len(Y), -1, dtype=int)
        for fi, (tr, te) in enumerate(KFold(n_splits=5, shuffle=False).split(X)):
            ftr, fte = band_features(X[tr].astype(np.float64), Y[tr],
                                     X[te].astype(np.float64))
            clf = LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
            clf.fit(ftr, Y[tr])
            correct[te] = clf.predict(fte) == Y[te]
            fold_of[te] = fi
            print("    [subj %02d fold %d] acc %.4f" % (s, fi, correct[te].mean()), flush=True)
        accs[s] = correct.mean()
        print("  [csp subject %02d] acc = %.4f" % (s, accs[s]), flush=True)

    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    np.savez(a.out, **{"%d" % s: np.array([v]) for s, v in accs.items()})
    print("")
    print("=== csp : mean %.4f  sd %.4f  n=%d  (released base 0.5779) ==="
          % (np.mean(list(accs.values())),
             np.std(list(accs.values()), ddof=1) if len(accs) > 1 else 0.0, len(accs)))
    print("CSP_DONE")


if __name__ == "__main__":
    main()
