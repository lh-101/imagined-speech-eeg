#!/bin/bash
cd /root/FAST
mv Results/FAST Results/FAST_vgpu4080 2>/dev/null
echo "=== STAGE 1: LOSO cross-subject probe, held-out subjects 0-4 ==="
/root/venv_fast/bin/python -u loso_probe.py --subjects 0-4
echo ""
echo "=== STAGE 2: subject-dependent baseline rerun on THIS card (3080 Ti) ==="
/root/venv_fast/bin/python -u BCIC2020Track3_train.py --gpu 0 --folds 0-15
echo "RUNNER_DONE"
