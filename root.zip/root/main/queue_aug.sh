#!/bin/bash
# Augmentation arms, after the riemann queue, serially, on an idle GPU -- same reason as
# queue_spatial.sh: a second process changes the free memory visible at model-construction
# time, and --harness exact is only reproducible with exclusive GPU access.
#
# WHY AUGMENTATION AND NOT A TWELFTH ARCHITECTURE. diagnose.py: base, subject 0, TRAIN
# 1.0000 / TEST 0.6143. The model memorises its 280 training trials. The released loader
# uses batch_size=len(x_train)=280 for 200 epochs, so with one full-batch step per epoch the
# model looks at THE SAME 280 trials 200 times. Augmentation applied in __getitem__ gives
# each of those 200 steps a different view -- the protocol's odd shape hands us 200 draws
# for free. Eleven architecture variants failed and the lr mismatch is worth +0.0095, i.e.
# below the +0.0120 placebo noise floor, so neither capacity nor the optimiser is binding.
#
# SCREEN FIRST: three presets x subjects 0-4. The other arms settle by subject 5. At n=5 the
# resolvable difference is ~0.03, which is enough to kill or promote a preset; it is NOT
# enough to report a win, so whichever preset survives extends to 5-14 before anything is
# quoted. presets: cdrop = channel dropout 0.1 alone (the minimal, most targeted test);
# light = shift 125 ms + gain 10% + dropout 0.1 + noise 5%; full = the same, doubled.
cd /root/FAST || exit 1
P=/root/venv_fast/bin/python
LOG=/root/FAST/arms.log

for _ in $(seq 1 960); do
  grep -q QUEUE_RIEMANN_DONE "$LOG" 2>/dev/null && break
  sleep 30
done
if ! grep -q QUEUE_RIEMANN_DONE "$LOG" 2>/dev/null; then
  echo "=== aug SKIPPED: riemann queue never reported done ===" >> "$LOG"
  exit 1
fi

# Gate on the augmentation's own ground-truth suite. An idle augmentation would run to
# completion and produce a null result indistinguishable from a real one.
if ! CUDA_VISIBLE_DEVICES= $P aug_dataset.py 2>&1 | grep -q ALL_TESTS_PASSED; then
  echo "=== aug SKIPPED: aug_dataset.py self-test did not pass ===" >> "$LOG"
  exit 1
fi

for preset in cdrop light full; do
  echo "=== aug-$preset START $(date +%H:%M:%S) ===" >> "$LOG"
  $P -u zone_attn_probe.py --variant base --harness exact --aug "$preset" \
      --subjects 0-4 >> "$LOG" 2>&1
  echo "=== aug-$preset END $(date +%H:%M:%S) ===" >> "$LOG"
done
echo QUEUE_AUG_DONE >> "$LOG"
