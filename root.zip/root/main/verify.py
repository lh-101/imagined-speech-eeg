import h5py, numpy as np, importlib
f = h5py.File("/root/FAST/Processed/BCIC2020Track3.h5","r")
ks = sorted(f.keys())
print("subjects:", len(ks), ks)
tot = 0
for k in ks:
    X, Y = f[k]["X"], f[k]["Y"]
    tot += X.shape[0]
    assert X.shape == (350,64,800), (k, X.shape)
    assert Y.shape == (350,), (k, Y.shape)
    assert X.dtype == np.float32 and Y.dtype == np.uint8, (k, X.dtype, Y.dtype)
    u, cnt = np.unique(Y, return_counts=True)
    assert len(u) == 5 and set(cnt.tolist()) == {70}, (k, list(zip(u.tolist(), cnt.tolist())))
print("PASS: 15/15 subjects shape (350,64,800) float32, Y uint8, 5x70 balanced")
print("total trials:", tot)
x0 = f[ks[0]]["X"][0]
print("subj01 trial0  min=%.3f max=%.3f mean=%.4f std=%.4f" % (x0.min(), x0.max(), x0.mean(), x0.std()))
f.close()
print()
print("=== deps ===")
for m in ["torch","lightning","pytorch_lightning","torchmetrics","einops","transformers","h5py","sklearn","scipy","numpy"]:
    try:
        mod = importlib.import_module(m)
        print("  OK   %-18s %s" % (m, getattr(mod,"__version__","?")))
    except Exception as ex:
        print("  FAIL %-18s %s %s" % (m, type(ex).__name__, ex))
import torch
print("  cuda_available=%s  torch_cuda=%s  device_count=%d" % (torch.cuda.is_available(), torch.version.cuda, torch.cuda.device_count()))
