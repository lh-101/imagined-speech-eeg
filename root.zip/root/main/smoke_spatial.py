"""One real training step at the released batch size, on the GPU, measuring peak memory.

The released protocol uses batch_size = len(x_train) = 280, so a single step holds 280 trials
x 5 windows x 62 timesteps = 86,800 tokens of dim 32 through the spatial attention. That is
the one place the corrected `spatial` arm could fail rather than score badly, and the failure
mode is specific: if F.scaled_dot_product_attention cannot use its flash or memory-efficient
kernel it falls back to the MATH backend, which materialises the (L, heads, C, C) weight
matrix -- 86,800 x 4 x 64 x 64 x 2 B = 2.8 GB for that tensor alone, times whatever autograd
retains. An OOM 20 minutes into a 40-minute run is the expensive way to learn that.

Also asserts the attention kernel actually used, via the SDPA backend switch, so the answer is
"we measured which kernel ran", not "we hoped".

Run on the training box: python smoke_spatial.py
"""

import sys
import torch
import torch.nn.functional as F
from transformers import PretrainedConfig

sys.path.insert(0, "/root/FAST")
from BCIC2020Track3_preprocess import Electrodes, Zones
from fast_zones import build, FAST_Spatial, SpatialHead

# torch 2.1 has no torch.nn.attention.sdpa_kernel; the equivalent context manager is on
# torch.backends.cuda. Probe for it rather than pinning one API, and if neither exists the
# per-backend section is skipped instead of failing the whole run -- the memory measurement
# below is the part that actually gates the training run.
try:
    from torch.nn.attention import sdpa_kernel as _sdpa  # torch >= 2.3
    def _only(backend_name):
        from torch.nn.attention import SDPBackend
        return _sdpa(getattr(SDPBackend, backend_name))
except ImportError:
    from contextlib import contextmanager

    @contextmanager
    def _only(backend_name):
        flags = {"FLASH_ATTENTION": dict(enable_flash=True, enable_math=False,
                                         enable_mem_efficient=False),
                 "EFFICIENT_ATTENTION": dict(enable_flash=False, enable_math=False,
                                             enable_mem_efficient=True)}
        with torch.backends.cuda.sdp_kernel(**flags[backend_name]):
            yield

torch.set_float32_matmul_precision("medium")
torch.manual_seed(42)


def cfg(variant):
    return PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1, variant=variant,
    )


def main():
    if not torch.cuda.is_available():
        print("NO CUDA -- this test is meaningless without the GPU")
        return

    # which kernels does this torch/GPU actually offer for our shapes?
    print("torch %s  gpu %s" % (torch.__version__, torch.cuda.get_device_name(0)))

    m = build(cfg("spatial"))
    assert isinstance(m, FAST_Spatial), "build() did not dispatch to the spatial arm"
    m = m.cuda().train()
    n_par = sum(p.numel() for p in m.parameters())
    # Assert the head count ACTUALLY took effect, rather than trusting the class default:
    # _build_spatial reads it from the config with a fallback, and a fallback that disagrees
    # with the class body puts head_dim back to 4 without any error.
    d = m.head.spatial.d
    print("params %d  heads %d  head_dim %d  time_stride %d"
          % (n_par, m.head.spatial.h, d, SpatialHead.TIME_STRIDE))
    assert d >= 8, ("head_dim %d: the flash kernel needs a multiple of 8, so this would fall "
                    "back to MATH and OOM -- N_HEADS is being overridden somewhere" % d)

    x = torch.randn(280, len(Electrodes), 800, device="cuda")
    y = torch.randint(0, 5, (280,), device="cuda")

    torch.cuda.reset_peak_memory_stats()
    opt = torch.optim.AdamW(m.parameters(), lr=5e-4)

    # Which memory-safe kernels are actually usable at this shape? MATH is deliberately NOT
    # probed: it is the fallback being avoided, and forcing it would allocate the very
    # (L, heads, C, C) matrix the design exists to avoid. What matters is that at least one
    # of the other two works -- if neither did, the real step below would use MATH and OOM.
    #
    # UNDER autocast(bf16), because that is how the released protocol runs. Probing in fp32
    # gives a FALSE negative: the flash kernel only accepts fp16/bf16, so an fp32 probe
    # reports "No available kernel" for a configuration that works fine in the real step.
    # This was measured, not assumed -- the first version of this probe was fp32 and was
    # wrong about a head_dim-8 configuration that trains.
    usable = None
    for name in ("FLASH_ATTENTION", "EFFICIENT_ATTENTION"):
        try:
            with _only(name), torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                with torch.no_grad():
                    m(x)
            usable = name
            print("  backend %-20s usable at this shape" % name)
            # Stop at the first working backend. A FAILING SDPA probe reports its CUDA error
            # asynchronously, so probing further leaves an error queued that surfaces at the
            # next kernel launch -- which is the real training step, attributing the failure
            # to the wrong line. One working backend is all the run needs.
            break
        except Exception as e:
            print("  backend %-20s NOT usable: %s: %s" % (name, type(e).__name__, e))
    assert usable, "no memory-safe SDPA backend -- the real step would fall back to MATH"
    torch.cuda.empty_cache()

    # The real step: autocast bf16 exactly as the released protocol runs it, forward AND
    # backward, because autograd is what retains the activations.
    with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
        logits = m(x)
        loss = F.cross_entropy(logits.float(), y)
    loss.backward()
    opt.step()

    peak = torch.cuda.max_memory_allocated() / 2 ** 30
    total = torch.cuda.get_device_properties(0).total_memory / 2 ** 30
    print("logits %s  loss %.4f" % (tuple(logits.shape), loss.item()))
    print("PEAK MEMORY %.2f GiB of %.2f GiB  (%.0f%%)" % (peak, total, 100 * peak / total))
    assert peak < 0.90 * total, \
        "peak %.2f GiB leaves no headroom on a %.2f GiB card" % (peak, total)

    # and the gradient actually reaches the new spatial block
    g = m.head.spatial.qkv.weight.grad
    assert g is not None and torch.isfinite(g).all() and g.abs().sum() > 0, \
        "the spatial attention got no gradient"
    print("ok  spatial attention trains; SMOKE_SPATIAL_PASSED")


if __name__ == "__main__":
    main()
