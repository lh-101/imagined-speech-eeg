"""Ground-truth tests for the `riemann` variant: FAST_Riemann + RiemannBranch.

`riemann` is the one arm that was built and never run, and `spatial` v1 is the precedent
for what that costs: an arm that silently evaluates a different model scores -0.26 and
burns two hours before anyone learns why. The failure modes that are specific to THIS
construction, and that no shape assert would catch:

  * `logm` is wrong -- eigh returns ASCENDING eigenvalues and the reconstruction must use
    V diag(log ev) V^T, not V log(ev) V^-1 or a mis-transposed V. A wrong log still returns
    a finite, correctly-shaped tensor and trains to a plausible-looking score.
  * the branch leaks ACROSS zones -- `_log_cov` indexes `x[:, self.index[area]]`, and if
    the index tensors were built wrong, zone A's covariance would carry zone B's channels.
    Nothing about the output shape reveals this.
  * the ridge is not scale-relative -- per-channel amplitude spans 21x-73x within a
    subject, so a fixed ridge degenerates on some subjects. The test fixes the RIDGE and
    recomputes the descriptor independently rather than trusting `_log_cov`.
  * the widened `input_layer` never replaced the deleted 256-wide one -- `del
    self.input_layer` followed by rebinding is easy to get wrong in a way that leaves the
    model running at the old width.
  * autocast is not actually disabled around `eigh` -- bf16 eigh has no kernel and the
    documented workaround is `torch.autocast(enabled=False)`. If that line were dropped the
    branch would silently run under bf16 wherever the caller is autocasting, which is the
    entire released protocol.
  * the backward through eigh NaNs -- eigenvalues can collide, and d log(ev)/d ev blows up
    there. That is why the ridge exists; this test checks the cure, not the theory.

Run on the training box (CPU only, so it does not disturb a run on the GPU):
    CUDA_VISIBLE_DEVICES= python test_riemann.py
"""

import os
import sys

import torch
from transformers import PretrainedConfig

sys.path.insert(0, "/root/FAST")
os.chdir("/root/FAST")

from BCIC2020Track3_preprocess import Electrodes, Zones
from fast_zones import FAST, FAST_Riemann, RiemannBranch, build

_TESTS = []


def test(fn):
    _TESTS.append(fn)
    return fn


def cfg(variant):
    return PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1, variant=variant,
    )


def branch():
    b = RiemannBranch(Electrodes, Zones, out_dim=8)
    b.eval()
    return b


# --------------------------------------------------------------------------------------
# 1. logm, against an independent computation. This is the load-bearing piece: everything
#    downstream is a linear readout of it.
# --------------------------------------------------------------------------------------

@test
def test_logm_matches_power_series():
    """log(I+N) = N - N^2/2 + N^3/3 - ... for small symmetric N, computed a different way.

    Independently from `logm`: no eigh anywhere in the reference, so a transpose or
    eigenvalue-order bug in logm cannot cancel out of the comparison.
    """
    torch.manual_seed(0)
    B, n = 4, 6
    S = torch.randn(B, n, n)
    S = (S + S.transpose(1, 2)) / 2
    S = S / S.reshape(B, -1).norm(dim=1).reshape(B, 1, 1) * 0.3   # spectral radius <= 0.3
    C = torch.eye(n).unsqueeze(0) + S

    got = RiemannBranch.logm(C)

    acc, term = S.clone(), S.clone()
    for k in range(2, 21):
        term = term @ S                       # S^k
        acc = acc + ((-1) ** (k + 1)) * term / k
    err = (got - acc).abs().max().item()
    assert err < 1e-5, "logm disagrees with the power series by %.3e" % err


@test
def test_logm_is_symmetric():
    torch.manual_seed(1)
    C = torch.randn(3, 5, 5)
    C = C @ C.transpose(1, 2) + 5 * torch.eye(5)     # SPD
    L = RiemannBranch.logm(C)
    asym = (L - L.transpose(1, 2)).abs().max().item()
    assert asym < 1e-6, "logm output is not symmetric (max asymmetry %.3e)" % asym


@test
def test_logm_eigenvalues_are_logs_of_covariance_eigenvalues():
    """The defining property, checked on the spectrum rather than the entries."""
    torch.manual_seed(2)
    C = torch.randn(3, 7, 7)
    C = C @ C.transpose(1, 2) + 2 * torch.eye(7)
    got = torch.linalg.eigvalsh(RiemannBranch.logm(C))
    want = torch.linalg.eigvalsh(C).clamp_min(1e-12).log()
    err = (got - want).abs().max().item()
    assert err < 1e-5, "logm spectrum is not log of the covariance spectrum (%.3e)" % err


@test
def test_logm_survives_a_degenerate_eigenvalue():
    """Rank-deficient C is exactly where d log(ev) blows up; the branch must not NaN."""
    C = torch.zeros(2, 4, 4)
    C[0, 0, 0] = 1.0
    C[1, 0, 0] = C[1, 1, 1] = 1.0
    L = RiemannBranch.logm(C)
    assert torch.isfinite(L).all(), "logm NaNs on a singular covariance"
    assert L[0, 0, 0] == 0.0 and L[0, 1, 1] < -20, \
        "log(0) should clamp to the eps floor, not vanish or explode"


# --------------------------------------------------------------------------------------
# 2. The descriptor, recomputed independently from a real window.
# --------------------------------------------------------------------------------------

@test
def test_log_cov_triu_matches_independent_recomputation():
    """Rebuild zone z's ridge-regularised log-covariance by hand and compare entries."""
    torch.manual_seed(3)
    b = branch()
    x = torch.randn(2, len(Electrodes), 250)

    got = b.log_cov_triu(x)

    for k, area in enumerate(b.zones):
        idx = b.index[area]
        xz = x[:, idx]
        xz = xz - xz.mean(dim=2, keepdim=True)
        C = torch.bmm(xz, xz.transpose(1, 2)) / xz.shape[2]
        n = C.shape[-1]
        eye = torch.eye(n, dtype=C.dtype)
        scale = C.diagonal(dim1=-2, dim2=-1).mean(-1).clamp_min(1e-12)
        C = C + (b.RIDGE * scale)[:, None, None] * eye
        want = RiemannBranch.logm(C)
        r, c = b.triu[area]
        err = (got[k] - want[:, r, c]).abs().max().item()
        assert err < 1e-5, "zone %s descriptor off by %.3e" % (area, err)
        assert got[k].shape == (2, n * (n + 1) // 2), \
            "zone %s triu has %s entries for %d channels" % (area, got[k].shape[1], n)


@test
def test_branch_output_shape_and_readout_width():
    b = branch()
    x = torch.randn(3, len(Electrodes), 250)
    y = b(x)
    assert y.shape == (3, len(Zones) * b.out_dim), \
        "branch returned %s, expected %s" % (tuple(y.shape), (3, len(Zones) * b.out_dim))
    for area in b.zones:
        n = len(Zones[area])
        assert b.projs[area].in_features == n * (n + 1) // 2, \
            "zone %s readout expects %d inputs for %d channels" \
            % (area, b.projs[area].in_features, n)
    assert b.projs[area].out_features == b.out_dim


@test
def test_branch_is_not_constant():
    """A branch that ignores its input would still pass every shape test."""
    b = branch()
    x = torch.randn(1, len(Electrodes), 250)
    x2 = torch.randn(1, len(Electrodes), 250)
    assert (b(x) - b(x2)).abs().max().item() > 1e-3, \
        "the branch output does not depend on the window"


# --------------------------------------------------------------------------------------
# 3. NO LEAKAGE ACROSS ZONES. Batch of ONE, so dim 0 is unambiguous.
# --------------------------------------------------------------------------------------

@test
def test_zones_do_not_leak_into_each_other():
    """Perturb one electrode; every OTHER zone's descriptor must be bit-identical.

    Batch of one on purpose: `forward` flattens (B, N) into one axis, so with B > 1 a row
    index does not mean what it looks like. That mistake already produced a false failure
    once, in test_spatial.py.
    """
    b = branch()
    x1 = torch.randn(1, len(Electrodes), 250)
    torch.manual_seed(7)          # the additive term below must be fixed, not resampled

    for target in b.zones:
        ch = b.index[target][0]
        xb = x1.clone()
        # NOT a constant offset. `_log_cov` subtracts the time mean first, so a per-channel
        # constant cancels EXACTLY and would leave the descriptor bit-identical -- a
        # perturbation that is a no-op by construction, which is how this test failed the
        # first time. Scale the channel (variance x4) and add a time-varying term instead.
        xb[:, ch] = xb[:, ch] * 2.0 + torch.randn(xb.shape[2])
        a, c = b.log_cov_triu(x1), b.log_cov_triu(xb)
        for k, area in enumerate(b.zones):
            moved = (a[k] - c[k]).abs().max().item()
            if area == target:
                assert moved > 1e-4, \
                    "perturbing %s did not move its own descriptor" % area
            else:
                assert moved < 1e-6, \
                    "perturbing an electrode of %s moved zone %s by %.3e" % (target, area, moved)


# --------------------------------------------------------------------------------------
# 4. The assembled model: the released contract, plus the width it changed.
# --------------------------------------------------------------------------------------

@test
def test_forward_returns_the_released_logit_contract():
    m = build(cfg("riemann")).eval()
    assert isinstance(m, FAST_Riemann)
    x = torch.randn(2, len(Electrodes), 800)
    with torch.no_grad():
        y = m(x)
    assert y.shape == (2, 5), "logits %s, expected (2, 5)" % (tuple(y.shape),)
    assert torch.isfinite(y).all(), "logits are not finite"
    assert m.n_tokens == 5, "the window count changed: n_tokens = %d" % m.n_tokens


@test
def test_widened_input_layer_replaced_the_deleted_one():
    """`del self.input_layer` then rebinding: the model must run at (32+8)*8 = 320."""
    m = build(cfg("riemann")).eval()
    n_zones = len(Zones)
    want = (32 + m.cov_dim) * n_zones
    got = m.input_layer[0].in_features
    assert got == want, "input_layer is %d wide, expected %d" % (got, want)
    assert m.input_layer[0].out_features == 32, "token width is not 32"
    # and the deleted 256-wide layer is really gone, not shadowed
    assert not hasattr(m, "_modules") or "input_layer" in m._modules


@test
def test_covariance_branch_is_live_in_the_forward_pass():
    """The branch must be reached by `forward` -- a variant that computes it and drops it
    would score exactly like base and look like a tie rather than a bug."""
    m = build(cfg("riemann")).eval()
    seen = {}
    h = m.riemann.register_forward_hook(lambda mod, i, o: seen.__setitem__("o", o.detach()))
    with torch.no_grad():
        m(torch.randn(1, len(Electrodes), 800))
    h.remove()
    assert "o" in seen, "m.riemann was never called by forward()"
    assert seen["o"].abs().max().item() > 0


@test
def test_non_default_forward_mode_fails_loudly():
    """The parent's other modes call forward_head, which here would silently drop the
    covariance branch and evaluate a different model. It must raise, not quietly run."""
    m = build(cfg("riemann")).eval()
    try:
        m(torch.randn(1, len(Electrodes), 800), forward_mode="zone")
    except NotImplementedError:
        return
    raise AssertionError("a non-default forward_mode ran without raising")


# --------------------------------------------------------------------------------------
# 5. Numerics: autocast really is disabled around eigh, and the backward is finite.
# --------------------------------------------------------------------------------------

@test
def test_branch_is_autocast_immune():
    """Under the released protocol everything runs under autocast(bf16). The branch is
    documented to escape it -- bf16 `eigh` has no kernel. Checked by equality, not by
    tolerance: if the escape works, the output is the fp32 output exactly."""
    b = branch()
    x = torch.randn(2, len(Electrodes), 250)
    with torch.no_grad():
        y32 = b(x)
        with torch.autocast(device_type="cpu", dtype=torch.bfloat16):
            y16 = b(x)
    err = (y16.float() - y32).abs().max().item()
    assert err < 1e-6, \
        "branch output moved by %.3e under autocast -- the escape is not holding" % err


@test
def test_backward_through_eigh_is_finite_and_reaches_the_readouts():
    b = branch()
    x = torch.randn(4, len(Electrodes), 250, requires_grad=True)
    b(x).pow(2).sum().backward()

    for area in b.zones:
        g = b.projs[area].weight.grad
        assert g is not None, "zone %s readout got no gradient" % area
        assert torch.isfinite(g).all(), "zone %s readout gradient is not finite" % area
        assert g.abs().sum().item() > 0, "zone %s readout gradient is all zero" % area
    assert torch.isfinite(x.grad).all(), "gradient through the covariance path is not finite"


@test
def test_parameter_census_is_the_documented_one():
    """191,781 -> 196,517, i.e. +4,736. A variant that quietly adds capacity is not the arm
    that was proposed, and `param_report` is what the write-up will quote.

    The +4,736 is TWO pieces and they must not be conflated: 2,688 in RiemannBranch itself
    (the per-zone readouts) plus 2,048 in the widened input layer (Linear(320,32) minus the
    deleted Linear(256,32) = 10,272 - 8,224). Attributing all of it to the branch was this
    test's first bug.
    """
    m = build(cfg("riemann"))
    base = build(cfg("base"))
    n_riemann = sum(p.numel() for p in m.parameters())
    n_base = sum(p.numel() for p in base.parameters())
    n_branch = sum(p.numel() for p in m.riemann.parameters())
    assert n_base == 191781, "base is %d params, not the recorded 191,781" % n_base
    assert n_riemann == 196517, \
        "riemann is %d params, not the documented 196,517" % n_riemann
    assert n_riemann - n_base == 4736, \
        "riemann adds %d params, not the documented +4,736" % (n_riemann - n_base)
    assert n_branch == 2688, "RiemannBranch is %d params, not 2,688" % n_branch
    assert m.input_layer[0].weight.numel() + m.input_layer[0].bias.numel() \
        - base.input_layer[0].weight.numel() - base.input_layer[0].bias.numel() == 2048, \
        "the widened input layer does not account for the other 2,048"
    # and the branch adds no time-window machinery: same token count as base
    assert m.n_tokens == base.n_tokens == 5


def main():
    fails = []
    for fn in _TESTS:
        try:
            fn()
            print("  ok    %s" % fn.__name__)
        except Exception as e:
            fails.append((fn.__name__, e))
            print("  FAIL  %s: %s: %s" % (fn.__name__, type(e).__name__, e))
    print("")
    if fails:
        print("%d/%d FAILED" % (len(fails), len(_TESTS)))
        for name, e in fails:
            print("   %s -> %s" % (name, e))
        sys.exit(1)
    print("ALL_TESTS_PASSED  (%d tests)" % len(_TESTS))


if __name__ == "__main__":
    main()
