"""Ground-truth checks for spectral_probe.py, on signals whose answer is known.

Every assertion here is against a number I can compute by hand, because the whole
point of the probe is to decide whether to rebuild the model -- a silent shape bug
or a mislabelled band would send the project the wrong way.

Run: python test_spectral.py
"""
import numpy as np
from spectral_probe import (band_power, features, cov_tangent, spd_mean, tangent,
                            cv, cv_cov, BANDS, FS)

RNG = np.random.RandomState(0)
N, CH, T = 60, 8, 800
t = np.arange(T) / FS


def synth():
    """ch 0-3 carry 6 Hz (theta), ch 4-7 carry 40 Hz (gamma), plus noise."""
    x = RNG.randn(N, CH, T).astype(np.float64)
    x[:, :4, :] += 10.0 * np.sin(2 * np.pi * 6.0 * t)
    x[:, 4:, :] += 10.0 * np.sin(2 * np.pi * 40.0 * t)
    return x


def main():
    x = synth()
    bp = band_power(x)
    assert bp.shape == (N, CH, len(BANDS)), bp.shape

    bands = [b[0] for b in BANDS]
    peak = bp.mean(axis=0).argmax(axis=1)
    print("  peak band per channel:", [bands[i] for i in peak])
    assert all(bands[peak[c]] == "theta" for c in range(4)), "theta half misassigned"
    assert all(bands[peak[c]] == "gamma" for c in range(4, 8)), "gamma half misassigned"
    print("  ok  band_power puts 6 Hz in theta and 40 Hz in gamma")

    # Cross-band leakage, measured on a NOISE-FREE signal. On the noisy signal above
    # this test is not meaningful: white noise accumulates across the 40 one-Hz bins
    # of the gamma band, so the gamma/beta ratio is set by the noise floor (~370x)
    # rather than by window leakage, and a 1e3 threshold fails for a reason that has
    # nothing to do with band assignment.
    x0 = np.zeros((1, CH, T))
    x0[0, :4, :] = np.sin(2 * np.pi * 6.0 * t)
    x0[0, 4:, :] = np.sin(2 * np.pi * 40.0 * t)
    m0 = band_power(x0)[0]
    assert m0[:4, 1].min() > 1e6 * m0[:4, [0, 2, 3, 4, 5]].max(), "theta leakage"
    assert m0[4:, 4].min() > 1e6 * m0[4:, [0, 1, 2, 3, 5]].max(), "gamma leakage"
    print("  ok  window leakage < 1e-6 of in-band power (noise-free)")

    zones = [np.arange(4), np.arange(4, 8)]
    f = features(x, zones)
    n_band = len(BANDS)
    assert f["raw_moments"].shape == (N, 2 * CH), f["raw_moments"].shape
    assert f["bp"].shape == (N, CH * n_band), f["bp"].shape
    assert f["bp_zone"].shape == (N, CH * n_band + 2 * n_band), f["bp_zone"].shape
    assert f["bp_time"].shape == (N, 5 * CH * n_band), f["bp_time"].shape
    assert np.isfinite(f["bp_zone"]).all(), "non-finite log band power"
    print("  ok  feature shapes", {k: v.shape for k, v in f.items() if k != "cov_tangent"})

    # bp must separate the two halves of the montage by construction
    d = f["bp"][:, :4 * n_band].mean(1) - f["bp"][:, 4 * n_band:].mean(1)
    assert d.min() > 0, "theta-channels not above gamma-channels in bp"
    print("  ok  bp separates the theta half from the gamma half on every trial")

    C = cov_tangent(x)
    assert C.shape == (N, n_band, CH, CH), C.shape
    ev = np.linalg.eigvalsh(C)
    assert (ev > 0).all(), "covariance not positive definite"
    print("  ok  cov_tangent gives %s, all SPD (min eig %.3g)" % (C.shape, ev.min()))

    ref = spd_mean(C[:, 1])
    L = tangent(np.stack([ref, ref]), ref)
    assert np.abs(L).max() < 1e-9, "tangent of the reference is not zero: %g" % np.abs(L).max()
    print("  ok  tangent projection of the reference is zero to 1e-9")

    # end-to-end sanity: a real class difference must beat chance
    y = np.zeros(2 * N, dtype=int)
    y[N:] = 1
    x2 = np.concatenate([x, synth()])
    x2[N:, :4, :] *= 4.0                      # class 1 = stronger theta
    F2 = features(x2, zones)
    acc_bp = cv(F2["bp"], y)
    C2 = cov_tangent(x2)
    acc_cov = cv_cov(C2, y)
    print("  separable synthetic problem: bp %.3f  cov_tangent %.3f (chance 0.50)"
          % (acc_bp, acc_cov))
    assert acc_bp > 0.85, "bp failed to recover a blatant class difference"
    assert acc_cov > 0.85, "cov_tangent failed to recover a blatant class difference"

    rng = np.random.RandomState(1)
    acc_shuf = cv(F2["bp"], rng.permutation(y))
    print("  shuffled labels: %.3f (must be ~0.50)" % acc_shuf)
    assert 0.30 < acc_shuf < 0.70, "shuffled control is not at chance"
    print("  ok  real class difference recovered, shuffled control at chance")

    print("ALL_TESTS_PASSED")


if __name__ == "__main__":
    main()
