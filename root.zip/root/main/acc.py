
import numpy as np, glob, os, re
fs = sorted(glob.glob("/root/FAST/Results/FAST/*-Tune.csv"), key=lambda p: int(re.findall(r"\d+", os.path.basename(p))[0]))
accs = []
for f in fs:
    d = np.loadtxt(f, delimiter=",", dtype=int)
    a = float(np.mean(d[:,0] == d[:,1]))
    accs.append(a)
    print("  subj %02d  %d rows  acc=%.4f" % (int(re.findall(r"\d+", os.path.basename(f))[0]), d.shape[0], a))
if accs:
    print("  ---")
    print("  n=%d  mean=%.4f  std=%.4f  min=%.4f  max=%.4f" % (len(accs), np.mean(accs), np.std(accs), np.min(accs), np.max(accs)))
