#!/bin/bash
# The tail of the improvement queue, after the augmentation branch was stopped early.
#
# WHY aug-full WAS DROPPED RATHER THAN RUN. The screen produced a monotone dose-response
# against the single correct reference (base-h8, n=15, 0.5949):
#
#     no augmentation     0.0000        (base, by definition)
#     aug cdrop           -0.0131   0/5
#     aug light           -0.0257   0/4
#
# More augmentation makes it monotonically worse, and every arm is at or below the ruler
# (placebo vs base-h8 = -0.0050, 5/15). aug full is a strictly stronger version of the arm
# that was already the worst of the three on 0/4 subjects, so it is not a coin flip worth
# 45 minutes of the GPU. Recorded here as a dropped arm, not as a measured one: there is no
# augfull npz and the table must not imply there is.
#
# THE REFERENCE BUG THIS QUEUE WAS BORN FROM, RECORDED SO IT IS NOT REPEATED. The first
# read of aug light was "+0.0295, 3/3 positive" -- against base-h8-ex, which exists for only
# 5 subjects and, on exactly subjects 0-2, sits 0.037-0.069 BELOW base-h8. Every ex-harness
# arm therefore collects a free +0.02 when benchmarked against it on the 0-4 screen. The
# placebo control is what exposed it: placebo-ex is +0.0194 vs base-h8-ex but only -0.0050
# vs base-h8 over all 15 subjects, so base-h8-ex is the low draw, not the placebo. ONE
# reference for every row: base-h8.
#
# Gate and abort rule unchanged from queue_final.sh: the gate is the resource itself (a
# marker cannot tell "finished" from "died instantly"), and an arm that writes no new npz
# aborts the chain rather than cascading.
cd /root/FAST || exit 1
P=/root/venv_fast/bin/python
LOG=/root/FAST/arms.log

gpu_mib() { nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits | head -1; }
trainers() { pgrep -f "venv_fast/bin/python -u zone_attn_probe" 2>/dev/null | wc -l; }

wait_free() {
  local n=0
  while [ "$(trainers)" -gt 0 ] || [ "$(gpu_mib)" -gt 500 ]; do
    n=$((n+1))
    [ $((n % 20)) -eq 0 ] && echo "  ...waiting ($(gpu_mib) MiB, $(trainers) trainers)" >> "$LOG"
    sleep 30
  done
}

n_npz() { ls /root/FAST/Results/ZA/*"$1"*.npz 2>/dev/null | wc -l; }

run_arm() {
  local label="$1" pat="$2"; shift 2
  wait_free
  local before after rc
  before=$(n_npz "$pat")
  echo "=== $label START $(date +%H:%M:%S)  (gpu $(gpu_mib) MiB, ${before} npz)" >> "$LOG"
  $P -u zone_attn_probe.py "$@" >> "$LOG" 2>&1
  rc=$?
  after=$(n_npz "$pat")
  echo "=== $label END $(date +%H:%M:%S)  rc=$rc  npz ${before} -> ${after} ===" >> "$LOG"
  if [ "$after" -le "$before" ]; then
    echo "=== $label PRODUCED NO NEW RESULTS -- aborting rather than cascading ===" >> "$LOG"
    exit 1
  fi
}

# 1. softzone: the user's "adaptive weight per electrode inside each region", as a learnable
#    soft channel->zone assignment. Built, tested (13/13 in test_softzone.py, re-run on the
#    box at 20:2x), never trained. The tests pin the slot/zone ordering, the RNG parity with
#    base, and the one-hot limit being bit-identical to Head.
if CUDA_VISIBLE_DEVICES= $P test_softzone.py 2>&1 | grep -q ALL_TESTS_PASSED; then
  run_arm "softzone-0-4" "softzone-h8-ex" --variant softzone --harness exact --subjects 0-4
else
  echo "=== softzone SKIPPED: test_softzone.py did not pass ===" >> "$LOG"
fi

# 2. tta8 on all 15 subjects. This is the only arm left with a mechanism that is not just
#    "regularise harder": averaging softmax over 8 augmented views of the TEST set attacks
#    variance at inference, where the diagnosed failure (TRAIN 1.0000) actually lives. It is
#    also the only arm whose effect cannot be read off 5 subjects, because it changes nothing
#    about training.
run_arm "tta8-0-14" "base-h8-tta8-ex" --variant base --harness exact --tta 8 --subjects 0-14

echo QUEUE_TAIL_DONE >> "$LOG"
