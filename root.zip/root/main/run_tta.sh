#!/bin/bash
# tta8 alone, relaunched after the device bug killed it 30 s in.
#
# THE BUG, RECORDED. augment_batch allocated its random tensors on the default device
# (CPU) while predict_tta handed it CUDA tensors:
#     RuntimeError: Expected all tensors to be on the same device, but found at least
#                   two devices, cuda:0 and cpu!
# Nothing caught it because AugDataset (the training path) is built on the CPU by a
# DataLoader and moved afterwards, so augment_batch had exactly ONE caller that could ever
# see a CUDA tensor -- the TTA arm -- and every test ran under CUDA_VISIBLE_DEVICES=.
# Fixed with device=y.device, and aug_dataset.py now carries a test that asserts the
# output follows the input device (a no-op on CPU, real on the box).
#
# Why this arm is worth 45 minutes when the augmentation screens were not: it is the only
# arm left whose mechanism is not "regularise harder". It averages softmax over 8
# augmented views of the TEST set, which attacks variance at inference -- where the
# diagnosed failure actually lives (TRAIN 1.0000 on 280 trials shown 200 times). And it is
# the only arm that runs on all 15 subjects, so its mean is comparable to the reference
# without the subject-selection trap that made subjects 0-4 look like +0.07.
cd /root/FAST || exit 1
LOG=/root/FAST/arms.log
P=/root/venv_fast/bin/python

before=$(ls /root/FAST/Results/ZA/*tta8*.npz 2>/dev/null | wc -l)
echo "=== tta8-0-14 START $(date +%H:%M:%S)  (gpu $(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits | head -1) MiB, ${before} npz)" >> "$LOG"
$P -u zone_attn_probe.py --variant base --harness exact --tta 8 --subjects 0-14 >> "$LOG" 2>&1
rc=$?
after=$(ls /root/FAST/Results/ZA/*tta8*.npz 2>/dev/null | wc -l)
echo "=== tta8-0-14 END $(date +%H:%M:%S)  rc=$rc  npz ${before} -> ${after} ===" >> "$LOG"
echo QUEUE_TTA_DONE >> "$LOG"
