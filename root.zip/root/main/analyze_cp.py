"""
Analysis of the single-channel leave-one-out probe (channel_probe.py).

Answers, in order:
  1. ANCHOR   -- does all-64-deranged collapse to chance?  If not, nothing below counts.
  2. MAP      -- per-subject 64-channel importance profile; is it consistent across
                 subjects, or idiosyncratic?  This is the H1/H2 decision.
  3. RELIAB   -- split-half across subjects, and fold-to-fold within a subject.
  4. POST HOC -- zone and hemisphere importance formed from the 64 numbers, using the
                 mean single-channel drop. That quantity is SIZE-INDEPENDENT (each
                 channel is damaged alone exactly once, so averaging over a zone's
                 members cannot favour big zones), which is what the earlier
                 group-perturbation probe could not achieve -- there, damaging 29
                 channels at once is not the sum of 29 single damages, because
                 neighbouring channels are redundant with each other.

Group tests use an EXACT paired sign-flip permutation (2^15 = 32768 relabelings for
15 subjects) rather than a t approximation -- no distributional assumption, and it
costs nothing at this n.

Read-only except for Results/CP/summary.npz at the end.
"""

import os
import sys
import glob
import itertools
import numpy as np

RUN = "Results/CP"
N_PERM = 2000


def load(run=RUN):
    subs = {}
    for f in sorted(glob.glob("%s/*-chan.npz" % run),
                    key=lambda p: int(os.path.basename(p).split("-")[0])):
        s = int(os.path.basename(f).split("-")[0])
        d = np.load(f, allow_pickle=False)
        subs[s] = dict(base=d["base"].astype(float), all_ok=d["all_ok"].astype(float),
                       ch=d["ch_correct"].astype(float), fold=d["fold_of"],
                       name=[str(x) for x in d["ch_name"]])
    return subs


def mean_pair_r(Z):
    """Mean Pearson r over all subject pairs; rows = subjects, cols = features."""
    Zc = Z - Z.mean(axis=1, keepdims=True)
    sd = Zc.std(axis=1, keepdims=True)
    sd[sd == 0] = 1e-12
    Zs = Zc / sd
    C = (Zs @ Zs.T) / Z.shape[1]
    iu = np.triu_indices(Z.shape[0], 1)
    return float(C[iu].mean())


def sign_flip_p(d):
    """Exact two-sided paired permutation p-value over all 2^n sign flips."""
    n = len(d)
    obs = abs(d.mean())
    if n > 20:                       # fall back to sampling above 2^20
        rng = np.random.RandomState(0)
        s = np.array([abs((d * rng.choice([-1.0, 1.0], n)).mean()) for _ in range(200000)])
        return float((s >= obs - 1e-12).mean()), obs
    flips = np.array(list(itertools.product([1.0, -1.0], repeat=n)))
    null = np.abs((flips * d).mean(axis=1))
    return float((null >= obs - 1e-12).mean()), obs


def hemi_of(nm):
    """10-20 convention: trailing z = midline, odd trailing digit = left, even right."""
    if nm.endswith("z"):
        return "mid"
    return "L" if int(nm[-1]) % 2 == 1 else "R"


def build_groups(names, Zones):
    """group name -> list of channel indices. Explicit index lists, no string surgery."""
    idx = {nm: i for i, nm in enumerate(names)}
    G = {}
    if Zones:
        for z, ele in Zones.items():
            ii = [idx[e] for e in ele if e in idx]
            if ii:
                G[z] = ii
    L = [i for i, nm in enumerate(names) if hemi_of(nm) == "L"]
    R = [i for i, nm in enumerate(names) if hemi_of(nm) == "R"]
    G["L-all"] = L
    G["R-all"] = R
    if Zones:
        for z in ("Frontal", "Temporal", "Parietal", "Occipital"):
            if z in Zones:
                li = [i for i in L if names[i] in Zones[z]]
                ri = [i for i in R if names[i] in Zones[z]]
                if li:
                    G["L-%s" % z] = li
                if ri:
                    G["R-%s" % z] = ri
    return G


def main():
    subs = load()
    if not subs:
        print("no Results/CP/*-chan.npz found -- run channel_probe.py first")
        return
    S = sorted(subs)
    names = subs[S[0]]["name"]
    C = len(names)

    try:
        sys.path.insert(0, "/root/FAST")
        from BCIC2020Track3_preprocess import Zones
    except Exception as e:
        print("note: could not import Zones (%s) -- zone rows will be omitted" % e)
        Zones = None

    print("subjects: %d   channels: %d" % (len(S), C))
    print("")

    # ---- 1. anchors -------------------------------------------------------
    print("=== 1. ANCHOR ===")
    print("  %-5s %8s %8s %8s" % ("subj", "base", "ALL-der", "n"))
    base_all, anch = [], []
    for s in S:
        b = subs[s]["base"].mean()
        a = subs[s]["all_ok"].mean()
        base_all.append(b)
        anch.append(a)
        print("  %-5d %8.4f %8.4f %8d" % (s, b, a, len(subs[s]["base"])))
    print("  mean base=%.4f  mean ALL-deranged=%.4f  (chance 0.20)"
          % (np.mean(base_all), np.mean(anch)))
    if np.mean(anch) > 0.35:
        print("  !! ANCHOR FAILED -- the model is not reading the input; stop and check.")
    else:
        print("  anchor OK -- the model reads the input, so per-channel damage is meaningful.")

    # ---- 2. per-channel map and its consistency ---------------------------
    D = np.array([[subs[s]["base"].mean() - subs[s]["ch"][c].mean() for c in range(C)]
                  for s in S])                      # (n_subj, 64) damage
    print("")
    print("=== 2. CROSS-SUBJECT CONSISTENCY OF THE 64-CHANNEL MAP ===")
    print("  per-channel damage, averaged over subjects: mean %+.4f  min %+.4f  max %+.4f"
          % (D.mean(), D.mean(axis=0).min(), D.mean(axis=0).max()))

    rng = np.random.RandomState(0)
    obs = mean_pair_r(D)
    null = np.array([mean_pair_r(np.array([rng.permutation(row) for row in D]))
                     for _ in range(N_PERM)])
    pval = float((null >= obs).mean())
    print("  mean pairwise r between subjects        : %+.4f" % obs)
    print("  permutation null (64 labels shuffled)   : mean %+.4f  sd %.4f  n=%d"
          % (null.mean(), null.std(), N_PERM))
    print("  p = %.4f" % pval)
    print("  -> %s" % ("CONSISTENT across subjects" if pval < 0.01 else
                       "NOT distinguishable from shuffled labels"))

    hs = []
    for _ in range(N_PERM):
        p = rng.permutation(len(S))
        a = D[p[:len(S) // 2]].mean(axis=0)
        b = D[p[len(S) // 2:]].mean(axis=0)
        hs.append(np.corrcoef(a, b)[0, 1])
    hs = np.array(hs)
    print("  split-half reliability (2000 splits)    : r = %.4f  [%.4f, %.4f]  (5-95%%)"
          % (hs.mean(), np.percentile(hs, 5), np.percentile(hs, 95)))

    # ---- 3. within-subject fold-to-fold -----------------------------------
    print("")
    print("=== 3. WITHIN-SUBJECT FOLD-TO-FOLD RELIABILITY (disjoint held-out trials) ===")
    fr = []
    for s in S:
        f = subs[s]["fold"]
        prof = [subs[s]["base"][f == fi].mean() - subs[s]["ch"][:, f == fi].mean(axis=1)
                for fi in sorted(set(f.tolist()))]
        prof = np.array(prof)
        rs = [np.corrcoef(prof[i], prof[j])[0, 1]
              for i in range(len(prof)) for j in range(i + 1, len(prof))]
        fr.append(float(np.mean(rs)))
    fr = np.array(fr)
    print("  per-subject mean fold-pair r: mean %.4f  range %.4f .. %.4f"
          % (fr.mean(), fr.min(), fr.max()))
    print("  (5 folds -> 10 disjoint trial sets. This caps how repeatable ANY signal in")
    print("   the map can be, so read the cross-subject r above AGAINST it, not against 1.)")

    # ---- 4. post-hoc anatomy ---------------------------------------------
    G = build_groups(names, Zones)
    print("")
    print("=== 4. POST-HOC GROUPING FROM THE 64 NUMBERS ===")
    print("  group damage = mean over its channels of that channel's SINGLE-channel drop")
    print("  (each channel damaged alone exactly once -> no size, no redundancy confound)")
    print("")
    Gd = {g: D[:, ii].mean(axis=1) for g, ii in G.items()}
    print("  %-16s %5s %9s %9s" % ("group", "k", "damage", "sd over subj"))
    for g, v in sorted(Gd.items(), key=lambda kv: -kv[1].mean()):
        print("  %-16s %5d %9.4f %9.4f" % (g, len(G[g]), v.mean(), v.std()))

    print("")
    print("=== 4b. LATERALITY (exact paired sign-flip test) ===")
    for lp, rp, label in (("L-all", "R-all", "whole hemisphere"),
                          ("L-Frontal", "R-Frontal", "frontal"),
                          ("L-Temporal", "R-Temporal", "temporal"),
                          ("L-Parietal", "R-Parietal", "parietal"),
                          ("L-Occipital", "R-Occipital", "occipital")):
        if lp in Gd and rp in Gd:
            d = Gd[lp] - Gd[rp]
            p, mu = sign_flip_p(d)
            n = len(d)
            se = d.std(ddof=1) / np.sqrt(n)
            print("  %-11s vs %-11s (%-16s) diff=%+.4f  L>R %2d/%d  p=%.4f  2SE=%.4f"
                  % (lp, rp, label, mu, int((d > 0).sum()), n, p, 2 * se))
    print("  positive diff = LEFT matters more; the paper predicts positive")

    # ---- 5. the map itself ------------------------------------------------
    print("")
    print("=== 5. THE MAP (mean damage per channel, sorted) ===")
    mu = D.mean(axis=0)
    sd = D.std(axis=0)
    order = np.argsort(-mu)
    for rank, c in enumerate(order, 1):
        print("  %2d. %-5s %+.4f  sd %.4f  %2d/%d subjects positive  %s"
              % (rank, names[c], mu[c], sd[c], int((D[:, c] > 0).sum()), len(S),
                 hemi_of(names[c])))
    np.savez("%s/summary.npz" % RUN, D=D, mu=mu, sd=sd,
             names=np.array(names), subjects=np.array(S))
    print("")
    print("  wrote %s/summary.npz (D, mu, sd, names, subjects)" % RUN)


if __name__ == "__main__":
    main()
