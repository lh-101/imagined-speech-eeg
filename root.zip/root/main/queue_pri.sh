#!/bin/bash
# Priority queue, replacing queue_lr.sh + queue_chain.sh.
#
# Why it was rewritten rather than appended to: the lr verdict is the gate on every other
# decision, and it was sitting behind ~80 minutes of w1std/w1/riemann. This reorders the
# same work so the two arms that decide something run first. Nothing is dropped -- the
# secondary arms are still here, just later.
#
# The runner skips any subject whose .npz already exists, so every arm below resumes
# rather than redoes. That also means the order of the lines is the only thing that
# matters; re-running this script after an interruption is safe.
cd /root/FAST || exit 1
P=/root/venv_fast/bin/python

# --- 1. THE VERDICT: both 1e-3 arms from 5 subjects to 15 (~36 min) -----------------
# Pre-registered rule, fixed before these numbers exist: if the difference-in-differences
# is positive with |t| >= 2, the released schedule charges architecture variants a
# mismatch fee and the comparison must be matched-budget. If |t| < 2 or it is negative,
# zoneattn is genuinely worse and the next move is structural, not schedule-side.
echo "=== base lr=1e-3 to n=15 START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant base --lr 1e-3 --subjects 0-14
echo "=== base lr=1e-3 END $(date +%H:%M:%S) ==="

echo "=== zoneattn lr=1e-3 to n=15 START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant zoneattn --lr 1e-3 --subjects 0-14
echo "=== zoneattn lr=1e-3 END $(date +%H:%M:%S) ==="

# --- 2. close the matched pair ------------------------------------------------------
# zoneattn at the released schedule is at 14/15; the matched-budget design compares
# best-of-two schedules per architecture, so it needs the 15th subject.
echo "=== zoneattn released to n=15 START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant zoneattn --subjects 0-14
echo "=== zoneattn released END $(date +%H:%M:%S) ==="

# --- 3. secondary screens (5 subjects, cheap) ---------------------------------------
# Dose-response: does the zoneattn penalty keep shrinking as lr rises? And the competing
# explanation -- if 400 steps fixes zoneattn, the diagnosis is under-training on a
# 1-step-per-epoch schedule, not a schedule fee as such. Both are screens; the 1e-3 arms
# above are the ones that carry the verdict.
echo "=== zoneattn lr=2e-4 START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant zoneattn --lr 2e-4 --subjects 0-4
echo "=== zoneattn lr=2e-4 END $(date +%H:%M:%S) ==="

echo "=== zoneattn 400 steps START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant zoneattn --epochs 400 --subjects 0-4
echo "=== zoneattn 400 steps END $(date +%H:%M:%S) ==="

# --- 4. the structural variants, full 15, released schedule --------------------------
# w1std has a mechanism behind it (whole-epoch mean+std is the best hand-built
# representation found and the released front end cannot compute the std); w1 prices the
# 5-window tokenisation; riemann is the spatial second-order branch.
echo "=== w1std START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant w1std
echo "=== w1std END $(date +%H:%M:%S) ==="

echo "=== w1 START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant w1
echo "=== w1 END $(date +%H:%M:%S) ==="

echo "=== riemann START $(date +%H:%M:%S) ==="
$P -u zone_attn_probe.py --variant riemann
echo "=== riemann END $(date +%H:%M:%S) ==="

echo QUEUE_PRI_DONE
