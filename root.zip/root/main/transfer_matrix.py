"""
Cross-subject TRANSFER MATRIX for FAST on BCIC2020 Track 3.

WHY: loso_probe.py showed cross-subject accuracy collapses to chance (18.29% vs a
20% chance level) while the same subjects score 63.09% subject-dependently. But a
single collapsed number cannot say WHICH part of the representation fails to
transfer. The full matrix can:

  - is the failure symmetric?  (A->B vs B->A)
  - is there a "canonical" source subject whose decoder travels unusually well?
  - is there structure at all, or is every off-diagonal cell the same noise floor?
  - do subject PAIRS transfer better than average?  That is the handle needed to
    test whether inter-subject representational similarity predicts transfer.

None of this is asked anywhere in the paper -- the released code is purely
subject-dependent. It is his model, his data, a question he never posed.

PROTOCOL: deliberately the RELEASED one, not the loso_probe one.
  - KFold(5, shuffle=False), fold 0 -> 280 train / 70 test, exactly as Finetune()
  - batch_size = len(x_train) = 280 (the released full batch; NOT loso_probe's 512)
  - 200 epochs, bf16-mixed, seed_all(42)
So the DIAGONAL cell (s,s) is directly comparable with the published 54.8% and with
our 57.79% subject-dependent baseline, and the off-diagonal cells differ from the
diagonal in exactly one respect: whose data the model was trained on.

OUTPUT: Results/TM/<s>-src.npz holding
    preds  (15, 350) int64   predictions of source s's model on each target subject
    trues  (15, 350) int64   the corresponding ground truth
    diag   70 held-out trials of s itself (fold 0 test split)
Resumable: a source whose npz already exists is skipped.

Runtime: ~15 x (1.3 min train + 15 x ~2 s inference) ~= 30 min on a 3080 Ti.
"""

import os
import sys
import logging
import numpy as np
import torch

sys.path.insert(0, "/root/FAST")
os.chdir("/root/FAST")

logging.getLogger("pytorch_lightning").setLevel(logging.WARNING)
logging.getLogger("lightning").setLevel(logging.WARNING)

import lightning as pl
from torch.utils.data import DataLoader
from transformers import PretrainedConfig
from sklearn.model_selection import KFold

from BCIC2020Track3_train import (
    EEG_Encoder_Module, BasicDataset, seed_all, load_standardized_h5, inference_on_loader,
)
from BCIC2020Track3_preprocess import Electrodes, Zones

RUN = "Results/TM"
MAX_EPOCHS = 200


def build_config():
    return PretrainedConfig(
        electrodes=Electrodes, zone_dict=Zones, dim_cnn=32, dim_token=32,
        seq_len=800, window_len=250, slide_step=125, head="Conv4Layers",
        n_classes=5, num_layers=4, num_heads=8, dropout=0.1,
    )


def train_one_source(s, X, Y, config):
    """Train on fold 0 of subject s (280 trials, released full batch) and read
    out that one model on every subject in the cohort, s included."""
    seed_all(42)
    train_idx, self_test_idx = next(iter(KFold(n_splits=5, shuffle=False).split(X[s])))
    x_train, y_train = X[s][train_idx], Y[s][train_idx]

    train_loader = DataLoader(BasicDataset(x_train, y_train), batch_size=len(x_train),
                              shuffle=True, num_workers=0, pin_memory=True)
    # len(train_loader) == 1: the released code runs one full-batch step per epoch.
    model = EEG_Encoder_Module(config, MAX_EPOCHS, len(train_loader))
    trainer = pl.Trainer(strategy="auto", accelerator="gpu", devices=[0],
                         max_epochs=MAX_EPOCHS, callbacks=[],
                         enable_progress_bar=False, enable_checkpointing=False,
                         precision="bf16-mixed", logger=False)
    trainer.fit(model, train_dataloaders=train_loader)

    preds = np.zeros((15, 350), dtype=np.int64)
    trues = np.zeros((15, 350), dtype=np.int64)
    for t in range(15):
        loader = DataLoader(BasicDataset(X[t], Y[t]), batch_size=len(X[t]),
                            shuffle=False, num_workers=0, pin_memory=True)
        p, r = inference_on_loader(model.model, loader)
        preds[t], trues[t] = p, r

    # the diagonal that matches the published protocol: fold 0's held-out 70 trials
    diag_pred = preds[s][self_test_idx]
    diag_true = trues[s][self_test_idx]

    del model, trainer
    torch.cuda.empty_cache()
    return preds, trues, diag_pred, diag_true


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--sources", type=str, default="0-14",
                    help="source subjects to train, e.g. '0-4'. Resumable.")
    a = ap.parse_args()
    if "-" in a.sources:
        lo, hi = [int(x) for x in a.sources.split("-")]
        todo = list(range(lo, hi + 1))
    else:
        todo = [int(x) for x in a.sources.split(",")]

    os.makedirs(RUN, exist_ok=True)
    config = build_config()

    X, Y = load_standardized_h5("Processed/BCIC2020Track3.h5")
    print("loaded X=%s Y=%s" % (X.shape, Y.shape), flush=True)
    print("TRANSFER MATRIX: released protocol (full batch 280, KFold fold 0), "
          "%d epochs" % MAX_EPOCHS, flush=True)
    print("source queue: %s" % todo, flush=True)

    for s in todo:
        logf = "%s/%d-src.npz" % (RUN, s)
        if os.path.exists(logf):
            print("skip source %02d (exists)" % s, flush=True)
            continue
        preds, trues, diag_pred, diag_true = train_one_source(s, X, Y, config)
        np.savez(logf, preds=preds, trues=trues, diag_pred=diag_pred, diag_true=diag_true)
        acc = (preds == trues).mean(axis=1)
        print("[source %02d] diag(fold0)=%.4f | row over targets: %s"
              % (s, (diag_pred == diag_true).mean(),
                 " ".join("%.3f" % v for v in acc)), flush=True)

    # ---- summary over whatever is on disk ----
    rows, diags = {}, {}
    for s in range(15):
        f = "%s/%d-src.npz" % (RUN, s)
        if os.path.exists(f):
            d = np.load(f)
            rows[s] = (d["preds"] == d["trues"]).mean(axis=1)
            diags[s] = float((d["diag_pred"] == d["diag_true"]).mean())

    if rows:
        common = sorted(rows)
        n = len(common)
        # rows[s][t] averages all 350 trials of t, and when t == s that includes the
        # 280 trials s was TRAINED on -- so the raw self-cell is leaky (reads ~0.92).
        # Show the clean fold-0 held-out number there instead.
        M = np.array([[rows[s][t] for t in common] for s in common], dtype=float)
        for i, s in enumerate(common):
            M[i, i] = diags[s]

        print("", flush=True)
        print("=== TRANSFER MATRIX (row = train on source, col = test on target) ===", flush=True)
        print("      " + "".join("%7d" % t for t in common), flush=True)
        for i, s in enumerate(common):
            print("src%02d" % s + "".join("%7.3f" % v for v in M[i]), flush=True)
        print("diagonal = that source's own fold-0 held-out 70 trials (clean; the all-350", flush=True)
        print("self-cell would be leaky because 280 of those 350 were trained on).", flush=True)

        offmask = ~np.eye(n, dtype=bool)
        off = M[offmask]
        print("", flush=True)
        print("off-diagonal (cross-subject)         : mean=%.4f std=%.4f n=%d"
              % (off.mean(), off.std(), off.size), flush=True)
        print("diagonal   (within-subject, fold 0)  : mean=%.4f n=%d   <- noisy, only 70 trials each"
              % (M.diagonal().mean(), n), flush=True)
        # authoritative within-subject number: the full 5-fold 350-trial baseline
        ref = []
        for s in common:
            f = "Results/FAST/%d-Tune.csv" % s
            if os.path.exists(f):
                d = np.loadtxt(f, delimiter=",", dtype=int)
                ref.append(float(np.mean(d[:, 0] == d[:, 1])))
        if ref:
            print("diagonal   (Results/FAST, 5-fold 350): mean=%.4f n=%d   <- authoritative"
                  % (np.mean(ref), len(ref)), flush=True)
        print("chance level = 0.20", flush=True)

        if n >= 2:
            print("off-diagonal MIN=%.4f MAX=%.4f" % (off.min(), off.max()), flush=True)
        if n >= 3:
            ab = M[offmask].reshape(n, n - 1)          # ab[i] = source i -> every other target
            ba = np.array([[M[j, i] for j in range(n) if j != i] for i in range(n)])
            r = np.corrcoef(ab.ravel(), ba.ravel())[0, 1]
            print("symmetry: corr(A->B, B->A) over %d ordered pairs = %.4f" % (ab.size, r), flush=True)
            print("per-source mean off-diag (who TRAVELS well): "
                  + " ".join("%d:%.3f" % (c, v) for c, v in zip(common, ab.mean(axis=1))), flush=True)
            tgtmean = np.array([M[offmask[:, j], j].mean() for j in range(n)])
            print("per-target mean off-diag (who is READABLE): "
                  + " ".join("%d:%.3f" % (c, v) for c, v in zip(common, tgtmean)), flush=True)
    print("TM_DONE", flush=True)
