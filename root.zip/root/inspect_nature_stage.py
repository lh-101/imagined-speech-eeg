from pathlib import Path
import json, urllib.request, xml.etree.ElementTree as ET, importlib.metadata

root=Path('/root/FAST/experiments/nature_stage_20261002')
root.mkdir(parents=True,exist_ok=True)
(root/'sources').mkdir(exist_ok=True)
for p in ['torch','numpy','scipy','scikit-learn','mne','matplotlib','pooch','decorator','packaging','lazy_loader','platformdirs','requests']:
    try: print('PACKAGE',p,importlib.metadata.version(p))
    except importlib.metadata.PackageNotFoundError: print('PACKAGE',p,'missing')
sources={
 'download_helper.py':'https://raw.githubusercontent.com/N-Nieto/Inner_Speech_Dataset/master/Python_Processing/lib/download_helper.py',
 'InnerSpeech_preprocessing.py':'https://raw.githubusercontent.com/N-Nieto/Inner_Speech_Dataset/master/InnerSpeech_preprocessing.py',
 'nieto2022.py':'https://raw.githubusercontent.com/NeuroTechX/moabb/develop/moabb/datasets/nieto2022.py',
}
for name,url in sources.items():
    try:
        data=urllib.request.urlopen(url,timeout=40).read()
        (root/'sources'/name).write_bytes(data)
        print('SOURCE',name,len(data))
    except Exception as e: print('SOURCE_ERROR',name,str(e))
url='https://s3.amazonaws.com/openneuro.org?list-type=2&prefix=ds003626/derivatives/sub-01/'
try:
    data=urllib.request.urlopen(url,timeout=40).read()
    (root/'sources'/'s3_listing.xml').write_bytes(data)
    r=ET.fromstring(data); ns={'s':'http://s3.amazonaws.com/doc/2006-03-01/'}
    files=[dict(key=e.findtext('s:Key',namespaces=ns),size=int(e.findtext('s:Size',namespaces=ns))) for e in r.findall('s:Contents',ns)]
    print('S3_FILES',json.dumps(files))
except Exception as e: print('S3_ERROR',str(e))
